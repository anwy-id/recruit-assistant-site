const STORAGE_KEY = "招聘速聊助手_settings";
/** 浏览器会话级配置（关闭浏览器后清空，不与岗位绑定） */
const SESSION_RUNTIME_KEY = "招聘速聊助手_session_runtime";
/** 岗位配置会话缓存（关浏览器清空；权威数据在宣双平台） */
const POSITIONS_SESSION_KEY = "招聘速聊助手_positions";
const AUTH_BASEURL_KEY = "招聘速聊助手_auth_base_url";

let isRunning = false;
let isAskResumeRunning = false;
let isResumeUploadRunning = false;
let dirty = false;
let ddOpen = false;
let pendingDelete = null;
let processedCount = 0;
/** 沟通页筛选为「全部职位」时：UI 锁定筛选条件，求简历不带岗位关键词 */
let isAllPositionsMode = false;
const ALL_POSITIONS_LABEL = "全部职位";
/** @type {{ username?: string, full_name?: string, department?: string } | null} */
let currentUser = null;
let isAuthenticated = false;
let mainAppInitialized = false;

/**
 * @typedef {{
 *   positions: Record<string, object>,
 *   activePosition: string|null,
 *   scrollDelayMin: number,
 *   scrollDelayMax: number,
 *   enableSound: boolean,
 *   analyzeImageBaseUrl: string,
 *   analyzeImageToken: string,
 *   matchLimit: number,
 *   resumeScript: string,
 *   rejectScript: string,
 * }} AppState
 */

/** @type {AppState} */
let state = {
  positions: {},
  activePosition: null,
  scrollDelayMin: 3,
  scrollDelayMax: 5,
  enableSound: true,
  analyzeImageBaseUrl: "https://upims.yili.com",
  analyzeImageToken: "",
  // 以下三项：不与岗位绑定，仅本次浏览器会话有效
  matchLimit: 200,
  resumeScript: "",
  rejectScript: "",
};

const $ = (id) => document.getElementById(id);

function escHtml(s) {
  const d = document.createElement("div");
  d.textContent = s;
  return d.innerHTML;
}

function defaultPositionData() {
  return {
    keywords: [],
    excludeKeywords: [],
  };
}

/** 内置默认话术（输入框灰色 placeholder；点「确定」且框空时采用） */
const DEFAULT_RESUME_SCRIPT = "您好，方便发一份简历过来吗？";
const DEFAULT_REJECT_SCRIPT =
  "您好，请您到伊利招聘官网投递简历，方便我们处理后续流程，感谢您的配合！";

function defaultSessionRuntime() {
  const d = window.招聘速聊助手_CONFIG?.DEFAULTS || {};
  return {
    matchLimit: d.matchLimit ?? 200,
    // 仅「确定」后写入；未确认前为空，运行时不使用
    resumeScript: "",
    rejectScript: "",
  };
}

function fillVersionLabel() {
  const v =
    (typeof chrome !== "undefined" &&
      chrome.runtime?.getManifest?.()?.version) ||
    window.招聘速聊助手_CONFIG?.VERSION ||
    "";
  if (!v) return;
  document.querySelectorAll(".hdr-sub").forEach((el) => {
    el.textContent = `版本 ${v}`;
  });
}

function defaultState() {
  const d = window.招聘速聊助手_CONFIG?.DEFAULTS || {};
  const api = window.招聘速聊助手_CONFIG?.ANALYZE_IMAGE_API || {};
  const session = defaultSessionRuntime();
  return {
    positions: {},
    activePosition: null,
    scrollDelayMin: d.scrollDelayMin ?? 3,
    scrollDelayMax: d.scrollDelayMax ?? 5,
    enableSound: d.enableSound !== false,
    runMode: "ai",
    analyzeImageBaseUrl:
      d.analyzeImageBaseUrl ||
      api.baseUrl ||
      "https://upims.yili.com",
    analyzeImageToken: d.analyzeImageToken || api.token || "",
    matchLimit: session.matchLimit,
    resumeScript: session.resumeScript,
    rejectScript: session.rejectScript,
  };
}

/** 从岗位对象上剥离会话级字段（上限/话术不再与岗位绑定） */
function stripPositionSessionFields(p = {}) {
  const next = { ...p };
  delete next.matchLimit;
  delete next.resumeScript;
  delete next.rejectScript;
  return next;
}

function migrateRawSettings(raw) {
  const base = { ...defaultState(), ...raw, runMode: "ai" };
  // 会话级字段不从 local 持久化读取，避免“关浏览器后仍带着旧话术”
  const sessionDefaults = defaultSessionRuntime();
  base.matchLimit = sessionDefaults.matchLimit;
  base.resumeScript = sessionDefaults.resumeScript;
  base.rejectScript = sessionDefaults.rejectScript;

  // 岗位配置不再从 local 读取（云端 + session）；忽略历史 local 岗位数据
  base.positions = {};
  base.activePosition = null;

  return base;
}

/**
 * 规范化岗位字典
 * @param {object} positions
 */
/** 岗位关键词列表深拷贝，避免多岗位共用同一数组引用 */
function cloneKeywordList(list) {
  if (!Array.isArray(list)) return [];
  return list.map((x) => String(x).trim()).filter(Boolean);
}

function normalizePositionsMap(positions) {
  const out = {};
  if (!positions || typeof positions !== "object") return out;
  for (const [name, conf] of Object.entries(positions)) {
    const n = String(name || "").trim();
    if (!n) continue;
    const p = stripPositionSessionFields(conf || {});
    // 必须拷贝数组：否则 push/splice 会串改所有岗位
    out[n] = {
      keywords: cloneKeywordList(p.keywords),
      excludeKeywords: cloneKeywordList(p.excludeKeywords),
    };
  }
  return out;
}

/**
 * 将云端/session 岗位应用到内存 state 并刷新 UI
 */
function applyPositionsToState(positions, activePosition) {
  state.positions = normalizePositionsMap(positions);
  let active = activePosition || null;
  if (active && !state.positions[active]) {
    active = Object.keys(state.positions)[0] || null;
  }
  if (!active && Object.keys(state.positions).length) {
    active = Object.keys(state.positions)[0];
  }
  state.activePosition = active;
  renderTrigger();
  if (state.activePosition) {
    showPanel(state.activePosition);
  } else {
    $("cond-panel")?.classList.add("hide");
  }
  updatePageButtons();
}

/** 岗位写入浏览器 session 缓存 */
async function persistPositionsSession() {
  if (!chrome.storage.session) return;
  const positions = {};
  for (const [name, conf] of Object.entries(state.positions || {})) {
    // 拷贝后再写入，避免 session structured clone 保留共享引用
    positions[name] = {
      keywords: cloneKeywordList(conf.keywords),
      excludeKeywords: cloneKeywordList(conf.excludeKeywords),
    };
  }
  try {
    await chrome.storage.session.set({
      [POSITIONS_SESSION_KEY]: {
        positions,
        activePosition: state.activePosition,
      },
    });
  } catch (error) {
    console.warn("写入岗位会话缓存失败:", error);
  }
}

/** 从 session 读取岗位（同浏览器会话内再次打开弹窗） */
async function loadPositionsFromSession() {
  try {
    if (!chrome.storage.session) return false;
    const stored = await chrome.storage.session.get([POSITIONS_SESSION_KEY]);
    const raw = stored[POSITIONS_SESSION_KEY];
    if (!raw || typeof raw !== "object") return false;
    // 有 key 即认为已拉取过（哪怕空配置）
    applyPositionsToState(raw.positions || {}, raw.activePosition || null);
    return true;
  } catch (error) {
    console.warn("读取岗位会话缓存失败:", error);
    return false;
  }
}

/**
 * 同步岗位到宣双平台（整包覆盖）
 * @param {{ silent?: boolean }} [opts]
 * @returns {Promise<boolean>}
 */
async function syncPositionsToCloud(opts = {}) {
  const positions = {};
  for (const [name, conf] of Object.entries(state.positions || {})) {
    positions[name] = {
      keywords: cloneKeywordList(conf.keywords),
      excludeKeywords: cloneKeywordList(conf.excludeKeywords),
    };
  }
  await persistPositionsSession();
  const result = await sendAuthMessage({
    type: "plugin_positions_save",
    positions,
    activePosition: state.activePosition,
  });
  if (!result?.success) {
    const msg = result?.error || "岗位同步到平台失败";
    if (!opts.silent) {
      toast(msg, "warn");
      addLog(escHtml(msg), "error");
    }
    return false;
  }
  return true;
}

/**
 * 登录后从平台拉取岗位；force=false 时优先 session
 * @param {{ force?: boolean }} [opts]
 */
async function loadPositionsFromCloud(opts = {}) {
  const force = opts.force !== false;
  if (!force) {
    const ok = await loadPositionsFromSession();
    if (ok) return true;
  }
  const result = await sendAuthMessage({
    type: "plugin_positions_load",
    force: true,
  });
  if (!result?.success) {
    // 拉取失败：尝试 session；仍失败则空列表
    const cached = await loadPositionsFromSession();
    if (!cached) {
      applyPositionsToState({}, null);
      const msg = result?.error || "拉取岗位配置失败";
      addLog(escHtml(msg), "warning");
    }
    return false;
  }
  applyPositionsToState(result.positions || {}, result.activePosition || null);
  await persistPositionsSession();
  return true;
}

/** 清除 local 中历史岗位字段，避免误读 */
async function stripLocalPositions() {
  try {
    const stored = await chrome.storage.local.get(STORAGE_KEY);
    const raw = stored[STORAGE_KEY];
    if (!raw || typeof raw !== "object") return;
    if (
      !raw.positions &&
      !raw.activePosition &&
      !raw.currentPosition &&
      !raw.keywords &&
      !raw.excludeKeywords
    ) {
      return;
    }
    const next = { ...raw };
    delete next.positions;
    delete next.activePosition;
    delete next.currentPosition;
    delete next.keywords;
    delete next.excludeKeywords;
    delete next.positionName;
    await chrome.storage.local.set({ [STORAGE_KEY]: next });
  } catch (error) {
    console.warn("清理本地岗位字段失败:", error);
  }
}

const MATCH_LIMIT_MIN = 1;
const MATCH_LIMIT_MAX = 200;

/**
 * 校验打招呼上限人数：必须是 1～200 的整数
 * @param {unknown} raw
 * @returns {{ ok: true, value: number } | { ok: false, message: string }}
 */
function validateMatchLimit(raw) {
  const text = String(raw ?? "").trim();
  if (!text) {
    return {
      ok: false,
      message: "请填写打招呼上限人数（须为 1～200 的整数）",
    };
  }
  // 仅纯数字整数：拒绝小数、负数、科学计数、中文等
  if (!/^\d+$/.test(text)) {
    return {
      ok: false,
      message: "打招呼上限人数须为 1～200 的整数",
    };
  }
  const n = Number(text);
  if (
    !Number.isInteger(n) ||
    n < MATCH_LIMIT_MIN ||
    n > MATCH_LIMIT_MAX
  ) {
    return {
      ok: false,
      message: "打招呼上限人数须为 1～200 的整数",
    };
  }
  return { ok: true, value: n };
}

function getMatchLimitInputRaw() {
  return String($("match-limit")?.value ?? "").trim();
}

/**
 * 输入框下方错误文案 + 红框
 * @param {string} [message]
 */
function setMatchLimitError(message) {
  const input = $("match-limit");
  const errEl = $("match-limit-error");
  const text = String(message || "").trim();
  if (input) {
    input.classList.toggle("inp-error", !!text);
  }
  if (errEl) {
    if (text) {
      errEl.textContent = text;
      errEl.hidden = false;
    } else {
      errEl.textContent = "";
      errEl.hidden = true;
    }
  }
}

/**
 * 规范化上限值到 1～200（用于会话恢复）
 * @param {unknown} value
 * @param {number} [fallback=200]
 */
function clampMatchLimit(value, fallback = 200) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  const i = Math.floor(n);
  if (i < MATCH_LIMIT_MIN || i > MATCH_LIMIT_MAX) return fallback;
  return i;
}

/**
 * 话术确认态标识：未确认 / 已确认 / 已修改待确认
 * @param {"resume"|"reject"} field
 */
function updateScriptConfirmUi(field) {
  const isResume = field === "resume";
  const ta = $(isResume ? "resume-script" : "reject-script");
  const statusEl = $(isResume ? "resume-script-status" : "reject-script-status");
  const btn = $(isResume ? "save-resume-script-btn" : "save-reject-script-btn");
  const confirmed = String(
    isResume ? state.resumeScript || "" : state.rejectScript || "",
  ).trim();
  const typed = String(ta?.value || "").trim();

  let mode = "pending"; // 未确认
  if (confirmed) {
    // 框空显示的是 placeholder，视为仍与已确认一致（会话恢复后）
    if (!typed || typed === confirmed) {
      mode = "confirmed";
    } else {
      mode = "dirty"; // 改过但未再点确定
    }
  }

  if (statusEl) {
    statusEl.classList.remove("is-pending", "is-confirmed", "is-dirty");
    if (mode === "confirmed") {
      statusEl.classList.add("is-confirmed");
      statusEl.textContent = "已确认";
    } else if (mode === "dirty") {
      statusEl.classList.add("is-dirty");
      statusEl.textContent = "已修改，请重新确定";
    } else {
      statusEl.classList.add("is-pending");
      statusEl.textContent = "未确认";
    }
  }

  if (ta) {
    ta.classList.toggle("ta-confirmed", mode === "confirmed");
  }
  if (btn) {
    btn.classList.toggle("btn-script-ok", mode === "confirmed");
    btn.textContent = mode === "confirmed" ? "已确定" : "确定";
  }
}

function refreshAllScriptConfirmUi() {
  updateScriptConfirmUi("resume");
  updateScriptConfirmUi("reject");
}

function fillSessionRuntimePanel() {
  if ($("match-limit")) {
    $("match-limit").value = clampMatchLimit(state.matchLimit, 200);
  }
  if ($("resume-script")) {
    $("resume-script").value = state.resumeScript || "";
  }
  if ($("reject-script")) {
    $("reject-script").value = state.rejectScript || "";
  }
  refreshAllScriptConfirmUi();
}

/**
 * 从面板同步「可自动读」的会话项。
 * 注意：求简历/拒简历话术仅在点「确定」时写入 state，此处不得用输入框覆盖。
 */
function readSessionRuntimeFromPanel() {
  const check = validateMatchLimit(getMatchLimitInputRaw());
  if (check.ok) {
    state.matchLimit = check.value;
  }
  // 非法时不改写 state.matchLimit，启动时再拦截
  return check;
}

/** 仅写入浏览器会话存储：关浏览器后自动清空 */
async function persistSessionRuntime() {
  // 上限：尽量同步输入框合法值；话术只用已确认的 state
  readSessionRuntimeFromPanel();
  const payload = {
    matchLimit: state.matchLimit,
    resumeScript: state.resumeScript || "",
    rejectScript: state.rejectScript || "",
  };
  try {
    if (chrome.storage.session) {
      await chrome.storage.session.set({ [SESSION_RUNTIME_KEY]: payload });
    }
  } catch (error) {
    console.warn("写入会话配置失败（将仅保留弹窗内存）:", error);
  }
}

async function loadSessionRuntime() {
  const defaults = defaultSessionRuntime();
  try {
    if (!chrome.storage.session) {
      state.matchLimit = defaults.matchLimit;
      state.resumeScript = defaults.resumeScript;
      state.rejectScript = defaults.rejectScript;
      return;
    }
    const stored = await chrome.storage.session.get([SESSION_RUNTIME_KEY]);
    const raw = stored[SESSION_RUNTIME_KEY] || {};
    state.matchLimit = clampMatchLimit(raw.matchLimit, defaults.matchLimit);
    state.resumeScript =
      typeof raw.resumeScript === "string" ? raw.resumeScript : "";
    state.rejectScript =
      typeof raw.rejectScript === "string" ? raw.rejectScript : "";
  } catch (error) {
    console.warn("读取会话配置失败:", error);
    state.matchLimit = defaults.matchLimit;
    state.resumeScript = defaults.resumeScript;
    state.rejectScript = defaults.rejectScript;
  }
}

function getActivePositionData() {
  if (!state.activePosition) return null;
  return state.positions[state.activePosition] || null;
}

function toast(message, type = "info") {
  const el = $("toast");
  el.textContent = message;
  el.className = `toast ${type}`;
  requestAnimationFrame(() => el.classList.add("show"));
  setTimeout(() => el.classList.remove("show"), 2200);
}

function logTypeMap(type) {
  if (type === "success") return { code: "s", label: "DONE" };
  if (type === "error") return { code: "e", label: "ERR" };
  if (type === "warning") return { code: "w", label: "WARN" };
  return { code: "i", label: "INFO" };
}

const RUNTIME_LOGS_KEY = "招聘速聊助手_runtime_logs";
const RUNTIME_LOGS_MAX = 800;
const LAST_RESUME_FILE_KEY = "招聘速聊助手_last_resume_file_capture";
let suppressLogPersist = false;
/** 弹窗侧进度日志去重（本轮汇总等） */
let lastProgressLogDedupe = { text: "", at: 0 };

function shouldDedupeProgressLog(plainText) {
  const text = String(plainText || "").trim();
  if (!text) return false;
  // 本轮汇总 / 扫描完成 / 已停止：短时间相同文案只显示一条
  if (
    !/^(本轮汇总|本轮扫描完成|回传本轮汇总|回传本轮扫描完成|已停止打招呼|已停止求简历|已停止简历回传|已停止自动滚动)/.test(
      text,
    )
  ) {
    return false;
  }
  const now = Date.now();
  if (
    lastProgressLogDedupe.text === text &&
    now - lastProgressLogDedupe.at < 4000
  ) {
    return true;
  }
  lastProgressLogDedupe = { text, at: now };
  return false;
}

function formatLogTime(isoOrDate) {
  try {
    const d = isoOrDate ? new Date(isoOrDate) : new Date();
    return d.toLocaleTimeString("zh-CN", { hour12: false });
  } catch {
    return new Date().toLocaleTimeString("zh-CN", { hour12: false });
  }
}

function isStatusRuntimeLog(message) {
  const t = String(message || "")
    .replace(/<[^>]+>/g, "")
    .trim();
  return (
    /^已经触达/.test(t) ||
    /^已跳过/.test(t) ||
    /^已打招呼\s*\d+\s*人/.test(t) ||
    /^已求简历\s*\d+\s*人/.test(t) ||
    /^已简历回传\s*\d+\s*人/.test(t) ||
    /^日志已清空/.test(t)
  );
}

function addLog(message, type = "info", options = {}) {
  const body = $("log-body");
  if (!body) return;
  const verbose =
    window.招聘速聊助手_CONFIG?.VERBOSE_RUNTIME_LOGS !== false;
  if (
    !verbose &&
    !options.skipStatusFilter &&
    type !== "error" &&
    !isStatusRuntimeLog(message)
  ) {
    return;
  }

  const plainForDedupe = String(message)
    .replace(/<[^>]+>/g, "")
    .trim();
  if (!options.skipDedupe && shouldDedupeProgressLog(plainForDedupe)) {
    return;
  }

  const { code, label } = logTypeMap(type);
  const line = document.createElement("div");
  line.className = "ll";
  const time = formatLogTime(options.time);
  // message 可能已是转义后的 HTML
  line.innerHTML = `<span class="lt">${time}</span><span class="lg ${code}">${label}</span><span class="lm">${message}</span>`;
  body.appendChild(line);
  scrollLog();

  // 弹窗内操作产生的日志也落盘（content 日志由 background 落盘）
  if (!options.skipPersist && !suppressLogPersist) {
    const plain = plainForDedupe;
    if (plain) {
      chrome.storage.local.get([RUNTIME_LOGS_KEY], (stored) => {
        const list = Array.isArray(stored[RUNTIME_LOGS_KEY])
          ? stored[RUNTIME_LOGS_KEY]
          : [];
        // 落盘也去重：避免 storage 里堆多条相同「本轮汇总」
        const last = list[list.length - 1];
        if (
          last &&
          last.message === plain &&
          Date.now() - new Date(last.time || 0).getTime() < 4000
        ) {
          return;
        }
        list.push({
          time: new Date().toISOString(),
          message: plain,
          type: type || "info",
        });
        while (list.length > RUNTIME_LOGS_MAX) list.shift();
        chrome.storage.local.set({ [RUNTIME_LOGS_KEY]: list });
      });
    }
  }
}

function scrollLog() {
  const body = $("log-body");
  if (body) body.scrollTop = body.scrollHeight;
}

function clearLog() {
  $("log-body").innerHTML = "";
  chrome.storage.local.set({ [RUNTIME_LOGS_KEY]: [] }, () => {
    addLog("日志已清空", "info");
  });
}

/** 从本地恢复历史日志（重新打开弹窗仍能看） */
async function restoreRuntimeLogs() {
  const stored = await chrome.storage.local.get([
    RUNTIME_LOGS_KEY,
    LAST_RESUME_FILE_KEY,
  ]);
  const list = Array.isArray(stored[RUNTIME_LOGS_KEY])
    ? stored[RUNTIME_LOGS_KEY]
    : [];
  const body = $("log-body");
  if (body) body.innerHTML = "";

  suppressLogPersist = true;
  if (list.length === 0) {
    addLog("暂无历史日志（运行后会自动保存，关掉弹窗也不丢）", "info", {
      skipPersist: true,
    });
  } else {
    const slice = list.slice(-200);
    for (const entry of slice) {
      addLog(escHtml(entry.message || ""), entry.type || "info", {
        skipPersist: true,
        time: entry.time,
      });
    }
    addLog(
      `已恢复最近 <span class="lh">${slice.length}</span> 条日志（共 ${list.length} 条）`,
      "info",
      { skipPersist: true },
    );
  }

  const last = stored[LAST_RESUME_FILE_KEY];
  if (last?.savedAt) {
    if (last.ok) {
      const hints = [];
      if (last.base64TxtPath) {
        hints.push(
          `base64 文本：下载夹/<span class="lh">${escHtml(last.base64TxtPath)}</span>（长度 ${last.base64Length || "?"}）`,
        );
      } else if (last.base64Length) {
        hints.push(`base64 长度 ${last.base64Length}（未导出 txt）`);
      }
      if (last.exportPath) {
        hints.push(
          `原文件：下载夹/<span class="lh">${escHtml(last.exportPath)}</span>`,
        );
      }
      if (!hints.length) {
        hints.push("已写入插件本地数据库");
      }
      addLog(
        `最近一次简历拦截成功：${escHtml(last.name || "")} / ${escHtml(last.filename || "")}（${last.size || 0} 字节）。${hints.join("；")}`,
        "success",
        { skipPersist: true },
      );
    } else {
      addLog(
        `最近一次简历下载失败：${escHtml(last.message || "未知")}`,
        "error",
        { skipPersist: true },
      );
    }
  }
  suppressLogPersist = false;
}

function markDirty() {
  dirty = true;
  const stat = $("cond-status");
  stat.textContent = "未保存";
  stat.className = "cstat dirty";
}

function markClean() {
  dirty = false;
  const stat = $("cond-status");
  stat.textContent = "已保存";
  stat.className = "cstat ok";
}

function isBossPage(url = "") {
  return /zhipin\.com/i.test(String(url || ""));
}

function isRecommendPage(url = "") {
  return isBossPage(url) && url.includes("/web/chat/recommend");
}

/** 沟通页：仅 /web/chat/index（求简历、简历回传） */
function isChatPage(url = "") {
  return isBossPage(url) && /\/web\/chat\/index(?:[/?#]|$)/i.test(String(url || ""));
}

function updateStatusBar() {
  const hdr = $("hdr-stat");
  const footer = $("footer-status");

  if (isAskResumeRunning) {
    hdr.classList.remove("idle");
    footer.classList.remove("idle");
    $("hdr-status-text").textContent = "求简历运行中";
    $("footer-status-text").textContent = "会话扫描中";
    return;
  }

  if (isResumeUploadRunning) {
    hdr.classList.remove("idle");
    footer.classList.remove("idle");
    $("hdr-status-text").textContent = "简历回传中";
    $("footer-status-text").textContent = "处理附件中（稍后回传大易）";
    return;
  }

  if (isRunning) {
    hdr.classList.remove("idle");
    footer.classList.remove("idle");
    $("hdr-status-text").textContent = "运行中";
    $("footer-status-text").textContent = "实时监控中";
    return;
  }

  hdr.classList.add("idle");
  footer.classList.add("idle");
  $("hdr-status-text").textContent = "就绪";
  $("footer-status-text").textContent = "待机中";
}

/**
 * 统一设置操作按钮：可用 / 置灰
 * @param {HTMLElement|null} el
 * @param {{ enabled: boolean, title?: string }} opts
 */
function setActionButton(el, { enabled, title = "" }) {
  if (!el) return;
  el.disabled = !enabled;
  el.classList.toggle("btn-muted", !enabled);
  el.title = title || "";
}

/**
 * 按当前标签页控制按钮：
 * - 一键打招呼：仅「推荐牛人」页可点
 * - 一键求简历 / 一键简历回传：仅「沟通」页可点
 * - 停止类按钮：任务运行中可点（便于跨页停止）
 */
async function updatePageButtons() {
  let url = "";
  try {
    const tab = await getActiveTab();
    url = tab?.url || "";
  } catch (_) {
    url = "";
  }

  const onRecommend = isRecommendPage(url);
  const onChat = isChatPage(url);
  // 全部职位模式也可点求简历；打招呼仍需具体岗位
  const hasPosition = !!state.activePosition || isAllPositionsMode;

  const startBtn = $("start-btn");
  const stopBtn = $("stop-btn");
  const askBtn = $("ask-resume-btn");
  const stopAskBtn = $("stop-ask-btn");
  const uploadBtn = $("resume-upload-btn");
  const stopUploadBtn = $("stop-resume-upload-btn");

  // —— 一键打招呼：仅推荐牛人页 ——
  if (onRecommend) {
    if (isAskResumeRunning) {
      setActionButton(startBtn, {
        enabled: false,
        title: "请先停止求简历",
      });
    } else if (isResumeUploadRunning) {
      setActionButton(startBtn, {
        enabled: false,
        title: "请先停止简历回传",
      });
    } else if (!hasPosition) {
      setActionButton(startBtn, {
        enabled: false,
        title: "请先选择职位",
      });
    } else if (isRunning) {
      setActionButton(startBtn, {
        enabled: false,
        title: "打招呼进行中",
      });
    } else {
      setActionButton(startBtn, { enabled: true, title: "" });
    }
  } else {
    setActionButton(startBtn, {
      enabled: false,
      title: onChat
        ? "一键打招呼仅可在推荐牛人页面使用"
        : isBossPage(url)
          ? "请进入推荐牛人页面"
          : "请先打开 Boss 直聘推荐牛人页面",
    });
  }

  // 停止打招呼：运行中可停
  setActionButton(stopBtn, {
    enabled: isRunning,
    title: isRunning ? "" : "当前没有运行中的打招呼任务",
  });

  // —— 一键求简历：仅沟通页（启动时会从页面同步职位，不强制先选手动岗位）——
  if (onChat) {
    if (isRunning) {
      setActionButton(askBtn, {
        enabled: false,
        title: "请先停止打招呼",
      });
    } else if (isResumeUploadRunning) {
      setActionButton(askBtn, {
        enabled: false,
        title: "请先停止简历回传",
      });
    } else if (isAskResumeRunning) {
      setActionButton(askBtn, {
        enabled: false,
        title: "求简历进行中",
      });
    } else {
      setActionButton(askBtn, {
        enabled: true,
        title: "将按沟通页当前筛选职位同步岗位后启动",
      });
    }
  } else {
    setActionButton(askBtn, {
      enabled: false,
      title: "一键求简历仅可在沟通页面使用（zhipin.com/web/chat/index）",
    });
  }

  // 停止求简历：运行中可停
  setActionButton(stopAskBtn, {
    enabled: isAskResumeRunning,
    title: isAskResumeRunning ? "" : "当前没有运行中的求简历任务",
  });

  // —— 一键简历回传：仅沟通页（不强制选岗位）——
  if (onChat) {
    if (isRunning) {
      setActionButton(uploadBtn, {
        enabled: false,
        title: "请先停止打招呼",
      });
    } else if (isAskResumeRunning) {
      setActionButton(uploadBtn, {
        enabled: false,
        title: "请先停止求简历",
      });
    } else if (isResumeUploadRunning) {
      setActionButton(uploadBtn, {
        enabled: false,
        title: "简历回传进行中",
      });
    } else {
      setActionButton(uploadBtn, {
        enabled: true,
        title: "仅处理聊天中已有附件简历；稍后简历将回传大易",
      });
    }
  } else {
    setActionButton(uploadBtn, {
      enabled: false,
      title: "一键简历回传仅可在沟通页面使用（zhipin.com/web/chat/index）",
    });
  }

  // 停止回传：运行中可停
  setActionButton(stopUploadBtn, {
    enabled: isResumeUploadRunning,
    title: isResumeUploadRunning ? "" : "当前没有运行中的回传任务",
  });
}

function setRunningState(running) {
  isRunning = running;
  updateStatusBar();
  updatePageButtons();
}

function setAskResumeRunningState(running) {
  isAskResumeRunning = running;
  updateStatusBar();
  updatePageButtons();
}

function setResumeUploadRunningState(running) {
  isResumeUploadRunning = running;
  updateStatusBar();
  updatePageButtons();
}

function setProcessedCount(count) {
  processedCount = count;
  $("processed-count").textContent = String(count);
}

function renderTrigger() {
  const el = $("sel-text");
  const wrap = $("sel-wrap");
  if (isAllPositionsMode) {
    el.textContent = ALL_POSITIONS_LABEL;
    wrap?.classList.add("is-all-positions");
    el.title = "当前为筛选全部职位，筛选条件及黑名单关键词使用对应职位内容";
    return;
  }
  wrap?.classList.remove("is-all-positions");
  if (state.activePosition && state.positions[state.activePosition]) {
    el.textContent = state.activePosition;
  } else {
    el.innerHTML = '<span class="t-ph">请选择职位</span>';
  }
}

/**
 * 全部职位模式：展示提示并锁定筛选条件面板
 * @param {boolean} locked
 */
function setFilterConditionsLocked(locked) {
  const panel = $("cond-panel");
  const banner = $("all-pos-banner");
  banner?.classList.toggle("show", !!locked);
  if (!panel) return;
  panel.classList.toggle("is-locked", !!locked);
  panel.querySelectorAll("input, button, textarea").forEach((el) => {
    if (locked) {
      el.setAttribute("disabled", "disabled");
    } else {
      el.removeAttribute("disabled");
    }
  });
}

/**
 * 进入 / 退出「全部职位」展示模式
 * @param {boolean} on
 */
function setAllPositionsMode(on) {
  isAllPositionsMode = !!on;
  renderTrigger();
  const panel = $("cond-panel");
  if (isAllPositionsMode) {
    // 仍展示条件区，但置灰且不可改；气泡清空展示
    panel?.classList.remove("hide");
    renderBubbles("filter", []);
    renderBubbles("black", []);
    setFilterConditionsLocked(true);
    const stat = $("cond-status");
    if (stat) {
      stat.textContent = "全部职位";
      stat.className = "cstat dirty";
    }
  } else {
    setFilterConditionsLocked(false);
    if (state.activePosition && state.positions[state.activePosition]) {
      showPanel(state.activePosition);
    } else {
      panel?.classList.add("hide");
    }
  }
  updatePageButtons();
}

/**
 * 用沟通页职位文案匹配插件岗位名
 * @param {string} pageText
 * @returns {string} 命中的岗位名，未命中空串
 */
function matchPositionNameByPageText(pageText) {
  const pageNorm = String(pageText || "")
    .replace(/\s+/g, " ")
    .trim();
  if (!pageNorm) return "";
  const names = Object.keys(state.positions || {}).filter(Boolean);
  if (!names.length) return "";

  const norm = (s) => String(s || "").replace(/\s+/g, " ").trim();
  let hit = names.find((n) => norm(n) === pageNorm) || "";
  if (hit) return hit;

  const scored = names
    .map((n) => {
      const nn = norm(n);
      if (!nn) return null;
      const pageHasJob = pageNorm.includes(nn);
      const jobHasPage = nn.includes(pageNorm) && pageNorm.length >= 2;
      if (!pageHasJob && !jobHasPage) return null;
      return { name: n, score: nn.length + (pageHasJob ? 100 : 0) };
    })
    .filter(Boolean)
    .sort((a, b) => b.score - a.score);
  return scored[0]?.name || "";
}

/**
 * 根据沟通页筛选职位文案，切换弹窗「当前岗位选择」
 * @param {string} pageText
 * @returns {{ ok: boolean, mode: "all"|"position", positionName?: string, message?: string }}
 */
function applyChatFilterPositionToUi(pageText) {
  const text = String(pageText || "")
    .replace(/\s+/g, " ")
    .trim();
  if (!text) {
    return {
      ok: false,
      mode: "position",
      message: "未读到沟通页当前筛选职位，请确认页面已加载完成",
    };
  }

  // 「全部职位」：锁定筛选
  if (text === ALL_POSITIONS_LABEL || /全部职位/.test(text)) {
    setAllPositionsMode(true);
    return { ok: true, mode: "all", positionName: ALL_POSITIONS_LABEL };
  }

  const hit = matchPositionNameByPageText(text);
  if (!hit) {
    setAllPositionsMode(false);
    return {
      ok: false,
      mode: "position",
      message: `沟通页职位「${text}」未匹配到插件岗位列表，请先在弹窗新增/同步同名岗位`,
    };
  }

  setAllPositionsMode(false);
  state.activePosition = hit;
  dirty = false;
  renderTrigger();
  showPanel(hit);
  // 会话缓存当前激活岗（不强制写云端，避免误覆盖）
  persistPositionsSession().catch(() => {});
  return { ok: true, mode: "position", positionName: hit };
}

function renderPositionList() {
  const names = Object.keys(state.positions);
  const list = $("sel-list");
  list.innerHTML = "";
  if (!names.length) {
    list.innerHTML = '<div class="sel-empty">暂无职位，请点击下方新增</div>';
    return;
  }
  for (const name of names) {
    const opt = document.createElement("div");
    opt.className = `sel-opt${name === state.activePosition ? " active" : ""}`;
    const label = document.createElement("span");
    label.textContent = name;
    const del = document.createElement("button");
    del.className = "od";
    del.type = "button";
    del.title = "删除";
    del.textContent = "×";
    del.addEventListener("click", (e) => {
      e.stopPropagation();
      askDelete(name);
    });
    opt.appendChild(label);
    opt.appendChild(del);
    opt.addEventListener("click", () => pickPosition(name));
    list.appendChild(opt);
  }
}

function openDropdown() {
  renderPositionList();
  ddOpen = true;
  $("sel-trigger").classList.add("open");
  $("sel-dd").classList.add("open");
}

function closeDropdown() {
  ddOpen = false;
  $("sel-trigger").classList.remove("open");
  $("sel-dd").classList.remove("open");
}

function toggleDropdown() {
  if (ddOpen) closeDropdown();
  else openDropdown();
}

function showPanel(name) {
  const panel = $("cond-panel");
  if (!name || !state.positions[name]) {
    panel.classList.add("hide");
    return;
  }
  panel.classList.remove("hide");
  const data = state.positions[name];
  renderBubbles("filter", data.keywords);
  renderBubbles("black", data.excludeKeywords);
  // 上限/话术与岗位无关，始终用会话级 state
  fillSessionRuntimePanel();
  markClean();
}

async function pickPosition(name) {
  if (dirty && !confirm("当前岗位有未保存的修改，是否放弃？")) return;
  setAllPositionsMode(false);
  state.activePosition = name;
  closeDropdown();
  renderTrigger();
  showPanel(name);
  await persistSettings();
  await syncPositionsToCloud({ silent: true });
  updatePageButtons();
  toast(`已切换至「${name}」`, "info");
  addLog(`切换岗位：<span class="lh">${escHtml(name)}</span>`, "info");
}

function showAddRow() {
  closeDropdown();
  $("add-row").classList.add("show");
  $("new-position-inp").value = "";
  setTimeout(() => $("new-position-inp").focus(), 50);
}

function hideAddRow() {
  $("add-row").classList.remove("show");
  $("new-position-inp").value = "";
}

async function confirmAddPosition() {
  const value = $("new-position-inp").value.trim();
  if (!value) {
    toast("请输入职位名称", "warn");
    $("new-position-inp").focus();
    return;
  }
  if (state.positions[value]) {
    toast("该职位已存在", "warn");
    return;
  }
  state.positions[value] = defaultPositionData();
  state.activePosition = value;
  hideAddRow();
  renderTrigger();
  showPanel(value);
  await persistSettings();
  const ok = await syncPositionsToCloud();
  if (ok) {
    toast(`职位「${value}」已添加并同步`, "success");
    addLog(`新增职位：<span class="lh">${escHtml(value)}</span>`, "success");
  } else {
    toast(`职位「${value}」已添加（同步失败，请稍后重试保存）`, "warn");
    addLog(
      `新增职位：<span class="lh">${escHtml(value)}</span>（平台同步失败）`,
      "warning",
    );
  }
}

function askDelete(name) {
  pendingDelete = name;
  $("modal-msg").innerHTML = `确定要删除职位 <strong>「${escHtml(name)}」</strong> 吗？<br>该岗位的所有筛选条件将一并删除，此操作不可恢复。`;
  $("modal-bg").classList.add("show");
}

function closeModal() {
  $("modal-bg").classList.remove("show");
  pendingDelete = null;
}

async function doDelete() {
  if (!pendingDelete) return;
  const name = pendingDelete;
  delete state.positions[name];
  if (state.activePosition === name) {
    const names = Object.keys(state.positions);
    state.activePosition = names[0] || null;
  }
  closeModal();
  renderTrigger();
  if (ddOpen) renderPositionList();
  if (state.activePosition) showPanel(state.activePosition);
  else $("cond-panel").classList.add("hide");
  await persistSettings();
  const ok = await syncPositionsToCloud();
  if (ok) {
    toast(`职位「${name}」已删除`, "info");
    addLog(`已删除职位：<span class="lh">${escHtml(name)}</span>`, "warning");
  } else {
    toast(`职位「${name}」已删除（同步失败）`, "warn");
    addLog(
      `已删除职位：<span class="lh">${escHtml(name)}</span>（平台同步失败）`,
      "warning",
    );
  }
}

function renderBubbles(type, tags) {
  const isFilter = type === "filter";
  const area = $(isFilter ? "filter-bubbles" : "black-bubbles");
  const countEl = $(isFilter ? "filter-count" : "black-count");
  const cls = isFilter ? "filter" : "black";

  area.className = tags.length ? "bubble-area has-tags" : "bubble-area";
  area.innerHTML = tags
    .map(
      (tag, i) =>
        `<span class="bubble ${cls}">
          <span title="${escHtml(tag)}">${escHtml(tag)}</span>
          <button class="b-del" type="button" data-type="${type}" data-index="${i}" title="删除">×</button>
        </span>`,
    )
    .join("");

  countEl.textContent = String(tags.length);

  area.querySelectorAll(".b-del").forEach((btn) => {
    btn.addEventListener("click", () => {
      removeTag(btn.dataset.type, Number(btn.dataset.index));
    });
  });
}

function removeTag(type, index) {
  const data = getActivePositionData();
  if (!data) return;
  const key = type === "filter" ? "keywords" : "excludeKeywords";
  const list = Array.isArray(data[key]) ? data[key] : [];
  // 写时拷贝：打断与其他岗位可能存在的数组共享
  data[key] = list.filter((_, i) => i !== index);
  renderBubbles(type, data[key]);
  markDirty();
}

function onTagKey(e, type) {
  const isFilter = type === "filter";
  const inp = $(isFilter ? "filter-inp" : "black-inp");
  const key = isFilter ? "keywords" : "excludeKeywords";
  const data = getActivePositionData();
  if (!data) return;

  if (e.key === "Enter") {
    e.preventDefault();
    const value = inp.value.trim();
    if (!value) return;
    const list = Array.isArray(data[key]) ? data[key] : [];
    if (list.includes(value)) {
      toast("该条件已存在", "warn");
      inp.value = "";
      return;
    }
    data[key] = [...list, value];
    inp.value = "";
    renderBubbles(type, data[key]);
    markDirty();
  }

  if (e.key === "Backspace" && !inp.value) {
    const list = Array.isArray(data[key]) ? data[key] : [];
    if (!list.length) return;
    data[key] = list.slice(0, -1);
    renderBubbles(type, data[key]);
    markDirty();
  }
}

function focusTagInput(id) {
  setTimeout(() => $(id)?.focus(), 50);
}

function readPanelToState() {
  // 岗位面板只负责关键词；上限/话术走会话级
  readSessionRuntimeFromPanel();
}

function readApiPanelToState() {
  const tokenEl = $("analyze-image-token");
  if (tokenEl) {
    state.analyzeImageToken = tokenEl.value.trim();
  }
  // 地址已固定为生产地址，不再从输入读取
  state.analyzeImageBaseUrl = "https://upims.yili.com";
}

function fillApiPanelFromState() {
  const tokenEl = $("analyze-image-token");
  if (tokenEl) {
    tokenEl.value = state.analyzeImageToken || "";
  }
  // 地址已固定为生产地址
}

async function persistSettings() {
  readPanelToState();
  readApiPanelToState();

  // local 不再保存岗位；岗位仅 session + 宣双平台
  const payload = {
    runMode: "ai",
    scrollDelayMin: state.scrollDelayMin,
    scrollDelayMax: state.scrollDelayMax,
    enableSound: state.enableSound,
    analyzeImageBaseUrl: state.analyzeImageBaseUrl,
    analyzeImageToken: state.analyzeImageToken,
  };
  await chrome.storage.local.set({ [STORAGE_KEY]: payload });
  // 会话级：上限/话术
  await persistSessionRuntime();
  // 岗位会话缓存（不代替云端同步）
  await persistPositionsSession();
}

async function saveApiConfig() {
  // 已移除接口地址输入，不再保存
  toast("接口地址已固定为生产环境", "info");
  // 仍然更新 token
  readApiPanelToState();
  await persistSettings();
}

async function saveConditions() {
  if (!state.activePosition || !state.positions[state.activePosition]) {
    toast("请先选择职位", "warn");
    return;
  }
  readPanelToState();
  await persistSettings();
  const ok = await syncPositionsToCloud();
  markClean();
  const data = state.positions[state.activePosition];
  if (ok) {
    toast(`「${state.activePosition}」筛选条件已保存`, "success");
    const parts = [];
    if (data.keywords.length) parts.push(`筛选:[${data.keywords.join(",")}]`);
    if (data.excludeKeywords.length)
      parts.push(`黑名单:[${data.excludeKeywords.join(",")}]`);
    addLog(
      `职位 [${escHtml(state.activePosition)}] 条件已同步到平台：<span class="lh">${escHtml(parts.join(" ") || "（空）")}</span>`,
      "success",
    );
  }
}

function resetConditions() {
  const data = getActivePositionData();
  if (!data) return;
  // 新空数组，避免与其他岗位共享
  data.keywords = [];
  data.excludeKeywords = [];
  renderBubbles("filter", []);
  renderBubbles("black", []);
  markDirty();
}

async function loadSettings() {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  state = migrateRawSettings(stored[STORAGE_KEY] || {});
  const d = defaultState();
  if (!state.analyzeImageBaseUrl) {
    state.analyzeImageBaseUrl = d.analyzeImageBaseUrl;
  }
  if (state.analyzeImageToken == null) {
    state.analyzeImageToken = d.analyzeImageToken;
  }
  // 上限/话术：仅从浏览器会话读取（关浏览器后为空，需重配）
  await loadSessionRuntime();
  // 岗位：不从 local 恢复；由登录后 loadPositionsFromCloud 填充
  renderTrigger();
  fillApiPanelFromState();
  fillSessionRuntimePanel();
  // 清理历史 local 岗位字段
  await stripLocalPositions();
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function sendToContent(action, data, options = {}) {
  const tab = await getActiveTab();
  if (!tab?.id) throw new Error("未找到当前标签页");
  const url = tab.url || "";
  if (!url.includes("zhipin.com")) {
    throw new Error("请先打开 Boss 直聘页面");
  }
  if (options.requireRecommendPage && !isRecommendPage(url)) {
    throw new Error("请先进入 Boss 直聘推荐牛人页面");
  }
  if (options.requireChatPage && !isChatPage(url)) {
    throw new Error(
      "请先进入 Boss 直聘沟通页面（https://www.zhipin.com/web/chat/index）",
    );
  }
  let response;
  try {
    response = await chrome.tabs.sendMessage(tab.id, { action, data });
  } catch (err) {
    const msg = err?.message || String(err);
    if (
      /Receiving end does not exist|Could not establish connection/i.test(msg)
    ) {
      throw new Error(
        "页面脚本未加载，请刷新当前 Boss 页面后重新点击（扩展更新后必须刷新页面）",
      );
    }
    throw new Error(msg || "与页面通信失败");
  }
  if (response?.status === "error") {
    throw new Error(response.message || "操作失败");
  }
  return response;
}

async function ensureLoggedIn() {
  if (isAuthenticated) return true;
  toast("请先登录后再操作", "warn");
  showLoginView();
  return false;
}

async function startRun() {
  if (!(await ensureLoggedIn())) return;
  if (dirty) {
    toast("请先保存筛选条件", "warn");
    return;
  }
  if (!state.activePosition) {
    toast("请先选择或新增职位", "warn");
    return;
  }
  if (isAskResumeRunning) {
    toast("一键求简历正在运行中，请先停止", "warn");
    return;
  }
  if (isResumeUploadRunning) {
    toast("一键简历回传正在运行中，请先停止", "warn");
    return;
  }

  // 上限合法性以「失焦校验」为准；启动时仅静默拦截，不再单独弹启动提示
  const limitCheck = validateMatchLimit(getMatchLimitInputRaw());
  if (!limitCheck.ok) {
    setMatchLimitError(`无法开启打招呼：${limitCheck.message}`);
    $("match-limit")?.focus();
    return;
  }
  state.matchLimit = limitCheck.value;
  setMatchLimitError("");

  readSessionRuntimeFromPanel();
  await persistSettings();
  const pos = state.positions[state.activePosition];

  try {
    await sendToContent(
      "START_AI_SCROLL",
      {
      matchLimit: state.matchLimit,
      scrollDelayMin: state.scrollDelayMin,
      scrollDelayMax: state.scrollDelayMax,
      enableSound: state.enableSound,
      communicationEnabled: false,
      communicationConfig: window.招聘速聊助手_CONFIG?.COMMUNICATION_CONFIG || {},
      positionName: state.activePosition,
      keywords: pos.keywords,
      excludeKeywords: pos.excludeKeywords,
      resumeScript: state.resumeScript,
      rejectScript: state.rejectScript,
      },
      { requireRecommendPage: true },
    );
    addLog("已启动打招呼", "success");
    setRunningState(true);
    await chrome.storage.local.set({ isRunning: true });
    toast("已开始一键打招呼", "success");
  } catch (err) {
    addLog(err.message || String(err), "error");
    toast(err.message || "启动失败", "warn");
  }
}

async function stopRun() {
  // 先写 storage：所有 frame 的 content script 会立刻收到停止（比 sendMessage 更可靠）
  setRunningState(false);
  await chrome.storage.local.set({ isRunning: false });
  try {
    await sendToContent("STOP_SCROLL", {});
    addLog("已停止打招呼", "info");
    toast("已停止", "info");
  } catch (err) {
    addLog(`已发送停止（页面通信：${err.message || err}）`, "warning");
    toast("已停止", "info");
  }
}

async function startAskResume() {
  if (!(await ensureLoggedIn())) return;
  if (isRunning) {
    toast("一键打招呼正在运行中，请先停止", "warn");
    return;
  }
  if (isResumeUploadRunning) {
    toast("一键简历回传正在运行中，请先停止", "warn");
    return;
  }
  if (isAskResumeRunning) {
    toast("求简历任务已在运行", "warn");
    return;
  }

  readSessionRuntimeFromPanel();
  await persistSettings();

  // 1) 先抓取沟通页当前筛选职位，同步到「当前岗位选择」
  let pagePositionText = "";
  try {
    const posResp = await sendToContent(
      "GET_CHAT_FILTER_POSITION",
      {},
      { requireChatPage: true },
    );
    pagePositionText = String(posResp?.positionText || "").trim();
  } catch (err) {
    addLog(err.message || String(err), "error");
    toast(err.message || "读取沟通页职位失败", "warn");
    return;
  }

  const applied = applyChatFilterPositionToUi(pagePositionText);
  if (!applied.ok) {
    toast(applied.message || "无法同步沟通页职位", "warn");
    addLog(escHtml(applied.message || "无法同步沟通页职位"), "error");
    return;
  }

  let positionName = "";
  let keywords = [];
  let excludeKeywords = [];

  if (applied.mode === "all") {
    positionName = ALL_POSITIONS_LABEL;
    keywords = [];
    excludeKeywords = [];
    addLog(
      "沟通页为「全部职位」：已切换岗位展示为全部职位，筛选条件已锁定（当前筛选全部职位）",
      "warning",
    );
    toast("当前要筛选全部职位，筛选条件已锁定", "info");
  } else {
    positionName = applied.positionName || "";
    const pos = state.positions[positionName];
    if (!pos) {
      toast("岗位数据异常，请重新选择职位", "warn");
      return;
    }
    keywords = cloneKeywordList(pos.keywords);
    excludeKeywords = cloneKeywordList(pos.excludeKeywords);
    addLog(
      `已按沟通页职位同步岗位：<span class="lh">${escHtml(pagePositionText)}</span> → <span class="lh">${escHtml(positionName)}</span>`,
      "success",
    );
  }

  try {
    await sendToContent(
      "START_ASK_RESUME",
      {
        positionName,
        keywords,
        excludeKeywords,
        resumeScript: state.resumeScript,
        rejectScript: state.rejectScript,
        pagePositionText,
        isAllPositions: applied.mode === "all",
      },
      { requireChatPage: true },
    );
    setAskResumeRunningState(true);
    await chrome.storage.local.set({ isAskResumeRunning: true });
    addLog("已启动求简历", "success");
    toast(
      applied.mode === "all"
        ? "已开始一键求简历（全部职位）"
        : `已开始一键求简历（${positionName}）`,
      "success",
    );
  } catch (err) {
    addLog(err.message || String(err), "error");
    toast(err.message || "启动失败", "warn");
  }
}

async function startResumeUpload() {
  if (!(await ensureLoggedIn())) return;
  if (isRunning) {
    toast("一键打招呼正在运行中，请先停止", "warn");
    return;
  }
  if (isAskResumeRunning) {
    toast("一键求简历正在运行中，请先停止", "warn");
    return;
  }
  if (isResumeUploadRunning) {
    toast("简历回传任务已在运行", "warn");
    return;
  }

  try {
    await sendToContent(
      "START_RESUME_UPLOAD",
      {},
      { requireChatPage: true },
    );
    setResumeUploadRunningState(true);
    await chrome.storage.local.set({ isResumeUploadRunning: true });
    addLog("已启动简历回传", "success");
    toast("已开始一键简历回传", "success");
  } catch (err) {
    addLog(err.message || String(err), "error");
    toast(err.message || "启动失败", "warn");
  }
}

async function stopResumeUpload() {
  try {
    await chrome.storage.local.set({ isResumeUploadRunning: false });
  } catch {
    /* ignore */
  }
  setResumeUploadRunningState(false);
  try {
    await sendToContent("STOP_RESUME_UPLOAD", {}, { requireChatPage: false });
    addLog("已停止简历回传", "info");
    toast("已停止简历回传", "info");
  } catch (err) {
    addLog(`已发送停止回传（页面通信：${err.message || err}）`, "warning");
    toast("已停止简历回传", "info");
  }
}

async function stopAskResume() {
  // 先写 storage 广播停止，再尝试消息（防 iframe / 通信失败导致停不掉）
  setAskResumeRunningState(false);
  await chrome.storage.local.set({ isAskResumeRunning: false });
  try {
    await sendToContent("STOP_ASK_RESUME", {}, { requireChatPage: false });
    addLog("已停止求简历", "info");
    toast("已停止求简历", "info");
  } catch (err) {
    addLog(`已发送停止（页面通信：${err.message || err}）`, "warning");
    toast("已停止求简历", "info");
  }
}

/**
 * 点击「确定」：采用当前话术（框空则用灰色内置默认），此后任务才使用
 * @param {"resume"|"reject"} field
 */
function saveScript(field) {
  if (field === "resume") {
    const typed = ($("resume-script")?.value || "").trim();
    const finalText = typed || DEFAULT_RESUME_SCRIPT;
    state.resumeScript = finalText;
    if ($("resume-script")) $("resume-script").value = finalText;
    toast("求简历话术已确认，将用于本次浏览器会话", "success");
    addLog(
      `求简历话术已确认：<span class="lh">${escHtml(finalText)}</span>`,
      "success",
    );
  } else {
    const typed = ($("reject-script")?.value || "").trim();
    const finalText = typed || DEFAULT_REJECT_SCRIPT;
    state.rejectScript = finalText;
    if ($("reject-script")) $("reject-script").value = finalText;
    toast("拒简历话术已确认，将用于本次浏览器会话", "success");
    addLog(
      `拒简历话术已确认：<span class="lh">${escHtml(finalText)}</span>`,
      "success",
    );
  }
  updateScriptConfirmUi(field);
  persistSessionRuntime();
}

$("sel-trigger").addEventListener("click", toggleDropdown);
$("sel-add-btn").addEventListener("click", (e) => {
  e.stopPropagation();
  showAddRow();
});
$("confirm-add-btn").addEventListener("click", confirmAddPosition);
$("cancel-add-btn").addEventListener("click", hideAddRow);
$("new-position-inp").addEventListener("keydown", (e) => {
  if (e.key === "Enter") confirmAddPosition();
});
$("modal-cancel").addEventListener("click", closeModal);
$("modal-confirm").addEventListener("click", doDelete);

$("filter-inp").addEventListener("keydown", (e) => onTagKey(e, "filter"));
$("black-inp").addEventListener("keydown", (e) => onTagKey(e, "black"));
$("filter-area").addEventListener("click", () => focusTagInput("filter-inp"));
$("black-area").addEventListener("click", () => focusTagInput("black-inp"));

$("save-cond-btn").addEventListener("click", saveConditions);
$("reset-cond-btn").addEventListener("click", resetConditions);
$("save-resume-script-btn").addEventListener("click", () => saveScript("resume"));
$("save-reject-script-btn").addEventListener("click", () => saveScript("reject"));
$("resume-script")?.addEventListener("input", () => updateScriptConfirmUi("resume"));
$("reject-script")?.addEventListener("input", () => updateScriptConfirmUi("reject"));

/**
 * 焦点离开「打招呼上限人数」时立刻校验并提示（主路径）
 */
function onMatchLimitBlur() {
  const check = validateMatchLimit(getMatchLimitInputRaw());
  if (!check.ok) {
    const msg = `无法开启打招呼：${check.message}`;
    setMatchLimitError(msg);
    toast(msg, "warn");
    addLog(msg, "warning");
    return;
  }
  state.matchLimit = check.value;
  if ($("match-limit")) {
    $("match-limit").value = String(check.value);
  }
  setMatchLimitError("");
  persistSessionRuntime();
}

// 仅失焦检测：不依赖点击「一键打招呼」
$("match-limit")?.addEventListener("blur", onMatchLimitBlur);
// 重新输入时先清掉红框，等再次离开时再验
$("match-limit")?.addEventListener("input", () => {
  setMatchLimitError("");
});

$("start-btn").addEventListener("click", startRun);
$("stop-btn").addEventListener("click", stopRun);
$("ask-resume-btn").addEventListener("click", startAskResume);
$("stop-ask-btn").addEventListener("click", stopAskResume);
$("resume-upload-btn").addEventListener("click", startResumeUpload);
$("stop-resume-upload-btn").addEventListener("click", stopResumeUpload);
$("clear-log-btn").addEventListener("click", clearLog);

// ——— 说明问号：浮层气泡，优先显示在图标右侧，避免挡住下方输入框 ———
function getHelpFloatEl() {
  return document.getElementById("help-float-bubble");
}

function hideHelpFloat() {
  const el = getHelpFloatEl();
  if (!el) return;
  el.classList.remove("show");
  el.setAttribute("aria-hidden", "true");
}

/**
 * 智能定位：优先右侧；右侧不够则左侧；再不够则上方，尽量不盖住下方输入框
 * @param {HTMLElement} anchor
 * @param {string} text
 */
function showHelpFloat(anchor, text) {
  const el = getHelpFloatEl();
  if (!el || !anchor) return;
  const textEl = el.querySelector(".help-float-text");
  const arrow = el.querySelector(".arrow");
  if (textEl) textEl.textContent = text || "";

  el.classList.add("show");
  el.setAttribute("aria-hidden", "false");

  // 先放到屏外测量尺寸
  el.style.left = "0px";
  el.style.top = "0px";
  const tipW = el.offsetWidth || 220;
  const tipH = el.offsetHeight || 72;
  const rect = anchor.getBoundingClientRect();
  const pad = 8;
  const gap = 10;
  const vw = window.innerWidth || 360;
  const vh = window.innerHeight || 580;

  const spaceRight = vw - rect.right - pad;
  const spaceLeft = rect.left - pad;
  const spaceAbove = rect.top - pad;

  let left = 0;
  let top = 0;
  let placement = "right";

  if (spaceRight >= tipW + gap) {
    placement = "right";
    left = rect.right + gap;
    top = rect.top + rect.height / 2 - tipH / 2;
  } else if (spaceLeft >= tipW + gap) {
    placement = "left";
    left = rect.left - gap - tipW;
    top = rect.top + rect.height / 2 - tipH / 2;
  } else if (spaceAbove >= tipH + gap) {
    // 上方：不挡下方输入框
    placement = "top";
    left = rect.left + rect.width / 2 - tipW / 2;
    top = rect.top - gap - tipH;
  } else {
    // 兜底下方，但尽量贴右，减少盖住整行输入
    placement = "bottom";
    left = Math.min(rect.left, vw - tipW - pad);
    top = rect.bottom + gap;
  }

  left = Math.max(pad, Math.min(left, vw - tipW - pad));
  top = Math.max(pad, Math.min(top, vh - tipH - pad));

  el.style.left = `${Math.round(left)}px`;
  el.style.top = `${Math.round(top)}px`;

  if (arrow) {
    arrow.style.left = "";
    arrow.style.right = "";
    arrow.style.top = "";
    arrow.style.bottom = "";
    if (placement === "right") {
      arrow.style.left = "-4px";
      arrow.style.top = `${Math.round(rect.top + rect.height / 2 - top - 4.5)}px`;
    } else if (placement === "left") {
      arrow.style.right = "-4px";
      arrow.style.top = `${Math.round(rect.top + rect.height / 2 - top - 4.5)}px`;
    } else if (placement === "top") {
      arrow.style.bottom = "-4px";
      arrow.style.left = `${Math.round(rect.left + rect.width / 2 - left - 4.5)}px`;
    } else {
      arrow.style.top = "-4px";
      arrow.style.left = `${Math.round(rect.left + rect.width / 2 - left - 4.5)}px`;
    }
  }
}

function initHelpTips() {
  const tips = document.querySelectorAll(".help-tip");
  tips.forEach((tip) => {
    const text = tip.getAttribute("data-tip") || tip.getAttribute("aria-label") || "";
    const show = () => showHelpFloat(tip, text);
    const hide = () => hideHelpFloat();
    tip.addEventListener("mouseenter", show);
    tip.addEventListener("mouseleave", hide);
    tip.addEventListener("focus", show);
    tip.addEventListener("blur", hide);
  });
  // 滚动时隐藏，避免错位
  window.addEventListener(
    "scroll",
    () => {
      hideHelpFloat();
    },
    true,
  );
}

initHelpTips();
$("scroll-log-btn").addEventListener("click", scrollLog);

document.addEventListener("click", (e) => {
  if (!ddOpen) return;
  if ($("sel-wrap").contains(e.target)) return;
  closeDropdown();
});

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "LOG_MESSAGE" && message.data?.message) {
    const t =
      message.data.type === "error"
        ? "error"
        : message.data.type === "success"
          ? "success"
          : message.data.type === "warning"
            ? "warning"
            : "info";
    addLog(escHtml(message.data.message), t);
  }
  if (message.type === "MATCH_SUCCESS") {
    setProcessedCount(processedCount + 1);
  }
  if (message.type === "RUN_STATE_CHANGED") {
    setRunningState(!!message.running);
    // 停止原因不再写日志：由 stop 按钮统一 addLog，避免「已停止」出现多条
    if (
      message.running === false &&
      message.reason &&
      !message.silentLog
    ) {
      addLog(escHtml(message.reason), "info");
    }
  }
  if (message.type === "ASK_RESUME_STATE_CHANGED") {
    setAskResumeRunningState(!!message.running);
  }
  if (message.type === "RESUME_UPLOAD_STATE_CHANGED") {
    setResumeUploadRunningState(!!message.running);
  }
});

// —— 登录态 UI ——

function defaultAuthBaseUrl() {
  const cfg = window.招聘速聊助手_CONFIG?.PLUGIN_AUTH || window.CONFIG?.PLUGIN_AUTH;
  const api = window.招聘速聊助手_CONFIG?.ANALYZE_IMAGE_API || window.CONFIG?.ANALYZE_IMAGE_API;
  return (
    cfg?.baseUrl ||
    api?.baseUrl ||
    "https://upims.yili.com"
  );
}

function hidePageGate() {
  $("page-gate")?.classList.remove("show");
}

function showPageGate() {
  isAuthenticated = false;
  currentUser = null;
  $("auth-loading")?.classList.remove("show");
  $("login-view")?.classList.remove("show");
  $("main-plugin")?.classList.remove("show");
  $("user-bar")?.classList.remove("show");
  $("page-gate")?.classList.add("show");
}

function showAuthLoading() {
  hidePageGate();
  $("auth-loading")?.classList.add("show");
  $("login-view")?.classList.remove("show");
  $("main-plugin")?.classList.remove("show");
}

function showLoginView(errorMsg) {
  isAuthenticated = false;
  currentUser = null;
  hidePageGate();
  $("auth-loading")?.classList.remove("show");
  $("main-plugin")?.classList.remove("show");
  $("user-bar")?.classList.remove("show");
  $("login-view")?.classList.add("show");

  const errEl = $("login-error");
  if (errEl) {
    if (errorMsg) {
      errEl.textContent = errorMsg;
      errEl.classList.add("show");
    } else {
      errEl.textContent = "";
      errEl.classList.remove("show");
    }
  }
}

function updateUserBar(user) {
  const bar = $("user-bar");
  const nameEl = $("user-bar-name");
  if (!bar || !nameEl) return;
  const display =
    (user?.full_name && String(user.full_name).trim()) ||
    user?.username ||
    "已登录";
  const dept = user?.department ? ` · ${user.department}` : "";
  nameEl.textContent = `${display}${dept}`;
  nameEl.title = user?.username || display;
  bar.classList.add("show");
}

function showMainView(user) {
  isAuthenticated = true;
  currentUser = user || null;
  hidePageGate();
  $("auth-loading")?.classList.remove("show");
  $("login-view")?.classList.remove("show");
  $("main-plugin")?.classList.add("show");
  updateUserBar(user);
}

function sendAuthMessage(payload) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage(payload, (response) => {
        if (chrome.runtime.lastError) {
          resolve({
            success: false,
            authenticated: false,
            error: chrome.runtime.lastError.message,
          });
          return;
        }
        resolve(response || {});
      });
    } catch (err) {
      resolve({
        success: false,
        authenticated: false,
        error: err.message || String(err),
      });
    }
  });
}

async function handleLoginSubmit() {
  const username = ($("login-username")?.value || "").trim();
  const password = $("login-password")?.value || "";
  const baseUrl = defaultAuthBaseUrl();
  const btn = $("login-btn");
  const errEl = $("login-error");

  if (!username || !password) {
    if (errEl) {
      errEl.textContent = "请输入用户名和密码";
      errEl.classList.add("show");
    }
    return;
  }

  if (btn) {
    btn.disabled = true;
    btn.textContent = "登录中…";
  }
  if (errEl) {
    errEl.textContent = "";
    errEl.classList.remove("show");
  }

  const result = await sendAuthMessage({
    type: "plugin_login",
    username,
    password,
    baseUrl,
  });

  if (btn) {
    btn.disabled = false;
    btn.textContent = "登 录";
  }

  if (result?.success && result.token) {
    // 密码不落盘
    if ($("login-password")) $("login-password").value = "";
    showMainView(result.user);
    toast("登录成功", "success");
    // 新登录：强制从平台拉取岗位
    await initMainApp({ forcePositions: true });
    return;
  }

  const msg = result?.error || "登录失败，请检查账号密码或平台地址";
  if (errEl) {
    errEl.textContent = msg;
    errEl.classList.add("show");
  }
  toast(msg, "warn");
}

async function handleLogout() {
  await sendAuthMessage({ type: "plugin_logout" });
  isAuthenticated = false;
  currentUser = null;
  mainAppInitialized = false;
  state.positions = {};
  state.activePosition = null;
  showLoginView();
  toast("已退出登录", "info");
}

/**
 * @param {{ forcePositions?: boolean }} [opts]
 */
async function initMainApp(opts = {}) {
  if (mainAppInitialized) {
    // 已初始化过：刷新用户条即可
    if (currentUser) updateUserBar(currentUser);
    return;
  }
  mainAppInitialized = true;

  await loadSettings();
  // 岗位：登录强制云端；同会话再开弹窗优先 session
  await loadPositionsFromCloud({ force: !!opts.forcePositions });
  await restoreRuntimeLogs();

  // 沟通页默认全部职位
  try {
    const tab = await getActiveTab();
    if (tab && isChatPage(tab.url || "")) {
      isAllPositionsMode = true;
      state.activePosition = ALL_POSITIONS_LABEL;
      renderTrigger();
      setFilterConditionsLocked(true);
      console.log("[招聘速聊助手] 沟通页打开，默认设置为全部职位模式");
      // 可选：持久化默认状态（重启弹窗仍默认）
      // chrome.storage.local.set({ isAllPositionsMode: true, activePosition: ALL_POSITIONS_LABEL }).catch(() => {});
    }
  } catch (e) {
    console.warn("[招聘速聊助手] 获取标签页失败，默认岗位选择");
  }

  const stored = await chrome.storage.local.get([
    "isRunning",
    "isAskResumeRunning",
    "isResumeUploadRunning",
    "招聘速聊助手_saved_resumes",
    "招聘速聊助手_last_resume_save",
  ]);
  setRunningState(!!stored.isRunning);
  setAskResumeRunningState(!!stored.isAskResumeRunning);
  setResumeUploadRunningState(!!stored.isResumeUploadRunning);
  await updatePageButtons();

  const count = (stored.招聘速聊助手_saved_resumes || []).length;
  setProcessedCount(count);

  const displayName =
    (currentUser?.full_name && String(currentUser.full_name).trim()) ||
    currentUser?.username ||
    "";
  if (displayName) {
    addLog(
      `已登录：<span class="lh">${escHtml(displayName)}</span>`,
      "success",
    );
  }

  const posCount = Object.keys(state.positions).length;
  if (posCount) {
    addLog(
      `已加载 <span class="lh">${posCount}</span> 个职位配置（平台同步）`,
      "info",
    );
    if (state.activePosition) {
      addLog(
        `当前激活职位：<span class="lh">${escHtml(state.activePosition)}</span>`,
        "success",
      );
    }
  } else {
    addLog("暂无职位配置，请新增职位并配置筛选条件后保存", "info");
  }

  if (count > 0) {
    addLog(`本地已缓存 <span class="lh">${count}</span> 条 AI 分析记录`, "info");
  }

  const last = stored.招聘速聊助手_last_resume_save;
  if (last?.savedAt) {
    const hint = last.downloadOk
      ? `上次保存: ${last.name}（已下载）`
      : last.storageOk
        ? `上次保存: ${last.name}（仅插件存储）`
        : `上次保存失败: ${last.error || "未知"}`;
    addLog(escHtml(hint), last.ok ? "success" : "error");
  }

  addLog(
    `平台接口：<span class="lh">${escHtml(state.analyzeImageBaseUrl || "未设置")}</span>；AI/回传优先用登录 Token${state.analyzeImageToken ? "（已配置可选 AccessToken）" : ""}`,
    "info",
  );

  addLog(
    "提示：不会把简历 PDF / base64 / 截图写入下载夹；仅拦截转 base64 存插件内并上传平台",
    "info",
  );
}

function bindAuthUi() {
  $("login-btn")?.addEventListener("click", () => {
    handleLoginSubmit().catch((err) => {
      toast(err.message || String(err), "warn");
    });
  });

  // 回车提交
  ["login-username", "login-password"].forEach((id) => {
    $(id)?.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        handleLoginSubmit().catch(() => {});
      }
    });
  });

  $("logout-btn")?.addEventListener("click", () => {
    handleLogout().catch((err) => {
      toast(err.message || String(err), "warn");
    });
  });
}

async function bootstrapAuth() {
  fillVersionLabel();
  // 非 Boss 直聘页面：只提示，不进入登录/主界面
  try {
    const tab = await getActiveTab();
    const url = tab?.url || "";
    if (!isBossPage(url)) {
      showPageGate();
      return;
    }
  } catch (_) {
    showPageGate();
    return;
  }

  showAuthLoading();
  bindAuthUi();

  // 预填平台地址（已移除高级输入）

  const check = await sendAuthMessage({ type: "plugin_auth_check" });

  if (check?.authenticated && check.user) {
    showMainView(check.user);
    // 同会话重开弹窗：优先 session 岗位缓存
    await initMainApp({ forcePositions: false });
    return;
  }

  // 网络异常但本地有 token：允许先进入（后台敏感接口仍会再校验）
  if (check?.offline && check.token && check.user) {
    showMainView(check.user);
    await initMainApp({ forcePositions: false });
    addLog("登录状态未能联网校验，已按本地会话暂时放行", "warning");
    return;
  }

  showLoginView(
    check?.reason === "invalid_token"
      ? "登录已失效，请重新登录"
      : "",
  );
}

bootstrapAuth().catch((err) => {
  console.error(err);
  showLoginView(err.message || "初始化失败");
});