// 招聘速聊助手 Service Worker
importScripts(
  "config.js",
  "utils/yili_agent.js",
  "utils/analyze_image.js",
  "utils/resume_file_store.js",
  "utils/plugin_auth.js",
);

self.addEventListener("install", (event) => {
  event.waitUntil(self.skipWaiting());
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

let runningSite = null;

const RUNTIME_LOGS_KEY = "招聘速聊助手_runtime_logs";
const RUNTIME_LOGS_MAX = 800;
const LAST_RESUME_FILE_KEY = "招聘速聊助手_last_resume_file_capture";

/** @type {null | {
 *   captureId: string,
 *   tabId: number|null,
 *   name: string,
 *   sessionKey: string,
 *   startedAt: number,
 *   timeoutId: ReturnType<typeof setTimeout>,
 *   handled: boolean
 * }} */
let resumeCapture = null;

/**
 * 持久化运行日志（弹窗关闭后重新打开仍可看）
 * 对本轮汇总/停止类文案做短时去重，避免多 frame 写入多条
 */
function isStatusRuntimeLog(message) {
  const t = String(message || "")
    .replace(/<[^>]+>/g, "")
    .trim();
  return (
    /^已经触达/.test(t) ||
    /^已跳过/.test(t) ||
    /^已打招呼\s*\d+\s*人/.test(t) ||
    /^已求简历\s*\d+\s*人/.test(t) ||
    /^已简历回传\s*\d+\s*人/.test(t) ||
    /^日志已清空/.test(t)
  );
}

function appendRuntimeLog(message, type = "info") {
  const text = String(message || "").trim();
  if (!text) return Promise.resolve();
  const verbose =
    typeof self !== "undefined" &&
    self.招聘速聊助手_CONFIG?.VERBOSE_RUNTIME_LOGS !== false;
  if (!verbose && !isStatusRuntimeLog(text)) return Promise.resolve();
  const entry = {
    time: new Date().toISOString(),
    message: text,
    type: type || "info",
  };
  return chrome.storage.local.get([RUNTIME_LOGS_KEY]).then((stored) => {
    const list = Array.isArray(stored[RUNTIME_LOGS_KEY])
      ? stored[RUNTIME_LOGS_KEY]
      : [];
    const last = list[list.length - 1];
    const isProgress =
      /^(本轮汇总|本轮扫描完成|已停止打招呼|已停止求简历|已停止自动滚动)/.test(
        text,
      );
    if (
      isProgress &&
      last &&
      last.message === text &&
      Date.now() - new Date(last.time || 0).getTime() < 4000
    ) {
      return;
    }
    list.push(entry);
    while (list.length > RUNTIME_LOGS_MAX) list.shift();
    return chrome.storage.local.set({ [RUNTIME_LOGS_KEY]: list });
  });
}

function sanitizeFilenamePart(name) {
  return String(name || "unknown")
    .replace(/[\\/:*?"<>|]+/g, "_")
    .replace(/\s+/g, "_")
    .slice(0, 40);
}

/**
 * 把任意文本写成 data URL，供 chrome.downloads 落盘
 * @param {string} text
 * @param {string} [mime]
 */
function textToDataUrl(text, mime = "text/plain;charset=utf-8") {
  const bytes = new TextEncoder().encode(String(text ?? ""));
  const chunk = 0x8000;
  let binary = "";
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return `data:${mime};base64,${btoa(binary)}`;
}

/**
 * 下载一个 dataUrl 到指定相对路径（位于 Chrome「下载」目录下）
 * 【本机落盘已关闭】业务仍用内存/扩展存储；需要恢复时取消注释下方 chrome.downloads 逻辑
 */
function downloadDataUrl(dataUrl, filename) {
  void dataUrl;
  return Promise.resolve({
    ok: false,
    skipped: true,
    message: "本机下载夹落盘已关闭",
    filename,
  });
  // return new Promise((resolve) => {
  //   chrome.downloads.download(
  //     {
  //       url: dataUrl,
  //       filename,
  //       conflictAction: "uniquify",
  //       saveAs: false,
  //     },
  //     (downloadId) => {
  //       if (chrome.runtime.lastError) {
  //         resolve({
  //           ok: false,
  //           message: chrome.runtime.lastError.message,
  //           filename,
  //         });
  //         return;
  //       }
  //       resolve({ ok: true, downloadId, filename });
  //     },
  //   );
  // });
}

/**
 * 把已捕获的原文件再落到用户可见的下载目录：Downloads/招聘速聊助手_resumes/files/
 * 【本机落盘已关闭】
 */
function exportResumeFileToDownloads(meta, base64) {
  void meta;
  void base64;
  return Promise.resolve({
    ok: false,
    skipped: true,
    message: "本机原文件导出已关闭",
  });
  // const cfg = getAskResumeConfig();
  // if (cfg.saveResumeFileToDownloads === false) {
  //   return Promise.resolve({ ok: false, skipped: true });
  // }
  // if (!base64) {
  //   return Promise.resolve({ ok: false, message: "无 base64" });
  // }
  // const safeName = sanitizeFilenamePart(meta.name);
  // const rawFile = meta.filename || `resume_${meta.id || Date.now()}.bin`;
  // const safeFile = sanitizeFilenamePart(rawFile).replace(/^\.+/, "") || "resume.bin";
  // const filename = `招聘速聊助手_resumes/files/${safeName}_${safeFile}`;
  // const mime = meta.mime || "application/octet-stream";
  // const dataUrl = `data:${mime};base64,${base64}`;
  // return downloadDataUrl(dataUrl, filename).then((result) => {
  //   if (!result.ok) {
  //     console.warn("[ResumeFileCapture] 导出原文件失败:", result.message);
  //   }
  //   return result;
  // });
}

/**
 * 把 base64 字符串原样写入 txt：Downloads/招聘速聊助手_resumes/base64/姓名_文件名.txt
 * 【本机落盘已关闭】base64 仍保存在扩展 ResumeFileStore，供平台上传
 */
function exportBase64ToTxt(meta, base64) {
  void meta;
  void base64;
  return Promise.resolve({
    ok: false,
    skipped: true,
    message: "本机 base64 txt 导出已关闭",
  });
  // const cfg = getAskResumeConfig();
  // if (cfg.saveResumeBase64ToTxt === false) {
  //   return Promise.resolve({ ok: false, skipped: true });
  // }
  // if (!base64) {
  //   return Promise.resolve({ ok: false, message: "无 base64" });
  // }
  // const safeName = sanitizeFilenamePart(meta.name);
  // const rawFile = meta.filename || `resume_${meta.id || Date.now()}.bin`;
  // const safeFile = sanitizeFilenamePart(rawFile).replace(/^\.+/, "") || "resume.bin";
  // const baseNoExt = safeFile.replace(/\.[^.]+$/, "") || safeFile;
  // const filename = `招聘速聊助手_resumes/base64/${safeName}_${baseNoExt}.txt`;
  // const dataUrl = textToDataUrl(base64, "text/plain;charset=utf-8");
  // return downloadDataUrl(dataUrl, filename).then((result) => {
  //   if (!result.ok) {
  //     console.warn("[ResumeFileCapture] 导出 base64 txt 失败:", result.message);
  //   } else {
  //     console.log(
  //       "[ResumeFileCapture] base64 已写入 txt:",
  //       filename,
  //       "chars=",
  //       base64.length,
  //     );
  //   }
  //   return result;
  // });
}

function getExecuteTextDefaults() {
  return (
    self.招聘速聊助手_CONFIG?.EXECUTE_TEXT_API ||
    self.招聘速聊助手_CONFIG?.YILI_AI_AGENT ||
    YiliAgentClient.DEFAULT_CONFIG ||
    {}
  );
}

function getAnalyzeImageDefaults() {
  return (
    self.招聘速聊助手_CONFIG?.ANALYZE_IMAGE_API ||
    self.AnalyzeImageClient?.ANALYZE_IMAGE_DEFAULTS ||
    {}
  );
}

function getAskResumeConfig() {
  return self.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG || {};
}

/**
 * 解析平台 baseUrl（弹窗地址 / 登录地址 / 默认配置）
 */
async function resolvePlatformBaseUrl(message = {}, extraDefaults = {}) {
  const analyzeDefaults = getAnalyzeImageDefaults();
  const pluginDefaults =
    self.招聘速聊助手_CONFIG?.PLUGIN_AUTH || extraDefaults || {};
  const stored = await chrome.storage.local.get([
    "招聘速聊助手_settings",
    "招聘速聊助手_auth_base_url",
  ]);
  const settings = stored.招聘速聊助手_settings || {};

  return (
    String(message.baseUrl || "").trim() ||
    String(settings.analyzeImageBaseUrl || "").trim() ||
    String(stored.招聘速聊助手_auth_base_url || "").trim() ||
    String(extraDefaults.baseUrl || "").trim() ||
    String(analyzeDefaults.baseUrl || "").trim() ||
    String(pluginDefaults.baseUrl || "").trim()
  );
}

/**
 * AI 接口鉴权 Token（方案 B 双轨，插件侧优先登录 Token）
 * 优先级：
 * 1) 消息显式传入 token
 * 2) 插件登录 session token（/plugin_auth/login/）
 * 3) 弹窗配置的 AccessToken（可选兼容）
 */
async function resolveAiAgentToken(message = {}) {
  const explicit = String(message.token || "").trim();
  if (explicit) {
    return { token: explicit, source: "message" };
  }

  try {
    const session = await getPluginAuthSession();
    if (session?.token) {
      return { token: String(session.token).trim(), source: "plugin_login" };
    }
  } catch (_) {
    /* ignore */
  }

  const stored = await chrome.storage.local.get(["招聘速聊助手_settings"]);
  const settings = stored.招聘速聊助手_settings || {};
  const analyzeDefaults = getAnalyzeImageDefaults();
  const executeDefaults = getExecuteTextDefaults();
  const fallback =
    String(settings.analyzeImageToken || "").trim() ||
    String(analyzeDefaults.token || "").trim() ||
    String(executeDefaults.token || "").trim();

  if (fallback) {
    return { token: fallback, source: "access_token_config" };
  }
  return { token: "", source: "none" };
}

/**
 * 从 chrome.storage 读取图片分析接口配置
 * Token：优先插件登录 Token，AccessToken 仅作兼容
 */
async function resolveAnalyzeImageSettings(message = {}) {
  const defaults = getAnalyzeImageDefaults();
  const baseUrl = await resolvePlatformBaseUrl(message, defaults);
  const { token, source } = await resolveAiAgentToken(message);

  const timeoutMs =
    Number(message.timeoutMs) > 0
      ? Number(message.timeoutMs)
      : Number(defaults.timeoutMs) > 0
        ? Number(defaults.timeoutMs)
        : 180000;

  return {
    baseUrl,
    token,
    tokenSource: source,
    path: defaults.path || "/ai_agent/analyze_image/",
    timeoutMs,
  };
}

/**
 * 文本 AI（打招呼 / 求简历）配置解析
 * Token：优先插件登录 Token
 */
async function resolveExecuteTextSettings(message = {}) {
  const defaults = getExecuteTextDefaults();
  const analyzeDefaults = getAnalyzeImageDefaults();
  const baseUrl = await resolvePlatformBaseUrl(message, {
    baseUrl: defaults.baseUrl || analyzeDefaults.baseUrl,
  });
  const { token, source } = await resolveAiAgentToken(message);

  const askTimeout = Number(
    self.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG?.aiTimeoutMs,
  );
  const timeoutMs =
    Number(message.timeoutMs) > 0
      ? Number(message.timeoutMs)
      : askTimeout > 0
        ? askTimeout
        : Number(defaults.timeoutMs) > 0
          ? Number(defaults.timeoutMs)
          : 180000;

  return {
    baseUrl,
    token,
    tokenSource: source,
    path: defaults.path || "/ai_agent/execute_text/",
    timeoutMs,
  };
}

async function handleAnalyzeImageUpload(message) {
  const cfg = await resolveAnalyzeImageSettings(message);
  if (!cfg.token) {
    throw new Error("请先登录插件（AI 使用登录 Token）；或配置 AccessToken");
  }
  if (!cfg.baseUrl) {
    throw new Error("请先在插件弹窗配置接口地址");
  }
  if (!message.dataUrl && !message.fileDataUrl) {
    throw new Error("缺少图片数据");
  }

  const dataUrl = message.dataUrl || message.fileDataUrl;
  const result = await AnalyzeImageClient.uploadAnalyzeImage({
    baseUrl: cfg.baseUrl,
    token: cfg.token,
    path: cfg.path,
    dataUrl,
    filename: message.filename,
    inputText0: message.input_text_0 ?? message.inputText0 ?? "",
    timeoutMs: cfg.timeoutMs,
  });

  return { success: true, ...result };
}

/**
 * 打招呼 / 求简历 AI：走宣双 /ai_agent/execute_text/
 * （不再直连 ai-agent-in.digitalyili.com）
 */
async function handleYiliAgentRequest(message) {
  const cfg = await resolveExecuteTextSettings(message);
  if (!cfg.token) {
    throw new Error(
      "请先登录插件（AI 使用登录 Token）；或在弹窗配置 AccessToken 作为兼容",
    );
  }
  if (!cfg.baseUrl) {
    throw new Error("请先登录插件");
  }

  const payload = {
    input_text_0: message.input_text_0 || "",
    input_text_1: message.input_text_1 || "",
    input_text_2: message.input_text_2 || "",
  };

  console.log(
    "[ExecuteText] 请求入参长度:",
    `resume=${payload.input_text_0.length}`,
    `kw=${payload.input_text_1.length}`,
    `ex=${payload.input_text_2.length}`,
    `url=${cfg.baseUrl}${cfg.path}`,
    `auth=${cfg.tokenSource || "unknown"}`,
  );

  const data = await YiliAgentClient.executeFlow(payload, {
    baseUrl: cfg.baseUrl,
    path: cfg.path,
    token: cfg.token,
    timeoutMs: cfg.timeoutMs,
  });

  return { success: true, response: data };
}

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  const chunk = 0x8000;
  let binary = "";
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

function guessExtFromNameOrUrl(filename, url) {
  const fromName = String(filename || "")
    .split("?")[0]
    .split("#")[0]
    .split(".")
    .pop();
  if (fromName && fromName.length <= 5 && fromName !== filename) {
    return fromName.toLowerCase();
  }
  try {
    const path = new URL(url).pathname;
    const ext = path.split(".").pop();
    if (ext && ext.length <= 5) return ext.toLowerCase();
  } catch {
    /* ignore */
  }
  return "";
}

function isWhitelistedResumeFile(filename, url, mime) {
  const cfg = getAskResumeConfig();
  const list = Array.isArray(cfg.resumeFileExtWhitelist)
    ? cfg.resumeFileExtWhitelist.map((x) => String(x).toLowerCase())
    : ["pdf", "doc", "docx"];
  const ext = guessExtFromNameOrUrl(filename, url);
  if (ext && list.includes(ext)) return true;
  const m = String(mime || "").toLowerCase();
  if (
    m.includes("pdf") ||
    m.includes("msword") ||
    m.includes("officedocument") ||
    m.includes("image/")
  ) {
    return true;
  }
  // 部分下载 filename 为空，armed 窗口内放行（仅一笔）
  if (!filename && !ext) return true;
  return false;
}

function clearResumeCaptureTimer() {
  if (resumeCapture?.timeoutId) {
    clearTimeout(resumeCapture.timeoutId);
  }
}

function notifyResumeCaptureResult(tabId, payload) {
  if (tabId == null || tabId < 0) {
    chrome.runtime
      .sendMessage({ type: "RESUME_FILE_CAPTURE_RESULT", ...payload })
      .catch(() => {});
    return;
  }
  chrome.tabs.sendMessage(
    tabId,
    { type: "RESUME_FILE_CAPTURE_RESULT", ...payload },
    () => {
      void chrome.runtime.lastError;
    },
  );
}

function finishResumeCapture(result) {
  if (!resumeCapture || resumeCapture.handled) return;
  resumeCapture.handled = true;
  clearResumeCaptureTimer();
  const tabId = resumeCapture.tabId;
  const captureId = resumeCapture.captureId;
  resumeCapture = null;
  notifyResumeCaptureResult(tabId, { captureId, ...result });
}

function armResumeFileCapture(message, sender) {
  const cfg = getAskResumeConfig();
  const timeoutMs =
    Number(message.timeoutMs) > 0
      ? Number(message.timeoutMs)
      : Number(cfg.resumeFileCaptureTimeoutMs) > 0
        ? Number(cfg.resumeFileCaptureTimeoutMs)
        : 30000;

  if (resumeCapture && !resumeCapture.handled) {
    clearResumeCaptureTimer();
    finishResumeCapture({
      ok: false,
      message: "已被新的下载捕获请求覆盖",
    });
  }

  const captureId =
    message.captureId ||
    `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const tabId = sender?.tab?.id ?? message.tabId ?? null;

  resumeCapture = {
    captureId,
    tabId,
    name: String(message.name || "未知"),
    sessionKey: String(message.sessionKey || ""),
    startedAt: Date.now(),
    handled: false,
    timeoutId: setTimeout(() => {
      finishResumeCapture({
        ok: false,
        message: `下载捕获超时（${timeoutMs}ms）`,
      });
    }, timeoutMs),
  };

  console.log(
    "[ResumeFileCapture] armed",
    captureId,
    "tab=",
    tabId,
    "name=",
    resumeCapture.name,
  );

  return { success: true, armed: true, captureId, timeoutMs };
}

async function processDownloadItem(item) {
  if (!resumeCapture || resumeCapture.handled) return;
  if (!item) return;

  // tabId 可能为 -1，仅在明确不匹配时跳过
  if (
    resumeCapture.tabId != null &&
    resumeCapture.tabId >= 0 &&
    typeof item.tabId === "number" &&
    item.tabId >= 0 &&
    item.tabId !== resumeCapture.tabId
  ) {
    console.log(
      "[ResumeFileCapture] 忽略其他 tab 下载",
      item.tabId,
      "expect",
      resumeCapture.tabId,
    );
    return;
  }

  const filename = item.filename || item.finalUrl || item.url || "";
  const url = item.finalUrl || item.url || "";
  const mime = item.mime || "";

  if (!url || url.startsWith("blob:") || url.startsWith("data:")) {
    // blob/data 下载无法二次 fetch；尝试用 chrome.downloads 无法读内容
    console.warn("[ResumeFileCapture] 不支持的下载 URL 类型:", url?.slice?.(0, 40));
  }

  if (!isWhitelistedResumeFile(filename, url, mime) && url) {
    // 仍尝试：armed 后第一笔下载通常就是目标
    console.log(
      "[ResumeFileCapture] 扩展名未命中白名单，仍尝试捕获:",
      filename,
      mime,
    );
  }

  // 标记处理中，避免重复 onCreated
  const capture = resumeCapture;
  capture.handled = true;
  clearResumeCaptureTimer();
  resumeCapture = null;

  const cfg = getAskResumeConfig();
  const cancelNative = cfg.cancelNativeDownload !== false;
  const downloadId = item.id;

  if (cancelNative && downloadId != null) {
    try {
      await chrome.downloads.cancel(downloadId);
    } catch (e) {
      console.warn("[ResumeFileCapture] cancel 失败:", e);
    }
    try {
      await chrome.downloads.erase({ id: downloadId });
    } catch {
      /* ignore */
    }
  }

  const shortName =
    (item.filename && item.filename.split(/[/\\]/).pop()) ||
    guessFilenameFromUrl(url) ||
    "resume.bin";

  try {
    if (!url || url.startsWith("blob:") || url.startsWith("data:")) {
      notifyResumeCaptureResult(capture.tabId, {
        captureId: capture.captureId,
        ok: false,
        message: `无法 fetch 该下载地址（${String(url).slice(0, 32)}…），请检查是否为直链`,
      });
      return;
    }

    console.log("[ResumeFileCapture] fetch", url.slice(0, 120));
    const response = await fetch(url, { credentials: "include" });
    if (!response.ok) {
      throw new Error(`fetch 失败 HTTP ${response.status}`);
    }
    const buffer = await response.arrayBuffer();
    const base64 = arrayBufferToBase64(buffer);
    const resolvedMime =
      mime ||
      response.headers.get("content-type") ||
      "application/octet-stream";

    const base64Length = base64.length;
    await appendRuntimeLog(
      `已拦截下载并转为 base64：${shortName}，文件 ${buffer.byteLength} 字节，base64 长度 ${base64Length}`,
      "info",
    );

    const meta = await ResumeFileStore.saveResumeFile({
      name: capture.name,
      sessionKey: capture.sessionKey,
      filename: shortName,
      mime: resolvedMime,
      size: buffer.byteLength,
      base64,
      source: "online_resume_download",
      url: url.slice(0, 500),
    });

    // 【本机落盘已关闭】不再导出 PDF / base64 txt 到下载夹；base64 已在 ResumeFileStore
    // const exported = await exportResumeFileToDownloads(meta, base64);
    // const base64Txt = await exportBase64ToTxt(meta, base64);
    const exported = { ok: false, skipped: true };
    const base64Txt = { ok: false, skipped: true };

    const parts = [
      `简历已拦截并转 base64：${meta.name} / ${meta.filename}`,
      `原文件 ${meta.size} 字节`,
      `base64 长度 ${base64Length}`,
      `插件库 ID=${meta.id}`,
      "未写入下载夹（本机落盘已关闭，仅扩展内存储，供平台上传）",
    ];
    // if (exported.ok) {
    //   parts.push(`原文件：下载夹/${exported.filename}`);
    // } else if (!exported.skipped) {
    //   parts.push(`原文件导出失败：${exported.message || "未知"}`);
    // }
    // if (base64Txt.ok) {
    //   parts.push(`base64 文本：下载夹/${base64Txt.filename}`);
    // } else if (!base64Txt.skipped) {
    //   parts.push(`base64 txt 导出失败：${base64Txt.message || "未知"}`);
    // } else {
    //   parts.push("base64 txt 导出未启用");
    // }

    const resultMessage = parts.join("；");

    console.log("[ResumeFileCapture]", resultMessage);

    const lastRecord = {
      ok: true,
      id: meta.id,
      name: meta.name,
      filename: meta.filename,
      size: meta.size,
      mime: meta.mime,
      base64Length,
      exportPath: "",
      exportOk: false,
      base64TxtPath: "",
      base64TxtOk: false,
      savedAt: new Date().toISOString(),
      message: resultMessage,
    };
    await chrome.storage.local.set({ [LAST_RESUME_FILE_KEY]: lastRecord });
    await appendRuntimeLog(resultMessage, "success");

    notifyResumeCaptureResult(capture.tabId, {
      captureId: capture.captureId,
      ok: true,
      id: meta.id,
      filename: meta.filename,
      mime: meta.mime,
      size: meta.size,
      name: meta.name,
      base64Length,
      exportPath: lastRecord.exportPath,
      base64TxtPath: lastRecord.base64TxtPath,
      message: resultMessage,
    });
  } catch (error) {
    console.error("[ResumeFileCapture] 失败:", error);
    const errMsg = error?.message || String(error);
    await chrome.storage.local.set({
      [LAST_RESUME_FILE_KEY]: {
        ok: false,
        message: errMsg,
        savedAt: new Date().toISOString(),
        url: url?.slice?.(0, 200),
      },
    });
    await appendRuntimeLog(`简历下载失败：${errMsg}`, "error");
    notifyResumeCaptureResult(capture.tabId, {
      captureId: capture.captureId,
      ok: false,
      message: errMsg,
      url: url?.slice?.(0, 200),
    });
  }
}

function guessFilenameFromUrl(url) {
  try {
    const path = new URL(url).pathname;
    const last = path.split("/").pop();
    if (last && last.includes(".")) return decodeURIComponent(last);
  } catch {
    /* ignore */
  }
  return "";
}

chrome.downloads.onCreated.addListener((item) => {
  if (!resumeCapture || resumeCapture.handled) return;
  console.log(
    "[ResumeFileCapture] onCreated",
    item?.id,
    item?.filename,
    item?.url?.slice?.(0, 80),
  );
  processDownloadItem(item).catch((e) =>
    console.error("[ResumeFileCapture] process error", e),
  );
});

chrome.downloads.onChanged.addListener((delta) => {
  if (!resumeCapture || resumeCapture.handled) return;
  if (!delta || delta.id == null) return;
  // 部分场景 onCreated 时 finalUrl 未就绪，state 变化后再查一次
  if (delta.filename || delta.url || delta.state) {
    chrome.downloads.search({ id: delta.id }, (results) => {
      if (chrome.runtime.lastError) return;
      const item = results && results[0];
      if (!item) return;
      if (!resumeCapture || resumeCapture.handled) return;
      // 仅在有 url 且尚未处理时
      if (item.url || item.finalUrl) {
        processDownloadItem(item).catch(() => {});
      }
    });
  }
});

async function handleExportResumeFile(message) {
  // 【本机落盘已关闭】不导出到下载夹；记录仍可从扩展存储读取
  void message;
  return {
    success: false,
    skipped: true,
    message: "本机导出已关闭",
  };
  // const id = message.id;
  // const record = await ResumeFileStore.getResumeFile(id);
  // if (!record || !record.base64) {
  //   throw new Error("未找到简历文件记录");
  // }
  // const mime = record.mime || "application/octet-stream";
  // const filename =
  //   message.filename ||
  //   `招聘速聊助手_resumes/files/${record.filename || `resume_${id}.bin`}`;
  // const dataUrl = `data:${mime};base64,${record.base64}`;
  // return new Promise((resolve, reject) => {
  //   chrome.downloads.download(
  //     {
  //       url: dataUrl,
  //       filename,
  //       conflictAction: "uniquify",
  //       saveAs: false,
  //     },
  //     (downloadId) => {
  //       if (chrome.runtime.lastError) {
  //         reject(new Error(chrome.runtime.lastError.message));
  //       } else {
  //         resolve({ success: true, downloadId, filename });
  //       }
  //     },
  //   );
  // });
}

/**
 * 校验插件登录态；未登录时返回错误对象，已登录返回 null。
 * @param {{ requireOnline?: boolean }} [opts]
 */
async function requirePluginAuth(opts = {}) {
  const check = await pluginAuthCheck({ clearOnFail: true });
  if (check.authenticated) {
    return null;
  }
  // 网络短暂失败但本地有 session：允许继续（避免误拦）
  if (check.offline && check.token) {
    return null;
  }
  return {
    success: false,
    error: check.error || "请先登录后再使用插件",
    authRequired: true,
    reason: check.reason || "unauthenticated",
  };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // 运行日志：弹窗关闭时 content 的 LOG_MESSAGE 也由 background 落盘
  if (message?.type === "LOG_MESSAGE" && message.data?.message) {
    appendRuntimeLog(message.data.message, message.data.type || "info").catch(
      () => {},
    );
    // 回包避免 content 把 lastError 当成失败并重发同一条日志
    try {
      sendResponse({ ok: true });
    } catch {
      /* ignore */
    }
    return true;
  }

  if (message?.type === "MATCH_SUCCESS") {
    try {
      sendResponse({ ok: true });
    } catch {
      /* ignore */
    }
    return true;
  }

  if (
    message?.action === "SET_TAB_KEEP_ALIVE" ||
    message?.type === "set_tab_keep_alive"
  ) {
    const tabId = sender?.tab?.id ?? message.tabId;
    const keep = message.keep !== false;
    if (tabId == null || tabId < 0) {
      sendResponse({ success: false, error: "无 tabId" });
      return true;
    }
    chrome.tabs.update(tabId, { autoDiscardable: !keep }, () => {
      const err = chrome.runtime.lastError;
      if (err) {
        sendResponse({ success: false, error: err.message });
        return;
      }
      sendResponse({ success: true, tabId, keep });
    });
    return true;
  }

  // —— 插件登录鉴权 ——
  if (message?.type === "plugin_login" || message?.action === "PLUGIN_LOGIN") {
    const username = message.username || message.data?.username;
    const password = message.password || message.data?.password;
    const baseUrl = message.baseUrl || message.data?.baseUrl;
    pluginLogin({ username, password, baseUrl })
      .then((result) => sendResponse(result))
      .catch((error) =>
        sendResponse({
          success: false,
          error: error.message || String(error),
          status: error.status || null,
        }),
      );
    return true;
  }

  if (
    message?.type === "plugin_auth_check" ||
    message?.action === "PLUGIN_AUTH_CHECK"
  ) {
    pluginAuthCheck({
      baseUrl: message.baseUrl || message.data?.baseUrl,
      clearOnFail: true,
    })
      .then((result) => sendResponse(result))
      .catch((error) =>
        sendResponse({
          authenticated: false,
          reason: "error",
          error: error.message || String(error),
        }),
      );
    return true;
  }

  if (
    message?.type === "plugin_logout" ||
    message?.action === "PLUGIN_LOGOUT"
  ) {
    pluginLogout({ baseUrl: message.baseUrl || message.data?.baseUrl })
      .then((result) => sendResponse(result))
      .catch((error) =>
        sendResponse({ success: false, error: error.message || String(error) }),
      );
    return true;
  }

  if (
    message?.type === "plugin_auth_local" ||
    message?.action === "PLUGIN_AUTH_LOCAL"
  ) {
    getPluginAuthSession()
      .then((session) =>
        sendResponse({
          authenticated: !!(session && session.token),
          user: session?.user || null,
        }),
      )
      .catch(() => sendResponse({ authenticated: false, user: null }));
    return true;
  }

  if (
    message?.type === "plugin_positions_load" ||
    message?.action === "PLUGIN_POSITIONS_LOAD"
  ) {
    const force = message.force !== false;
    (async () => {
      // force=false：优先 session 缓存
      if (!force) {
        const cached = await getPluginPositionsSession();
        if (cached) {
          return {
            success: true,
            fromCache: true,
            positions: cached.positions,
            activePosition: cached.activePosition,
            updated_at: cached.updated_at,
          };
        }
      }
      return fetchPluginPositions({
        baseUrl: message.baseUrl || message.data?.baseUrl,
      });
    })()
      .then((result) => sendResponse(result))
      .catch((error) =>
        sendResponse({
          success: false,
          error: error.message || String(error),
          status: error.status || null,
        }),
      );
    return true;
  }

  if (
    message?.type === "plugin_positions_save" ||
    message?.action === "PLUGIN_POSITIONS_SAVE"
  ) {
    savePluginPositions({
      positions: message.positions || message.data?.positions || {},
      activePosition:
        message.activePosition ?? message.data?.activePosition ?? null,
      baseUrl: message.baseUrl || message.data?.baseUrl,
    })
      .then((result) => sendResponse(result))
      .catch((error) =>
        sendResponse({
          success: false,
          error: error.message || String(error),
          status: error.status || null,
        }),
      );
    return true;
  }

  // —— 简历查重 / 上传（API_RESUME.md）——
  if (
    message?.type === "plugin_resume_check" ||
    message?.action === "PLUGIN_RESUME_CHECK"
  ) {
    const meta = message.meta || message.data || message;
    pluginResumeCheck({
      meta,
      baseUrl: message.baseUrl || message.data?.baseUrl,
      timeoutMs: message.timeoutMs,
    })
      .then((result) => sendResponse({ success: true, ...result }))
      .catch((error) =>
        sendResponse({
          success: false,
          error: error.message || String(error),
          status: error.status || null,
          authRequired: !!error.authRequired,
        }),
      );
    return true;
  }

  if (
    message?.type === "plugin_resume_upload" ||
    message?.action === "PLUGIN_RESUME_UPLOAD"
  ) {
    const meta = message.meta || message.data?.meta || message.data || {};
    const fileBase64 =
      message.file_base64 ||
      message.pdf_base64 ||
      message.base64 ||
      message.data?.file_base64 ||
      message.data?.base64 ||
      "";
    pluginResumeUpload({
      meta,
      file_base64: fileBase64,
      baseUrl: message.baseUrl || message.data?.baseUrl,
      timeoutMs: message.timeoutMs,
    })
      .then((result) => sendResponse({ success: true, ...result }))
      .catch((error) =>
        sendResponse({
          success: false,
          error: error.message || String(error),
          status: error.status || null,
          authRequired: !!error.authRequired,
        }),
      );
    return true;
  }

  if (message.action === "captureVisibleTab") {
    try {
      const windowId = sender.tab ? sender.tab.windowId : null;
      chrome.tabs.captureVisibleTab(windowId, { format: "png" }, (dataUrl) => {
        if (chrome.runtime.lastError) {
          console.error("截图失败:", chrome.runtime.lastError.message);
          sendResponse({
            success: false,
            error: chrome.runtime.lastError.message,
          });
        } else {
          console.log("截图成功，数据长度:", dataUrl?.length || 0);
          sendResponse({ success: true, imageData: dataUrl });
        }
      });
    } catch (error) {
      console.error("调用截图 API 时出错:", error);
      sendResponse({ success: false, error: error.message || String(error) });
    }
    return true;
  }

  if (
    message.action === "YILI_AGENT_REQUEST" ||
    message.action === "EXECUTE_TEXT_REQUEST" ||
    message?.type === "execute_text"
  ) {
    // 文本 AI 使用 AccessToken，仍要求插件已登录（与图片分析一致）
    requirePluginAuth()
      .then((authErr) => {
        if (authErr) {
          sendResponse(authErr);
          return null;
        }
        return handleYiliAgentRequest(message);
      })
      .then((result) => {
        if (result) sendResponse(result);
      })
      .catch((error) => {
        console.error("文本 AI（execute_text）请求失败:", error);
        sendResponse({
          success: false,
          error: error.message || String(error),
          status: error.status || null,
        });
      });
    return true;
  }

  if (message.action === "ANALYZE_IMAGE_UPLOAD") {
    requirePluginAuth()
      .then((authErr) => {
        if (authErr) {
          sendResponse(authErr);
          return null;
        }
        return handleAnalyzeImageUpload(message);
      })
      .then((result) => {
        if (result) sendResponse(result);
      })
      .catch((error) => {
        console.error("图片分析接口上传失败:", error);
        sendResponse({
          success: false,
          error: error.message || String(error),
          response: error.response || null,
          status: error.status || null,
        });
      });
    return true;
  }

  if (message.action === "ARM_RESUME_FILE_CAPTURE") {
    try {
      const result = armResumeFileCapture(message, sender);
      sendResponse(result);
    } catch (error) {
      sendResponse({ success: false, error: error.message || String(error) });
    }
    return true;
  }

  if (
    message.action === "GET_RESUME_FILE" ||
    message?.type === "get_resume_file"
  ) {
    const id = message.id ?? message.data?.id;
    ResumeFileStore.getResumeFile(id)
      .then((record) => {
        if (!record || !record.base64) {
          sendResponse({
            ok: false,
            success: false,
            error: "未找到简历文件或缺少 base64",
          });
          return;
        }
        sendResponse({
          ok: true,
          success: true,
          id: record.id,
          name: record.name,
          filename: record.filename,
          mime: record.mime,
          size: record.size,
          base64: record.base64,
          source: record.source,
          createdAt: record.createdAt,
        });
      })
      .catch((error) =>
        sendResponse({
          ok: false,
          success: false,
          error: error.message || String(error),
        }),
      );
    return true;
  }

  if (message.action === "GET_RESUME_FILE_META_LIST") {
    ResumeFileStore.listResumeFileMetaFromStorage()
      .then((list) => sendResponse({ success: true, list }))
      .catch((error) =>
        sendResponse({ success: false, error: error.message || String(error) }),
      );
    return true;
  }

  if (message.action === "EXPORT_RESUME_FILE") {
    handleExportResumeFile(message)
      .then((result) => sendResponse(result))
      .catch((error) =>
        sendResponse({ success: false, error: error.message || String(error) }),
      );
    return true;
  }

  try {
    switch (message.action) {
      case "OPEN_PLUGIN":
        chrome.action.openPopup();
        sendResponse({ status: "success" });
        break;

      case "CHECK_RUNNING_SITE": {
        // 启动任务前校验登录（content 侧也会走此检查）
        requirePluginAuth()
          .then((authErr) => {
            if (authErr) {
              sendResponse({
                canStart: false,
                authRequired: true,
                error: authErr.error,
              });
              return;
            }
            const canStart = !runningSite || runningSite === message.site;
            sendResponse({ canStart });
          })
          .catch((error) => {
            sendResponse({
              canStart: false,
              error: error.message || String(error),
            });
          });
        return true;
      }

      case "SITE_STARTED":
        runningSite = message.site;
        sendResponse({ status: "success" });
        break;

      case "SITE_STOPPED":
        if (runningSite === message.site) {
          runningSite = null;
        }
        sendResponse({ status: "success" });
        break;

      case "SITE_INITIALIZED":
        if (!runningSite) {
          runningSite = message.site;
        }
        sendResponse({ status: "success" });
        break;

      case "DOWNLOAD_IMAGE":
        // 【本机落盘已关闭】
        // chrome.downloads.download(
        //   {
        //     url: message.url,
        //     filename: message.filename,
        //     conflictAction: "uniquify",
        //   },
        //   (downloadId) => {
        //     if (chrome.runtime.lastError) {
        //       sendResponse({
        //         success: false,
        //         error: chrome.runtime.lastError.message,
        //       });
        //     } else {
        //       sendResponse({ success: true, downloadId });
        //     }
        //   },
        // );
        sendResponse({
          success: true,
          skipped: true,
          message: "本机下载夹落盘已关闭",
        });
        return true;

      case "SAVE_RESUME_SCREENSHOT": {
        // 【本机落盘已关闭】截图业务仍走内存拼接 + 接口上传，不写下载夹
        // const dataUrl = message.dataUrl || "";
        // const filename =
        //   message.filename || "招聘速聊助手_resumes/screenshots/screenshot.png";
        // if (!dataUrl.startsWith("data:image/")) {
        //   sendResponse({ success: false, error: "无效的截图数据" });
        //   break;
        // }
        // chrome.downloads.download(
        //   {
        //     url: dataUrl,
        //     filename,
        //     conflictAction: "uniquify",
        //     saveAs: false,
        //   },
        //   (downloadId) => { ... },
        // );
        void message;
        sendResponse({
          success: true,
          skipped: true,
          message: "本机截图落盘已关闭",
        });
        return true;
      }

      case "SAVE_RESUME_JSON": {
        // 【本机落盘已关闭】AI 记录仍可写 chrome.storage，不写下载夹
        // const fileContent = message.content || "";
        // const filename = message.filename || "招聘速聊助手_resumes/resume.txt";
        // ... chrome.downloads.download(...)
        void message;
        sendResponse({
          success: true,
          skipped: true,
          message: "本机 JSON/TXT 落盘已关闭",
        });
        return true;
      }

      default:
        sendResponse({ status: "unknown_message_type" });
    }
  } catch (error) {
    console.error("处理消息时出错:", error);
    sendResponse({ status: "error", error: error.message });
  }

  return true;
});
