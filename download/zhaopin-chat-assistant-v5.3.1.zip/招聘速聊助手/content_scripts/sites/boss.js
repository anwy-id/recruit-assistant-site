import { BaseParser } from "./common.js";
import { captureFullResumeScreenshot } from "./resume_screenshot.js";
import { saveScreenshotBatch } from "./screenshot_store.js";
import {
  buildPartsFromFilenames,
  stitchScreenshotParts,
} from "./screenshot_merge.js";

/** 运行日志只保留状态句 */
function isBossStatusRuntimeLog(message) {
  const t = String(message || "").trim();
  return (
    /^已经触达/.test(t) ||
    /^已跳过/.test(t) ||
    /^已打招呼\s*\d+\s*人/.test(t) ||
    /^已求简历\s*\d+\s*人/.test(t) ||
    /^已简历回传\s*\d+\s*人/.test(t) ||
    /^日志已清空/.test(t)
  );
}

// VERBOSE_RUNTIME_LOGS=false 时拦截明细 LOG_MESSAGE，只放行状态句
(function muteVerboseBossRuntimeLogs() {
  if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) return;
  if (chrome.runtime.sendMessage.__招聘速聊助手_muted) return;
  const raw = chrome.runtime.sendMessage.bind(chrome.runtime);
  function wrapped(message, ...rest) {
    if (message && message.type === "LOG_MESSAGE") {
      const verbose =
        typeof window !== "undefined" &&
        window.招聘速聊助手_CONFIG?.VERBOSE_RUNTIME_LOGS !== false;
      if (!verbose && !isBossStatusRuntimeLog(message.data?.message)) {
        const cb = rest.find((x) => typeof x === "function");
        if (cb) cb({ ok: true, muted: true });
        return;
      }
    }
    return raw(message, ...rest);
  }
  wrapped.__招聘速聊助手_muted = true;
  chrome.runtime.sendMessage = wrapped;
})();

class BossParser extends BaseParser {
  constructor() {
    super();
    // 定义完整的 class 名称
    //新牛人 recommend-card-list
    this.fullClasses = {
      container: "card-list",
      items: [
        "candidate-card-wrap",
        "geek-info-card",
        "card-container",
        "card-inner clear-fix",
      ],
      name: "name",
      age: "job-card-left_labels__wVUfs",
      education: "base-info join-text-wrap",
      university: "content join-text-wrap",
      description: "content",
      clickTarget: [
        "btn btn-greet",
        "btn btn-getcontact search-btn-tip btn-prop-common prop-card-chat",
      ],
    };
    this.urlInfo = {
      url: "/web/chat/recommend",
      site: "推荐牛人",
    };

    // 定义部分 class 名称（用于模糊匹配）
    this.selectors = {
      container: "card-list",
      items: [
        "candidate-card-wrap",
        "card-inner clear-fix",
        "card-container",
        "geek-info-card",
      ],
      name: "name",
      age: ["job-card-left"],
      education: ["base-info join-text-wrap", "geek-info-detail"],
      university: "content join-text-wrap",
      description: "content",
      clickTarget: [
        "btn btn-greet",
        "btn btn-getcontact search-btn-tip btn-prop-common prop-card-chat",
      ],
      activeText: "active-text",
      continueButton: ["btn btn-continue btn-outline"],
      phoneButton: "operate-item",

      extraSelectors: [
        { prefix: "salary-text", type: "薪资" },
        { prefix: "job-info-primary", type: "基本信息" },
        { prefix: "tags-wrap", type: "标签" },
        { prefix: "content join-text-wrap", type: "公司信息" },
      ],
      // 同事是否沟通过
      isContacted: ["colleague-collaboration"],
    };

    // BOSS特定的选择器
    this.detailSelectors = {
      detailLink: [
        "card-inner common-wrap",
        "card-inner clear-fix",
        "candidate-card-wrap",
        "card-inner blue-collar-wrap",
        "card-container",
        "geek-info-card",
        "card-inner new-geek-wrap",
        "btn btn-greet",
        "candidate-card-wrap css-type-1",
        "card-inner common-wrap css-type-1",
      ],
      closeButton: [
        "boss-popup__close",
        "resume-custom-close",
        "boss-popup__close",
        "dialog-wrap active",
      ],
      closeButtonXpath: ['//*[@id="boss-dynamic-dialog-1j38fleo5"]/div/div[2]'],
      // 消息提示
      messageTip: "chat-global-entry",
      //消息列表元素
      messageListItem: "friend-list-item",
      // 沟通页聊天区
      chatContainer: [
        "chat-conversation",
        "chat-history",
        "message-list",
        "im-chat",
        "chat-content",
      ],
      messageMyself: ["item-myself", "message-item-self", "item-me"],
      messageFriend: ["item-friend", "message-item-friend", "item-geek"],
      messageSystem: ["item-system", "message-system"],
    };

    this.askResumeRunState = {
      loggedOnce: new Set(),
      aiDecisions: new Map(),
      completedSessions: new Set(),
      sessionUiAttempts: new Map(),
      bossRejectScriptSynced: false,
    };

    /** @type {Map<string, { initiator: 'hr' | 'candidate' | 'unknown', source: string }>} */
    this.friendInitiatorCache = new Map();

    /** @type {Map<string, { resumeRequestSent: boolean, resumeReceived: boolean, candidateReplied: boolean, source?: string }>} */
    this.sessionResumeCache = new Map();

    /** @type {Map<string, { geekCard?: object, name?: string }>} */
    this.geekDetailCache = new Map();

    /** @type {Array<{ name: string, resolve: (value: object|null) => void, timer: number }>} */
    this._geekDetailWaiters = [];

    this._lastResumeViewAt = 0;
    this._askResumeRateLimitedUntil = 0;

    // 初始化数据拦截监听
    this.initDataInterceptor();
  }

  /** @param {string} url */
  static isRecommendPage(url = "") {
    return /zhipin\.com/.test(url) && url.includes("/web/chat/recommend");
  }

  /** 沟通页：仅 /web/chat/index（求简历、简历回传） */
  /** @param {string} url */
  static isChatPage(url = "") {
    return (
      /zhipin\.com/.test(url) &&
      /\/web\/chat\/index(?:[/?#]|$)/i.test(String(url || ""))
    );
  }

  /**
   * 从文档集合中收集沟通页会话列表项
   * @param {Document[]} documents
   */
  collectChatSessionItems(documents) {
    const items = [];
    const seenElements = new Set();
    const seenKeys = new Set();
    const listItemClass = this.detailSelectors.messageListItem;

    const addItem = (element, doc, clickTarget) => {
      if (!element || seenElements.has(element)) return;

      const sessionItem = {
        element,
        doc,
        clickTarget: clickTarget || element,
      };
      const key = this.getSessionKey(sessionItem);
      if (seenKeys.has(key)) return;

      seenElements.add(element);
      seenKeys.add(key);
      items.push(sessionItem);
    };

    for (const doc of documents) {
      // 策略 1：friend-list-item（旧版沟通列表）
      doc
        .querySelectorAll(`[class*="${listItemClass}"]`)
        .forEach((element) => {
          const clickTarget =
            element.querySelector('[class*="geek-item-wrap"]') || element;
          addItem(element, doc, clickTarget);
        });

      // 策略 2：role=listitem（新版沟通列表，与简历下载器一致）
      doc.querySelectorAll('[role="group"] [role="listitem"]').forEach((element) => {
        const clickTarget =
          element.querySelector('[class*="geek-item-wrap"]') ||
          element.querySelector(".geek-item-wrap") ||
          element;
        addItem(element, doc, clickTarget);
      });

      // 策略 3：直接匹配 geek-item-wrap，归并到父级列表项
      doc.querySelectorAll('[class*="geek-item-wrap"]').forEach((wrap) => {
        const parent =
          wrap.closest('[role="listitem"]') ||
          wrap.closest(`[class*="${listItemClass}"]`) ||
          wrap;
        addItem(parent, doc, wrap);
      });
    }

    return items;
  }

  /**
   * 调试用：统计各选择器命中数量
   * @param {Document[]} documents
   */
  diagnoseChatSessionScan(documents) {
    let friendList = 0;
    let roleList = 0;
    let geekWrap = 0;

    for (const doc of documents) {
      friendList += doc.querySelectorAll(
        `[class*="${this.detailSelectors.messageListItem}"]`,
      ).length;
      roleList += doc.querySelectorAll('[role="group"] [role="listitem"]').length;
      geekWrap += doc.querySelectorAll('[class*="geek-item-wrap"]').length;
    }

    return { documents: documents.length, friendList, roleList, geekWrap };
  }

  /**
   * @param {{ element: Element }} sessionItem
   */
  getSessionDisplayName(sessionItem) {
    const el = sessionItem.element;
    const nameSelectors = [
      '[class*="geek-name"]',
      '[class*="name-text"]',
      '[class*="title"]',
      ".name",
    ];

    for (const selector of nameSelectors) {
      const nameEl = el.querySelector(selector);
      const text = nameEl?.textContent?.trim();
      if (text) return text.slice(0, 40);
    }

    const raw = el.textContent?.replace(/\s+/g, " ").trim() || "";
    return raw.slice(0, 40) || "未知会话";
  }

  /**
   * 从会话列表项解析性别（优先 SVG use 图标，其次文本）
   * @param {{ element: Element }} sessionItem
   */
  extractGenderFromSessionItem(sessionItem) {
    const el = sessionItem?.element;
    if (!el) return "";
    const fromIcon = this.extractGenderFromSvgIcons(el);
    if (fromIcon) return fromIcon;
    const text = el.textContent?.replace(/\s+/g, " ").trim() || "";
    return this.extractGenderFromText(text);
  }

  /**
   * 从 SVG <use> 的 href / xlink:href 解析性别
   * 推荐牛人卡片：#icon-icon-woman / #icon-icon-man（单数）
   * 沟通页常见：#icon-icon-women / #icon-icon-men（复数）
   * 女必须先于男：woman 里含 man，women 里含 men
   * @param {string} href
   */
  parseGenderFromIconHref(href) {
    if (!href) return "";
    const s = String(href).toLowerCase();
    if (
      s.includes("woman") ||
      s.includes("women") ||
      s.includes("female") ||
      s.includes("icon-nv") ||
      s.includes("icon-girl")
    ) {
      return "女";
    }
    if (
      s.includes("icon-icon-man") ||
      s.includes("icon-icon-men") ||
      s.includes("icon-man") ||
      s.includes("icon-men") ||
      /(?:^|[^a-z])man(?:[^a-z]|$)/.test(s) ||
      /(?:^|[^a-z])men(?:[^a-z]|$)/.test(s) ||
      s.includes("male") ||
      s.includes("icon-nan") ||
      s.includes("icon-boy")
    ) {
      return "男";
    }
    return "";
  }

  /**
   * 读取单个 <use> 节点上的性别
   * @param {Element} useEl
   */
  extractGenderFromUseNode(useEl) {
    if (!useEl) return "";
    const hrefs = [
      useEl.getAttribute("xlink:href"),
      useEl.getAttribute("href"),
      useEl.getAttributeNS?.("http://www.w3.org/1999/xlink", "href"),
      useEl.href?.baseVal,
      useEl.href?.animVal,
    ];
    for (const href of hrefs) {
      const gender = this.parseGenderFromIconHref(href);
      if (gender) return gender;
    }
    return "";
  }

  /**
   * 在根节点（或文档）内查找性别图标 <use>
   * 优先右侧聊天区 / 简历浮层，避免误读左侧无关图标
   * @param {ParentNode|Document|Element|null} root
   * @param {{ preferRightPanel?: boolean }} [options]
   */
  extractGenderFromSvgIcons(root, options = {}) {
    if (!root) return "";

    const preferRight = options.preferRightPanel !== false;
    const viewWidth =
      (typeof window !== "undefined" && window.innerWidth) || 1920;
    const minLeft = viewWidth * 0.28;

    /** @type {Element[]} */
    let useNodes = [];
    try {
      useNodes = Array.from(
        root.querySelectorAll?.(
          'use[href*="icon"], use[xlink\\:href*="icon"], use[href*="woman"], use[href*="women"], use[href*="man"], use[href*="men"], use[xlink\\:href*="woman"], use[xlink\\:href*="women"], use[xlink\\:href*="man"], use[xlink\\:href*="men"], use',
        ) || [],
      );
    } catch {
      try {
        useNodes = Array.from(root.querySelectorAll?.("use") || []);
      } catch {
        useNodes = [];
      }
    }

    // 先扫带 women/men 的 use，再扫全部
    const scored = useNodes.map((el) => {
      const href =
        el.getAttribute("xlink:href") ||
        el.getAttribute("href") ||
        el.getAttributeNS?.("http://www.w3.org/1999/xlink", "href") ||
        el.href?.baseVal ||
        "";
      const hrefLower = String(href).toLowerCase();
      let score = 0;
      if (/woman|women|man|men|male|female/.test(hrefLower)) score += 10;
      if (/icon-icon-/.test(hrefLower)) score += 5;

      if (preferRight) {
        try {
          const rect = el.getBoundingClientRect?.();
          if (rect && rect.width > 0 && rect.left >= minLeft) score += 8;
          // 聊天头 / 简历区
          if (
            el.closest?.(
              '[class*="chat-header"], [class*="chat-top"], [class*="im-top"], [class*="base-info"], [class*="geek-info"], [class*="resume"], [class*="dialog"], [class*="profile"], [class*="name"]',
            )
          ) {
            score += 6;
          }
          // 左侧会话列表降权（但会话项单独调用时 preferRight 可关）
          if (
            el.closest?.(
              '[class*="friend-list"], [class*="geek-list"], [role="group"] [role="listitem"]',
            )
          ) {
            score -= 4;
          }
        } catch {
          /* ignore */
        }
      }

      return { el, score, href };
    });

    scored.sort((a, b) => b.score - a.score);

    for (const item of scored) {
      const gender = this.extractGenderFromUseNode(item.el);
      if (gender) return gender;
    }

    return "";
  }

  /**
   * 从右侧聊天区 / 简历浮层解析性别（优先 SVG 性别图标）
   * @param {Document[]} documents
   */
  extractGenderFromChatDocuments(documents) {
    const docs = documents || this.collectAccessibleDocuments(true);

    // 1) 全局扫 use 图标（右侧加权）
    for (const doc of docs) {
      const fromIcon = this.extractGenderFromSvgIcons(doc, {
        preferRightPanel: true,
      });
      if (fromIcon) return fromIcon;
    }

    // 2) 重点区域再扫一遍（header / 简历浮层）
    const focusSelectors = [
      '[class*="chat-header"]',
      '[class*="chat-top"]',
      '[class*="im-top"]',
      '[class*="base-info"]',
      '[class*="geek-info"]',
      '[class*="resume"]',
      '[class*="dialog-wrap"]',
      '[class*="boss-dialog"]',
      '[class*="resume-detail"]',
      '[class*="profile"]',
      '[class*="name-box"]',
      '[class*="user-info"]',
    ].join(",");

    for (const doc of docs) {
      for (const root of doc.querySelectorAll(focusSelectors)) {
        const fromIcon = this.extractGenderFromSvgIcons(root, {
          preferRightPanel: false,
        });
        if (fromIcon) return fromIcon;
      }
    }

    // 3) 文本兜底
    const chunks = [];
    for (const doc of docs) {
      for (const root of doc.querySelectorAll(focusSelectors)) {
        const text = root.textContent?.replace(/\s+/g, " ").trim();
        if (text && text.length < 800) {
          chunks.push(text);
        }
      }
    }

    for (const text of chunks) {
      const gender = this.extractGenderFromText(text);
      if (gender) return gender;
    }
    return "";
  }

  /**
   * 从 geek 详情缓存按姓名匹配性别
   * @param {string} name
   */
  resolveGenderFromGeekCache(name) {
    if (!name || !this.geekDetailCache?.size) return "";

    const normalizedKey =
      typeof this.normalizePersonName === "function"
        ? this.normalizePersonName(name)
        : name;
    if (normalizedKey && this.geekDetailCache.has(normalizedKey)) {
      const direct = this.geekDetailCache.get(normalizedKey);
      const gender = this.resolveCandidateGender(direct);
      if (gender && gender !== "未知") return gender;
    }

    for (const [, entry] of this.geekDetailCache) {
      const entryName =
        entry?.name ||
        entry?.geekCard?.geekName ||
        entry?.geekCard?.name ||
        "";
      if (entryName && this.namesLikelyMatch(name, entryName)) {
        const gender = this.resolveCandidateGender(entry);
        if (gender && gender !== "未知") return gender;
      }
    }

    return "";
  }

  /**
   * 解析「当前沟通中」候选人的姓名与性别
   * @param {{ element: Element }} sessionItem
   * @param {Document[]} [documents]
   * @returns {Promise<{ name: string, gender: string }>}
   */
  async getActiveChatEmployeeIdentity(sessionItem, documents) {
    const docs = documents || this.collectAccessibleDocuments(true);
    const sessionName = this.getSessionDisplayName(sessionItem);
    const panelName = this.getActiveChatPanelGeekName(docs);
    const name =
      (panelName && this.namesLikelyMatch(sessionName, panelName)
        ? panelName
        : "") ||
      panelName ||
      sessionName ||
      "未知";

    // 沟通页点开后性别图标最准：<use xlink:href="#icon-icon-women|men">
    let gender =
      this.extractGenderFromChatDocuments(docs) ||
      this.extractGenderFromSessionItem(sessionItem) ||
      this.resolveGenderFromGeekCache(name) ||
      this.resolveGenderFromGeekCache(sessionName) ||
      "";

    if (!gender) {
      try {
        const apiCandidate = await this.waitForGeekDetailApi(name, 1500);
        if (apiCandidate) {
          gender = this.resolveCandidateGender(apiCandidate) || "";
        }
      } catch {
        /* ignore */
      }
    }

    // 打开在线简历后浮层里再补扫一次图标
    if (!gender || gender === "未知") {
      const again = this.extractGenderFromChatDocuments(
        this.collectAccessibleDocuments(true),
      );
      if (again) gender = again;
    }

    if (!gender || gender === "未知") {
      gender = "未知";
    }

    return { name, gender };
  }

  /**
   * 从图片分析接口响应中尽量提取可读简历文本
   * @param {any} response
   * @returns {string}
   */
  extractTextFromAnalyzeImageResponse(response) {
    if (response == null) return "";
    if (typeof response === "string") return response.trim();

    const visit = (value, depth = 0) => {
      if (depth > 8 || value == null) return "";
      if (typeof value === "string") return value.trim();
      if (typeof value === "number" || typeof value === "boolean") {
        return String(value);
      }
      if (typeof value !== "object") return "";

      // 常见业务错误不作为简历正文
      if (value.error && typeof value.error === "string" && !value.data) {
        return "";
      }

      for (const key of [
        "output_text_0",
        "output_text_1",
        "output_text",
        "resume_text",
        "resumeText",
        "resume",
        "content",
        "text",
        "answer",
        "result",
        "output",
        "message",
        "msg",
        "data",
        "response",
      ]) {
        if (value[key] != null) {
          const nested = visit(value[key], depth + 1);
          if (nested && nested.length > 2) return nested;
        }
      }

      for (const key of Object.keys(value)) {
        if (/^output_text_\d+$/i.test(key) && value[key] != null) {
          const nested = visit(value[key], depth + 1);
          if (nested && nested.length > 2) return nested;
        }
      }

      // 数组拼接
      if (Array.isArray(value)) {
        const parts = value
          .map((item) => visit(item, depth + 1))
          .filter(Boolean);
        if (parts.length) return parts.join("\n");
      }

      try {
        const json = JSON.stringify(value);
        // 过短或纯错误对象不采用
        if (json && json.length > 20 && !/"error"\s*:/.test(json)) {
          return json;
        }
      } catch {
        /* ignore */
      }
      return "";
    };

    // 优先 data 层
    if (response.data != null) {
      const fromData = visit(response.data, 0);
      if (fromData) return fromData;
    }
    return visit(response, 0);
  }

  /**
   * 将图片分析结果组装为一键打招呼同款「简历信息」文本
   * @param {string} name
   * @param {string} gender
   * @param {any} analyzeResponse
   */
  buildResumeInfoFromAnalyzeResponse(name, gender, analyzeResponse) {
    const extracted = this.extractTextFromAnalyzeImageResponse(analyzeResponse);
    const lines = [
      `姓名：${name || "未知"}`,
      `性别：${gender || "未知"}`,
    ];
    if (extracted) {
      lines.push("", "【图片识别简历信息】", extracted);
    } else {
      lines.push(
        "",
        "【图片识别简历信息】",
        "（接口已返回但未解析到正文，原始响应已附在下方）",
      );
      try {
        lines.push(JSON.stringify(analyzeResponse).slice(0, 4000));
      } catch {
        lines.push(String(analyzeResponse || "").slice(0, 4000));
      }
    }
    return lines.join("\n");
  }

  /**
   * 用一键打招呼同款伊利 AI 接口判断简历是否匹配
   * @param {string} resumeInfoText
   * @returns {Promise<{ isok: boolean, msg: string }>}
   */
  async judgeResumeWithGreetAI(resumeInfoText) {
    // 调试开关：强制全部判定为「否」，用于验证拒简历流程
    if (window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG?.forceAiDecisionNo === true) {
      return {
        isok: false,
        msg: "调试：强制判定为否（forceAiDecisionNo）",
      };
    }
    // 调试开关：强制全部判定为「是」，用于验证求简历流程
    if (window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG?.forceAiDecisionYes === true) {
      return {
        isok: true,
        msg: "调试：强制判定为是（forceAiDecisionYes）",
      };
    }

    if (!resumeInfoText || !String(resumeInfoText).trim()) {
      return { isok: false, msg: "简历信息为空，无法 AI 判断" };
    }

    // 优先使用 content script 注入的求简历/打招呼 AI 决策函数
    if (typeof this.performAskResumeAIDecision === "function") {
      return this.performAskResumeAIDecision(resumeInfoText);
    }
    if (typeof this.performGreetAIDecision === "function") {
      return this.performGreetAIDecision(resumeInfoText);
    }

    // 兜底：走 background → 宣双 /ai_agent/execute_text/
    const settings = this.getAskResumeSettings() || this.aiSettings || {};
    const formatList = (keywords) =>
      (Array.isArray(keywords) ? keywords : [])
        .filter(Boolean)
        .join("、") || "无";

    try {
      const result = await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          {
            action: "YILI_AGENT_REQUEST",
            input_text_0: resumeInfoText,
            input_text_1: formatList(settings.keywords),
            input_text_2: formatList(settings.excludeKeywords),
            timeoutMs:
              window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG?.aiTimeoutMs ||
              window.招聘速聊助手_CONFIG?.EXECUTE_TEXT_API?.timeoutMs ||
              180000,
          },
          (response) => {
            if (chrome.runtime.lastError) {
              resolve({
                success: false,
                error: chrome.runtime.lastError.message,
              });
              return;
            }
            resolve(response || { success: false, error: "AI 无响应" });
          },
        );
      });

      if (!result?.success) {
        return { isok: false, msg: result?.error || "AI 请求失败" };
      }

      const text =
        typeof result.response === "string"
          ? result.response
          : JSON.stringify(result.response || {});
      const jsonMatch = text.match(/\{[\s\S]*?"decision"[\s\S]*?\}/);
      if (jsonMatch) {
        try {
          const parsed = JSON.parse(jsonMatch[0]);
          return {
            isok: String(parsed.decision || "").includes("是"),
            msg: parsed.reason || "未提供原因",
          };
        } catch {
          /* fallthrough */
        }
      }
      if (/是|匹配|合适|符合/.test(text) && !/否|不匹配|不合适|不符合/.test(text)) {
        return { isok: true, msg: text.slice(0, 80) };
      }
      return { isok: false, msg: text.slice(0, 80) || "AI 未给出明确结论" };
    } catch (error) {
      return { isok: false, msg: error.message || String(error) };
    }
  }

  /**
   * 调用 background 上传拼接后的简历长图
   * @param {{ name: string, gender: string, dataUrl: string, filename?: string }} payload
   */
  async uploadMergedResumeImage(payload) {
    const name = payload.name || "未知";
    const gender = payload.gender || "未知";
    const dataUrl = payload.dataUrl;
    if (!dataUrl) {
      return { success: false, error: "缺少拼接图片数据" };
    }

    const safeName = String(name)
      .replace(/[\\/:*?"<>|]/g, "_")
      .trim()
      .slice(0, 40) || "unknown";
    const filename =
      payload.filename ||
      `${safeName}_${new Date().toISOString().replace(/[-:TZ.]/g, "").slice(0, 14)}.png`;

    const input_text_0 = `姓名：${name}\n性别：${gender}`;

    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(
          {
            action: "ANALYZE_IMAGE_UPLOAD",
            dataUrl,
            filename,
            input_text_0,
          },
          (response) => {
            if (chrome.runtime.lastError) {
              resolve({
                success: false,
                error: chrome.runtime.lastError.message,
              });
              return;
            }
            resolve(response || { success: false, error: "上传无响应" });
          },
        );
      } catch (error) {
        resolve({
          success: false,
          error: error.message || String(error),
        });
      }
    });
  }

  /**
   * @param {{ element: Element }} sessionItem
   */
  getSessionKey(sessionItem) {
    const el = sessionItem.element;
    const uid =
      el.getAttribute("data-id") ||
      el.getAttribute("data-uid") ||
      el.getAttribute("key") ||
      "";
    const name = this.getSessionDisplayName(sessionItem);
    return uid ? `uid:${uid}` : `name:${name}`;
  }

  /**
   * @param {Document[]} documents
   */
  getChatAreaText(documents) {
    const chunks = [];
    const seen = new Set();

    for (const doc of documents) {
      for (const prefix of this.detailSelectors.chatContainer) {
        doc.querySelectorAll(`[class*="${prefix}"]`).forEach((el) => {
          if (seen.has(el)) return;
          seen.add(el);
          const text = el.textContent?.replace(/\s+/g, " ").trim();
          if (text) chunks.push(text);
        });
      }
    }

    if (!chunks.length) {
      for (const doc of documents) {
        doc.querySelectorAll('[class*="message"], [class*="chat"]').forEach((el) => {
          if (seen.has(el)) return;
          if (el.children.length > 6) return;
          seen.add(el);
          const text = el.textContent?.replace(/\s+/g, " ").trim();
          if (text && text.length < 500) chunks.push(text);
        });
      }
    }

    return chunks.join(" ");
  }

  /**
   * @param {Document[]} documents
   * @param {string} [expandedText]
   */
  getExpandedChatText(documents, expandedText) {
    if (expandedText) return expandedText;

    const parts = [this.getChatAreaText(documents)];
    for (const msg of this.collectChatMessageItems(documents)) {
      if (msg.text) parts.push(msg.text);
    }

    for (const doc of documents) {
      doc
        .querySelectorAll(
          '[class*="operate"], [class*="toolbar"], [class*="chat-header"], [class*="im-top"]',
        )
        .forEach((el) => {
          const text = el.textContent?.replace(/\s+/g, " ").trim();
          if (text && text.length < 400) parts.push(text);
        });
    }

    return parts.join(" ");
  }

  /**
   * @param {object} msg
   */
  getMessageBodyText(msg) {
    if (!msg || typeof msg !== "object") return "";
    const body = msg.body;
    if (typeof body === "string") return body;
    if (body && typeof body === "object") {
      return (
        body.text ||
        body.pushText ||
        body.content ||
        body.title ||
        body.desc ||
        ""
      );
    }
    return msg.text || msg.pushText || msg.content || msg.title || "";
  }

  /**
   * @param {object[]} messages
   */
  extractChatHistorySignals(messages) {
    const signals = {
      resumeRequestSent: false,
      resumeReceived: false,
      candidateReplied: false,
    };

    if (!Array.isArray(messages)) return signals;

    for (const msg of messages) {
      const body = this.getMessageBodyText(msg).replace(/\s+/g, " ").trim();
      const msgType = msg.msgType ?? msg.type ?? msg.body?.type ?? msg.body?.msgType;
      const fromType = msg.fromType ?? msg.from ?? msg.senderType;

      if (
        /简历请求已发送|已向.{0,12}索要简历|已发送简历请求|简历索取请求已发送|您已向.{0,12}索要简历|您已向牛人索要简历|已向候选人发送简历|索要在线简历|请求查看在线简历|已向对方索要/.test(
          body,
        )
      ) {
        signals.resumeRequestSent = true;
      }

      // 仅明确「对方已发送/投递附件简历」类文案；不要用宽泛的「附件简历」二字单独命中
      if (
        /对方已发送简历|牛人已发送简历|已收到您的简历|对方投递了简历|牛人投递了简历|发送了一份简历|对方发送了简历|牛人发送了简历|已同意发送简历|向您发送了简历|发送了附件简历|发来了附件简历|对方发送了附件简历/.test(
          body,
        )
      ) {
        signals.resumeReceived = true;
      }

      const isCandidate =
        fromType === 2 ||
        fromType === "2" ||
        fromType === "geek" ||
        fromType === "candidate";
      if (
        isCandidate &&
        body.length > 0 &&
        !this.isSystemMessageText(body)
      ) {
        signals.candidateReplied = true;
      }
    }

    if (signals.resumeReceived) {
      signals.candidateReplied = true;
    }

    return signals;
  }

  /**
   * @param {string} name
   * @param {{ resumeRequestSent?: boolean, resumeReceived?: boolean, candidateReplied?: boolean }} signals
   */
  cacheSessionResumeStatus(name, signals) {
    const key = this.normalizePersonName(name);
    if (!key) return;

    const prev = this.sessionResumeCache.get(key) || {
      resumeRequestSent: false,
      resumeReceived: false,
      candidateReplied: false,
    };

    this.sessionResumeCache.set(key, {
      resumeRequestSent: prev.resumeRequestSent || !!signals.resumeRequestSent,
      resumeReceived: prev.resumeReceived || !!signals.resumeReceived,
      candidateReplied: prev.candidateReplied || !!signals.candidateReplied,
      source: "chat-history-api",
      _cacheName: key,
    });
  }

  /**
   * @param {string} name
   */
  getResumeStatusFromCache(name) {
    const defaults = {
      resumeRequestSent: false,
      resumeReceived: false,
      candidateReplied: false,
      source: "",
    };
    const key = this.normalizePersonName(name);
    if (!key) return defaults;

    if (this.sessionResumeCache.has(key)) {
      return { ...defaults, ...this.sessionResumeCache.get(key) };
    }

    return defaults;
  }

  /**
   * 右侧聊天面板根节点（排除左侧会话列表）
   * @param {Document[]} documents
   * @returns {Element[]}
   */
  getChatPanelRoots(documents) {
    const candidates = [];
    const panelSelectors = [
      '[class*="chat-conversation"]',
      '[class*="chat-content"]',
      '[class*="chat-box"]',
    ];

    for (const doc of documents) {
      for (const selector of panelSelectors) {
        doc.querySelectorAll(selector).forEach((el) => {
          if (el.closest('[class*="friend-list"], [class*="geek-list"]')) return;

          const rect = el.getBoundingClientRect();
          if (rect.width < 180 || rect.height < 120) return;
          if (!el.querySelector('[class*="message-item"], [class*="msg-item"]')) {
            return;
          }

          candidates.push({ el, left: rect.left });
        });
      }
    }

    candidates.sort((a, b) => b.left - a.left);
    const roots = [];
    for (const item of candidates) {
      if (!roots.includes(item.el)) roots.push(item.el);
      if (roots.length >= 2) break;
    }
    return roots;
  }

  namesLikelyMatch(expected = "", actual = "") {
    const left = this.normalizePersonName(expected);
    const right = this.normalizePersonName(actual);
    if (!left || !right) return false;
    if (left === right) return true;
    if (left.length >= 2 && right.length >= 2) {
      return left.includes(right) || right.includes(left);
    }
    return false;
  }

  isSessionNodeSelected(node) {
    if (!node) return false;

    const cls = typeof node.className === "string" ? node.className : "";
    if (/\b(active|selected|cur|current|is-active|highlight|on)\b/i.test(cls)) {
      return true;
    }
    if (node.getAttribute("aria-selected") === "true") return true;
    if (node.getAttribute("aria-current") === "true") return true;

    return false;
  }

  /**
   * @param {{ element: Element }} sessionItem
   */
  isSessionListItemSelected(sessionItem) {
    const el = sessionItem?.element;
    if (!el) return false;

    if (this.isSessionNodeSelected(el)) return true;
    if (
      el.querySelector(
        '[class*="active"], [class*="selected"], [class*="cur"], [class*="highlight"]',
      )
    ) {
      return true;
    }

    let node = el.parentElement;
    for (let depth = 0; depth < 5 && node; depth += 1) {
      if (this.isSessionNodeSelected(node)) return true;
      node = node.parentElement;
    }

    return false;
  }

  /**
   * @param {Document[]} documents
   */
  getActiveSessionNameFromList(documents) {
    const listSelectors = [
      `[class*="${this.detailSelectors.messageListItem}"][class*="active"]`,
      `[class*="${this.detailSelectors.messageListItem}"].active`,
      '[role="listitem"][class*="active"]',
      '[role="listitem"][aria-selected="true"]',
      '[class*="friend-list"] [class*="active"]',
      '[class*="geek-item-wrap"][class*="active"]',
    ];

    for (const doc of documents) {
      for (const selector of listSelectors) {
        const nodes = doc.querySelectorAll(selector);
        for (const node of nodes) {
          const itemEl =
            node.closest('[role="listitem"]') ||
            node.closest(`[class*="${this.detailSelectors.messageListItem}"]`) ||
            node;
          const name = this.getSessionDisplayName({ element: itemEl });
          if (name && name !== "未知会话") return name;
        }
      }
    }

    return "";
  }

  /**
   * @param {Document[]} documents
   * @param {string} expectedName
   */
  isNameInChatPanel(documents, expectedName) {
    const panelRoots = this.getChatPanelRoots(documents);

    for (const root of panelRoots) {
      let container = root;
      for (let depth = 0; depth < 6 && container; depth += 1) {
        const names = container.querySelectorAll(
          '[class*="geek-name"], [class*="name-text"], [class*="user-name"], [class*="chat-name"], [class*="title"]',
        );
        for (const el of names) {
          const text = el.textContent?.replace(/\s+/g, " ").trim();
          if (!text || text.length > 40 || /求简历|不合适|发送|简历/.test(text)) {
            continue;
          }
          if (this.namesLikelyMatch(expectedName, text)) return true;
        }
        container = container.parentElement;
      }
    }

    for (const doc of documents) {
      const viewWidth =
        doc.defaultView?.innerWidth || window.innerWidth || 1920;
      const minLeft = viewWidth * 0.28;
      const nodes = doc.querySelectorAll(
        '[class*="geek-name"], [class*="name-text"], [class*="user-name"], [class*="chat-name"]',
      );

      for (const el of nodes) {
        if (el.closest('[class*="friend-list"], [role="group"] [role="listitem"]')) {
          continue;
        }

        const rect = el.getBoundingClientRect();
        if (rect.width < 1 || rect.left < minLeft) continue;

        const text = el.textContent?.replace(/\s+/g, " ").trim();
        if (!text || text.length > 40) continue;
        if (this.namesLikelyMatch(expectedName, text)) return true;
      }
    }

    return false;
  }

  /**
   * 仅读取右侧聊天区当前候选人姓名（绝不使用左侧列表高亮，避免误判已切换）
   * @param {Document[]} documents
   */
  getActiveChatPanelGeekName(documents) {
    const viewWidth = window.innerWidth || 1920;
    const minLeft = viewWidth * 0.3;

    const headerSelectors = [
      '[class*="chat-header"] [class*="geek-name"]',
      '[class*="chat-header"] [class*="name-text"]',
      '[class*="chat-top"] [class*="geek-name"]',
      '[class*="im-top"] [class*="geek-name"]',
      '[class*="chat-user"] [class*="name"]',
      '[class*="top-info"] [class*="geek-name"]',
      '[class*="name-box"] [class*="geek-name"]',
      '[class*="conversation"] [class*="geek-name"]',
      '[class*="user-info"] [class*="name"]',
      '[class*="geek-name"]',
      '[class*="name-text"]',
    ];

    for (const doc of documents) {
      for (const selector of headerSelectors) {
        const nodes = doc.querySelectorAll(selector);
        for (const el of nodes) {
          if (
            el.closest(
              '[class*="friend-list"], [class*="geek-list"], [role="group"] [role="listitem"]',
            )
          ) {
            continue;
          }

          const rect = el.getBoundingClientRect();
          if (rect.width < 1 || rect.left < minLeft) continue;

          const text = el.textContent?.replace(/\s+/g, " ").trim();
          if (!text || text.length < 2 || text.length > 20) continue;
          if (/简历|沟通|职位|发送|不合适|在线|附件/.test(text)) continue;
          return text;
        }
      }
    }

    const panelSelectors = [
      '[class*="chat-conversation"]',
      '[class*="chat-content"]',
      '[class*="chat-box"]',
      '[class*="im-chat"]',
    ];

    for (const doc of documents) {
      for (const selector of panelSelectors) {
        for (const el of doc.querySelectorAll(selector)) {
          if (el.closest('[class*="friend-list"], [class*="geek-list"]')) continue;
          const rect = el.getBoundingClientRect();
          if (rect.left < minLeft || rect.width < 200) continue;

          const firstLine = el.innerText?.split("\n").find((line) => line.trim())?.trim();
          if (!firstLine) continue;
          const nameMatch =
            firstLine.match(
              /^([\u4e00-\u9fa5·]{2,8})(?:\s+刚刚活跃|\s+\d+岁|\s+在线|\s+离线|\s+\d+年|\s+本科|\s+硕士|\s+博士)/,
            ) ||
            firstLine.match(/^([\u4e00-\u9fa5·]{2,8})(?=\s)/);
          if (nameMatch?.[1]) return nameMatch[1].trim();
        }
      }
    }

    return "";
  }

  /**
   * @param {Document[]} documents
   */
  getActiveChatGeekName(documents) {
    const panelName = this.getActiveChatPanelGeekName(documents);
    if (panelName) return panelName;

    const fromList = this.getActiveSessionNameFromList(documents);
    if (fromList) return fromList;

    return "";
  }

  getChatSessionReadyReason(sessionItem, documents) {
    const expected = this.getSessionDisplayName(sessionItem);
    const active = this.getActiveChatPanelGeekName(documents);
    const resumeBlocking = this.isResumePanelBlocking(documents);

    if (resumeBlocking) {
      const resumeMatches = this.resumePanelShowsCandidate(documents, expected);
      if (!resumeMatches && active && !this.namesLikelyMatch(expected, active)) {
        return {
          ready: false,
          current: active,
          via: "resume-panel-blocking",
        };
      }
      if (!resumeMatches && !active) {
        return {
          ready: false,
          current: "未知",
          via: "resume-panel-blocking",
        };
      }
    }

    if (active && this.namesLikelyMatch(expected, active)) {
      return {
        ready: true,
        current: active,
        via: resumeBlocking ? "panel-header-resume-open" : "panel-header",
      };
    }
    // 右侧已显示其他候选人时，不再用模糊文本匹配误判为已切换
    if (
      !active &&
      !resumeBlocking &&
      this.isNameInChatPanel(documents, expected)
    ) {
      return {
        ready: true,
        current: expected,
        via: "panel-text",
      };
    }
    if (this.isSessionListItemSelected(sessionItem)) {
      return {
        ready: false,
        current: active || "未知",
        via: "list-selected-pending",
      };
    }

    return { ready: false, current: active || "未知", via: "none" };
  }

  /**
   * 当前会话是否已可采集（右侧已是目标人，无需再点列表）
   * @param {{ element: Element, clickTarget?: Element }} sessionItem
   * @param {Document[]} documents
   */
  isAskResumeSessionAlreadyReady(sessionItem, documents) {
    const docs = documents || this.collectAccessibleDocuments(true);
    const expected = this.getSessionDisplayName(sessionItem);
    const readyInfo = this.getChatSessionReadyReason(sessionItem, docs);
    const activePanelName = this.getActiveChatPanelGeekName(docs);
    const panelMatchesTarget =
      activePanelName && this.namesLikelyMatch(expected, activePanelName);

    if (
      readyInfo.ready &&
      !this.isResumePanelBlocking(docs) &&
      panelMatchesTarget
    ) {
      return true;
    }
    if (
      readyInfo.ready &&
      this.isResumePanelVisible(docs) &&
      this.resumePanelShowsCandidate(docs, expected)
    ) {
      return true;
    }
    // 列表已选中且右侧标题已是目标：视为就绪，避免重复点会话
    if (
      panelMatchesTarget &&
      this.isSessionListItemSelected(sessionItem) &&
      !this.isResumePanelBlocking(docs)
    ) {
      return true;
    }
    return false;
  }

  /**
   * 切换会话直到右侧聊天区显示目标候选人（避免同一会话无脑连点）
   * @param {{ element: Element, clickTarget?: Element }} sessionItem
   */
  async ensureChatSessionReadyForCollect(sessionItem) {
    const maxWait = this.getAskResumeTiming("chatReadyTimeoutMs", 5000);
    // 默认最多 2 次：先轻点，再强制；避免 force×3 连点
    const maxAttempts = this.getAskResumeTiming("sessionSwitchMaxAttempts", 2);
    const expected = this.getSessionDisplayName(sessionItem);

    let documents = this.collectAccessibleDocuments(true);

    if (this.isAskResumeSessionAlreadyReady(sessionItem, documents)) {
      return documents;
    }

    if (
      this.isResumePanelBlocking(documents) ||
      this.isResumePanelVisible(documents)
    ) {
      await this.dismissResumeViewToChat(sessionItem);
      documents = this.collectAccessibleDocuments(true);
      if (this.isAskResumeSessionAlreadyReady(sessionItem, documents)) {
        return documents;
      }
    }

    for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
      if (this.isAskResumeAborted?.()) break;

      const docsNow = this.collectAccessibleDocuments(true);
      if (
        this.isResumePanelBlocking(docsNow) ||
        this.isResumePanelVisible(docsNow)
      ) {
        await this.dismissResumeViewToChat(sessionItem);
        await this.waitForResumePanelHidden(2000);
      }

      // 再次确认：关闭简历后可能已经是目标会话
      documents = this.collectAccessibleDocuments(true);
      if (this.isAskResumeSessionAlreadyReady(sessionItem, documents)) {
        return documents;
      }

      // 第 1 次轻点，第 2 次起 force（减少「查看太频繁」）
      const useForce = attempt > 0;
      await this.openChatSession(sessionItem, { force: useForce });
      // 点击后多等一会再判就绪，避免标题未刷新误判
      await new Promise((resolve) => setTimeout(resolve, useForce ? 400 : 500));
      documents = await this.waitForChatSessionReady(sessionItem, maxWait);
      if (this.isAskResumeSessionAlreadyReady(sessionItem, documents)) {
        return documents;
      }

      const readyInfo = this.getChatSessionReadyReason(sessionItem, documents);
      const activeAfterSwitch = this.getActiveChatPanelGeekName(documents);
      if (
        readyInfo.ready &&
        !this.isResumePanelBlocking(documents) &&
        activeAfterSwitch &&
        this.namesLikelyMatch(expected, activeAfterSwitch)
      ) {
        return documents;
      }
      await new Promise((resolve) => setTimeout(resolve, 600));
    }

    return documents;
  }

  /**
   * @param {Document[]} documents
   * @param {{ element: Element }} sessionItem
   */
  isChatSessionReady(sessionItem, documents) {
    return this.getChatSessionReadyReason(sessionItem, documents).ready;
  }

  /**
   * @param {{ element: Element, clickTarget?: Element }} sessionItem
   */
  async waitForChatSessionReady(sessionItem, maxWaitMs) {
    const timeout =
      maxWaitMs ?? this.getAskResumeTiming("chatReadyTimeoutMs", 2200);
    const clickTarget =
      sessionItem.clickTarget ||
      sessionItem.element?.querySelector?.('[class*="geek-item-wrap"]') ||
      sessionItem.element;
    const start = Date.now();

    while (Date.now() - start < timeout) {
      const documents = this.collectAccessibleDocuments(true);
      if (this.isChatSessionReady(sessionItem, documents)) {
        return documents;
      }

      await new Promise((resolve) => setTimeout(resolve, 250));
    }

    return this.collectAccessibleDocuments(true);
  }

  /**
   * 仅收集聊天气泡文本（不含顶部工具栏「在线简历」等区域，避免误判）
   * @param {Document[]} documents
   */
  getChatMessagesText(documents) {
    return this.collectChatMessageItems(documents)
      .map((msg) => msg.text)
      .join(" ");
  }

  /**
   * @param {string} text
   */
  isResumeDeliveryMessage(text = "") {
    const normalized = text.replace(/\s+/g, " ").trim();
    if (!normalized) return false;
    // 求简历/在线简历相关，不算「已收到附件」
    if (
      /简历请求|索要简历|已向.*索要|请求.*简历|索取简历|在线简历|查看在线/.test(
        normalized,
      )
    ) {
      return false;
    }

    return /对方已发送简历|牛人已发送简历|对方发送了简历|牛人发送了简历|已收到您的简历|对方投递了简历|牛人投递了简历|发送了一份简历|已同意发送简历|向您发送了简历|牛人向您发送了简历|对方同意发送简历|对方发送了附件简历|牛人发送了附件简历|发来了附件简历|发送了附件简历/.test(
      normalized,
    );
  }

  /**
   * 是否为候选人「附件简历」卡片（勿把在线简历预览卡当成附件）
   * BOSS：message-card-wrap boss-green，非 blue
   * @param {Element} el
   */
  isCandidateResumeCardElement(el) {
    if (!el) return false;

    const cls = typeof el.className === "string" ? el.className : "";
    if (!/message-card-wrap/.test(cls)) return false;
    if (/\bblue\b/.test(cls)) return false;
    if (!/boss-green/.test(cls)) return false;

    const text = el.textContent?.replace(/\s+/g, " ") || "";
    // 仅在线简历入口/预览，不算已收附件
    if (/在线简历/.test(text) && !/附件/.test(text)) return false;

    // 必须有明确「附件/已发送/投递」语义，避免仅含「工作经历」的绿卡误判
    return /附件简历|简历附件|已发送简历|发送了简历|投递了简历|点击预览附件|预览附件|下载简历/.test(
      text,
    );
  }

  /**
   * 当前会话消息区是否存在候选人发来的「附件」简历卡片（不扫全页）
   * @param {Document[]} documents
   */
  hasCandidateResumeCard(documents) {
    const scanRoot = (root) => {
      const cards = root.querySelectorAll(
        '[class*="message-card-wrap"], [class*="message-card"], [class*="file-card"]',
      );
      for (const card of cards) {
        if (this.isCandidateResumeCardElement(card)) return true;
      }
      return false;
    };

    const roots = this.getCurrentChatMessageRoots(documents);
    for (const root of roots) {
      if (scanRoot(root)) return true;
    }

    // 不再全页扫 message-card-wrap：会把其他会话/浮层残留当成当前人有附件
    return false;
  }

  /**
   * 仅在「当前会话右侧消息列表」内找附件证据（禁止全页扫，否则会串会话）
   * @param {Document[]} documents
   * @returns {Element[]}
   */
  getCurrentChatMessageRoots(documents) {
    const roots = this.getChatPanelRoots(documents) || [];
    if (roots.length) return roots;

    // 兜底：常见消息列表容器（仍排除左侧会话列表）
    const fallback = [];
    const docs = documents || this.collectAccessibleDocuments(true);
    for (const doc of docs) {
      doc
        .querySelectorAll(
          '[class*="chat-message"], [class*="message-list"], [class*="msg-list"], [class*="conversation-message"]',
        )
        .forEach((el) => {
          if (el.closest('[class*="friend-list"], [class*="geek-list"], [role="group"]')) {
            return;
          }
          fallback.push(el);
        });
    }
    return fallback;
  }

  /**
   * 当前会话消息列表内是否有明确的附件简历入口（不做全页扫描）
   * @param {Document[]} documents
   */
  hasAttachmentResumeEntryInCurrentChat(documents) {
    const roots = this.getCurrentChatMessageRoots(documents);
    if (!roots.length) return false;

    for (const root of roots) {
      // 只看消息气泡/卡片，不看顶部工具栏
      const scope =
        root.querySelector(
          '[class*="message-list"], [class*="msg-list"], [class*="chat-message"], [class*="message-content"]',
        ) || root;

      const cards = scope.querySelectorAll(
        '[class*="message-card"], [class*="msg-card"], [class*="message-item"], [class*="msg-item"], [class*="file-card"], [class*="resume-card"]',
      );
      for (const card of cards) {
        const text = (card.textContent || "").replace(/\s+/g, " ").trim();
        if (!text || text.length > 200) continue;
        if (/在线简历/.test(text) && !/附件/.test(text)) continue;
        if (
          /附件简历|简历附件|发送了附件|发来了附件|点击预览附件|预览附件简历/.test(
            text,
          )
        ) {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * 本会话已确认「不是附件简历」——本轮不再走下载
   * @param {string} sessionKey
   */
  markResumeNotAttachment(sessionKey) {
    if (!sessionKey) return;
    if (!this._resumeNotAttachmentKeys) {
      this._resumeNotAttachmentKeys = new Set();
    }
    this._resumeNotAttachmentKeys.add(sessionKey);
  }

  isResumeNotAttachment(sessionKey) {
    if (!sessionKey) return false;
    return !!this._resumeNotAttachmentKeys?.has(sessionKey);
  }

  /**
   * @param {Document[]} documents
   * @returns {boolean}
   */
  detectResumeReceivedInChat(documents) {
    return this.detectResumeReceivedDetail(documents).received;
  }

  /**
   * 带来源的「已有附件简历」检测
   * 规则：只认「当前会话消息区」内的投递文案 / 附件卡片，绝不扫全页工具栏
   * @param {Document[]} documents
   * @param {{ sessionKey?: string }} [options]
   * @returns {{ received: boolean, source: string }}
   */
  detectResumeReceivedDetail(documents, options = {}) {
    const sessionKey = options.sessionKey || "";
    if (sessionKey && this.isResumeNotAttachment(sessionKey)) {
      return { received: false, source: "" };
    }

    // 1) 当前会话聊天气泡：明确「对方已发送/投递简历」
    if (
      this.collectChatMessageItems(documents).some((msg) =>
        this.isResumeDeliveryMessage(msg.text),
      )
    ) {
      return { received: true, source: "投递/发送简历文案" };
    }

    // 2) 当前会话消息区附件卡片（已收紧，不含在线简历预览）
    if (this.hasCandidateResumeCard(documents)) {
      return { received: true, source: "附件简历卡片" };
    }

    // 3) 当前会话消息列表内的附件入口（全页扫描已废弃，避免串会话）
    if (this.hasAttachmentResumeEntryInCurrentChat(documents)) {
      return { received: true, source: "当前会话附件入口" };
    }

    return { received: false, source: "" };
  }

  getResumeConsentPromptText() {
    return String(
      this.getAskResumeTiming(
        "resumeConsentPromptText",
        "对方想发送附件简历给您，您是否同意",
      ) || "",
    ).replace(/\s+/g, "");
  }

  isResumeConsentPromptText(text = "") {
    const needle = this.getResumeConsentPromptText();
    if (!needle) return false;
    return String(text || "").replace(/\s+/g, "").includes(needle);
  }

  /**
   * 当前右侧聊天里是否出现「对方想发送附件简历…是否同意」
   * @param {Document[]} documents
   * @returns {Element|null}
   */
  findResumeConsentPromptNode(documents) {
    const roots = [
      ...(this.getCurrentChatMessageRoots(documents) || []),
      ...(this.getChatPanelRoots(documents) || []),
    ];
    let best = null;
    let bestLen = Infinity;
    const seen = new Set();

    const consider = (el) => {
      if (!el || seen.has(el)) return;
      seen.add(el);
      const text = el.textContent || "";
      if (!this.isResumeConsentPromptText(text)) return;
      const len = text.replace(/\s+/g, "").length;
      if (len > 0 && len < bestLen) {
        bestLen = len;
        best = el;
      }
    };

    for (const root of roots) {
      consider(root);
      if (!root?.querySelectorAll) continue;
      root.querySelectorAll("div, p, span, li, section, a").forEach(consider);
    }
    return best;
  }

  nodesShareNearbyAncestor(a, b, maxDepth = 10) {
    if (!a || !b) return false;
    if (a === b || a.contains(b) || b.contains(a)) return true;
    let p = a;
    for (let i = 0; i < maxDepth && p; i++) {
      if (p.contains(b)) return true;
      p = p.parentElement;
    }
    return false;
  }

  pickResumeConsentAgreeFromWrap(wrap) {
    if (!wrap?.querySelectorAll) return null;
    const nodes = Array.from(
      wrap.querySelectorAll("a, button, [role='button'], span"),
    );
    const clickable = nodes.filter(
      (el) => this.isElementClickable(el) || this.isElementVisible?.(el),
    );
    const agreeText = String(
      this.getAskResumeTiming("resumeConsentAgreeText", "同意") || "同意",
    ).replace(/\s+/g, "");

    const byText = clickable.find((el) => {
      const t = (el.textContent || "").replace(/\s+/g, "");
      if (!t) return false;
      if (/拒绝|不同意|取消/.test(t)) return false;
      return t === agreeText || t.includes(agreeText);
    });
    if (byText) return byText;

    const links = clickable.filter((el) => el.tagName === "A");
    if (links.length >= 2) {
      const second = links[1];
      const t = (second.textContent || "").replace(/\s+/g, "");
      if (!/拒绝|不同意|取消/.test(t)) return second;
    }
    return null;
  }

  /**
   * 同意接收附件简历：优先用户提供的 a[2] XPath，再在提示卡片内找「同意」
   * @param {Document[]} documents
   * @returns {Element|null}
   */
  findResumeConsentAgreeButton(documents) {
    const docs = documents || this.collectAccessibleDocuments(true);
    const promptEl = this.findResumeConsentPromptNode(docs);
    if (!promptEl) return null;

    const xpath = this.getAskResumeTiming(
      "resumeConsentAgreeXPath",
      '//*[@id="container"]/div[1]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div/div/div[2]/a[2]',
    );
    const byXPath = this.evaluateXPathFirst(docs, xpath);
    if (byXPath && this.nodesShareNearbyAncestor(byXPath, promptEl, 12)) {
      const t = (byXPath.textContent || "").replace(/\s+/g, "");
      if (!/拒绝|不同意|取消/.test(t)) return byXPath;
    }

    let wrap = promptEl;
    for (let i = 0; i < 8 && wrap; i++) {
      const picked = this.pickResumeConsentAgreeFromWrap(wrap);
      if (picked) return picked;
      wrap = wrap.parentElement;
    }
    return null;
  }

  /**
   * 若当前聊天出现「对方想发送附件简历给您，您是否同意」，点击同意。
   * @param {Document[]} documents
   * @param {string} [name]
   * @returns {Promise<{ clicked: boolean, foundPrompt: boolean, documents: Document[] }>}
   */
  async acceptResumeConsentIfPresent(documents, name = "") {
    const docs = documents || this.collectAccessibleDocuments(true);
    const promptEl = this.findResumeConsentPromptNode(docs);
    if (!promptEl) {
      return { clicked: false, foundPrompt: false, documents: docs };
    }

    const prefix = name ? `${name}：` : "";
    const btn = this.findResumeConsentAgreeButton(docs);
    if (!btn) {
      this.emitRuntimeLog(
        `${prefix}聊天中出现「对方想发送附件简历…是否同意」，但未找到同意按钮`,
        "warning",
      );
      return { clicked: false, foundPrompt: true, documents: docs };
    }

    await this.waitHumanStep("同意接收附件简历");
    const clicked = await this.dispatchRealClick(btn);
    if (!clicked) {
      await this.gentleClickElement(btn);
    }
    this.emitRuntimeLog(`${prefix}已点击同意接收附件简历`, "success");
    await new Promise((resolve) => setTimeout(resolve, 1000));
    return {
      clicked: true,
      foundPrompt: true,
      documents: this.collectAccessibleDocuments(true),
    };
  }

  /**
   * @param {Document[]} documents
   * @param {string} [expandedText]
   */
  detectResumeRequestSent(documents, expandedText) {
    const text = this.getExpandedChatText(documents, expandedText);
    if (
      /简历请求已发送|已向.{0,12}索要简历|已发送简历请求|简历索取请求已发送|您已向.{0,12}索要简历|您已向牛人索要简历|已向候选人发送简历|索要在线简历|请求查看在线简历|已向对方索要|简历索取/.test(
        text,
      )
    ) {
      return true;
    }

    const button = this.findAskResumeButton(documents);
    const buttonText = button?.element?.textContent?.replace(/\s+/g, "") || "";
    if (/再次索要|已索要|已求过/.test(buttonText)) return true;

    return false;
  }

  /**
   * @param {Document[]} documents
   * @param {{ element: Element }} sessionItem
   */
  assessSessionStatus(documents, sessionItem) {
    const name = this.getSessionDisplayName(sessionItem);
    const key = sessionItem ? this.getSessionKey(sessionItem) : "";
    const expandedText = this.getExpandedChatText(documents);
    const cached = this.getResumeStatusFromCache(name);
    const button = this.findAskResumeButton(documents);

    const domCandidateReplied = this.collectChatMessageItems(documents).some(
      (msg) =>
        msg.side === "candidate" &&
        msg.text.length > 0 &&
        !this.isSystemMessageText(msg.text),
    );
    // 本会话已确认非附件：强制 false，避免反复走下载
    if (key && this.isResumeNotAttachment(key)) {
      return {
        candidateReplied:
          domCandidateReplied || cached.candidateReplied,
        resumeRequestSent:
          this.detectResumeRequestSent(documents, expandedText) ||
          cached.resumeRequestSent,
        resumeReceived: false,
        resumeReceivedSource: "",
        askResumeButtonClickable: !!button?.clickable,
        detectionSource: "denied-not-attachment",
      };
    }

    const resumeDetail = this.detectResumeReceivedDetail(documents, {
      sessionKey: key,
    });
    const domResumeReceived = !!resumeDetail.received;
    const domResumeRequestSent = this.detectResumeRequestSent(
      documents,
      expandedText,
    );
    // 默认不采用跨会话缓存的 resumeReceived，防止上一人有附件导致下一人误判
    // 仅当缓存姓名精确命中且来源为 chat-history 投递信号时才采纳
    const cacheOk =
      !!cached.resumeReceived &&
      cached.source === "chat-history-api" &&
      this.normalizePersonName(name) ===
        this.normalizePersonName(cached._cacheName || name);
    const resumeReceived = domResumeReceived || cacheOk;
    const resumeReceivedSource = domResumeReceived
      ? resumeDetail.source || "dom"
      : resumeReceived
        ? "接口历史投递"
        : "";
    return {
      candidateReplied:
        domCandidateReplied ||
        resumeReceived ||
        cached.candidateReplied,
      resumeRequestSent: domResumeRequestSent || cached.resumeRequestSent,
      resumeReceived,
      resumeReceivedSource,
      askResumeButtonClickable: !!button?.clickable,
      detectionSource: domResumeReceived
        ? "dom"
        : resumeReceived
          ? cached.source || "cache"
          : cached.source || "none",
    };
  }

  formatInitiatorSource(source = "") {
    const map = {
      "greet-record": "插件打招呼记录",
      "friend-list-api": "好友列表接口",
      "chat-history-api": "聊天记录接口",
      dom: "页面识别",
    };
    return map[source] || source || "未知来源";
  }

  formatSessionStatusLog(name, context, action) {
    const initiatorText =
      context.initiator === "hr"
        ? "HR主动"
        : context.initiator === "candidate"
          ? "候选人主动"
          : "未知";
    const yesNo = (value) => (value ? "是" : "否");
    const aiPart =
      context.aiMatched == null
        ? ""
        : ` | AI匹配=${yesNo(context.aiMatched)}${context.aiReason ? `（${context.aiReason}）` : ""}`;

    const resumePart = context.resumeReceived
      ? `是${context.resumeReceivedSource ? `（${context.resumeReceivedSource}）` : ""}`
      : "否";
    return `${name}：发起方=${initiatorText}（${this.formatInitiatorSource(context.source)}）${aiPart} | 候选人已回复=${yesNo(context.candidateReplied)} | 已求简历=${yesNo(context.resumeRequestSent)} | 已有简历=${resumePart} | 处理=${action}`;
  }

  getAskResumeSettings() {
    return this.askResumeSettings || {};
  }

  getAskResumeTiming(key, defaultValue) {
    const value = window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG?.[key];
    return value == null ? defaultValue : value;
  }

  /**
   * 读取全局操作节奏（打招呼 / 求简历 / 简历回传共用）
   * @param {"step"|"candidate"|"think"|"resumeRead"} kind
   */
  getHumanTimingRange(kind) {
    const t = window.招聘速聊助手_CONFIG?.TIMING || {};
    if (kind === "step") {
      const min = Number(t.stepDelayMinMs);
      const max = Number(t.stepDelayMaxMs);
      return {
        minMs: Number.isFinite(min) && min > 0 ? min : 500,
        maxMs: Number.isFinite(max) && max > 0 ? max : 2000,
      };
    }
    if (kind === "think") {
      const min = Number(t.thinkPauseMinMs);
      const max = Number(t.thinkPauseMaxMs);
      return {
        minMs: Number.isFinite(min) && min > 0 ? min : 2000,
        maxMs: Number.isFinite(max) && max > 0 ? max : 6000,
      };
    }
    if (kind === "resumeRead") {
      const min = Number(t.resumeReadMinMs);
      const max = Number(t.resumeReadMaxMs);
      return {
        minMs: Number.isFinite(min) && min > 0 ? min : 3000,
        maxMs: Number.isFinite(max) && max > 0 ? max : 8000,
      };
    }
    const min = Number(t.candidateGapMinMs);
    const max = Number(t.candidateGapMaxMs);
    return {
      minMs: Number.isFinite(min) && min > 0 ? min : 3000,
      maxMs: Number.isFinite(max) && max > 0 ? max : 5000,
    };
  }

  /** @param {number} minMs @param {number} maxMs */
  randomBetweenMs(minMs, maxMs) {
    const lo = Math.min(minMs, maxMs);
    const hi = Math.max(minMs, maxMs);
    return lo + Math.floor(Math.random() * (hi - lo + 1));
  }

  /**
   * 单人流程内步骤间隔：0.5–2 秒随机
   * @param {string} [label]
   */
  async interruptibleDelay(delayMs) {
    const total = Math.max(0, Number(delayMs) || 0);
    const slice = 200;
    let waited = 0;
    while (waited < total) {
      if (this.isChatTaskAborted()) return false;
      const chunk = Math.min(slice, total - waited);
      await new Promise((resolve) => setTimeout(resolve, chunk));
      waited += chunk;
    }
    return true;
  }

  async waitHumanStep(label = "") {
    const { minMs, maxMs } = this.getHumanTimingRange("step");
    const delayMs = this.randomBetweenMs(minMs, maxMs);
    void label;
    await this.interruptibleDelay(delayMs);
  }

  /**
   * 换下一个候选人：3–5 秒随机
   * @param {string} [label]
   */
  async waitHumanCandidateGap(label = "") {
    const { minMs, maxMs } = this.getHumanTimingRange("candidate");
    const delayMs = this.randomBetweenMs(minMs, maxMs);
    // try {
    //   chrome.runtime.sendMessage({
    //     type: "LOG_MESSAGE",
    //     data: {
    //       message: `候选人间隔 ${(delayMs / 1000).toFixed(1)} 秒${label ? `（${label}）` : ""}`,
    //       type: "info",
    //     },
    //   });
    // } catch {
    //   /* ignore */
    // }
    void label;
    await this.interruptibleDelay(delayMs);
  }

  /**
   * 思考停顿：更长、更稀（看一眼再操作）
   * @param {string} [label]
   */
  async waitHumanThinkPause(label = "") {
    const t = window.招聘速聊助手_CONFIG?.TIMING || {};
    const min = Number(t.thinkPauseMinMs);
    const max = Number(t.thinkPauseMaxMs);
    const minMs = Number.isFinite(min) && min > 0 ? min : 2000;
    const maxMs = Number.isFinite(max) && max > 0 ? max : 6000;
    const delayMs = this.randomBetweenMs(minMs, maxMs);
    // try {
    //   chrome.runtime.sendMessage({
    //     type: "LOG_MESSAGE",
    //     data: {
    //       message: `思考停顿 ${(delayMs / 1000).toFixed(1)} 秒${label ? `（${label}）` : ""}`,
    //       type: "info",
    //     },
    //   });
    // } catch {
    //   /* ignore */
    // }
    void label;
    await this.interruptibleDelay(delayMs);
  }

  /**
   * 按概率思考停顿
   * @param {string} [label]
   */
  async maybeWaitHumanThinkPause(label = "") {
    const t = window.招聘速聊助手_CONFIG?.TIMING || {};
    let chance = Number(t.thinkPauseChance);
    if (!Number.isFinite(chance)) chance = 0.25;
    if (Math.random() >= chance) return false;
    await this.waitHumanThinkPause(label);
    return true;
  }

  /**
   * 打开在线简历后：模拟阅读再关
   * @param {string} [name]
   */
  async waitResumeReadPause(name = "") {
    const docs = this.collectAccessibleDocuments(true);
    if (
      !this.isOnlineResumeOverlayOpen?.(docs, "") &&
      !this.isResumePanelVisible?.(docs)
    ) {
      return false;
    }
    // 短时间重复关闭路径只阅读一次
    if (this._lastResumeReadAt && Date.now() - this._lastResumeReadAt < 2500) {
      return false;
    }
    const t = window.招聘速聊助手_CONFIG?.TIMING || {};
    const min = Number(t.resumeReadMinMs);
    const max = Number(t.resumeReadMaxMs);
    const minMs = Number.isFinite(min) && min > 0 ? min : 3000;
    const maxMs = Number.isFinite(max) && max > 0 ? max : 8000;
    const delayMs = this.randomBetweenMs(minMs, maxMs);
    this._lastResumeReadAt = Date.now();
    // try {
    //   chrome.runtime.sendMessage({
    //     type: "LOG_MESSAGE",
    //     data: {
    //       message: `模拟阅读简历 ${(delayMs / 1000).toFixed(1)} 秒${name ? `（${name}）` : ""}`,
    //       type: "info",
    //     },
    //   });
    // } catch {
    //   /* ignore */
    // }
    void name;
    await this.interruptibleDelay(delayMs);
    return true;
  }

  /**
   * @param {Document[]} documents
   */
  detectBossViewRateLimit(documents) {
    const docs = documents || this.collectAccessibleDocuments(true);
    for (const doc of docs) {
      const text = doc.body?.innerText || "";
      if (/查看太频繁|请稍后重试|操作过于频繁|访问过于频繁/.test(text)) {
        return true;
      }
    }
    return false;
  }

  isAskResumeRateLimited() {
    return Date.now() < (this._askResumeRateLimitedUntil || 0);
  }

  markAskResumeRateLimited(documents) {
    const cooldown = this.getAskResumeTiming("rateLimitCooldownMs", 90000);
    this._askResumeRateLimitedUntil = Date.now() + cooldown;
    if (this.detectBossViewRateLimit(documents)) {
      console.warn("BOSS 提示查看太频繁，进入冷却", cooldown, "ms");
    }
  }

  async waitForResumeViewCooldown() {
    const gap = this.getAskResumeTiming("resumeViewGapMs", 12000);
    const elapsed = Date.now() - (this._lastResumeViewAt || 0);
    if (elapsed < gap) {
      await new Promise((resolve) => setTimeout(resolve, gap - elapsed));
    }
  }

  /**
   * 轻点一次，避免 forceClick 触发 BOSS「查看太频繁」
   * @param {Element} el
   */
  async gentleClickElement(el) {
    if (!el) return false;
    if (this.isChatTaskAborted()) return false;
    try {
      await this.waitHumanStep();
      if (this.isChatTaskAborted()) return false;
      el.scrollIntoView?.({ block: "center", inline: "center" });
      await new Promise((resolve) => setTimeout(resolve, 80));
      el.click?.();
      return true;
    } catch (error) {
      console.warn("gentleClickElement 失败:", error);
      return false;
    }
  }

  async primeAskResumeCaches() {
    return new Promise((resolve) => {
      chrome.storage.local.get(
        ["招聘速聊助手_saved_resumes", "bossZhipinCandidates"],
        (result) => {
          this._greetedListCache = result.招聘速聊助手_saved_resumes || [];
          this._bossCandidatesCache = result.bossZhipinCandidates || [];
          resolve();
        },
      );
    });
  }

  clearAskResumeRuntimeCaches() {
    this._greetedListCache = null;
    this._bossCandidatesCache = null;
    this._accessibleDocumentsCache = null;
    this._accessibleDocumentsCacheAt = 0;
  }

  isAskResumeChatActionsEnabled() {
    return (
      window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG?.enableChatActions === true
    );
  }

  isAskResumeAiMatchEnabled() {
    return window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG?.enableAiMatch === true;
  }

  isAskResumeCollectEnabled() {
    return window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG?.enableResumeCollect === true;
  }

  isAskResumeScreenshotEnabled() {
    return window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG?.enableResumeScreenshot !== false;
  }

  /** 在线简历弹窗下载文件 → base64 本地存档 */
  isResumeFileDownloadEnabled() {
    return (
      window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG?.enableResumeFileDownload === true
    );
  }

  /** 识别到已有简历后：查重 + 上传平台 */
  isResumePlatformUploadEnabled() {
    return (
      window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG?.enableResumePlatformUpload !==
      false
    );
  }

  getResumeFileCaptureTimeoutMs() {
    return this.getAskResumeTiming("resumeFileCaptureTimeoutMs", 30000);
  }

  /**
   * 用 XPath 取节点文案
   * @param {Document[]} documents
   * @param {string} xpath
   */
  getTextByXPath(documents, xpath) {
    if (!xpath) return "";
    const el = this.evaluateXPathFirst?.(documents, xpath);
    if (!el) return "";
    return (el.textContent || el.innerText || "").replace(/\s+/g, " ").trim();
  }

  /**
   * 规范化年龄：保留数字，如 28岁 → 28
   * @param {string|number} raw
   */
  normalizeAgeForPlatform(raw) {
    const s = String(raw ?? "").trim();
    if (!s) return "";
    const m = s.match(/(\d{1,3})\s*岁?/);
    if (m) return m[1];
    const digits = s.replace(/[^\d]/g, "");
    return digits || s;
  }

  /**
   * 规范化工龄：提取数字，如 5年 / 3-5年 → 优先取首个数字
   * @param {string|number} raw
   */
  normalizeWorkYearsForPlatform(raw) {
    const s = String(raw ?? "").trim();
    if (!s) return "";
    if (/应届|在校|无经验|经验不限/.test(s)) {
      const m0 = s.match(/(\d+)/);
      return m0 ? m0[1] : "0";
    }
    const m = s.match(/(\d+(?:\.\d+)?)\s*年?/);
    if (m) return m[1];
    const digits = s.replace(/[^\d.]/g, "");
    return digits || s;
  }

  /**
   * 规范化学历文案
   * @param {string} raw
   */
  normalizeEducationForPlatform(raw) {
    const s = String(raw ?? "").replace(/\s+/g, " ").trim();
    if (!s) return "";
    const known =
      s.match(
        /博士|MBA|EMBA|硕士|研究生|本科|大专|专科|高中|中专|中技|初中|小学/,
      ) || null;
    return known ? known[0] : s.slice(0, 20);
  }

  /**
   * 沟通页：抓取简历查重/上传所需五要素
   * 姓名、沟通职位、年龄、工龄、学历
   * @param {{ element?: Element }} sessionItem
   * @param {Document[]} documents
   * @returns {{
   *   candidate_name: string,
   *   job_name: string,
   *   age: string,
   *   education: string,
   *   work_years: string,
   *   ok: boolean,
   *   missing: string[],
   *   raw: object
   * }}
   */
  scrapeChatCandidateFiveKeys(sessionItem, documents) {
    const docs = documents || this.collectAccessibleDocuments(true);
    const cfg = window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG || {};

    const candidate_name = (
      this.getActiveChatPanelGeekName?.(docs) ||
      this.getSessionDisplayName(sessionItem) ||
      ""
    )
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 40);

    const job_name = (
      this.getSessionPositionNameText?.(sessionItem, docs) || ""
    )
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 80);

    const ageXPath =
      cfg.chatCandidateAgeXPath ||
      "/html/body/div[3]/div[3]/div[1]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]";
    const workXPath =
      cfg.chatCandidateWorkYearsXPath ||
      "/html/body/div[3]/div[3]/div[1]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]";
    const eduXPath =
      cfg.chatCandidateEducationXPath ||
      "/html/body/div[3]/div[3]/div[1]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]";

    let ageRaw = this.getTextByXPath(docs, ageXPath);
    let workRaw = this.getTextByXPath(docs, workXPath);
    let eduRaw = this.getTextByXPath(docs, eduXPath);

    // 兜底：聊天顶栏 / base-info 区域按「岁 / 年 / 学历词」解析
    if (!ageRaw || !workRaw || !eduRaw) {
      const fallback = this.scrapeChatBaseInfoFallback(docs);
      if (!ageRaw && fallback.age) ageRaw = fallback.age;
      if (!workRaw && fallback.work_years) workRaw = fallback.work_years;
      if (!eduRaw && fallback.education) eduRaw = fallback.education;
    }

    const age = this.normalizeAgeForPlatform(ageRaw);
    const work_years = this.normalizeWorkYearsForPlatform(workRaw);
    const education = this.normalizeEducationForPlatform(eduRaw);

    const missing = [];
    if (!candidate_name || candidate_name === "未知会话") {
      missing.push("姓名");
    }
    if (!job_name) missing.push("沟通职位");
    if (!age) missing.push("年龄");
    // work_years "0" 合法（应届/无经验）
    if (work_years === "" || work_years == null) missing.push("工龄");
    if (!education) missing.push("学历");

    return {
      candidate_name,
      job_name,
      age,
      education,
      work_years: work_years === "" ? "" : String(work_years),
      ok: missing.length === 0,
      missing,
      raw: { ageRaw, workRaw, eduRaw },
    };
  }

  /**
   * 从沟通页顶栏/信息条兜底解析年龄、工龄、学历
   * @param {Document[]} documents
   */
  scrapeChatBaseInfoFallback(documents) {
    const docs = documents || this.collectAccessibleDocuments(true);
    const result = { age: "", work_years: "", education: "" };
    const texts = [];

    for (const doc of docs) {
      const roots = [
        ...doc.querySelectorAll(
          '[class*="base-info"], [class*="geek-info"], [class*="chat-user"], [class*="chat-header"], [class*="im-basic"], [class*="user-info"]',
        ),
      ];
      for (const root of roots) {
        const t = (root.innerText || root.textContent || "")
          .replace(/\s+/g, " ")
          .trim();
        if (t && t.length < 200) texts.push(t);
        // 子 div 序列：常见 姓名行后 年龄/工龄/学历
        const kids = [...root.querySelectorAll(":scope > div, :scope span")];
        for (const kid of kids) {
          const kt = (kid.textContent || "").replace(/\s+/g, " ").trim();
          if (kt && kt.length <= 20) texts.push(kt);
        }
      }
    }

    for (const t of texts) {
      if (!result.age) {
        const m = t.match(/(\d{1,3})\s*岁/);
        if (m) result.age = m[0];
      }
      if (!result.work_years) {
        if (/应届|在校|无经验/.test(t)) result.work_years = t;
        else {
          const m = t.match(/(\d+(?:\.\d+)?)\s*年(?:以上|以内|以下|经验)?/);
          if (m) result.work_years = m[0];
        }
      }
      if (!result.education) {
        const m = t.match(
          /博士|MBA|EMBA|硕士|研究生|本科|大专|专科|高中|中专|中技|初中/,
        );
        if (m) result.education = m[0];
      }
    }
    return result;
  }

  /**
   * 调用 background 查重
   * @param {object} meta
   */
  async checkResumeOnPlatform(meta) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(
          {
            type: "plugin_resume_check",
            action: "PLUGIN_RESUME_CHECK",
            meta,
          },
          (response) => {
            if (chrome.runtime.lastError) {
              resolve({
                success: false,
                error: chrome.runtime.lastError.message,
              });
              return;
            }
            resolve(response || { success: false, error: "无响应" });
          },
        );
      } catch (error) {
        resolve({
          success: false,
          error: error?.message || String(error),
        });
      }
    });
  }

  /**
   * 调用 background 上传 PDF base64
   * @param {object} meta
   * @param {string} fileBase64
   */
  async uploadResumeToPlatform(meta, fileBase64) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(
          {
            type: "plugin_resume_upload",
            action: "PLUGIN_RESUME_UPLOAD",
            meta: {
              ...meta,
              source_platform: meta.source_platform || "boss",
            },
            file_base64: fileBase64,
          },
          (response) => {
            if (chrome.runtime.lastError) {
              resolve({
                success: false,
                error: chrome.runtime.lastError.message,
              });
              return;
            }
            resolve(response || { success: false, error: "无响应" });
          },
        );
      } catch (error) {
        resolve({
          success: false,
          error: error?.message || String(error),
        });
      }
    });
  }

  /**
   * 从本地 IndexedDB 按 id 取出 base64（供上传）
   * @param {string|number} id
   */
  async getLocalResumeFileBase64(id) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(
          {
            action: "GET_RESUME_FILE",
            id,
          },
          (response) => {
            if (chrome.runtime.lastError) {
              resolve({
                ok: false,
                error: chrome.runtime.lastError.message,
              });
              return;
            }
            if (!response?.ok || !response?.base64) {
              resolve({
                ok: false,
                error: response?.error || response?.message || "未取到 base64",
              });
              return;
            }
            resolve({
              ok: true,
              base64: response.base64,
              filename: response.filename,
              mime: response.mime,
            });
          },
        );
      } catch (error) {
        resolve({ ok: false, error: error?.message || String(error) });
      }
    });
  }

  ensureResumeFileCaptureState() {
    if (!this._resumeFileCapturedKeys) {
      this._resumeFileCapturedKeys = new Set();
    }
    return this._resumeFileCapturedKeys;
  }

  isResumeFileAlreadyCaptured(sessionKey) {
    if (!sessionKey) return false;
    return this.ensureResumeFileCaptureState().has(sessionKey);
  }

  markResumeFileCaptured(sessionKey) {
    if (!sessionKey) return;
    this.ensureResumeFileCaptureState().add(sessionKey);
  }

  /**
   * 聊天中识别到「已有简历」时：
   * 1) 抓取五要素（姓名/职位/年龄/工龄/学历）
   * 2) 平台查重 → 已回传则跳过
   * 3) 未回传：打开附件 → 下载转 base64 → 本地存档 → 上传平台
   * 与发起方无关（HR主动 / 候选人主动 / 未识别 均可调用）
   * @param {{ element: Element, clickTarget?: Element }} sessionItem
   * @param {Document[]} documents
   * @param {Function} buildLog
   * @param {string} key
   * @param {object} [logContext]
   */
  async handleReceivedResumeFileDownload(
    sessionItem,
    documents,
    buildLog,
    key,
    logContext = {},
  ) {
    const name = this.getSessionDisplayName(sessionItem);
    const log = (action, logType = "info", extra = {}) => ({
      status: extra.status || "info_saved",
      key,
      name,
      message: buildLog
        ? buildLog(logContext, action)
        : this.formatSessionStatusLog(name, logContext, action),
      logType,
      ...extra,
    });

    const sendLog = (message, type = "info") => {
      try {
        chrome.runtime.sendMessage({
          type: "LOG_MESSAGE",
          data: { message, type },
        });
      } catch {
        /* ignore */
      }
    };

    const pageNotify = (text) => {
      try {
        const el = document.createElement("div");
        el.textContent = text;
        el.style.cssText =
          "position:fixed;left:50%;top:24px;transform:translateX(-50%);z-index:2147483647;background:rgba(20,30,50,.94);color:#fff;padding:12px 18px;border-radius:8px;font-size:14px;max-width:90vw;box-shadow:0 4px 20px rgba(0,0,0,.25);pointer-events:none;";
        document.body.appendChild(el);
        setTimeout(() => el.remove(), 4500);
      } catch {
        /* ignore */
      }
    };

    if (this.isChatTaskAborted()) {
      return log("已停止，取消简历下载", "warning", { status: "skip_done" });
    }

    if (!this.isResumeFileDownloadEnabled()) {
      // 不 mark completed，便于打开开关后下一轮/重新开始仍能下载
      return log("跳过（聊天中已有简历，下载开关未开）", "info");
    }

    if (this.isResumeFileAlreadyCaptured(key)) {
      this.markAskResumeSessionCompleted(key);
      return log("跳过（本会话简历文件已下载存本地）", "info");
    }

    // 再次确认：聊天区确实已有简历信号
    let docs = documents || this.collectAccessibleDocuments(true);
    const status = this.assessSessionStatus(docs, sessionItem);
    if (!status.resumeReceived) {
      return {
        status: "wait_resume_ui",
        key,
        name,
        message: buildLog
          ? buildLog(logContext, "未确认聊天中已有简历，暂不下载转 base64")
          : `${name}：未确认聊天中已有简历，暂不下载转 base64`,
        logType: "warning",
      };
    }

    // ——— ① 抓取五要素：姓名、沟通职位、年龄、工龄、学历 ———
    await this.waitHumanStep("抓取五要素前");
    const five = this.scrapeChatCandidateFiveKeys(sessionItem, docs);
    const fiveSummary = `姓名=${five.candidate_name || "?"}，职位=${five.job_name || "?"}，年龄=${five.age || "?"}，工龄=${five.work_years || "?"}，学历=${five.education || "?"}`;
    sendLog(`${name}：已抓取候选人信息（${fiveSummary}）`, "info");

    const platformUploadOn = this.isResumePlatformUploadEnabled();
    let platformMeta = null;

    if (platformUploadOn) {
      if (!five.ok) {
        return log(
          `已有简历 → 基础信息不全（缺：${five.missing.join("、")}），暂不查重/下载，等待下轮`,
          "warning",
          { status: "wait_resume_ui", fiveKeys: five },
        );
      }
      platformMeta = {
        candidate_name: five.candidate_name,
        job_name: five.job_name,
        age: five.age,
        education: five.education,
        work_years: five.work_years,
        source_platform: "boss",
      };

      // ——— ② 平台查重 ———
      await this.waitHumanStep("平台查重前");
      const checkResult = await this.checkResumeOnPlatform(platformMeta);
      if (!checkResult?.success) {
        const authHint = checkResult?.authRequired
          ? "（请先在插件中登录宣双平台）"
          : "";
        return log(
          `已有简历 → 查重失败${authHint}：${checkResult?.error || "未知"}，暂不下载`,
          "warning",
          {
            status: checkResult?.authRequired ? "skip_done" : "wait_resume_ui",
            checkResult,
            fiveKeys: five,
          },
        );
      }

      if (checkResult.exists) {
        this.markAskResumeSessionCompleted(key);
        this.markResumeFileCaptured(key);
        const msg =
          checkResult.message ||
          "该候选人简历已存在，无需重复上传";
        pageNotify(`${name}：${msg}`);
        sendLog(
          `${name}：${msg}${checkResult.resume_uuid ? ` uuid=${checkResult.resume_uuid}` : ""}`,
          "info",
        );
        return log(`已有简历 → 平台侧已存在，跳过（${msg}）`, "info", {
          status: "skip_done",
          checkResult,
          fiveKeys: five,
          resume_uuid: checkResult.resume_uuid || null,
        });
      }

      sendLog(
        `${name}：平台查重通过（尚未回传大易），继续下载附件`,
        "info",
      );
    }

    // 1) 打开简历入口（优先带「附件」语义的按钮，其次通用 resume-btn-file）
    let openBtn = this.findAttachmentResumeOpenButton(docs);
    if (!openBtn) {
      openBtn = this.findChatResumeViewButton(docs);
    }
    if (!openBtn) {
      await new Promise((r) => setTimeout(r, 600));
      docs = this.collectAccessibleDocuments(true);
      openBtn =
        this.findAttachmentResumeOpenButton(docs) ||
        this.findChatResumeViewButton(docs);
    }
    if (!openBtn) {
      // 可能是误判：没有附件入口 → 回退到正常求简历/截图流程
      this.markResumeNotAttachment(key);
      return {
        ...log("聊天中疑似有简历，但未找到可打开的附件入口，改走常规流程", "warning"),
        status: "resume_download_unavailable",
        resumeNotAttachment: true,
      };
    }

    try {
      const who =
        logContext.initiator === "hr"
          ? "HR主动"
          : logContext.initiator === "candidate"
            ? "候选人主动"
            : logContext.initiator === "unknown"
              ? "发起方未识别"
              : "不限发起方";
      sendLog(
        `${name}：聊天中已识别到简历（${who}），准备下载并转 base64 存本地`,
        "info",
      );
    } catch {
      /* ignore */
    }

    if (this.isChatTaskAborted()) {
      return log("已停止，取消简历下载", "warning", { status: "skip_done" });
    }

    await this.waitForResumeViewCooldown?.();
    await this.waitHumanStep("打开附件简历前");
    if (this.isChatTaskAborted()) {
      return log("已停止，取消简历下载", "warning", { status: "skip_done" });
    }
    await this.gentleClickElement(openBtn);
    await this.waitHumanStep("等待附件打开");

    // 2) 等待简历弹窗
    const overlayOk =
      (await this.waitForResumePanelVisible?.(8000)) ||
      this.isOnlineResumeOverlayOpen?.(
        this.collectAccessibleDocuments(true),
        name,
      );

    if (!overlayOk) {
      // 部分附件简历只出 boss-dynamic-dialog，不一定走 resume-detail 浮层
      const hasDialog = this.collectAccessibleDocuments(true).some((doc) =>
        !!doc.querySelector('[id^="boss-dynamic-dialog"]'),
      );
      if (!hasDialog) {
        try {
          await this.closeResumePanelOnly?.();
        } catch {
          /* ignore */
        }
        this.markResumeNotAttachment(key);
        return {
          ...log(
            "已点开入口但未出现附件弹窗，判定非附件简历，改走常规流程",
            "warning",
          ),
          status: "resume_download_unavailable",
          resumeNotAttachment: true,
        };
      }
    }

    // 3) 点下载并转 base64；若无下载 SVG，多半是在线简历而非附件 → 回退常规流程
    await this.waitHumanStep("点击下载前");
    const fileResult = await this.captureOnlineResumeFileDownload(
      platformMeta?.candidate_name || name,
      key,
      this.collectAccessibleDocuments(true),
    );

    if (
      !fileResult?.ok &&
      /未找到.*下载|下载按钮/.test(String(fileResult?.message || ""))
    ) {
      try {
        await this.closeResumePanelOnly?.();
        await this.waitForResumePanelHidden?.(2000);
      } catch {
        /* ignore */
      }
      this.markResumeNotAttachment(key);
      return {
        ...log(
          `未找到附件下载按钮（${fileResult?.message || "未知"}），判定非附件简历，改走常规流程`,
          "warning",
        ),
        status: "resume_download_unavailable",
        resumeNotAttachment: true,
      };
    }

    try {
      await this.closeResumePanelOnly?.();
      await this.waitForResumePanelHidden?.(3000);
    } catch {
      /* ignore */
    }

    if (!fileResult?.ok) {
      const failAction = `已有简历 → 下载失败（${fileResult?.message || "未知"}）`;
      pageNotify(`${name} 简历下载失败：${fileResult?.message || "未知"}`);
      sendLog(`${name}：${failAction}`, "warning");
      return {
        ...log(failAction, "warning"),
        status: "info_saved",
        saveResult: {
          ok: false,
          message: fileResult?.message || "下载失败",
        },
      };
    }

    // 本地已落库
    this.markResumeFileCaptured(key);
    const pathPart = fileResult.exportPath
      ? `，原文件：下载文件夹/${fileResult.exportPath}`
      : "";
    const b64Part = fileResult.base64TxtPath
      ? `，base64：下载文件夹/${fileResult.base64TxtPath}（长度 ${fileResult.base64Length || "?"}）`
      : fileResult.base64Length
        ? `，base64 长度 ${fileResult.base64Length}`
        : "";
    let action = `已有简历 → 拦截并转 base64 成功 ${fileResult.filename || ""}（${fileResult.size || 0} 字节）${pathPart}${b64Part}`;

    // ——— ④ 上传平台（check 已通过 / 或未开启平台时跳过）———
    let uploadResult = null;
    if (platformUploadOn && platformMeta) {
      await this.waitHumanStep("上传前");
      let fileBase64 = fileResult.base64 || "";
      if (!fileBase64 && fileResult.id != null) {
        const local = await this.getLocalResumeFileBase64(fileResult.id);
        if (local.ok) fileBase64 = local.base64;
        else {
          action += `；平台上传失败：无法读取本地 base64（${local.error || "未知"}）`;
          sendLog(`${name}：${action}`, "warning");
          pageNotify(`${name} 本地已存档，但上传平台失败：读 base64 失败`);
          this.markAskResumeSessionCompleted(key);
          return log(action, "warning", {
            saveResult: {
              ok: true,
              id: fileResult.id,
              filename: fileResult.filename,
              size: fileResult.size,
              exportPath: fileResult.exportPath || "",
            },
            fiveKeys: five,
            uploadResult: local,
          });
        }
      }

      // 非 PDF 时接口会拒，先按文件名/mime 提示
      const fname = String(fileResult.filename || "").toLowerCase();
      const mime = String(fileResult.mime || "").toLowerCase();
      const looksPdf =
        fname.endsWith(".pdf") ||
        mime.includes("pdf") ||
        // 无扩展名时仍尝试上传，由服务端校验 %PDF
        (!fname.includes(".") && !mime);

      if (!looksPdf && (fname || mime)) {
        action += `；文件似乎不是 PDF（${fileResult.filename || mime}），平台要求 PDF，仍尝试上传`;
        sendLog(`${name}：${action}`, "warning");
      }

      uploadResult = await this.uploadResumeToPlatform(
        platformMeta,
        fileBase64,
      );

      if (uploadResult?.success && uploadResult.exists) {
        action += `；平台已存在，无需重复上传${uploadResult.resume_uuid ? ` uuid=${uploadResult.resume_uuid}` : ""}`;
        pageNotify(
          `${name}：${uploadResult.message || "该候选人简历已存在，无需重复上传"}`,
        );
        sendLog(`${name}：${action}`, "info");
      } else if (uploadResult?.success && uploadResult.created) {
        action += `；已接收，稍后简历将回传大易${uploadResult.resume_uuid ? ` uuid=${uploadResult.resume_uuid}` : ""}${uploadResult.pdf_path ? ` path=${uploadResult.pdf_path}` : ""}`;
        pageNotify(`${name}：稍后简历将回传大易`);
        sendLog(`${name}：${action}`, "success");
      } else if (uploadResult?.success) {
        action += `；已接收（${uploadResult.message || "ok"}），稍后简历将回传大易`;
        pageNotify(`${name}：稍后简历将回传大易`);
        sendLog(`${name}：${action}`, "success");
      } else {
        const authHint = uploadResult?.authRequired
          ? "（请重新登录）"
          : "";
        action += `；平台上传失败${authHint}：${uploadResult?.error || "未知"}（本地 base64 已保留）`;
        pageNotify(
          `${name} 本地已存档，上传失败：${uploadResult?.error || "未知"}`,
        );
        sendLog(`${name}：${action}`, "warning");
      }
    } else {
      pageNotify(
        `${name} 简历 base64 已保存${fileResult.base64TxtPath ? ` → ${fileResult.base64TxtPath}` : ""}`,
      );
      sendLog(`${name}：${action}`, "success");
    }

    this.markAskResumeSessionCompleted(key);

    const logType =
      uploadResult && !uploadResult.success
        ? "warning"
        : "success";

    return {
      ...log(action, logType),
      status: "info_saved",
      saveResult: {
        ok: true,
        message: fileResult.message,
        id: fileResult.id,
        filename: fileResult.filename,
        size: fileResult.size,
        exportPath: fileResult.exportPath || "",
      },
      fiveKeys: five,
      uploadResult,
      resume_uuid: uploadResult?.resume_uuid || null,
    };
  }

  /**
   * 在 boss-dynamic-dialog 简历弹窗内定位下载图标
   * 用户结构：dialog/…/div[3]/span/svg（dialog id 动态）
   * @param {Document[]} documents
   * @returns {Element|null}
   */
  findOnlineResumeFileDownloadButton(documents) {
    const cfg = window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG || {};
    const svgXPath =
      cfg.resumeFileDownloadSvgXPath ||
      '//*[starts-with(@id,"boss-dynamic-dialog")]/div[1]/div/div/div/div/div[1]/div/div[1]/div/div/div[3]/span/svg';
    const spanXPath =
      cfg.resumeFileDownloadSpanXPath ||
      '//*[starts-with(@id,"boss-dynamic-dialog")]/div[1]/div/div/div/div/div[1]/div/div[1]/div/div/div[3]/span';
    const docs = documents || this.collectAccessibleDocuments(true);

    const evalXPath = (doc, xpath) => {
      try {
        return doc.evaluate(
          xpath,
          doc,
          null,
          XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
          null,
        );
      } catch {
        return null;
      }
    };

    for (const doc of docs) {
      const snap = evalXPath(doc, svgXPath);
      if (snap && snap.snapshotLength > 0) {
        const svg = snap.snapshotItem(snap.snapshotLength - 1);
        if (svg) {
          const clickable =
            svg.closest("span, a, button, [role='button']") || svg.parentElement || svg;
          return clickable;
        }
      }
    }

    for (const doc of docs) {
      const snap = evalXPath(doc, spanXPath);
      if (snap && snap.snapshotLength > 0) {
        const span = snap.snapshotItem(snap.snapshotLength - 1);
        if (span) return span;
      }
    }

    // 兜底：动态 dialog 内第 3 个工具区 span/svg，或 title/aria 含「下载」
    for (const doc of docs) {
      const dialogs = doc.querySelectorAll('[id^="boss-dynamic-dialog"]');
      for (const dialog of dialogs) {
        if (!this.isElementVisible?.(dialog) && dialog.offsetParent === null) {
          // 仍尝试查找，部分 dialog 可见性判断不准
        }
        const labeled = dialog.querySelector(
          '[title*="下载"], [aria-label*="下载"], [data-title*="下载"]',
        );
        if (labeled) return labeled;

        const toolSpans = dialog.querySelectorAll(
          "div > div > div > span > svg, span > svg",
        );
        // 优先：结构接近 div[3]/span/svg 的父 span
        for (const svg of toolSpans) {
          const span = svg.closest("span");
          const parent = span?.parentElement;
          if (!span || !parent) continue;
          // 父级下第 3 个子块常为下载（用户 XPath div[3]）
          const kids = Array.from(parent.children || []);
          const idx = kids.indexOf(span);
          if (idx === 2 || kids.length >= 3) {
            // 若该行有多个图标，取第 3 个 span
          }
        }
        const rowCandidates = dialog.querySelectorAll(
          '[class*="toolbar"] span, [class*="operate"] span, [class*="icon"] span',
        );
        if (rowCandidates.length >= 3) {
          return rowCandidates[2];
        }
      }
    }

    // 文案「下载」在 dialog 内
    const dlText = cfg.resumeDownloadButtonText || "下载";
    for (const doc of docs) {
      const dialogs = doc.querySelectorAll('[id^="boss-dynamic-dialog"]');
      for (const dialog of dialogs) {
        const nodes = dialog.querySelectorAll(
          'a, button, span, div, [role="button"]',
        );
        for (const el of nodes) {
          const text = (el.textContent || "").replace(/\s+/g, "");
          if (text === dlText || text === "下载简历") {
            return el;
          }
        }
      }
    }

    return null;
  }

  /**
   * 等待 background 回传 RESUME_FILE_CAPTURE_RESULT
   * @param {string} captureId
   * @param {number} timeoutMs
   */
  waitForResumeFileCaptureResult(captureId, timeoutMs) {
    return new Promise((resolve) => {
      const timer = setTimeout(() => {
        chrome.runtime.onMessage.removeListener(handler);
        resolve({
          ok: false,
          captureId,
          message: `等待下载结果超时（${timeoutMs}ms）`,
        });
      }, timeoutMs);

      function handler(message) {
        if (message?.type !== "RESUME_FILE_CAPTURE_RESULT") return;
        if (captureId && message.captureId && message.captureId !== captureId) {
          return;
        }
        clearTimeout(timer);
        chrome.runtime.onMessage.removeListener(handler);
        resolve({
          ok: !!message.ok,
          captureId: message.captureId || captureId,
          id: message.id,
          filename: message.filename,
          mime: message.mime,
          size: message.size,
          name: message.name,
          exportPath: message.exportPath || "",
          base64TxtPath: message.base64TxtPath || "",
          base64Length: message.base64Length || 0,
          message: message.message || (message.ok ? "下载成功" : "下载失败"),
        });
      }

      chrome.runtime.onMessage.addListener(handler);
    });
  }

  /**
   * 简历弹窗已打开时：武装捕获 → 点下载 SVG → 等 base64 落库
   * @param {string} name
   * @param {string} sessionKey
   * @param {Document[]} documents
   */
  async captureOnlineResumeFileDownload(name, sessionKey, documents) {
    if (!this.isResumeFileDownloadEnabled()) {
      return { ok: false, skipped: true, message: "简历文件下载未启用" };
    }

    const docs = documents || this.collectAccessibleDocuments(true);
    let btn = this.findOnlineResumeFileDownloadButton(docs);
    if (!btn) {
      // 弹窗可能稍晚渲染工具栏
      await new Promise((r) => setTimeout(r, 800));
      btn = this.findOnlineResumeFileDownloadButton(
        this.collectAccessibleDocuments(true),
      );
    }
    if (!btn) {
      return { ok: false, message: "未找到简历弹窗内的下载按钮（SVG）" };
    }

    const timeoutMs = this.getResumeFileCaptureTimeoutMs();
    const captureId = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

    let arm;
    try {
      arm = await chrome.runtime.sendMessage({
        action: "ARM_RESUME_FILE_CAPTURE",
        captureId,
        name: name || "未知",
        sessionKey: sessionKey || name || "",
        timeoutMs,
      });
    } catch (error) {
      return {
        ok: false,
        message: `武装下载捕获失败：${error?.message || error}`,
      };
    }

    if (!arm?.success && !arm?.armed) {
      return {
        ok: false,
        message: arm?.error || "武装下载捕获未成功",
      };
    }

    const resultPromise = this.waitForResumeFileCaptureResult(
      arm.captureId || captureId,
      timeoutMs + 2000,
    );

    try {
      await this.gentleClickElement(btn);
      // SVG 有时要点父 span 两次才触发
      await new Promise((r) => setTimeout(r, 200));
      const span = btn.closest?.("span") || btn;
      if (span !== btn) {
        try {
          await this.gentleClickElement(span);
        } catch {
          /* ignore */
        }
      }
    } catch (error) {
      return {
        ok: false,
        message: `点击下载按钮失败：${error?.message || error}`,
      };
    }

    return resultPromise;
  }

  getResumeScreenshotRenderWaitMs() {
    return this.getAskResumeTiming("screenshotRenderWaitMs", 800);
  }

  async appendScreenshotRecord(record) {
    return new Promise((resolve) => {
      chrome.storage.local.get(["招聘速聊助手_resume_screenshots"], (result) => {
        if (chrome.runtime.lastError) {
          resolve(false);
          return;
        }
        const list = result.招聘速聊助手_resume_screenshots || [];
        list.push(record);
        chrome.storage.local.set({ 招聘速聊助手_resume_screenshots: list }, () => {
          resolve(!chrome.runtime.lastError);
        });
      });
    });
  }

  buildScreenshotFolderDate(savedAt = new Date().toISOString()) {
    return String(savedAt).slice(0, 10).replace(/-/g, "");
  }

  buildScreenshotFilename(name, savedAt, index) {
    const dateFolder = this.buildScreenshotFolderDate(savedAt);
    const timePart = String(savedAt)
      .replace(/[-:TZ.]/g, "")
      .slice(0, 14);
    const base = `${this.sanitizeFilename(name)}_${timePart}`;
    return `招聘速聊助手_resumes/screenshots/${dateFolder}/${base}_${index}.png`;
  }

  async downloadResumeScreenshot(filename, dataUrl, retries = 2) {
    // 【本机落盘已关闭】截图不写下载夹；业务截图走内存拼接 + 上传
    void filename;
    void dataUrl;
    void retries;
    return { success: true, skipped: true, message: "本机截图落盘已关闭" };
    // let lastResult = { success: false, error: "未知错误" };
    // for (let attempt = 0; attempt <= retries; attempt += 1) {
    //   try {
    //     const response = await chrome.runtime.sendMessage({
    //       action: "SAVE_RESUME_SCREENSHOT",
    //       filename,
    //       dataUrl,
    //     });
    //     if (response?.success) {
    //       return response;
    //     }
    //     lastResult = response || lastResult;
    //   } catch (error) {
    //     lastResult = { success: false, error: error.message || String(error) };
    //   }
    //   if (attempt < retries) {
    //     await new Promise((resolve) => setTimeout(resolve, 400));
    //   }
    // }
    // return lastResult;
  }

  /**
   * 在线简历面板打开后：多张截图 → 按序拼接 → 上传接口（姓名+性别+图片）
   * @param {string} name
   * @param {Document[]} documents
   * @param {string} source
   * @param {{ gender?: string }} [options]
   */
  async captureAndSaveOnlineResumeScreenshots(
    name,
    documents,
    source = "ask_resume_ui_flow",
    options = {},
  ) {
    const gender = options.gender || "未知";

    if (!this.isAskResumeScreenshotEnabled()) {
      return {
        ok: false,
        count: 0,
        files: [],
        message: "简历截图功能未启用",
        name,
        gender,
        uploadOk: false,
        partCount: 0,
      };
    }

    const docs = documents || this.collectAccessibleDocuments(true);
    const gate = this.isOnlineResumeReadyToCapture(name, docs);
    if (!gate.ok) {
      return {
        ok: false,
        count: 0,
        files: [],
        message: gate.reason || "在线简历未就绪，已取消截图",
        name,
        gender,
        uploadOk: false,
        partCount: 0,
      };
    }

    const renderWaitMs = this.getResumeScreenshotRenderWaitMs();
    await new Promise((resolve) => setTimeout(resolve, renderWaitMs));

    const docsAfterWait = this.collectAccessibleDocuments(true);
    const gateAfterWait = this.isOnlineResumeReadyToCapture(name, docsAfterWait);
    if (!gateAfterWait.ok) {
      return {
        ok: false,
        count: 0,
        files: [],
        message: gateAfterWait.reason || "等待后在线简历已关闭或不是当前候选人",
        name,
        gender,
        uploadOk: false,
        partCount: 0,
      };
    }

    let screenshotDebug = null;
    const imageList = await captureFullResumeScreenshot(docsAfterWait, {
      renderWaitMs,
      allowFullPageFallback: false,
      onDiagnostic: (info) => {
        screenshotDebug = info;
      },
    });

    if (screenshotDebug) {
      const diagMessage = [
        `截图诊断：分支=${screenshotDebug.branch}`,
        `容器=${screenshotDebug.containerSource || "无"}`,
        `高度=${screenshotDebug.totalHeight || 0}/${screenshotDebug.viewportHeight || 0}`,
        `张数=${screenshotDebug.imageCount ?? imageList.length}`,
        `裁剪=${screenshotDebug.cropWidth || 0}x${screenshotDebug.cropHeight || 0}`,
        `裁剪来源=${screenshotDebug.cropSource || "无"}`,
      ].join("，");
      console.log(`${name} ${diagMessage}`);
      try {
        chrome.runtime.sendMessage({
          type: "LOG_MESSAGE",
          data: { message: `${name}：${diagMessage}`, type: "info" },
        });
      } catch {
        /* ignore */
      }
    }

    if (!imageList || imageList.length === 0) {
      return {
        ok: false,
        count: 0,
        files: [],
        message: "未能生成简历截图",
        name,
        gender,
        uploadOk: false,
        partCount: 0,
      };
    }

    const savedAt = new Date().toISOString();
    let storeBatch = null;

    try {
      storeBatch = await saveScreenshotBatch({
        name,
        source,
        savedAt,
        images: imageList,
      });
    } catch (error) {
      console.error("截图写入本地数据库失败:", error);
    }

    const partFilenames = imageList.map((_, i) =>
      this.buildScreenshotFilename(name, savedAt, i + 1),
    );

    let mergedDataUrl = null;
    let mergeErrorMsg = "";
    try {
      const mergeParts = buildPartsFromFilenames(imageList, partFilenames);
      mergedDataUrl = await stitchScreenshotParts(mergeParts);
    } catch (mergeError) {
      console.error("拼接简历截图失败:", mergeError);
      mergeErrorMsg = mergeError.message || String(mergeError);
    }

    if (!mergedDataUrl) {
      const message = mergeErrorMsg
        ? `长图拼接失败（${mergeErrorMsg}）`
        : "长图拼接失败";
      return {
        ok: false,
        count: 0,
        files: [],
        message,
        name,
        gender,
        uploadOk: false,
        partCount: imageList.length,
        batchId: storeBatch?.id ?? null,
      };
    }

    try {
      chrome.runtime.sendMessage({
        type: "LOG_MESSAGE",
        data: {
          message: `${name}：已拼接 ${imageList.length} 张截图，姓名=${name}，性别=${gender}，正在回传接口…`,
          type: "info",
        },
      });
    } catch {
      /* ignore */
    }

    const uploadResult = await this.uploadMergedResumeImage({
      name,
      gender,
      dataUrl: mergedDataUrl,
    });

    const uploadOk = !!uploadResult?.success;
    const uploadError = uploadResult?.error || "";
    // background 返回 { success, data, ... }，data 为上游 Flow 结果
    const uploadResponse =
      uploadResult?.data ?? uploadResult?.response ?? uploadResult ?? null;

    let resumeInfoText = "";
    let aiMatch = null;
    let aiMatchError = "";

    if (uploadOk) {
      resumeInfoText = this.buildResumeInfoFromAnalyzeResponse(
        name,
        gender,
        uploadResponse,
      );

      try {
        chrome.runtime.sendMessage({
          type: "LOG_MESSAGE",
          data: {
            message: `${name}：图片分析完成，提取简历信息 ${resumeInfoText.length} 字，正在调用简历匹配 AI…`,
            type: "info",
          },
        });
      } catch {
        /* ignore */
      }

      try {
        aiMatch = await this.judgeResumeWithGreetAI(resumeInfoText);
      } catch (error) {
        aiMatchError = error.message || String(error);
        aiMatch = { isok: false, msg: aiMatchError };
      }

      // 调试覆盖：否优先于是
      if (window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG?.forceAiDecisionNo === true) {
        aiMatch = {
          isok: false,
          msg: "调试：强制判定为否（forceAiDecisionNo）",
        };
      } else if (
        window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG?.forceAiDecisionYes === true
      ) {
        aiMatch = {
          isok: true,
          msg: "调试：强制判定为是（forceAiDecisionYes）",
        };
      }

      try {
        chrome.runtime.sendMessage({
          type: "LOG_MESSAGE",
          data: {
            message: `${name}：简历匹配结果 = ${aiMatch?.isok ? "符合" : "不符合"}（${aiMatch?.msg || "无原因"}）`,
            type: aiMatch?.isok ? "success" : "warning",
          },
        });
      } catch {
        /* ignore */
      }

      // 写入本地记录，便于后续查看
      try {
        await this.saveAIRecordToLocal(
          { name, gender },
          {
            input_text_0: resumeInfoText,
            aiDecision: aiMatch?.isok ? "是" : "否",
            aiReason: aiMatch?.msg || "",
            source: `${source}_image_match`,
            analyzeImageResponse: uploadResponse,
            greeted: false,
          },
        );
      } catch (error) {
        console.warn("保存图片分析+匹配记录失败:", error);
      }
    }

    // 调试覆盖：即使图片回传失败，也强制 AI 结果，便于测求简历/不合适
    if (window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG?.forceAiDecisionNo === true) {
      aiMatch = {
        isok: false,
        msg: "调试：强制判定为否（forceAiDecisionNo）",
      };
    } else if (
      window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG?.forceAiDecisionYes === true
    ) {
      aiMatch = {
        isok: true,
        msg: "调试：强制判定为是（forceAiDecisionYes）",
      };
      try {
        chrome.runtime.sendMessage({
          type: "LOG_MESSAGE",
          data: {
            message: `${name}：调试强制 AI 符合（forceAiDecisionYes）`,
            type: "warning",
          },
        });
      } catch {
        /* ignore */
      }
    }

    const record = {
      savedAt,
      name,
      gender,
      source,
      screenshotCount: imageList.length,
      files: [],
      batchId: storeBatch?.id ?? null,
      uploadOk,
      uploadError: uploadOk ? "" : uploadError,
      aiMatched: aiMatch?.isok ?? null,
      aiReason: aiMatch?.msg || aiMatchError || "",
      type: "resume_screenshot_upload",
    };
    const storageOk = await this.appendScreenshotRecord(record);

    let message = `已拼接 ${imageList.length} 张截图`;
    if (uploadOk) {
      message += `；已回传接口（姓名：${name}，性别：${gender}）`;
    } else {
      message += `；回传失败：${uploadError || "未知错误"}`;
    }
    if (aiMatch) {
      message += `；简历匹配=${aiMatch.isok ? "符合" : "不符合"}（${aiMatch.msg || "无"}）`;
    }

    return {
      ok: uploadOk,
      count: imageList.length,
      files: [],
      message,
      storageOk,
      batchId: storeBatch?.id ?? null,
      name,
      gender,
      uploadOk,
      uploadError,
      uploadResponse,
      resumeInfoText,
      aiMatch,
      partCount: imageList.length,
      mergedDataUrl: null,
    };
  }

  buildAskResumeSavePayload(candidateInfoText = "") {
    const settings = this.getAskResumeSettings();
    const formatList = (keywords) =>
      (keywords || []).filter(Boolean).join("、");

    return {
      input_text_0: candidateInfoText || "",
      input_text_1: formatList(settings.keywords),
      input_text_2: formatList(settings.excludeKeywords),
    };
  }

  /**
   * @param {string} name
   * @param {object} payload
   */
  async saveAskResumeCandidateInfo(name, payload = {}) {
    return this.saveAIRecordToLocal(
      { name },
      {
        ...payload,
        aiResponseRaw: payload.aiResponseRaw || "（AI匹配暂未启用）",
        aiDecision: payload.aiDecision ?? null,
        aiReason: payload.aiReason || "阶段三暂跳过AI匹配",
        greeted: false,
      },
    );
  }

  getCachedAiDecision(key) {
    return this.askResumeRunState?.aiDecisions?.get(key) || null;
  }

  setCachedAiDecision(key, decision) {
    if (!this.askResumeRunState) {
      this.askResumeRunState = {
        loggedOnce: new Set(),
        aiDecisions: new Map(),
        completedSessions: new Set(),
        sessionUiAttempts: new Map(),
        bossRejectScriptSynced: false,
      };
    }
    this.askResumeRunState.aiDecisions.set(key, decision);
  }

  isAskResumeSessionCompleted(key) {
    return this.askResumeRunState?.completedSessions?.has(key) || false;
  }

  markAskResumeSessionCompleted(key, _reason = "") {
    if (!this.askResumeRunState) {
      this.askResumeRunState = {
        loggedOnce: new Set(),
        aiDecisions: new Map(),
        completedSessions: new Set(),
        sessionUiAttempts: new Map(),
        bossRejectScriptSynced: false,
      };
    }
    this.askResumeRunState.completedSessions.add(key);
  }

  getSessionUiAttempt(key) {
    return this.askResumeRunState?.sessionUiAttempts?.get(key)?.count || 0;
  }

  incrementSessionUiAttempt(key) {
    if (!this.askResumeRunState) {
      this.askResumeRunState = {
        loggedOnce: new Set(),
        aiDecisions: new Map(),
        completedSessions: new Set(),
        sessionUiAttempts: new Map(),
        bossRejectScriptSynced: false,
      };
    }
    if (!this.askResumeRunState.sessionUiAttempts) {
      this.askResumeRunState.sessionUiAttempts = new Map();
    }
    const prev = this.askResumeRunState.sessionUiAttempts.get(key) || {
      count: 0,
      lastAt: 0,
    };
    const next = {
      count: prev.count + 1,
      lastAt: Date.now(),
    };
    this.askResumeRunState.sessionUiAttempts.set(key, next);
    return next.count;
  }

  /**
   * 简历面板内容是否属于目标候选人
   * @param {Document[]} documents
   * @param {string} expectedName
   */
  resumePanelShowsCandidate(documents, expectedName = "") {
    return this.resumePanelShowsCandidateInOverlay(documents, expectedName);
  }

  /**
   * 处理完一个候选人后，关闭简历面板，便于切换下一个
   * @param {string} sessionName
   */
  /**
   * 从简历视图退回聊天（点击会话 + 关闭钮 + Esc）
   * @param {{ element: Element, clickTarget?: Element }} sessionItem
   */
  async dismissResumeViewToChat(sessionItem) {
    const documents = this.collectAccessibleDocuments(true);
    if (
      !this.isResumePanelBlocking(documents) &&
      !this.isResumePanelVisible(documents)
    ) {
      return true;
    }

    await this.waitResumeReadPause(
      this.getSessionDisplayName?.(sessionItem) || "",
    );

    const clickTarget =
      sessionItem?.clickTarget ||
      sessionItem?.element?.querySelector?.('[class*="geek-item-wrap"]') ||
      sessionItem?.element;

    if (clickTarget) {
      await this.forceClickElement(clickTarget);
      await new Promise((resolve) => setTimeout(resolve, 700));
      if (!this.isResumePanelBlocking(this.collectAccessibleDocuments(true))) {
        return true;
      }
    }

    const backSelectors = [
      '[class*="resume-back"]',
      '[class*="back-btn"]',
      '[class*="icon-back"]',
      'button[aria-label="返回"]',
      '[class*="nav-back"]',
    ];

    for (const doc of this.getAllAccessibleDocuments()) {
      for (const sel of backSelectors) {
        for (const el of doc.querySelectorAll(sel)) {
          if (!this.isElementVisible(el)) continue;
          await this.forceClickElement(el);
          await new Promise((resolve) => setTimeout(resolve, 350));
          if (!this.isResumePanelBlocking(this.collectAccessibleDocuments(true))) {
            return true;
          }
        }
      }
    }

    await this.closeResumePanelOnly(3);
    if (!this.isResumePanelBlocking(this.collectAccessibleDocuments(true))) {
      return true;
    }

    for (let i = 0; i < 3; i += 1) {
      for (const doc of this.getAllAccessibleDocuments()) {
        await this.dispatchEscapeKey(doc);
      }
      await new Promise((resolve) => setTimeout(resolve, 300));
      if (!this.isResumePanelBlocking(this.collectAccessibleDocuments(true))) {
        return true;
      }
    }

    return !this.isResumePanelBlocking(this.collectAccessibleDocuments(true));
  }

  async cleanupBetweenAskResumeSessions(sessionName = "", sessionItem = null) {
    const documents = this.collectAccessibleDocuments(true);
    if (!this.isOnlineResumeOverlayOpen(documents, "")) {
      return { closed: false, hidden: true, name: sessionName };
    }

    const reason =
      this.getResumePanelVisibleReason(documents, { mode: "blocking" }) ||
      this.getResumePanelVisibleReason(documents, { mode: "open" });

    // 像真人看完再关，避免秒关秒下一个
    await this.waitResumeReadPause(sessionName);

    if (sessionItem) {
      await this.dismissResumeViewToChat(sessionItem);
    } else {
      await this.closeResumePanelOnly();
    }

    const hidden = await this.waitForResumePanelHidden(3000);
    const stillReason =
      this.getResumePanelVisibleReason(this.collectAccessibleDocuments(true), {
        mode: "blocking",
      }) ||
      this.getResumePanelVisibleReason(this.collectAccessibleDocuments(true), {
        mode: "open",
      });
    return {
      closed: true,
      hidden,
      name: sessionName,
      reason,
      stillReason,
    };
  }

  /**
   * @param {Document[]} documents
   * @param {{ element: Element }} sessionItem
   */
  /**
   * @param {string} text
   * @param {string} expectedName
   */
  textMentionsCandidateName(text = "", expectedName = "") {
    if (!text || !expectedName) return false;
    const normalized = text.replace(/\s+/g, " ").trim();
    const key = this.normalizePersonName(expectedName);
    if (!key) return false;
    if (normalized.includes(key)) return true;
    return this.namesLikelyMatch(
      expectedName,
      normalized.slice(0, Math.min(normalized.length, 60)),
    );
  }

  extractCandidateInfoFromChatDom(documents, sessionItem) {
    const parts = [];
    const name = this.getSessionDisplayName(sessionItem);
    parts.push(`姓名: ${name}`);

    for (const doc of documents) {
      const selectors = [
        '[class*="user-info"]',
        '[class*="geek-info"]',
        '[class*="base-info"]',
        '[class*="resume-detail"]',
        '[class*="job-info"]',
        '[class*="source-job"]',
        '[class*="chat-header"]',
      ];
      for (const selector of selectors) {
        doc.querySelectorAll(selector).forEach((el) => {
          if (el.closest('[class*="friend-list"], [role="group"] [role="listitem"]')) {
            return;
          }
          const text = el.textContent?.replace(/\s+/g, " ").trim();
          if (!text || text.length < 10 || text.length > 2000) return;
          if (!this.textMentionsCandidateName(text, name)) return;
          parts.push(text);
        });
      }
    }

    const itemText =
      sessionItem.element.textContent?.replace(/\s+/g, " ").trim() || "";
    if (itemText) {
      parts.push(`会话摘要: ${itemText.slice(0, 500)}`);
    }

    const messages = this.collectChatMessageItems(documents)
      .filter((msg) => msg.side === "candidate" && msg.text.length > 0)
      .slice(0, 5)
      .map((msg) => msg.text);
    if (messages.length) {
      parts.push(`候选人消息: ${messages.join(" | ")}`);
    }

    return parts.join("\n");
  }

  /**
   * 沟通页收集简历信息（对齐一键打招呼：列表/cache → 打开详情弹窗 → 补充全文）
   * @param {Document[]} documents
   * @param {{ element: Element }} sessionItem
   */
  async collectCandidateInfoForAskResume(documents, sessionItem) {
    // 入口 processAskResumeSession 已 ensure 过：已就绪则不再点会话
    let docs = documents || this.collectAccessibleDocuments(true);
    if (!this.isAskResumeSessionAlreadyReady(sessionItem, docs)) {
      docs = await this.ensureChatSessionReadyForCollect(sessionItem);
    }
    documents = docs;
    const readyReason = this.getChatSessionReadyReason(sessionItem, documents);
    const name = this.getSessionDisplayName(sessionItem);
    const item = sessionItem.element;

    if (!readyReason.ready) {
      return `姓名: ${name}\n\n【采集失败】聊天区尚未切换到该候选人（当前显示：${readyReason.current || "未知"}），请下轮重试`;
    }

    let candidate = null;
    const extracted = await this.extractCandidates([item]);
    if (extracted.length > 0) {
      candidate = extracted[0];
    } else {
      const cachedData = await this.getCachedCandidateData();
      candidate = await this.processCandidate(item, name, cachedData);
    }

    if (!candidate) {
      candidate = { name };
    }

    candidate = this.enrichCandidateGender(
      this.normalizeCandidateName(candidate, name),
    );
    await this.updateCandidateFromPage(candidate, item);

    let info = this.getSimpleCandidateInfo(candidate);
    let openedDetail = false;

    try {
      openedDetail = await this.clickChatResumeDetail(documents, name);
      if (openedDetail) {
        const apiCandidate = await this.waitForGeekDetailApi(name, 8000);
        if (!apiCandidate?.geekCard) {
          console.warn(`未捕获到 ${name} 的在线简历接口数据，将尝试左侧简历面板抓取`);
        }
        candidate = this.mergeGeekDetailCandidate(candidate, apiCandidate, name);
        info = this.getSimpleCandidateInfo(candidate);

        const profileText = await this.waitForResumeProfileText(documents, name, 10000);
        if (profileText) {
          info += `\n\n【在线简历详情】\n${profileText}`;
        } else {
          const freshDocuments = this.collectAccessibleDocuments(true);
          await this.waitForDetailPopup(3000, freshDocuments);
          const popupText = this.scrapeDetailPopupText(freshDocuments);
          if (popupText && this.isResumeDetailText(popupText)) {
            info += `\n\n【在线简历详情】\n${popupText}`;
          }
        }

        if (!/【在线简历详情】/.test(info)) {
          const summary = this.extractChatResumeSummaryFromPanel(
            this.collectAccessibleDocuments(true),
            name,
          );
          if (summary) {
            info += `\n\n【沟通页简历摘要】\n${summary}`;
          }
        }

        try {
          const colleagueInfo = await this.queryColleagueContactedInfo(candidate);
          if (
            colleagueInfo &&
            !this.isColleagueOrChatOverlayText(colleagueInfo) &&
            !info.includes(colleagueInfo)
          ) {
            info += `\n\n【同事沟通信息】\n${colleagueInfo}`;
          }
        } catch (error) {
          console.error("查询同事沟通信息失败:", error);
        }

        const captureDocs = this.collectAccessibleDocuments(true);
        const captureGate = this.isOnlineResumeReadyToCapture(name, captureDocs);
        if (captureGate.ok) {
          const captureGender =
            this.resolveCandidateGender(candidate) ||
            this.extractGenderFromChatDocuments(captureDocs) ||
            "未知";
          const screenshotResult =
            await this.captureAndSaveOnlineResumeScreenshots(
              name,
              captureDocs,
              "ask_resume_collect",
              { gender: captureGender },
            );
          if (screenshotResult.ok) {
            info += `\n\n【简历截图回传】\n${screenshotResult.message}`;
          } else if (this.isAskResumeScreenshotEnabled()) {
            info += `\n\n【简历截图回传】\n失败：${screenshotResult.message}`;
          }
        } else if (this.isAskResumeScreenshotEnabled()) {
          info += `\n\n【简历截图回传】\n跳过：${captureGate.reason}`;
        }
      }
    } catch (error) {
      console.error("沟通页打开简历详情失败:", error);
    } finally {
      if (openedDetail) {
        await this.closeDetail();
        await new Promise((resolve) => setTimeout(resolve, 300));
      }
    }

    if (this.hasMeaningfulResumeContent(info, name)) {
      return info;
    }

    const summary = this.extractChatResumeSummaryFromPanel(documents, name);
    if (summary && !info.includes(summary)) {
      info += `\n\n【沟通页简历摘要】\n${summary}`;
    }

    if (this.hasMeaningfulResumeContent(info, name)) {
      return info;
    }

    return info;
  }

  /**
   * @param {Document[]} documents
   * @param {string} scriptText
   */
  hasScriptBeenSent(documents, scriptText = "") {
    const normalized = scriptText.replace(/\s+/g, "").trim();
    if (!normalized) return false;

    const snippet = normalized.slice(0, Math.min(16, normalized.length));
    const docs = documents || this.collectAccessibleDocuments(true);

    // 1) 右侧 HR 气泡
    if (
      this.collectChatMessageItems(docs).some(
        (msg) =>
          (msg.side === "hr" || msg.side === "unknown") &&
          msg.text.replace(/\s+/g, "").includes(snippet),
      )
    ) {
      return true;
    }

    // 2) 聊天区全文兜底（侧别识别失败时）
    try {
      const full = this.getExpandedChatText?.(docs) || "";
      if (full.replace(/\s+/g, "").includes(snippet)) return true;
    } catch {
      /* ignore */
    }

    return false;
  }

  /**
   * @param {Document[]} documents
   * @param {{ element: Element } | null} sessionItem
   */
  detectInappropriateMarked(documents, sessionItem) {
    const docs = documents || this.collectAccessibleDocuments(true);
    const markedByMessage = this.collectChatMessageItems(docs).some(
      (msg) =>
        /已标记为不合适|已设为不合适|不再合适|您已将对方标记为不合适|已将对方设为不合适|标记为不合适成功/.test(
          msg.text,
        ),
    );
    if (markedByMessage) return true;

    if (sessionItem?.element) {
      const itemText = sessionItem.element.textContent || "";
      if (/已标不合适|标记不合适|不合适/.test(itemText) && /已/.test(itemText)) {
        return true;
      }
    }

    // 页面提示条 / toast
    for (const doc of docs) {
      const tips = doc.querySelectorAll(
        '[class*="toast"], [class*="message"], [class*="tip"], [class*="notice"], [class*="success"]',
      );
      for (const tip of tips) {
        const t = tip.textContent || "";
        if (/不合适|已标记|设置成功/.test(t) && t.length < 80) return true;
      }
    }

    // 「不合适」按钮变为不可点/已处理态
    const btn = this.findInappropriateButton?.(docs);
    if (btn?.element) {
      const text = (btn.element.textContent || "").replace(/\s+/g, "");
      if (/已不合适|已标记/.test(text)) return true;
      if (
        btn.element.getAttribute("aria-disabled") === "true" ||
        btn.element.disabled
      ) {
        // 仅当附近文案仍与不合适相关时
        if (/不合适/.test(text)) return true;
      }
    }

    return false;
  }

  /**
   * @param {Document[]} documents
   */
  findChatInput(documents) {
    const docs = documents || this.collectAccessibleDocuments(true);
    const selectors = [
      '[class*="chat-input"] textarea',
      '[class*="chat-conversation"] textarea',
      '[class*="chat-footer"] textarea',
      '[class*="submit"] textarea',
      '[class*="chat-input"] [contenteditable="true"]',
      '[class*="editor"] [contenteditable="true"]',
      '[class*="im-chat"] textarea',
      'textarea[class*="input"]',
      '[contenteditable="true"][class*="input"]',
      '[contenteditable="true"][class*="editor"]',
      "textarea",
    ];

    const viewWidth = window.innerWidth || 1920;
    /** @type {{ el: Element, score: number }[]} */
    const scored = [];

    for (const doc of docs) {
      for (const selector of selectors) {
        for (const el of doc.querySelectorAll(selector)) {
          if (el.closest?.('[class*="friend-list"], [role="group"]')) continue;
          let score = 0;
          try {
            const rect = el.getBoundingClientRect();
            if (rect.width < 40 || rect.height < 10) continue;
            if (rect.top > (window.innerHeight || 900) * 0.45) score += 10;
            if (rect.left > viewWidth * 0.25) score += 5;
            if (/chat|input|editor|submit/i.test(el.className || "")) score += 8;
            if ((el.tagName || "").toUpperCase() === "TEXTAREA") score += 6;
          } catch {
            continue;
          }
          scored.push({ el, score });
        }
      }
    }

    scored.sort((a, b) => b.score - a.score);
    return scored[0]?.el || null;
  }

  /**
   * 聊天区发送按钮（优先配置 XPath）
   * @param {Document[]} documents
   * @param {Element|null} [nearInput]
   */
  findSendButton(documents, nearInput = null) {
    const docs = documents || this.collectAccessibleDocuments(true);
    const cfg = window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG || {};
    const xpath =
      cfg.chatSendButtonXPath ||
      '//*[@id="container"]/div[1]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[2]/div[2]/div';

    // 1) 用户提供的绝对 XPath
    const byXPath = this.evaluateXPathFirst(docs, xpath);
    if (byXPath) return byXPath;

    // 2) 输入框附近
    if (nearInput) {
      const root =
        nearInput.closest?.(
          '[class*="chat-input"], [class*="chat-footer"], [class*="submit"], [class*="conversation"], [class*="im-chat"]',
        ) || nearInput.parentElement?.parentElement;
      if (root) {
        const nearBtns = root.querySelectorAll(
          'button, [role="button"], [class*="btn"], [class*="send"], div',
        );
        for (const btn of nearBtns) {
          const text = (btn.textContent || "").replace(/\s+/g, "");
          if (text === "发送" || text === "发送消息") return btn;
          if (/send/i.test(String(btn.className || "")) && text.length <= 6) {
            return btn;
          }
        }
      }
    }

    // 3) 全文文案「发送」
    for (const doc of docs) {
      const candidates = doc.querySelectorAll(
        'button, [role="button"], [class*="btn"], [class*="send"], div, span',
      );
      for (const btn of candidates) {
        const text = (btn.textContent || "").replace(/\s+/g, "");
        if (!/^(发送|发送消息)$/.test(text)) continue;
        if (btn.closest?.('[class*="friend-list"]')) continue;
        try {
          const rect = btn.getBoundingClientRect();
          if (rect.width < 2 || rect.height < 2) continue;
          // 优先右下角发送区
          if (rect.top < (window.innerHeight || 900) * 0.4) continue;
        } catch {
          continue;
        }
        return btn;
      }
    }

    return null;
  }

  /**
   * @param {Document[]} documents
   * @param {string} text
   */
  async sendChatMessage(documents, text) {
    const message = text?.trim();
    if (!message) return false;

    let docs = documents || this.collectAccessibleDocuments(true);
    const input = this.findChatInput(docs);
    if (!input) {
      try {
        chrome.runtime.sendMessage({
          type: "LOG_MESSAGE",
          data: { message: "未找到聊天输入框，话术发送失败", type: "error" },
        });
      } catch {
        /* ignore */
      }
      return false;
    }

    try {
      input.scrollIntoView?.({ block: "center", inline: "nearest" });
    } catch {
      /* ignore */
    }
    input.focus?.();
    await new Promise((r) => setTimeout(r, 80));

    const tag = (input.tagName || "").toUpperCase();
    if (tag === "TEXTAREA" || tag === "INPUT") {
      const proto =
        tag === "TEXTAREA"
          ? window.HTMLTextAreaElement?.prototype
          : window.HTMLInputElement?.prototype;
      const nativeSetter = proto
        ? Object.getOwnPropertyDescriptor(proto, "value")?.set
        : null;
      if (nativeSetter) nativeSetter.call(input, message);
      else input.value = message;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
      try {
        input.dispatchEvent(
          new InputEvent("input", {
            bubbles: true,
            data: message,
            inputType: "insertText",
          }),
        );
      } catch {
        /* ignore */
      }
    } else {
      // contenteditable
      try {
        input.focus();
        // 清空再插入
        input.textContent = "";
        input.innerText = message;
        input.textContent = message;
        input.dispatchEvent(new Event("input", { bubbles: true }));
        try {
          document.execCommand?.("selectAll", false, null);
          document.execCommand?.("insertText", false, message);
        } catch {
          /* ignore */
        }
      } catch {
        input.textContent = message;
        input.dispatchEvent(new Event("input", { bubbles: true }));
      }
    }

    await new Promise((resolve) => setTimeout(resolve, 350));

    docs = this.collectAccessibleDocuments(true);
    let sendBtn = this.findSendButton(docs, input);

    if (sendBtn) {
      try {
        chrome.runtime.sendMessage({
          type: "LOG_MESSAGE",
          data: {
            message: `已输入话术，点击发送（文案=${(sendBtn.textContent || "").replace(/\s+/g, "").slice(0, 8) || "节点"}）`,
            type: "info",
          },
        });
      } catch {
        /* ignore */
      }
      if (typeof this.dispatchRealClick === "function") {
        await this.dispatchRealClick(sendBtn);
      } else {
        sendBtn.click();
      }
    } else {
      // Enter 兜底
      try {
        chrome.runtime.sendMessage({
          type: "LOG_MESSAGE",
          data: {
            message: "未找到发送按钮，尝试回车发送",
            type: "warning",
          },
        });
      } catch {
        /* ignore */
      }
      input.dispatchEvent(
        new KeyboardEvent("keydown", {
          key: "Enter",
          code: "Enter",
          keyCode: 13,
          which: 13,
          bubbles: true,
          cancelable: true,
        }),
      );
      input.dispatchEvent(
        new KeyboardEvent("keyup", {
          key: "Enter",
          code: "Enter",
          keyCode: 13,
          which: 13,
          bubbles: true,
        }),
      );
    }

    // 等待出现在聊天记录里
    for (let i = 0; i < 10; i++) {
      await new Promise((resolve) => setTimeout(resolve, 300));
      if (
        this.hasScriptBeenSent(this.collectAccessibleDocuments(true), message)
      ) {
        return true;
      }
    }
    return this.hasScriptBeenSent(this.collectAccessibleDocuments(true), message);
  }

  /**
   * 在文档（含 iframe）中执行 XPath，返回首个元素节点
   * @param {Document[]|null} documents
   * @param {string} xpath
   * @param {Node|null} [contextNode]
   * @returns {Element|null}
   */
  evaluateXPathFirst(documents, xpath, contextNode = null) {
    if (!xpath) return null;

    if (contextNode) {
      const ownerDoc =
        contextNode.ownerDocument ||
        (contextNode.nodeType === 9 ? contextNode : null);
      if (ownerDoc) {
        try {
          const node = ownerDoc.evaluate(
            xpath,
            contextNode,
            null,
            XPathResult.FIRST_ORDERED_NODE_TYPE,
            null,
          ).singleNodeValue;
          if (node && node.nodeType === 1) return /** @type {Element} */ (node);
        } catch (error) {
          console.warn("相对 XPath 解析失败:", xpath, error);
        }
      }
    }

    const docs = documents || this.collectAccessibleDocuments(true);
    for (const doc of docs) {
      try {
        const node = doc.evaluate(
          xpath,
          doc,
          null,
          XPathResult.FIRST_ORDERED_NODE_TYPE,
          null,
        ).singleNodeValue;
        if (node && node.nodeType === 1) return /** @type {Element} */ (node);
      } catch (error) {
        console.warn("XPath 解析失败:", xpath, error);
      }
    }
    return null;
  }

  /**
   * 记录并临时改写 style，便于事后完整还原（避免弄乱 BOSS 页面布局）
   * @param {Element} el
   * @param {Record<string, string>} props
   */
  pushForcedStyle(el, props) {
    if (!el || !props) return;
    if (!this._forcedStyleStack) this._forcedStyleStack = [];
    const snapshot = {};
    for (const key of Object.keys(props)) {
      snapshot[key] = el.style.getPropertyValue(key);
      snapshot[`${key}__priority`] = el.style.getPropertyPriority(key);
    }
    this._forcedStyleStack.push({ el, snapshot });
    for (const [key, value] of Object.entries(props)) {
      if (value == null) continue;
      el.style.setProperty(key, value, "important");
    }
  }

  /**
   * 还原所有临时强制样式，并收起残留气泡/菜单
   */
  restoreForcedStyles() {
    const stack = this._forcedStyleStack || [];
    while (stack.length) {
      const item = stack.pop();
      if (!item?.el) continue;
      try {
        const { el, snapshot } = item;
        for (const key of Object.keys(snapshot)) {
          if (key.endsWith("__priority")) continue;
          const prev = snapshot[key];
          const pri = snapshot[`${key}__priority`] || "";
          if (!prev) {
            el.style.removeProperty(key);
          } else {
            el.style.setProperty(key, prev, pri);
          }
        }
      } catch {
        /* ignore */
      }
    }
    this._forcedStyleStack = [];

    // 收起可能残留的 not-fit-wrap（不改全局其它菜单）
    try {
      const docs = this.collectAccessibleDocuments(true);
      for (const doc of docs) {
        doc.querySelectorAll(".not-fit-wrap, [class*='not-fit-wrap']").forEach((el) => {
          try {
            el.style.removeProperty("display");
            el.style.removeProperty("visibility");
            el.style.removeProperty("opacity");
            el.style.removeProperty("pointer-events");
            el.style.removeProperty("z-index");
            el.style.removeProperty("max-height");
            el.style.removeProperty("overflow");
          } catch {
            /* ignore */
          }
        });
      }
    } catch {
      /* ignore */
    }
  }

  /**
   * 仅临时显示 not-fit-wrap 一类气泡（不做全局乱改）
   * @param {Element} el
   */
  forceShowElement(el) {
    if (!el) return false;
    try {
      // 只允许操作 not-fit 相关节点，避免把「更多」菜单等强行 display:block 弄乱页面
      const cls = String(el.className || "");
      const isNotFit =
        /not-fit/i.test(cls) ||
        !!el.closest?.(".not-fit-wrap, [class*='not-fit-wrap']");
      if (!isNotFit) return false;

      this.pushForcedStyle(el, {
        display: "block",
        visibility: "visible",
        opacity: "1",
        "pointer-events": "auto",
        "z-index": "9999",
      });
      el.removeAttribute("hidden");
      return true;
    } catch {
      return false;
    }
  }

  /**
   * 鼠标移出，关闭悬停态
   * @param {Element} el
   */
  async unhoverElement(el) {
    if (!el) return;
    try {
      const rect = el.getBoundingClientRect();
      const clientX = rect.left + rect.width / 2;
      const clientY = rect.top + rect.height / 2;
      const base = {
        bubbles: true,
        cancelable: true,
        view: window,
        clientX,
        clientY,
        relatedTarget: document.body,
      };
      const chain = [el, el.parentElement, el.parentElement?.parentElement].filter(
        Boolean,
      );
      for (const target of chain) {
        target.dispatchEvent(new MouseEvent("mousemove", base));
        target.dispatchEvent(new MouseEvent("mouseleave", { ...base, bubbles: false }));
        target.dispatchEvent(new MouseEvent("mouseout", base));
        target.dispatchEvent(
          new MouseEvent("pointerleave", { ...base, bubbles: false }),
        );
        target.dispatchEvent(new MouseEvent("pointerout", base));
      }
      // 移到页面空白处
      document.body?.dispatchEvent?.(
        new MouseEvent("mousemove", {
          bubbles: true,
          clientX: 8,
          clientY: 8,
          view: window,
        }),
      );
    } catch {
      /* ignore */
    }
  }

  /**
   * 查找 not-fit-wrap 悬停气泡容器
   * @param {Document[]} documents
   * @param {Element|null} nearEl
   * @returns {Element|null}
   */
  findNotFitWrap(documents, nearEl = null) {
    const docs = documents || this.collectAccessibleDocuments(true);
    const cfg = window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG || {};
    const selector =
      cfg.inappropriateHoverWrapSelector ||
      ".not-fit-wrap, [class*='not-fit-wrap']";

    /** @type {Element[]} */
    const found = [];

    // 按钮附近优先
    if (nearEl) {
      let node = nearEl;
      for (let i = 0; i < 8 && node; i++) {
        try {
          if (node.matches?.(selector) || /not-fit-wrap/i.test(node.className || "")) {
            found.push(node);
          }
          node.querySelectorAll?.(selector).forEach((el) => found.push(el));
          // 兄弟节点
          node.parentElement
            ?.querySelectorAll?.(selector)
            .forEach((el) => found.push(el));
        } catch {
          /* ignore */
        }
        node = node.parentElement;
      }
    }

    for (const doc of docs) {
      try {
        doc.querySelectorAll(selector).forEach((el) => found.push(el));
      } catch {
        try {
          doc
            .querySelectorAll("[class*='not-fit-wrap']")
            .forEach((el) => found.push(el));
        } catch {
          /* ignore */
        }
      }
    }

    // 去重
    const unique = [...new Set(found)];
    if (!unique.length) return null;

    // 靠近按钮的优先
    if (nearEl) {
      try {
        const br = nearEl.getBoundingClientRect();
        unique.sort((a, b) => {
          const da = (() => {
            try {
              const r = a.getBoundingClientRect();
              return Math.hypot(r.left - br.left, r.top - br.top);
            } catch {
              return 99999;
            }
          })();
          const db = (() => {
            try {
              const r = b.getBoundingClientRect();
              return Math.hypot(r.left - br.left, r.top - br.top);
            } catch {
              return 99999;
            }
          })();
          return da - db;
        });
      } catch {
        /* ignore */
      }
    }

    return unique[0] || null;
  }

  /**
   * 仅展开 not-fit-wrap 悬停气泡（绝不碰其它菜单/气泡，避免页面错乱）
   * @param {Element} root
   */
  forceRevealHoverPanels(root) {
    if (!root) return 0;
    let revealed = 0;
    try {
      const list = [];
      if (
        root.matches?.(".not-fit-wrap, [class*='not-fit-wrap']") ||
        /not-fit-wrap/i.test(String(root.className || ""))
      ) {
        list.push(root);
      }
      root
        .querySelectorAll?.(".not-fit-wrap, [class*='not-fit-wrap']")
        .forEach((el) => list.push(el));

      // 也在父级兄弟中找
      root.parentElement
        ?.querySelectorAll?.(".not-fit-wrap, [class*='not-fit-wrap']")
        .forEach((el) => list.push(el));

      for (const wrap of new Set(list)) {
        if (this.forceShowElement(wrap)) revealed += 1;
      }
    } catch {
      /* ignore */
    }
    return revealed;
  }

  /**
   * 触发元素悬停（mouseenter / mouseover / mousemove），并对父级一并派发
   * @param {Element} el
   */
  async hoverElement(el) {
    if (!el) return false;
    try {
      el.scrollIntoView?.({ block: "center", inline: "nearest" });
      await new Promise((resolve) => setTimeout(resolve, 80));
      const rect = el.getBoundingClientRect();
      const clientX = rect.left + Math.max(rect.width / 2, 1);
      const clientY = rect.top + Math.max(rect.height / 2, 1);
      const base = {
        bubbles: true,
        cancelable: true,
        view: window,
        clientX,
        clientY,
        screenX: clientX,
        screenY: clientY,
        buttons: 0,
      };

      const chain = [el, el.parentElement, el.parentElement?.parentElement].filter(
        Boolean,
      );
      for (const target of chain) {
        target.dispatchEvent(new MouseEvent("pointerover", base));
        target.dispatchEvent(
          new MouseEvent("pointerenter", { ...base, bubbles: false }),
        );
        target.dispatchEvent(new MouseEvent("mouseover", base));
        target.dispatchEvent(
          new MouseEvent("mouseenter", { ...base, bubbles: false }),
        );
        target.dispatchEvent(new MouseEvent("mousemove", base));
      }

      // 仅尝试展开 not-fit-wrap（不遍历父级乱改样式）
      this.forceRevealHoverPanels(el);
      if (el.parentElement) this.forceRevealHoverPanels(el.parentElement);
      return true;
    } catch (error) {
      console.warn("悬停元素失败:", error);
      return false;
    }
  }

  /**
   * 将节点文本改为指定话术（p / 可编辑节点 / 邻近输入框）
   * @param {Element} el
   * @param {string} text
   */
  setNodeTextContent(el, text) {
    if (!el) return false;
    const script = String(text || "");
    try {
      const tag = (el.tagName || "").toUpperCase();
      if (tag === "TEXTAREA" || tag === "INPUT") {
        const proto =
          tag === "TEXTAREA"
            ? window.HTMLTextAreaElement?.prototype
            : window.HTMLInputElement?.prototype;
        const nativeSetter = proto
          ? Object.getOwnPropertyDescriptor(proto, "value")?.set
          : null;
        if (nativeSetter) nativeSetter.call(el, script);
        else el.value = script;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        return true;
      }

      el.focus?.();
      if (el.isContentEditable || el.getAttribute("contenteditable") === "true") {
        el.textContent = script;
        el.innerText = script;
      } else {
        // 纯 <p>：直接改文案（BOSS 悬停气泡常见）
        el.textContent = script;
        try {
          el.innerHTML = "";
          el.appendChild(document.createTextNode(script));
        } catch {
          try {
            el.innerText = script;
          } catch {
            /* ignore */
          }
        }
      }
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      try {
        el.dispatchEvent(
          new InputEvent("input", { bubbles: true, data: script, inputType: "insertText" }),
        );
      } catch {
        /* ignore */
      }

      // 同步修改邻近可编辑区
      const scope = el.parentElement || el;
      for (const input of scope.querySelectorAll(
        "textarea, input, [contenteditable='true']",
      )) {
        if (input === el) continue;
        const t = (input.tagName || "").toUpperCase();
        if (t === "TEXTAREA" || t === "INPUT") {
          input.value = script;
          input.dispatchEvent(new Event("input", { bubbles: true }));
        } else {
          input.textContent = script;
          input.dispatchEvent(new Event("input", { bubbles: true }));
        }
      }

      const now = el.textContent || el.value || "";
      return !script || now.includes(script.slice(0, Math.min(4, script.length)));
    } catch (error) {
      console.warn("写入拒简历话术失败:", error);
      return false;
    }
  }

  /**
   * 判断是否像「不合适」操作按钮文案
   * @param {Element} el
   */
  isInappropriateLabelText(el) {
    const text = el?.textContent?.replace(/\s+/g, "") || "";
    return (
      text === "不合适" ||
      text === "标记不合适" ||
      text === "暂不合适" ||
      (text.includes("不合适") && text.length <= 8)
    );
  }

  /**
   * 是否 operate-icon-item 类名
   * @param {Element} el
   */
  isOperateIconItem(el) {
    if (!el) return false;
    const cls = String(el.className || "");
    return (
      cls.split(/\s+/).includes("operate-icon-item") ||
      /operate-icon-item/i.test(cls)
    );
  }

  /**
   * 定位「不合适」按钮：优先 class=operate-icon-item 且文案为「不合适」
   * @param {Document[]} documents
   */
  findInappropriateButton(documents) {
    const docs = documents || this.collectAccessibleDocuments(true);
    const cfg = window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG || {};
    const viewWidth = window.innerWidth || 1920;

    /** @type {{ element: Element, labelElement: Element, score: number, source: string }[]} */
    const scored = [];

    const pushCandidate = (el, source, baseScore = 0) => {
      if (!el) return;
      const text = (el.textContent || "").replace(/\s+/g, "");
      // 必须包含「不合适」，且不能是超大容器
      if (!text.includes("不合适")) return;
      if (text.length > 16) return;
      // 排除「已不合适」等已处理态作为点击目标时仍可收录，但降权
      let score = baseScore;
      if (text === "不合适") score += 20;
      else if (/^不合适/.test(text) || /不合适$/.test(text)) score += 12;
      else score += 5;

      try {
        const rect = el.getBoundingClientRect();
        if (rect.width < 1 || rect.height < 1) score -= 8;
        else score += 3;
        if (rect.left > viewWidth * 0.35) score += 6;
        if (rect.top > 60 && rect.top < (window.innerHeight || 900) * 0.9) {
          score += 3;
        }
      } catch {
        /* ignore */
      }

      if (this.isOperateIconItem(el)) score += 40;
      if (el.closest?.(".operate-icon-item, [class*='operate-icon-item']")) {
        score += 25;
      }
      if (/operate-icon|operate-item|operate-btn/i.test(String(el.className || ""))) {
        score += 10;
      }

      // 点击目标：优先 operate-icon-item 本体
      const item =
        el.closest?.(".operate-icon-item, [class*='operate-icon-item']") || el;
      scored.push({
        element: item,
        labelElement: el,
        score,
        source,
      });
    };

    // 1) 最高优先级：.operate-icon-item
    for (const doc of docs) {
      const items = doc.querySelectorAll(
        ".operate-icon-item, [class*='operate-icon-item']",
      );
      for (const el of items) {
        pushCandidate(el, "operate-icon-item", 50);
      }
    }

    // 2) 配置 XPath
    const xpath =
      cfg.inappropriateButtonXPath ||
      '//*[@id="container"]//*[contains(@class,"operate-icon-item") and contains(normalize-space(.),"不合适")]';
    const byXPath = this.evaluateXPathFirst(docs, xpath);
    if (byXPath) pushCandidate(byXPath, "xpath", 30);

    // 3) 文本兜底
    for (const doc of docs) {
      const nodes = doc.querySelectorAll(
        "span, button, a, div, li, [role='button']",
      );
      for (const el of nodes) {
        const t = (el.textContent || "").replace(/\s+/g, "");
        if (t !== "不合适" && t !== "标记不合适") continue;
        pushCandidate(el, "text", 5);
      }
    }

    scored.sort((a, b) => b.score - a.score);
    if (scored[0]) {
      return {
        element: scored[0].element,
        labelElement: scored[0].labelElement,
        clickable: true,
        source: scored[0].source,
        score: scored[0].score,
      };
    }

    return null;
  }

  /**
   * 在 not-fit-wrap 内挑选话术可写节点
   * @param {Element} wrap
   * @returns {Element|null}
   */
  pickMessageNodeInNotFitWrap(wrap) {
    if (!wrap) return null;
    const candidates = [
      ...wrap.querySelectorAll(
        "p, textarea, [contenteditable='true'], [class*='input'], [class*='editor'], [class*='text']",
      ),
    ];
    if (!candidates.length) {
      // 没有子节点时，直接写 wrap 本身（少见）
      return wrap;
    }

    candidates.sort((a, b) => {
      const score = (el) => {
        let s = 0;
        const tag = (el.tagName || "").toUpperCase();
        if (tag === "TEXTAREA") s += 30;
        if (el.isContentEditable || el.getAttribute("contenteditable") === "true") {
          s += 25;
        }
        if (tag === "P") s += 20;
        if (/text|editor|msg|content/i.test(el.className || "")) s += 8;
        const t = (el.textContent || el.value || "").trim();
        if (t === "不合适" || t === "求简历" || t === "发送") s -= 50;
        if (this.isInappropriateLabelText(el)) s -= 50;
        s += Math.min(t.length, 120) / 10;
        return s;
      };
      return score(b) - score(a);
    });

    return candidates[0] || null;
  }

  /**
   * 从「不合适」按钮附近定位悬停话术节点（优先 .not-fit-wrap）
   * @param {Element} buttonEl
   * @param {Document[]} documents
   * @returns {Element|null}
   */
  findHoverMessageNearButton(buttonEl, documents) {
    const docs = documents || this.collectAccessibleDocuments(true);
    const cfg = window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG || {};

    // 1) 优先：not-fit-wrap 气泡
    const wrap = this.findNotFitWrap(docs, buttonEl);
    if (wrap) {
      this.forceShowElement(wrap);
      this.forceRevealHoverPanels(wrap);
      const inWrap = this.pickMessageNodeInNotFitWrap(wrap);
      if (inWrap) return inWrap;
    }

    // 2) 配置 / 宽松 XPath：not-fit-wrap 下的 p
    const absXpath =
      cfg.inappropriateHoverMessageXPath ||
      '//*[@id="container"]//*[contains(@class,"not-fit-wrap")]//p';
    let msgEl = this.evaluateXPathFirst(docs, absXpath);
    if (msgEl) return msgEl;

    msgEl = this.evaluateXPathFirst(
      docs,
      '//*[contains(@class,"not-fit-wrap")]//p | //*[contains(@class,"not-fit-wrap")]//textarea',
    );
    if (msgEl) return msgEl;

    if (!buttonEl) return null;

    // 3) 相对路径（用户提供结构）
    const relativeXpaths = [
      "./following-sibling::div[contains(@class,'not-fit-wrap')]//p",
      "./following-sibling::*[contains(@class,'not-fit-wrap')]//p",
      "./ancestor::*[contains(@class,'not-fit') or contains(@class,'operate')][1]//*[contains(@class,'not-fit-wrap')]//p",
      "./following-sibling::div//p",
      "../div//p",
      "../div/div//p",
      "../div/div[1]/div[2]/div[2]/p",
      "./../div/div[1]/div[2]/div[2]/p",
      "./ancestor::div[3]//*[contains(@class,'not-fit-wrap')]//p",
      "./parent::*//p",
    ];

    for (const rel of relativeXpaths) {
      msgEl = this.evaluateXPathFirst(null, rel, buttonEl);
      if (msgEl && !this.isInappropriateLabelText(msgEl)) return msgEl;
    }

    // 4) 向上扫描父级
    let node = buttonEl;
    for (let depth = 0; depth < 7 && node; depth++) {
      this.forceRevealHoverPanels(node);
      const localWrap = node.querySelector?.(
        ".not-fit-wrap, [class*='not-fit-wrap']",
      );
      if (localWrap) {
        this.forceShowElement(localWrap);
        const inWrap = this.pickMessageNodeInNotFitWrap(localWrap);
        if (inWrap) return inWrap;
      }
      node = node.parentElement;
    }

    return null;
  }

  /**
   * 悬停「不合适」后，定位 not-fit-wrap 气泡中的话术节点并改写
   * @param {Document[]} documents
   * @param {Element|null} buttonEl
   * @param {string} message
   */
  async fillInappropriateHoverMessage(documents, buttonEl, message) {
    const script = String(message || "").trim();
    if (!script) return { ok: false, reason: "拒简历话术为空" };

    let msgEl = null;
    let wrapEl = null;
    let lastHint = "";

    for (let i = 0; i < 12; i++) {
      const docs = this.collectAccessibleDocuments(true);
      if (buttonEl) {
        await this.hoverElement(buttonEl);
        if (buttonEl.parentElement) {
          await this.hoverElement(buttonEl.parentElement);
        }
      }

      wrapEl = this.findNotFitWrap(docs, buttonEl);
      if (wrapEl) {
        this.forceShowElement(wrapEl);
        this.forceRevealHoverPanels(wrapEl);
        msgEl = this.pickMessageNodeInNotFitWrap(wrapEl);
      }
      if (!msgEl) {
        msgEl = this.findHoverMessageNearButton(buttonEl, docs);
      }
      if (msgEl) break;

      lastHint = `round=${i + 1}, wrap=${!!wrapEl}, btn=${!!buttonEl}`;
      await new Promise((resolve) => setTimeout(resolve, 180));
    }

    if (!msgEl) {
      return {
        ok: false,
        reason: `未找到 not-fit-wrap 话术节点（${lastHint}）`,
      };
    }

    // 写入前确保气泡可见
    const wrap =
      msgEl.closest?.(".not-fit-wrap, [class*='not-fit-wrap']") || wrapEl;
    if (wrap) {
      this.forceShowElement(wrap);
      this.forceRevealHoverPanels(wrap);
    }
    let p = msgEl.parentElement;
    for (let i = 0; i < 4 && p; i++) {
      this.forceRevealHoverPanels(p);
      p = p.parentElement;
    }

    const ok = this.setNodeTextContent(msgEl, script);
    // 若写的是 p，再把 wrap 内其它 textarea 一并写上
    if (wrap && ok) {
      for (const input of wrap.querySelectorAll("textarea, [contenteditable='true']")) {
        if (input !== msgEl) this.setNodeTextContent(input, script);
      }
    }

    const preview = (msgEl.textContent || msgEl.value || "").slice(0, 30);
    return {
      ok,
      reason: ok ? "" : `写入 not-fit-wrap 话术失败（当前：${preview}）`,
      element: msgEl,
      wrap,
    };
  }

  /**
   * 查找「不合适」确认弹窗（点击后可能出现）
   * @param {Document[]} documents
   */
  findInappropriateDialog(documents) {
    const docs = documents || this.collectAccessibleDocuments(true);
    const dialogSelectors = [
      ".dialog-wrap.active",
      '[class*="dialog-wrap"].active',
      '[class*="boss-dialog"]',
      '[class*="boss-popup"]',
      '[class*="dialog-container"]',
      '[class*="modal"]',
      '[role="dialog"]',
      ".boss-layer",
      '[class*="boss-layer"]',
    ];

    for (const doc of docs) {
      for (const sel of dialogSelectors) {
        for (const dialog of doc.querySelectorAll(sel)) {
          if (!this.isElementVisible?.(dialog) && dialog.offsetParent === null) {
            const style = window.getComputedStyle(dialog);
            if (style.display === "none" || style.visibility === "hidden") {
              continue;
            }
          }
          const text = dialog.textContent?.replace(/\s+/g, " ") || "";
          if (/不合适|向牛人发送|发送消息|标记为不合适|不再合适/.test(text)) {
            return dialog;
          }
        }
      }
    }
    return null;
  }

  /**
   * 完整鼠标点击序列（兼容 React/Vue 绑定）
   * @param {Element} el
   */
  async dispatchRealClick(el) {
    if (!el) return false;
    try {
      el.scrollIntoView?.({ block: "center", inline: "nearest" });
      await new Promise((resolve) => setTimeout(resolve, 60));
      const rect = el.getBoundingClientRect();
      if (rect.width < 1 || rect.height < 1) {
        // 不可见时仍尝试 native click
        try {
          HTMLElement.prototype.click.call(el);
          return true;
        } catch {
          return false;
        }
      }
      const clientX = rect.left + rect.width / 2;
      const clientY = rect.top + rect.height / 2;
      const common = {
        bubbles: true,
        cancelable: true,
        view: window,
        clientX,
        clientY,
        screenX: clientX,
        screenY: clientY,
        button: 0,
        buttons: 1,
        detail: 1,
        composed: true,
      };

      // 先 focus，部分组件依赖
      try {
        el.focus?.({ preventScroll: true });
      } catch {
        try {
          el.focus?.();
        } catch {
          /* ignore */
        }
      }

      // Pointer + Mouse 全套（现代框架常监听 pointer）
      const fire = (type, Ctor, extra = {}) => {
        try {
          el.dispatchEvent(new Ctor(type, { ...common, ...extra }));
        } catch {
          /* ignore */
        }
      };

      fire("pointerover", window.PointerEvent || MouseEvent, {
        pointerId: 1,
        pointerType: "mouse",
        isPrimary: true,
      });
      fire("pointerenter", window.PointerEvent || MouseEvent, {
        pointerId: 1,
        pointerType: "mouse",
        bubbles: false,
      });
      fire("mouseover", MouseEvent);
      fire("mouseenter", MouseEvent, { bubbles: false });
      fire("pointerdown", window.PointerEvent || MouseEvent, {
        pointerId: 1,
        pointerType: "mouse",
        isPrimary: true,
      });
      fire("mousedown", MouseEvent);
      fire("pointerup", window.PointerEvent || MouseEvent, {
        pointerId: 1,
        pointerType: "mouse",
        isPrimary: true,
        buttons: 0,
      });
      fire("mouseup", MouseEvent, { buttons: 0 });
      fire("click", MouseEvent, { buttons: 0 });

      // 原生 click（绕过部分框架只认 HTMLElement.click）
      try {
        HTMLElement.prototype.click.call(el);
      } catch {
        try {
          el.click();
        } catch {
          /* ignore */
        }
      }
      return true;
    } catch (error) {
      console.warn("点击失败:", error);
      try {
        el.click();
        return true;
      } catch {
        return false;
      }
    }
  }

  /**
   * 对 operate-icon-item「不合适」做多策略点击
   * @param {Element} itemEl
   */
  async clickOperateIconNotFit(itemEl) {
    if (!itemEl) return { ok: false, strategy: "none" };

    const item =
      itemEl.closest?.(".operate-icon-item, [class*='operate-icon-item']") ||
      itemEl;

    // 策略列表：本体 → 内部含「不合适」的子节点 → elementFromPoint 命中
    /** @type {Element[]} */
    const targets = [item];
    for (const child of item.querySelectorAll("span, i, em, div, a")) {
      const t = (child.textContent || "").replace(/\s+/g, "");
      if (t === "不合适" || t.includes("不合适")) targets.push(child);
    }

    try {
      const rect = item.getBoundingClientRect();
      const x = rect.left + rect.width / 2;
      const y = rect.top + rect.height / 2;
      const topEl = document.elementFromPoint(x, y);
      if (topEl) {
        const viaPoint =
          topEl.closest?.(".operate-icon-item, [class*='operate-icon-item']") ||
          topEl;
        targets.push(viaPoint, topEl);
      }
    } catch {
      /* ignore */
    }

    // 去重
    const unique = [...new Set(targets.filter(Boolean))];
    for (let i = 0; i < unique.length; i++) {
      const el = unique[i];
      await this.dispatchRealClick(el);
      await new Promise((r) => setTimeout(r, 280));

      // 点击后若出现 not-fit-wrap / 确认层，尝试点其中的确定/发送
      const docs = this.collectAccessibleDocuments(true);
      const wrap = this.findNotFitWrap(docs, item);
      if (wrap) {
        // 有的 UI 需要再点气泡里的确认
        const confirmInWrap = [...wrap.querySelectorAll("span, button, a")].find(
          (n) => {
            const t = (n.textContent || "").replace(/\s+/g, "");
            return /^(确定|确认|发送|提交)$/.test(t);
          },
        );
        if (confirmInWrap) {
          await this.dispatchRealClick(confirmInWrap);
          await new Promise((r) => setTimeout(r, 300));
          return { ok: true, strategy: `wrap-confirm#${i}` };
        }
      }

      const dialog =
        this.findInappropriateDialog(docs) || this.findBossDynamicDialog?.(docs);
      if (dialog && /不合适|确定|发送/.test(dialog.textContent || "")) {
        await this.confirmOperateDialog(docs);
        return { ok: true, strategy: `dialog#${i}` };
      }

      if (
        this.detectInappropriateMarked(docs, null)
      ) {
        return { ok: true, strategy: `marked#${i}` };
      }
    }

    return { ok: false, strategy: "all-tried" };
  }

  /**
   * 点击「不合适」（class=operate-icon-item，文案=不合适）
   * @param {Document[]} documents
   * @param {{ message?: string, skipScriptEdit?: boolean }} [options]
   */
  async clickInappropriate(documents, options = {}) {
    this.restoreForcedStyles();

    let docs = documents || this.collectAccessibleDocuments(true);
    // 确保简历浮层不挡操作栏
    if (this.isOnlineResumeOverlayOpen?.(docs, "")) {
      await this.closeResumePanelOnly?.();
      await this.waitForResumePanelHidden?.(2500);
      docs = this.collectAccessibleDocuments(true);
    }

    let button = this.findInappropriateButton(docs);
    if (!button?.element) {
      return {
        ok: false,
        filled: false,
        clicked: false,
        marked: false,
        detail: "未找到 operate-icon-item「不合适」按钮",
      };
    }

    const item =
      button.element.closest?.(
        ".operate-icon-item, [class*='operate-icon-item']",
      ) || button.element;

    try {
      chrome.runtime.sendMessage({
        type: "LOG_MESSAGE",
        data: {
          message: `准备点击不合适（来源=${button.source}，class=${String(item.className || "").slice(0, 40)}，文案=${(item.textContent || "").replace(/\s+/g, "").slice(0, 12)}）`,
          type: "info",
        },
      });
    } catch {
      /* ignore */
    }

    // 收起悬停气泡，避免挡住点击
    await this.unhoverElement(item);
    this.restoreForcedStyles();
    await new Promise((r) => setTimeout(r, 180));

    // 关闭残留弹窗
    const leftover = this.findBossDynamicDialog?.(
      this.collectAccessibleDocuments(true),
    );
    if (leftover) {
      const close = leftover.querySelector(
        '[class*="close"], .boss-popup__close, [aria-label="关闭"]',
      );
      if (close) await this.dispatchRealClick(close);
      await new Promise((r) => setTimeout(r, 200));
    }

    // 重新定位（防重绘）
    docs = this.collectAccessibleDocuments(true);
    button = this.findInappropriateButton(docs) || button;
    const target =
      button.element.closest?.(
        ".operate-icon-item, [class*='operate-icon-item']",
      ) ||
      button.element ||
      item;

    try {
      target.scrollIntoView?.({ block: "center", inline: "nearest" });
    } catch {
      /* ignore */
    }
    await new Promise((r) => setTimeout(r, 100));

    // 多策略真实点击
    const clickResult = await this.clickOperateIconNotFit(target);

    // 再等确认弹窗
    let confirmed = !!clickResult.ok;
    for (let i = 0; i < 5; i++) {
      const afterDocs = this.collectAccessibleDocuments(true);
      const dialog =
        this.findInappropriateDialog(afterDocs) ||
        this.findBossDynamicDialog?.(afterDocs);
      if (dialog && /不合适|确定|发送|消息/.test(dialog.textContent || "")) {
        const okBtn = [...dialog.querySelectorAll("button, span, a")].find(
          (el) =>
            /^(确定|确认|发送|完成)$/.test(
              (el.textContent || "").replace(/\s+/g, ""),
            ),
        );
        if (okBtn) {
          await this.dispatchRealClick(okBtn);
          confirmed = true;
          await new Promise((r) => setTimeout(r, 350));
          break;
        }
        confirmed =
          !!(await this.confirmOperateDialog(afterDocs)) || confirmed;
        await new Promise((r) => setTimeout(r, 350));
        break;
      }
      await new Promise((r) => setTimeout(r, 200));
    }

    let marked = false;
    for (let i = 0; i < 10; i++) {
      await new Promise((r) => setTimeout(r, 300));
      marked = this.detectInappropriateMarked(
        this.collectAccessibleDocuments(true),
        null,
      );
      if (marked) break;
    }

    this.restoreForcedStyles();

    const ok = marked || confirmed;
    return {
      ok,
      filled: false,
      clicked: true,
      marked,
      confirmed,
      strategy: clickResult.strategy,
      detail: marked
        ? `已检测到不合适标记（${clickResult.strategy}）`
        : confirmed
          ? `已确认不合适相关弹窗（${clickResult.strategy}）`
          : `已点 operate-icon-item，但未检测到标记成功（${clickResult.strategy}）`,
    };
  }

  /**
   * 查找 BOSS 动态弹窗（id 形如 boss-dynamic-dialog-xxx）
   * @param {Document[]} documents
   */
  findBossDynamicDialog(documents) {
    const docs = documents || this.collectAccessibleDocuments(true);
    for (const doc of docs) {
      // 可能同时存在多个动态弹窗，优先含「话术/模板」的
      const byIds = [...doc.querySelectorAll('[id^="boss-dynamic-dialog"]')];
      const scored = byIds
        .map((el) => {
          if (this.isElementVisible?.(el) === false) return null;
          const text = el.textContent || "";
          let score = 1;
          if (/话术|模板|常用语|编辑|不合适/.test(text)) score += 10;
          if (el.querySelector?.("textarea, [contenteditable='true'], form")) {
            score += 5;
          }
          return { el, score };
        })
        .filter(Boolean)
        .sort((a, b) => b.score - a.score);
      if (scored[0]?.el) return scored[0].el;

      const candidates = doc.querySelectorAll(
        '.dialog-wrap.active, [class*="dialog-wrap"].active, [class*="boss-dialog"], [class*="boss-popup"], [role="dialog"]',
      );
      for (const el of candidates) {
        const text = el.textContent || "";
        // 修改话术后台常见文案
        if (/话术|不合适|模板|常用语|编辑/.test(text)) {
          const style = window.getComputedStyle(el);
          if (style.display === "none" || style.visibility === "hidden") continue;
          return el;
        }
      }
    }
    return null;
  }

  /**
   * 是否可作为话术写入目标的 input
   * @param {Element} el
   */
  isRejectScriptWritableInput(el) {
    if (!el || (el.tagName || "").toUpperCase() !== "INPUT") return false;
    if (el.disabled) return false;
    const type = String(el.getAttribute("type") || "text").toLowerCase();
    if (
      /^(hidden|checkbox|radio|button|submit|reset|file|image|range|color|date|datetime-local|time|month|week|number|password)$/i.test(
        type,
      )
    ) {
      return false;
    }
    // 下拉组件自带的只读 input 通常不是话术正文
    if (el.readOnly) {
      const cls = String(el.className || "");
      if (/ui-select|select/i.test(cls)) return false;
    }
    return true;
  }

  /**
   * 在修改话术后台内查找可写入话术的编辑区
   * 实测：部分后台只有 1 个 input（无 textarea / contenteditable）
   * @param {Document[]} documents
   * @param {Element|null} [dialog]
   * @returns {Element|null}
   */
  findRejectScriptEditField(documents, dialog = null) {
    const docs = documents || this.collectAccessibleDocuments(true);
    const cfg = window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG || {};
    const xpath =
      cfg.rejectScriptTextareaXPath ||
      '//*[starts-with(@id,"boss-dynamic-dialog")]//textarea | //*[starts-with(@id,"boss-dynamic-dialog")]//input | //*[starts-with(@id,"boss-dynamic-dialog")]//*[@contenteditable="true"]';

    // XPath 命中后仍过滤不可写 input
    const byXPath = this.evaluateXPathFirst(docs, xpath);
    if (byXPath) {
      const tag = (byXPath.tagName || "").toUpperCase();
      if (tag !== "INPUT" || this.isRejectScriptWritableInput(byXPath)) {
        return byXPath;
      }
    }

    const roots = [];
    if (dialog) roots.push(dialog);
    for (const doc of docs) {
      doc
        .querySelectorAll(
          '[id^="boss-dynamic-dialog"], [role="dialog"], .dialog-wrap.active, [class*="dialog-wrap"].active',
        )
        .forEach((el) => {
          if (!roots.includes(el)) roots.push(el);
        });
    }
    // 无 dialog 时也扫 body（编辑区偶发不在 dialog 根下）
    for (const doc of docs) {
      if (doc.body && !roots.includes(doc.body)) roots.push(doc.body);
    }

    const cfgEditor =
      cfg.rejectScriptEditorSelector ||
      ".boss-chat-editor-input, [class*='boss-chat-editor-input']";

    const selectors = [
      ".boss-chat-editor-input",
      "[class*='boss-chat-editor-input']",
      cfgEditor,
      "form textarea",
      "textarea",
      '[contenteditable="true"]',
      '[contenteditable=""]',
      '[role="textbox"]',
      "input",
      'input[type="text"]',
      'input[type="search"]',
      "input:not([type])",
      '[class*="textarea"]',
      '[class*="editor"]',
      '[class*="input-wrap"] input',
      '[class*="ui-input"] input',
      ".ui-input input",
      '[class*="input-area"]',
      '[class*="ipt"]',
      "form input",
      "form [class*='input']",
    ];

    /** @type {{ el: Element, score: number }[]} */
    const candidates = [];
    /** @type {Element[]} */
    const inputFallback = [];

    const consider = (el, strictVisible) => {
      if (!el || el.disabled) return;
      const tag = (el.tagName || "").toUpperCase();
      if (tag === "INPUT" && !this.isRejectScriptWritableInput(el)) return;

      let hidden = false;
      try {
        const style = window.getComputedStyle(el);
        if (
          style.display === "none" ||
          style.visibility === "hidden" ||
          Number(style.opacity) === 0
        ) {
          hidden = true;
        }
      } catch {
        /* ignore */
      }

      const rect = el.getBoundingClientRect?.() || { width: 0, height: 0 };
      const tiny = rect.width < 8 && rect.height < 8;

      if (tag === "INPUT") {
        inputFallback.push(el);
      }

      if (strictVisible && (hidden || tiny)) return;
      // 非严格：允许略小的 input（单行话术框高度可能很小）
      if (!strictVisible && tag !== "INPUT" && (hidden || tiny)) return;

      let score = 0;
      const clsName = String(el.className || "");
      if (/boss-chat-editor-input/i.test(clsName)) score += 80; // 实测最终写入区
      else if (tag === "TEXTAREA") score += 50;
      else if (el.isContentEditable || el.getAttribute("contenteditable") === "true") {
        score += 40;
      } else if (el.getAttribute("role") === "textbox") score += 35;
      else if (tag === "INPUT") score += 45; // 实测后台常只有 input
      else score += 10;

      if (hidden) score -= 25;
      if (tiny) score -= 15;

      score += Math.min(30, Math.floor((rect.width * Math.max(rect.height, 12)) / 2000));

      const cls = String(el.className || "");
      const ph = String(el.getAttribute("placeholder") || "");
      const name = String(el.getAttribute("name") || "");
      const aria = String(el.getAttribute("aria-label") || "");
      const blob = `${ph} ${name} ${cls} ${aria}`;
      if (/search|验证码|手机号|验证/i.test(blob)) score -= 50;
      if (/ui-select|select-inner/i.test(cls)) score -= 60;
      if (/话术|模板|内容|说明|不合适|消息|统一/.test(blob)) score += 20;
      // 在动态弹窗内加分
      if (el.closest?.('[id^="boss-dynamic-dialog"]')) score += 25;

      candidates.push({ el, score });
    };

    for (const root of roots) {
      for (const sel of selectors) {
        let nodes = [];
        try {
          nodes = [...root.querySelectorAll(sel)];
        } catch {
          continue;
        }
        for (const el of nodes) consider(el, true);
      }
      // 兜底：dialog 内全部 input 再扫一遍（不因 opacity/尺寸过严丢弃）
      if (root !== document?.body) {
        try {
          for (const el of root.querySelectorAll("input")) {
            consider(el, false);
          }
        } catch {
          /* ignore */
        }
      }
    }

    // 去重，按分数
    const seen = new Set();
    const unique = [];
    for (const c of candidates.sort((a, b) => b.score - a.score)) {
      if (seen.has(c.el)) continue;
      seen.add(c.el);
      unique.push(c);
    }
    if (unique[0]?.score > -30) return unique[0].el;

    // 最后手段：dialog 内唯一可写 input（日志已证实 input=1 的情况）
    const dialogRoot =
      dialog ||
      this.findBossDynamicDialog(docs) ||
      null;
    if (dialogRoot) {
      const inputs = [...dialogRoot.querySelectorAll("input")].filter((el) =>
        this.isRejectScriptWritableInput(el),
      );
      if (inputs.length === 1) return inputs[0];
      if (inputs.length > 1) {
        // 选最宽的那个
        inputs.sort((a, b) => {
          const ra = a.getBoundingClientRect?.() || { width: 0 };
          const rb = b.getBoundingClientRect?.() || { width: 0 };
          return rb.width - ra.width;
        });
        return inputs[0];
      }
    }

    // 全页 input 兜底里挑一个在 dialog 附近的
    const nearDialog = inputFallback.filter((el) => {
      if (!this.isRejectScriptWritableInput(el)) return false;
      if (dialogRoot && dialogRoot.contains(el)) return true;
      return !!el.closest?.('[id^="boss-dynamic-dialog"]');
    });
    if (nearDialog.length) return nearDialog[0];

    return unique[0]?.el || null;
  }

  /**
   * 选完模板后轮询等待话术编辑区出现
   * @param {number} [maxAttempts]
   * @param {number} [intervalMs]
   */
  async waitForRejectScriptEditField(maxAttempts = 15, intervalMs = 250) {
    let lastDialog = null;
    for (let i = 0; i < maxAttempts; i++) {
      const docs = this.collectAccessibleDocuments(true);
      lastDialog = this.findBossDynamicDialog(docs) || lastDialog;
      const field = this.findRejectScriptEditField(docs, lastDialog);
      if (field) {
        return { field, dialog: lastDialog, attempts: i + 1 };
      }
      await new Promise((r) => setTimeout(r, intervalMs));
    }
    return {
      field: null,
      dialog: lastDialog || this.findBossDynamicDialog(),
      attempts: maxAttempts,
    };
  }

  /**
   * 修改话术后台：点 ui-select-inner 下拉，再选文案为「发送统一消息」的 ui-select-item
   * @param {Element|null} dialog
   * @param {Document[]} [documents]
   */
  async selectRejectScriptUnifiedMessage(dialog, documents) {
    const cfg = window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG || {};
    const innerSel =
      cfg.rejectScriptSelectInnerSelector ||
      ".ui-select-inner, [class*='ui-select-inner']";
    const itemSel =
      cfg.rejectScriptSelectItemSelector ||
      ".ui-select-item, [class*='ui-select-item'], li[class*='ui-select-item']";
    const itemText = String(
      cfg.rejectScriptSelectItemText || "发送统一消息",
    ).trim();

    const normalize = (t) => String(t || "").replace(/\s+/g, "").trim();
    const want = normalize(itemText);

    /** @param {Element|null} root @param {string} selector */
    const queryAllIn = (root, selector) => {
      if (!root) return [];
      try {
        return [...root.querySelectorAll(selector)];
      } catch {
        return [];
      }
    };

    // ① 打开下拉：dialog 内优先，否则全文档
    let docs = documents || this.collectAccessibleDocuments(true);
    let selectInner =
      queryAllIn(dialog, innerSel).find((el) => {
        try {
          const s = window.getComputedStyle(el);
          return s.display !== "none" && s.visibility !== "hidden";
        } catch {
          return true;
        }
      }) || null;

    if (!selectInner) {
      for (const doc of docs) {
        const hit = queryAllIn(doc.body || doc.documentElement, innerSel).find(
          (el) => {
            // 尽量限制在动态弹窗附近
            if (el.closest?.('[id^="boss-dynamic-dialog"]')) return true;
            if (dialog && dialog.contains(el)) return true;
            return false;
          },
        );
        if (hit) {
          selectInner = hit;
          break;
        }
      }
    }

    // 再宽松：任意可见 ui-select-inner
    if (!selectInner) {
      for (const doc of docs) {
        selectInner =
          queryAllIn(doc.body || doc.documentElement, innerSel)[0] || null;
        if (selectInner) break;
      }
    }

    if (!selectInner) {
      return { ok: false, reason: "ui-select-inner-not-found" };
    }

    await this.dispatchRealClick(selectInner);
    await new Promise((r) => setTimeout(r, 350));

    // ② 下拉项可能挂在 body 门户层，不在 dialog 内
    /** @returns {Element|null} */
    const findItem = () => {
      const allDocs = this.collectAccessibleDocuments(true);
      /** @type {Element[]} */
      const items = [];
      for (const doc of allDocs) {
        items.push(
          ...queryAllIn(doc.body || doc.documentElement, itemSel),
          ...queryAllIn(doc.body || doc.documentElement, "li"),
        );
      }
      // 去重
      const unique = [...new Set(items)];
      return (
        unique.find((el) => {
          const cls = String(el.className || "");
          const text = normalize(el.textContent);
          const classOk =
            /ui-select-item/i.test(cls) || el.matches?.(itemSel);
          if (!classOk && !/ui-select/i.test(cls)) {
            // li 兜底：仅当文案精确匹配
            if (el.tagName?.toUpperCase() === "LI" && text === want) return true;
            return false;
          }
          return text === want || text.includes(want);
        }) || null
      );
    };

    let item = null;
    for (let i = 0; i < 12; i++) {
      item = findItem();
      if (item) break;
      // 偶发下拉未展开，再点一次 inner
      if (i === 4 || i === 8) {
        await this.dispatchRealClick(selectInner);
      }
      await new Promise((r) => setTimeout(r, 200));
    }

    if (!item) {
      return {
        ok: false,
        reason: `ui-select-item-not-found（目标：${itemText}）`,
      };
    }

    await this.dispatchRealClick(item);
    await new Promise((r) => setTimeout(r, 350));
    return { ok: true, itemText };
  }

  /**
   * 选完「发送统一消息」后：点击 class 含 radiov2-item、文案为「自定义回复语」的 span
   * （不点则只会停留在默认第一条话术，写不进自定义内容）
   * @param {Element|null} dialog
   * @param {Document[]} [documents]
   */
  async clickRejectScriptRadioItem(dialog, documents) {
    const cfg = window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG || {};
    const radioSel =
      cfg.rejectScriptRadioItemSelector ||
      "span.radiov2-item, span[class*='radiov2-item'], .radiov2-item, [class*='radiov2-item']";
    const wantText = String(
      cfg.rejectScriptRadioItemText || "自定义回复语",
    ).trim();
    const normalize = (t) => String(t || "").replace(/\s+/g, "").trim();
    const want = normalize(wantText);

    const collectRadios = () => {
      const docs = documents || this.collectAccessibleDocuments(true);
      /** @type {Element[]} */
      const list = [];
      const roots = [];
      if (dialog) roots.push(dialog);
      for (const doc of docs) {
        doc
          .querySelectorAll('[id^="boss-dynamic-dialog"]')
          .forEach((el) => roots.push(el));
        if (doc.body) roots.push(doc.body);
      }
      const seen = new Set();
      for (const root of roots) {
        let nodes = [];
        try {
          nodes = [...root.querySelectorAll(radioSel)];
        } catch {
          continue;
        }
        for (const el of nodes) {
          if (!el || seen.has(el)) continue;
          const tag = (el.tagName || "").toUpperCase();
          const cls = String(el.className || "");
          if (!/radiov2-item/i.test(cls) && tag !== "SPAN") {
            const inner = el.querySelector?.(
              "span.radiov2-item, span[class*='radiov2-item']",
            );
            if (inner && !seen.has(inner)) {
              seen.add(inner);
              list.push(inner);
            }
            continue;
          }
          seen.add(el);
          list.push(el);
        }
      }
      return list;
    };

    /** @param {Element} el */
    const isVisible = (el) => {
      try {
        const s = window.getComputedStyle(el);
        if (s.display === "none" || s.visibility === "hidden") return false;
        const r = el.getBoundingClientRect();
        return r.width > 0 || r.height > 0;
      } catch {
        return true;
      }
    };

    /** @param {Element} el */
    const textOf = (el) =>
      normalize(el.textContent || el.getAttribute?.("title") || "");

    /** @param {Element} el */
    const matchesWant = (el) => {
      const t = textOf(el);
      if (t === want || t.includes(want)) return true;
      // 文案可能在子节点 / 兄弟节点
      const parentText = normalize(el.parentElement?.textContent || "");
      if (parentText === want || parentText.includes(want)) return true;
      return false;
    };

    let pick = null;
    let allCount = 0;
    for (let i = 0; i < 12; i++) {
      const radios = collectRadios().filter(isVisible);
      allCount = radios.length;
      pick =
        radios.find((el) => matchesWant(el)) ||
        // 兜底：任意节点树里带目标文案的 radiov2 容器
        radios.find((el) =>
          normalize(el.closest?.("label")?.textContent || "").includes(want),
        ) ||
        null;
      if (pick) break;
      await new Promise((r) => setTimeout(r, 200));
    }

    if (!pick) {
      return {
        ok: false,
        reason: `radiov2-item-not-found（目标：${wantText}，可见项 ${allCount}）`,
      };
    }

    // 点 span 本体；必要时再点父级 label/容器（保证 radio 选中）
    const targets = [
      pick,
      pick.closest?.("label"),
      pick.parentElement,
      pick.querySelector?.("input[type='radio']"),
      pick.querySelector?.("input"),
    ].filter(Boolean);

    const uniqueTargets = [...new Set(targets)];
    for (const t of uniqueTargets) {
      await this.dispatchRealClick(t);
      await new Promise((r) => setTimeout(r, 180));
    }

    await new Promise((r) => setTimeout(r, 350));
    return {
      ok: true,
      count: allCount,
      text: String(pick.textContent || wantText).replace(/\s+/g, " ").trim().slice(0, 40),
    };
  }

  /**
   * 在 not-fit-wrap 气泡中找到「修改话术」入口并点击
   * @param {Element} wrap
   * @param {Document[]} documents
   */
  async clickRejectScriptEditEntry(wrap, documents) {
    const docs = documents || this.collectAccessibleDocuments(true);
    const cfg = window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG || {};
    const xpath =
      cfg.rejectScriptEditEntryXPath ||
      '//*[@id="container"]//*[contains(@class,"not-fit-wrap")]//span[2]';

    let entry =
      this.evaluateXPathFirst(docs, xpath) ||
      (wrap
        ? this.evaluateXPathFirst(
            null,
            ".//div[1]/div[2]/div[1]/span[2]",
            wrap,
          )
        : null);

    if (!entry && wrap) {
      // 兜底：气泡内可点的 span / 图标
      const spans = [...wrap.querySelectorAll("span, i, a, button")];
      entry =
        spans.find((el) => /编辑|修改|设置|话术/.test(el.textContent || "")) ||
        spans.find((el) => {
          const cls = String(el.className || "");
          return /edit|setting|config|icon/i.test(cls);
        }) ||
        // 结构上的 span[2]
        wrap.querySelector("div div div span:nth-child(2)") ||
        spans[1] ||
        spans[spans.length - 1];
    }

    if (!entry) return { ok: false, reason: "未找到修改话术入口" };
    await this.dispatchRealClick(entry);
    return { ok: true, element: entry };
  }

  /**
   * 仅第一次：悬停不合适 → 打开修改话术后台 → 选模板项 → 写入拒简历话术 → 确定
   * 后续候选人跳过（bossRejectScriptSynced=true）
   * @param {Document[]} documents
   * @param {string} [scriptOverride]
   */
  async ensureBossRejectScriptSynced(documents, scriptOverride) {
    if (!this.askResumeRunState) {
      this.askResumeRunState = {
        loggedOnce: new Set(),
        aiDecisions: new Map(),
        completedSessions: new Set(),
        sessionUiAttempts: new Map(),
        bossRejectScriptSynced: false,
      };
    }

    if (this.askResumeRunState.bossRejectScriptSynced) {
      return { ok: true, skipped: true, reason: "already-synced" };
    }

    const script = String(
      scriptOverride ?? this.getAskResumeSettings()?.rejectScript ?? "",
    ).trim();
    if (!script) {
      return { ok: true, skipped: true, reason: "empty-script" };
    }

    if (!this.isAskResumeChatActionsEnabled()) {
      return { ok: false, skipped: false, reason: "chat-actions-disabled" };
    }

    let docs = documents || this.collectAccessibleDocuments(true);
    if (this.isOnlineResumeOverlayOpen?.(docs, "")) {
      await this.closeResumePanelOnly?.();
      await this.waitForResumePanelHidden?.(3000);
      docs = this.collectAccessibleDocuments(true);
    }

    const button = this.findInappropriateButton(docs);
    if (!button?.element) {
      return { ok: false, skipped: false, reason: "no-button" };
    }

    const hoverTarget = button.labelElement || button.element;
    try {
      chrome.runtime.sendMessage({
        type: "LOG_MESSAGE",
        data: {
          message:
            "首次同步拒简历话术到 BOSS：悬停「不合适」→ 打开修改话术后台 → 选「发送统一消息」→ 点「自定义回复语」→ 写入",
          type: "info",
        },
      });
    } catch {
      /* ignore */
    }

    const cleanupUi = async () => {
      await this.unhoverElement(hoverTarget);
      this.restoreForcedStyles();
      await new Promise((r) => setTimeout(r, 150));
    };

    try {
      // 1) 悬停并展开 not-fit-wrap
      await this.hoverElement(hoverTarget);
      await new Promise((r) => setTimeout(r, 300));
      await this.hoverElement(hoverTarget.parentElement || hoverTarget);
      await new Promise((r) => setTimeout(r, 250));

      let wrap = this.findNotFitWrap(
        this.collectAccessibleDocuments(true),
        hoverTarget,
      );
      for (let i = 0; i < 8 && !wrap; i++) {
        await this.hoverElement(hoverTarget);
        await new Promise((r) => setTimeout(r, 200));
        wrap = this.findNotFitWrap(
          this.collectAccessibleDocuments(true),
          hoverTarget,
        );
      }
      if (wrap) {
        this.forceShowElement(wrap);
        this.forceRevealHoverPanels(wrap);
      }

      // 2) 点击气泡中的修改入口
      const entryResult = await this.clickRejectScriptEditEntry(
        wrap,
        this.collectAccessibleDocuments(true),
      );
      if (!entryResult.ok) {
        await cleanupUi();
        return {
          ok: false,
          skipped: false,
          reason: entryResult.reason || "edit-entry-failed",
        };
      }

      // 3) 等待动态弹窗（弹窗出现后即可收起气泡样式）
      let dialog = null;
      for (let i = 0; i < 15; i++) {
        await new Promise((r) => setTimeout(r, 200));
        dialog = this.findBossDynamicDialog(
          this.collectAccessibleDocuments(true),
        );
        if (dialog) break;
      }
      // 弹窗已开：还原 not-fit-wrap 强制样式，避免挡页面
      this.restoreForcedStyles();
      if (!dialog) {
        await cleanupUi();
        return { ok: false, skipped: false, reason: "dialog-not-found" };
      }

      const cfg = window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG || {};
      const docs2 = this.collectAccessibleDocuments(true);

      // 4) 打开后台后：
      // ① 点 .ui-select-inner
      // ② 选「发送统一消息」
      // ③ 点 span.radiov2-item（进入可改话术，避免只选中默认第一条）
      // ④ 再写编辑区
      const selectResult = await this.selectRejectScriptUnifiedMessage(
        dialog,
        docs2,
      );
      if (!selectResult.ok) {
        try {
          chrome.runtime.sendMessage({
            type: "LOG_MESSAGE",
            data: {
              message: `选择「发送统一消息」未成功（${selectResult.reason}），仍尝试后续步骤`,
              type: "warning",
            },
          });
        } catch {
          /* ignore */
        }
      } else {
        try {
          chrome.runtime.sendMessage({
            type: "LOG_MESSAGE",
            data: {
              message: "已选择话术类型：发送统一消息",
              type: "info",
            },
          });
        } catch {
          /* ignore */
        }
      }

      // 刷新 dialog 引用（下拉可能改动了 DOM）
      dialog =
        this.findBossDynamicDialog(this.collectAccessibleDocuments(true)) ||
        dialog;

      const radioResult = await this.clickRejectScriptRadioItem(
        dialog,
        this.collectAccessibleDocuments(true),
      );
      if (!radioResult.ok) {
        try {
          chrome.runtime.sendMessage({
            type: "LOG_MESSAGE",
            data: {
              message: `未点到「自定义回复语」（${radioResult.reason}），写入可能仍落在默认第一条话术`,
              type: "warning",
            },
          });
        } catch {
          /* ignore */
        }
      } else {
        try {
          chrome.runtime.sendMessage({
            type: "LOG_MESSAGE",
            data: {
              message: `已选择「自定义回复语」${radioResult.text ? `（${radioResult.text}）` : ""}，准备写入话术`,
              type: "info",
            },
          });
        } catch {
          /* ignore */
        }
      }

      dialog =
        this.findBossDynamicDialog(this.collectAccessibleDocuments(true)) ||
        dialog;

      // 5) 填写话术编辑区（点 radio 后编辑器才可写，轮询等待）
      // 兼容 textarea / contenteditable / role=textbox，不强制 form
      const waited = await this.waitForRejectScriptEditField(18, 280);
      dialog = waited.dialog || dialog;
      let textarea = waited.field;

      if (!textarea) {
        // 最后再扫一遍全文档
        const docs3 = this.collectAccessibleDocuments(true);
        dialog = this.findBossDynamicDialog(docs3) || dialog;
        textarea = this.findRejectScriptEditField(docs3, dialog);
      }
      if (!textarea) {
        let hint = "无";
        try {
          const d = dialog || this.findBossDynamicDialog();
          if (d) {
            const ta = d.querySelectorAll("textarea").length;
            const ce = d.querySelectorAll("[contenteditable='true']").length;
            const allInps = [...d.querySelectorAll("input")];
            const writable = allInps.filter((el) =>
              this.isRejectScriptWritableInput(el),
            );
            const sample = allInps
              .slice(0, 3)
              .map((el) => {
                const t = el.getAttribute("type") || "text";
                const ro = el.readOnly ? "ro" : "rw";
                const cls = String(el.className || "").slice(0, 40);
                const ph = String(el.placeholder || "").slice(0, 20);
                return `input[type=${t},${ro},cls=${cls},ph=${ph}]`;
              })
              .join("; ");
            hint = `dialog内 textarea=${ta} contenteditable=${ce} input=${allInps.length} writable=${writable.length}${sample ? ` | ${sample}` : ""}`;
          } else {
            hint = "dialog已消失";
          }
        } catch {
          /* ignore */
        }
        await cleanupUi();
        return {
          ok: false,
          skipped: false,
          reason: `textarea-not-found（${hint}）`,
        };
      }

      try {
        textarea.scrollIntoView?.({ block: "center", inline: "nearest" });
      } catch {
        /* ignore */
      }
      try {
        textarea.focus?.();
        textarea.click?.();
      } catch {
        /* ignore */
      }
      await new Promise((r) => setTimeout(r, 120));

      // 选中已有内容再覆盖，兼容部分受控组件
      try {
        if (typeof textarea.select === "function") textarea.select();
        else if (textarea.setSelectionRange && textarea.value != null) {
          textarea.setSelectionRange(0, String(textarea.value).length);
        }
      } catch {
        /* ignore */
      }

      const filled = this.setNodeTextContent(textarea, script);
      if (!filled) {
        try {
          textarea.focus();
          if ("value" in textarea) {
            textarea.value = script;
          } else {
            textarea.textContent = script;
          }
          textarea.dispatchEvent(new Event("input", { bubbles: true }));
          textarea.dispatchEvent(new Event("change", { bubbles: true }));
        } catch {
          /* ignore */
        }
      }
      // 校验是否写入成功；input 受控组件有时要二次触发
      try {
        const now =
          textarea.value != null
            ? String(textarea.value)
            : String(textarea.textContent || "");
        if (!now.includes(script.slice(0, Math.min(8, script.length)))) {
          const proto =
            (textarea.tagName || "").toUpperCase() === "TEXTAREA"
              ? window.HTMLTextAreaElement?.prototype
              : window.HTMLInputElement?.prototype;
          const setter = proto
            ? Object.getOwnPropertyDescriptor(proto, "value")?.set
            : null;
          if (setter) setter.call(textarea, script);
          textarea.dispatchEvent(
            new InputEvent("input", {
              bubbles: true,
              data: script,
              inputType: "insertText",
            }),
          );
          textarea.dispatchEvent(new Event("change", { bubbles: true }));
        }
      } catch {
        /* ignore */
      }

      try {
        const tag = (textarea.tagName || "").toLowerCase();
        chrome.runtime.sendMessage({
          type: "LOG_MESSAGE",
          data: {
            message: `话术已写入编辑区（${tag}${textarea.className ? "." + String(textarea.className).split(/\s+/)[0] : ""}，${script.length} 字）`,
            type: "info",
          },
        });
      } catch {
        /* ignore */
      }
      await new Promise((r) => setTimeout(r, 250));

      // 6) 点击确定/完成
      const docs4 = this.collectAccessibleDocuments(true);
      dialog = this.findBossDynamicDialog(docs4) || dialog;
      let confirmBtn =
        this.evaluateXPathFirst(
          docs4,
          cfg.rejectScriptConfirmXPath ||
            '//*[starts-with(@id,"boss-dynamic-dialog")]//span[contains(normalize-space(.),"确定") or contains(normalize-space(.),"完成") or contains(normalize-space(.),"保存")]',
        ) || null;

      if (!confirmBtn && dialog) {
        const buttons = [
          ...dialog.querySelectorAll(
            "button, span, a, [class*='btn'], [role='button']",
          ),
        ];
        confirmBtn =
          buttons.find((el) =>
            /^(确定|完成|保存|确认)$/.test(
              (el.textContent || "").replace(/\s+/g, ""),
            ),
          ) ||
          buttons.find((el) =>
            /确定|完成|保存|确认/.test(
              (el.textContent || "").replace(/\s+/g, ""),
            ),
          ) ||
          dialog.querySelector(":scope > div > div > div:nth-child(3) > span") ||
          dialog.querySelector("div:nth-child(3) > span");
      }

      if (!confirmBtn) {
        await cleanupUi();
        return { ok: false, skipped: false, reason: "confirm-not-found" };
      }

      await this.dispatchRealClick(confirmBtn);
      await new Promise((r) => setTimeout(r, 500));

      // 关闭残留弹窗
      const still = this.findBossDynamicDialog(
        this.collectAccessibleDocuments(true),
      );
      if (still) {
        const close =
          still.querySelector(
            '[class*="close"], .boss-popup__close, [aria-label="关闭"]',
          ) || null;
        if (close) await this.dispatchRealClick(close);
        await new Promise((r) => setTimeout(r, 200));
      }

      this.askResumeRunState.bossRejectScriptSynced = true;
      try {
        chrome.runtime.sendMessage({
          type: "LOG_MESSAGE",
          data: {
            message: `拒简历话术已写入 BOSS 后台（仅首次，共 ${script.length} 字），后续候选人将直接点「不合适」`,
            type: "success",
          },
        });
      } catch {
        /* ignore */
      }

      await cleanupUi();
      return { ok: true, skipped: false, scriptLength: script.length };
    } catch (error) {
      await cleanupUi();
      return {
        ok: false,
        skipped: false,
        reason: error?.message || String(error),
      };
    }
  }

  /**
   * AI 不匹配时：点不合适（话术已在首次同步到 BOSS，此处不再改气泡）
   * @param {{ element: Element }} sessionItem
   * @param {Document[]} documents
   * @param {Function} buildLog
   * @param {string} key
   * @param {{ aiMatched?: boolean, aiReason?: string }} aiContext
   */
  async executeRejectWithScript(
    sessionItem,
    documents,
    buildLog,
    key,
    aiContext = {},
  ) {
    const name = this.getSessionDisplayName(sessionItem);
    const settings = this.getAskResumeSettings() || {};
    const rejectScript = String(settings.rejectScript || "").trim();
    let docs = documents || this.collectAccessibleDocuments(true);

    await this.waitHumanThinkPause("点不合适前");

    if (this.detectInappropriateMarked(docs, sessionItem)) {
      this.markAskResumeSessionCompleted(key);
      return {
        status: "skip_done",
        key,
        name,
        message: buildLog(aiContext, "跳过（已标记不合适）"),
        logType: "info",
      };
    }

    if (!this.isAskResumeChatActionsEnabled()) {
      return {
        status: "ready_to_reject",
        key,
        name,
        message: buildLog(
          aiContext,
          "AI不匹配，将点击不合适（操作暂未启用）",
        ),
        logType: "info",
        aiMatch: { isok: false, msg: aiContext.aiReason || "" },
      };
    }

    // 确保在线简历浮层已关，避免挡住操作按钮
    if (this.isOnlineResumeOverlayOpen?.(docs, "")) {
      await this.closeResumePanelOnly?.();
      await this.waitForResumePanelHidden?.(3000);
      docs = this.collectAccessibleDocuments(true);
    }

    // 若首次同步失败，拒绝前再尝试一次
    if (rejectScript && !this.askResumeRunState?.bossRejectScriptSynced) {
      const sync = await this.ensureBossRejectScriptSynced(docs, rejectScript);
      if (!sync.ok && !sync.skipped) {
        try {
          chrome.runtime.sendMessage({
            type: "LOG_MESSAGE",
            data: {
              message: `同步拒简历话术未成功（${sync.reason}），仍将尝试点击不合适`,
              type: "warning",
            },
          });
        } catch {
          /* ignore */
        }
      }
      docs = this.collectAccessibleDocuments(true);
    }

    const inappropriateBtn = this.findInappropriateButton(docs);
    if (!inappropriateBtn?.element) {
      return {
        status: "wait_button",
        key,
        name,
        message: buildLog(aiContext, "不合适按钮暂不可点，等待下轮"),
        logType: "warning",
        aiMatch: { isok: false, msg: aiContext.aiReason || "" },
      };
    }

    // 话术已在 BOSS 后台配置好，这里只点击「不合适」
    const rejectOutcome = await this.clickInappropriate(docs, {
      skipScriptEdit: true,
    });
    const outcome =
      typeof rejectOutcome === "object" && rejectOutcome
        ? rejectOutcome
        : {
            ok: !!rejectOutcome,
            filled: false,
            clicked: !!rejectOutcome,
            marked: !!rejectOutcome,
            detail: rejectOutcome ? "已处理" : "失败",
          };

    if (outcome.ok) {
      this.markAskResumeSessionCompleted(key);
      return {
        status: "rejected",
        key,
        name,
        message: buildLog(
          aiContext,
          `AI不匹配，已点击不合适（${outcome.detail || "完成"}）`,
        ),
        logType: outcome.marked ? "info" : "warning",
        aiMatch: { isok: false, msg: aiContext.aiReason || "" },
        rejectOutcome: outcome,
      };
    }

    await new Promise((resolve) => setTimeout(resolve, 800));
    if (
      this.detectInappropriateMarked(
        this.collectAccessibleDocuments(true),
        sessionItem,
      )
    ) {
      this.markAskResumeSessionCompleted(key);
      return {
        status: "rejected",
        key,
        name,
        message: buildLog(aiContext, "AI不匹配，已标记不合适（延迟确认）"),
        logType: "info",
        aiMatch: { isok: false, msg: aiContext.aiReason || "" },
      };
    }

    return {
      status: "wait_button",
      key,
      name,
      message: buildLog(
        aiContext,
        `标记不合适未成功（${outcome.detail || "未知"}），等待下轮重试`,
      ),
      logType: "warning",
      aiMatch: { isok: false, msg: aiContext.aiReason || "" },
      rejectOutcome: outcome,
    };
  }

  /**
   * @param {Element} el
   */
  isElementClickable(el) {
    if (!el) return false;
    if (el.disabled) return false;
    if (el.getAttribute("aria-disabled") === "true") return false;

    const cls = typeof el.className === "string" ? el.className : "";
    if (/disabled|is-disabled|btn-disabled|not-allowed/i.test(cls)) return false;

    const style = window.getComputedStyle(el);
    if (style.pointerEvents === "none" || style.visibility === "hidden") {
      return false;
    }
    if (Number(style.opacity) === 0) return false;

    return true;
  }

  /**
   * 定位「求简历」：优先 class=operate-icon-item 且文案为「求简历」
   * @param {Document[]} documents
   */
  findAskResumeButton(documents) {
    const docs = documents || this.collectAccessibleDocuments(true);
    const cfg = window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG || {};
    const viewWidth = window.innerWidth || 1920;

    /** @type {{ element: Element, labelElement: Element, score: number, source: string }[]} */
    const scored = [];

    const pushCandidate = (el, source, baseScore = 0) => {
      if (!el) return;
      const text = (el.textContent || "").replace(/\s+/g, "");
      if (!/求简历|索要简历/.test(text)) return;
      if (text.length > 16) return;

      let score = baseScore;
      if (text === "求简历") score += 20;
      else if (/求简历|索要简历/.test(text)) score += 10;

      try {
        const rect = el.getBoundingClientRect();
        if (rect.width < 1 || rect.height < 1) score -= 8;
        else score += 3;
        if (rect.left > viewWidth * 0.35) score += 6;
      } catch {
        /* ignore */
      }

      if (this.isOperateIconItem?.(el)) score += 40;
      if (el.closest?.(".operate-icon-item, [class*='operate-icon-item']")) {
        score += 25;
      }

      const item =
        el.closest?.(".operate-icon-item, [class*='operate-icon-item']") || el;
      scored.push({
        element: item,
        labelElement: el,
        score,
        source,
      });
    };

    // 1) operate-icon-item
    for (const doc of docs) {
      const selector =
        cfg.askResumeButtonSelector ||
        ".operate-icon-item, [class*='operate-icon-item']";
      try {
        doc.querySelectorAll(selector).forEach((el) => {
          pushCandidate(el, "operate-icon-item", 50);
        });
      } catch {
        /* ignore */
      }
    }

    // 2) XPath
    const xpath =
      cfg.askResumeButtonXPath ||
      '//*[@id="container"]//*[contains(@class,"operate-icon-item") and contains(normalize-space(.),"求简历")]';
    const byXPath = this.evaluateXPathFirst(docs, xpath);
    if (byXPath) pushCandidate(byXPath, "xpath", 30);

    // 3) 文案兜底
    for (const doc of docs) {
      for (const el of doc.querySelectorAll(
        "span, button, a, div, [role='button']",
      )) {
        const t = (el.textContent || "").replace(/\s+/g, "");
        if (t === "求简历" || t === "索要简历") {
          pushCandidate(el, "text", 5);
        }
      }
    }

    scored.sort((a, b) => b.score - a.score);
    if (scored[0]) {
      return {
        element: scored[0].element,
        labelElement: scored[0].labelElement,
        clickable: true,
        source: scored[0].source,
      };
    }

    return null;
  }

  /**
   * 点击求简历后的确认节点（用户提供 XPath + 文案兜底）
   * @param {Document[]} documents
   */
  async clickAskResumeConfirm(documents) {
    const docs = documents || this.collectAccessibleDocuments(true);
    const cfg = window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG || {};
    const xpath =
      cfg.askResumeConfirmXPath ||
      '//*[@id="container"]/div[1]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div/div/span[2]';

    let el = this.evaluateXPathFirst(docs, xpath);

    // 宽松：container 下可见气泡/浮层中的 span[2] 或「确定/发送」
    if (!el) {
      for (const doc of docs) {
        const container = doc.getElementById("container") || doc.body;
        if (!container) continue;
        // 尝试与用户结构相近的 span[2]
        const spans = container.querySelectorAll(
          '[class*="operate"] span, [class*="dropdown"] span, [class*="popover"] span, [class*="tip"] span, [class*="menu"] span',
        );
        for (const span of spans) {
          const t = (span.textContent || "").replace(/\s+/g, "");
          if (/^(确定|确认|发送|提交|好的)$/.test(t)) {
            el = span;
            break;
          }
        }
        if (el) break;
      }
    }

    if (!el) {
      // 弹窗内确定
      const dialog =
        this.findBossDynamicDialog?.(docs) ||
        this.findInappropriateDialog?.(docs);
      if (dialog) {
        el = [...dialog.querySelectorAll("button, span, a")].find((n) =>
          /^(确定|确认|发送|提交)$/.test(
            (n.textContent || "").replace(/\s+/g, ""),
          ),
        );
      }
    }

    if (!el) {
      return { ok: false, reason: "未找到求简历确认按钮" };
    }

    await this.dispatchRealClick(el);
    return { ok: true, element: el };
  }

  /**
   * @param {string} text
   */
  isSystemMessageText(text) {
    return /简历请求|系统提示|温馨提示|您已向|对方已|查看过您的|查看你的职位|沟通的职位|请礼貌|已读|撤回|发送了名片|交换联系方式|这条消息由系统|开启了沟通|职位链接|不感兴趣/.test(
      text,
    );
  }

  /**
   * @param {Element} el
   * @returns {'hr' | 'candidate' | 'system' | 'unknown'}
   */
  classifyMessageSide(el) {
    if (!el) return "unknown";

    let node = el;
    for (let depth = 0; depth < 8 && node; depth += 1) {
      const cls = typeof node.className === "string" ? node.className : "";
      if (/item-system|message-system|msg-system|system-tip/i.test(cls)) {
        return "system";
      }
      if (
        /item-myself|message-item-self|item-self|item-me|msg-self|is-self|is-mine|text-self|message-boss|msg-boss/i.test(
          cls,
        )
      ) {
        return "hr";
      }
      if (
        /item-friend|item-geek|message-item-friend|msg-friend|is-friend|text-friend|message-geek|msg-geek/i.test(
          cls,
        )
      ) {
        return "candidate";
      }
      node = node.parentElement;
    }

    return this.classifyMessageSideByPosition(el);
  }

  /**
   * 聊天气泡左右位置：右侧=HR，左侧=候选人
   * @param {Element} el
   */
  classifyMessageSideByPosition(el) {
    if (!el) return "unknown";

    const bubble =
      el.closest(
        '[class*="message-item"], [class*="msg-item"], [class*="chat-msg"], [class*="im-msg"], [class*="text"]',
      ) || el;
    const container =
      bubble.closest(
        '[class*="chat-conversation"], [class*="chat-history"], [class*="message-list"], [class*="chat-content"], [class*="im-chat"]',
      ) || bubble.parentElement;

    if (!container) return "unknown";

    const bubbleRect = bubble.getBoundingClientRect();
    const containerRect = container.getBoundingClientRect();
    if (bubbleRect.width < 1 || containerRect.width < 1) return "unknown";

    const bubbleCenter = bubbleRect.left + bubbleRect.width / 2;
    const containerCenter = containerRect.left + containerRect.width / 2;
    const threshold = Math.max(24, containerRect.width * 0.12);

    if (bubbleCenter > containerCenter + threshold) return "hr";
    if (bubbleCenter < containerCenter - threshold) return "candidate";

    return "unknown";
  }

  /**
   * 按 DOM 顺序收集聊天消息（用于判断首条真实消息来自哪一方）
   * @param {Document[]} documents
   */
  collectChatMessageItems(documents) {
    const items = [];
    const seen = new Set();
    const roots = this.getChatPanelRoots(documents);
    const rowSelector =
      '[class*="message-item"], [class*="msg-item"], [class*="chat-msg"], [class*="im-msg"]';

    const scanRoot = (root) => {
      root.querySelectorAll(rowSelector).forEach((row) => {
        if (seen.has(row)) return;

        const parentRow = row.parentElement?.closest(rowSelector);
        if (parentRow && parentRow !== row) return;

        seen.add(row);
        const side = this.classifyMessageSide(row);
        const text = row.textContent?.replace(/\s+/g, " ").trim() || "";
        if (!text || text.length > 2000) return;

        items.push({ side, text, element: row });
      });
    };

    if (roots.length) {
      roots.forEach(scanRoot);
      return items;
    }

    for (const doc of documents) {
      doc.querySelectorAll(rowSelector).forEach((row) => {
        if (seen.has(row)) return;
        if (row.closest('[class*="friend-list"], [role="group"] [role="listitem"]')) {
          return;
        }

        const parentRow = row.parentElement?.closest(rowSelector);
        if (parentRow && parentRow !== row) return;

        seen.add(row);
        const side = this.classifyMessageSide(row);
        const text = row.textContent?.replace(/\s+/g, " ").trim() || "";
        if (!text || text.length > 2000) return;

        items.push({ side, text, element: row });
      });
    }

    return items;
  }

  /**
   * @param {{ element: Element }} sessionItem
   * @returns {'hr' | 'candidate' | 'unknown'}
   */
  getSessionInitiatorFromListItem(sessionItem) {
    const el = sessionItem.element;
    const fullText = el.textContent?.replace(/\s+/g, " ") || "";

    const candidateHints = [
      /牛人新招呼/,
      /新牛人/,
      /对方发起/,
      /牛人主动/,
      /向你咨询/,
      /对方向你/,
      /主动找你/,
      /向你打招呼/,
    ];
    const hrHints = [/你发起/, /你打招呼/, /已向牛人/, /你发送/, /你沟通/];

    for (const pattern of candidateHints) {
      if (pattern.test(fullText)) return "candidate";
    }
    for (const pattern of hrHints) {
      if (pattern.test(fullText)) return "hr";
    }

    const tagEls = el.querySelectorAll(
      '[class*="source"], [class*="tag"], [class*="label"], [class*="badge"], [class*="status"]',
    );
    for (const tag of tagEls) {
      const tagText = tag.textContent?.replace(/\s+/g, "") || "";
      if (/新招呼|主动|咨询|牛人找/.test(tagText)) return "candidate";
      if (/你打|你发起/.test(tagText)) return "hr";
    }

    return "unknown";
  }

  /**
   * @param {Document[]} documents
   */
  analyzeMessageSides(documents) {
    const messages = this.collectChatMessageItems(documents);
    let hrCount = 0;
    let candidateCount = 0;
    let firstSide = null;

    for (const msg of messages) {
      if (msg.side === "system" || this.isSystemMessageText(msg.text)) continue;
      if (msg.side === "hr") hrCount += 1;
      if (msg.side === "candidate") candidateCount += 1;
      if (!firstSide && (msg.side === "hr" || msg.side === "candidate")) {
        firstSide = msg.side;
      }
    }

    return { hrCount, candidateCount, firstSide };
  }

  normalizePersonName(name = "") {
    return name
      .replace(/[先生女士]/g, "")
      .replace(/\s+/g, "")
      .trim()
      .toLowerCase();
  }

  /**
   * @param {object} friend
   * @returns {'hr' | 'candidate' | 'unknown'}
   */
  parseFriendInitiatorFromApi(friend) {
    if (!friend || typeof friend !== "object") return "unknown";

    const label = [
      friend.relationLabel,
      friend.sourceTitle,
      friend.sourceDesc,
      friend.lastMsg,
      friend.tip,
    ]
      .filter(Boolean)
      .join(" ");

    if (/牛人新招呼|对方主动|牛人主动|向你咨询|对方向你|主动找你/.test(label)) {
      return "candidate";
    }
    if (/你发起|你打招呼|已向牛人|你发送|你沟通/.test(label)) {
      return "hr";
    }

    // BOSS 常见：friendSource 0=牛人主动，1=BOSS主动；relationType 1=牛人主动，2=BOSS主动
    const friendSource = friend.friendSource ?? friend.source ?? friend.chatSource;
    if (friendSource === 0 || friendSource === "0") return "candidate";
    if (friendSource === 1 || friendSource === "1") return "hr";

    const relationType = friend.relationType ?? friend.relation;
    if (relationType === 1 || relationType === "1") return "candidate";
    if (relationType === 2 || relationType === "2") return "hr";

    return "unknown";
  }

  cacheFriendInitiator(name, initiator, source) {
    const key = this.normalizePersonName(name);
    if (!key || initiator === "unknown") return;
    this.friendInitiatorCache.set(key, { initiator, source });
  }

  /**
   * @param {object} payload
   */
  processFriendListData(payload) {
    const zpData = payload?.zpData || payload || {};
    const friends =
      zpData.friendList ||
      zpData.friends ||
      zpData.list ||
      zpData.result ||
      [];

    if (!Array.isArray(friends)) return;

    for (const friend of friends) {
      const name = friend.name || friend.geekName || friend.showName;
      const initiator = this.parseFriendInitiatorFromApi(friend);
      this.cacheFriendInitiator(name, initiator, "friend-list-api");
    }
  }

  /**
   * @param {object} payload
   */
  processChatHistoryData(payload) {
    const zpData = payload?.zpData || payload || {};
    const messages = zpData.messages || zpData.msgList || zpData.list || [];
    if (!Array.isArray(messages) || !messages.length) return;

    const geekName =
      zpData.geekName || zpData.name || zpData.friendName || zpData.toName;
    if (!geekName) return;

    this.cacheSessionResumeStatus(
      geekName,
      this.extractChatHistorySignals(messages),
    );

    const first = messages.find((msg) => {
      const body = this.getMessageBodyText(msg);
      return body && body.trim().length > 0;
    });
    if (!first) return;

    const from = first.from || first.fromUid || first.sender || first.source;
    const fromType = first.fromType ?? first.msgType ?? first.type;
    let initiator = "unknown";

    if (fromType === 1 || from === 1 || from === "boss" || from === "hr") {
      initiator = "hr";
    } else if (
      fromType === 2 ||
      from === 2 ||
      from === "geek" ||
      from === "candidate"
    ) {
      initiator = "candidate";
    }

    this.cacheFriendInitiator(geekName, initiator, "chat-history-api");
  }

  /**
   * @param {string} name
   */
  getInitiatorFromFriendCache(name) {
    const key = this.normalizePersonName(name);
    if (!key) return { initiator: "unknown", source: "" };

    if (this.friendInitiatorCache.has(key)) {
      return this.friendInitiatorCache.get(key);
    }

    for (const [cachedName, value] of this.friendInitiatorCache.entries()) {
      if (cachedName.includes(key) || key.includes(cachedName)) {
        return value;
      }
    }

    return { initiator: "unknown", source: "" };
  }

  matchGreetedRecord(list, name) {
    const key = this.normalizePersonName(name);
    if (!key || !Array.isArray(list)) return false;

    return list.some((item) => {
      if (!item?.greeted) return false;
      const itemName = this.normalizePersonName(item.name || "");
      if (!itemName || !key) return false;
      if (itemName === key) return true;
      if (itemName.length >= 2 && key.length >= 2) {
        return itemName.includes(key) || key.includes(itemName);
      }
      return false;
    });
  }

  async getInitiatorFromGreetedRecord(name) {
    const key = this.normalizePersonName(name);
    if (!key) return false;

    if (Array.isArray(this._greetedListCache)) {
      return this.matchGreetedRecord(this._greetedListCache, name);
    }

    return new Promise((resolve) => {
      chrome.storage.local.get(["招聘速聊助手_saved_resumes"], (result) => {
        const list = result.招聘速聊助手_saved_resumes || [];
        resolve(this.matchGreetedRecord(list, name));
      });
    });
  }

  /**
   * @param {Document[]} documents
   * @param {{ element: Element }} [sessionItem]
   * @returns {'hr' | 'candidate' | 'unknown'}
   */
  identifySessionInitiatorFromDom(documents, sessionItem) {
    const candidateSystemPatterns = [
      /对方主动向你发起沟通/,
      /牛人向你发起沟通/,
      /对方向你发起沟通/,
      /对方查看了你的职位/,
      /牛人查看了你的职位/,
      /对方正在查看你的职位/,
      /收到了牛人.*招呼/,
      /牛人新招呼/,
      /对方主动/,
      /牛人主动/,
      /对方向你/,
      /向你咨询/,
      /向你发起/,
      /主动向你/,
    ];
    const hrSystemPatterns = [
      /你向对方发起沟通/,
      /你向牛人发起沟通/,
      /你已向该牛人发送/,
      /你已向牛人发送/,
      /你发送了打招呼/,
      /你发起沟通/,
      /你向对方/,
      /你向TA/,
      /你发起/,
      /已向牛人/,
      /发送了打招呼/,
      /向牛人发送了消息/,
      /你沟通了牛人/,
    ];

    if (sessionItem) {
      const listHint = this.getSessionInitiatorFromListItem(sessionItem);
      if (listHint !== "unknown") return listHint;
    }

    const chatText = this.getChatAreaText(documents);
    for (const pattern of candidateSystemPatterns) {
      if (pattern.test(chatText)) return "candidate";
    }
    for (const pattern of hrSystemPatterns) {
      if (pattern.test(chatText)) return "hr";
    }

    // 扫描系统提示条（候选人主动时常见「牛人向你发起沟通」等）
    for (const doc of documents) {
      const tipEls = doc.querySelectorAll(
        '[class*="system"], [class*="tip"], [class*="notice"], [class*="message-card"]',
      );
      for (const el of tipEls) {
        const text = el.textContent?.replace(/\s+/g, " ") || "";
        for (const pattern of candidateSystemPatterns) {
          if (pattern.test(text)) return "candidate";
        }
        for (const pattern of hrSystemPatterns) {
          if (pattern.test(text)) return "hr";
        }
      }
    }

    const hasCandidateIntro = this.hasCandidateIntroText(chatText);
    const hasHrIntro = hrSystemPatterns.some((pattern) => pattern.test(chatText));

    const messages = this.collectChatMessageItems(documents);
    for (let i = 0; i < messages.length; i++) {
      const msg = messages[i];
      if (msg.side === "system" || this.isSystemMessageText(msg.text)) {
        for (const pattern of candidateSystemPatterns) {
          if (pattern.test(msg.text)) return "candidate";
        }
        for (const pattern of hrSystemPatterns) {
          if (pattern.test(msg.text)) return "hr";
        }
        continue;
      }

      if (msg.side === "candidate") {
        return "candidate";
      }

      if (msg.side === "hr") {
        // 候选人主动场景：常有系统提示 + HR 自动回复模板，首条气泡在右侧
        if (hasCandidateIntro && !hasHrIntro) return "candidate";

        const laterCandidate = messages
          .slice(i + 1)
          .some(
            (m) =>
              m.side === "candidate" &&
              m.text.length > 0 &&
              !this.isSystemMessageText(m.text),
          );
        if (laterCandidate && this.isLikelyHrAutoReply(msg.text) && !hasHrIntro) {
          return "candidate";
        }

        return "hr";
      }
    }

    if (hasCandidateIntro && !hasHrIntro) return "candidate";
    if (hasHrIntro && !hasCandidateIntro) return "hr";

    const sides = this.analyzeMessageSides(documents);
    if (sides.firstSide === "candidate") return "candidate";
    if (sides.firstSide === "hr" && !hasCandidateIntro) return "hr";

    return "unknown";
  }

  /**
   * @param {Document[]} documents
   * @param {{ element: Element }} sessionItem
   */
  async identifySessionInitiator(documents, sessionItem) {
    const name = this.getSessionDisplayName(sessionItem);

    const greeted = await this.getInitiatorFromGreetedRecord(name);
    if (greeted) {
      return { initiator: "hr", source: "greet-record" };
    }

    const cached = this.getInitiatorFromFriendCache(name);
    if (cached.initiator !== "unknown") {
      return { initiator: cached.initiator, source: cached.source };
    }

    const domInitiator = this.identifySessionInitiatorFromDom(documents, sessionItem);
    return { initiator: domInitiator, source: "dom" };
  }

  hasCandidateIntroText(text = "") {
    return /对方主动向你发起沟通|牛人向你发起沟通|对方向你发起沟通|对方查看了你的职位|牛人查看了你的职位|牛人新招呼|对方主动|牛人主动|对方向你|向你咨询|向你发起|主动向你/.test(
      text,
    );
  }

  isLikelyHrAutoReply(text = "") {
    return /您好|你好|感谢|我是|方便|感兴趣|岗位|薪资|期待|沟通/.test(text);
  }

  formatInitiatorReason(initiator, source) {
    if (initiator === "candidate") {
      if (source === "friend-list-api") return "候选人主动发起（好友列表接口），本阶段跳过";
      if (source === "chat-history-api") return "候选人主动发起（聊天记录接口），本阶段跳过";
      if (source === "dom") return "候选人主动发起（页面识别），本阶段跳过";
      return "候选人主动发起，本阶段跳过";
    }
    if (initiator === "hr") {
      if (source === "greet-record") return "HR主动发起（插件打招呼记录）";
      if (source === "friend-list-api") return "HR主动发起（好友列表接口）";
      if (source === "chat-history-api") return "HR主动发起（聊天记录接口）";
      return "HR主动发起";
    }
    return "未识别为HR主动发起，本阶段跳过";
  }

  /**
   * @param {Document[]} documents
   */
  isCandidateReplied(documents) {
    if (this.detectResumeReceivedInChat(documents)) return true;

    return this.collectChatMessageItems(documents).some(
      (msg) =>
        msg.side === "candidate" &&
        msg.text.length > 0 &&
        !this.isSystemMessageText(msg.text),
    );
  }

  /**
   * @param {Document[]} documents
   */
  async confirmOperateDialog(documents) {
    for (const doc of documents) {
      const buttons = doc.querySelectorAll(
        '[class*="boss-btn-primary"], [class*="btn-primary"], button',
      );
      for (const btn of buttons) {
        const text = btn.textContent?.trim() || "";
        if (/确认|确定|发送|同意/.test(text) && this.isElementClickable(btn)) {
          btn.click();
          await new Promise((resolve) => setTimeout(resolve, 250));
          return true;
        }
      }
    }
    return false;
  }

  /**
   * 点击 operate-icon-item「求简历」，再点确认 span
   * @param {Document[]} documents
   * @returns {Promise<{ ok: boolean, detail: string, requestSent: boolean }>}
   */
  async clickAskResume(documents) {
    this.restoreForcedStyles?.();
    await this.maybeWaitHumanThinkPause("点求简历前");
    let docs = documents || this.collectAccessibleDocuments(true);

    if (this.isOnlineResumeOverlayOpen?.(docs, "")) {
      await this.closeResumePanelOnly?.();
      await this.waitForResumePanelHidden?.(2500);
      docs = this.collectAccessibleDocuments(true);
    }

    const button = this.findAskResumeButton(docs);
    if (!button?.element) {
      return {
        ok: false,
        detail: "未找到 operate-icon-item「求简历」按钮",
        requestSent: false,
      };
    }

    const item =
      button.element.closest?.(
        ".operate-icon-item, [class*='operate-icon-item']",
      ) || button.element;

    try {
      chrome.runtime.sendMessage({
        type: "LOG_MESSAGE",
        data: {
          message: `准备点击求简历（来源=${button.source || "unknown"}，class=${String(item.className || "").slice(0, 40)}）`,
          type: "info",
        },
      });
    } catch {
      /* ignore */
    }

    await this.unhoverElement?.(item);
    this.restoreForcedStyles?.();
    await new Promise((r) => setTimeout(r, 150));

    try {
      item.scrollIntoView?.({ block: "center", inline: "nearest" });
    } catch {
      /* ignore */
    }
    await new Promise((r) => setTimeout(r, 100));

    // 多策略点击求简历
    const targets = [item];
    for (const child of item.querySelectorAll("span, i, em, div, a")) {
      const t = (child.textContent || "").replace(/\s+/g, "");
      if (t === "求简历" || /求简历|索要简历/.test(t)) targets.push(child);
    }
    try {
      const rect = item.getBoundingClientRect();
      const topEl = document.elementFromPoint(
        rect.left + rect.width / 2,
        rect.top + rect.height / 2,
      );
      if (topEl) {
        targets.push(
          topEl.closest?.(".operate-icon-item, [class*='operate-icon-item']") ||
            topEl,
        );
      }
    } catch {
      /* ignore */
    }

    for (const el of [...new Set(targets.filter(Boolean))]) {
      await this.dispatchRealClick(el);
      await new Promise((r) => setTimeout(r, 280));
    }

    await new Promise((r) => setTimeout(r, 350));

    // 第二步：确认节点
    const confirmResult = await this.clickAskResumeConfirm(
      this.collectAccessibleDocuments(true),
    );
    if (confirmResult.ok) {
      try {
        chrome.runtime.sendMessage({
          type: "LOG_MESSAGE",
          data: {
            message: "已点击求简历后的确认按钮",
            type: "info",
          },
        });
      } catch {
        /* ignore */
      }
    } else {
      // 回退通用确认弹窗
      await this.confirmOperateDialog(this.collectAccessibleDocuments(true));
      try {
        chrome.runtime.sendMessage({
          type: "LOG_MESSAGE",
          data: {
            message: `求简历确认节点：${confirmResult.reason || "未命中"}，已尝试通用确认`,
            type: "warning",
          },
        });
      } catch {
        /* ignore */
      }
    }

    await new Promise((r) => setTimeout(r, 500));

    let requestSent = false;
    for (let i = 0; i < 8; i++) {
      requestSent = this.detectResumeRequestSent(
        this.collectAccessibleDocuments(true),
      );
      if (requestSent) break;
      await new Promise((r) => setTimeout(r, 300));
    }

    this.restoreForcedStyles?.();

    return {
      ok: requestSent || confirmResult.ok,
      detail: requestSent
        ? "已检测到简历请求已发送"
        : confirmResult.ok
          ? "已点求简历并确认（等待系统回显）"
          : "已点求简历，但未检测到请求已发送",
      requestSent,
      confirmed: !!confirmResult.ok,
    };
  }

  /**
   * AI 匹配后：发送求简历话术 + 点击求简历 + 确认
   * 条件：候选人主动且未 resumeRequestSent（调用方保证）
   */
  async executeAskResumeWithScript(
    sessionItem,
    documents,
    buildLog,
    key,
    aiContext = {},
  ) {
    const name = this.getSessionDisplayName(sessionItem);
    const settings = this.getAskResumeSettings() || {};
    const resumeScript = String(settings.resumeScript || "").trim();
    let docs = documents || this.collectAccessibleDocuments(true);
    let status = this.assessSessionStatus(docs, sessionItem);

    if (status.resumeReceived) {
      // AI 匹配后若已有简历：走下载存本地，不再重复求简历
      return this.handleReceivedResumeFileDownload(
        sessionItem,
        docs,
        buildLog,
        key,
        { ...aiContext, ...status },
      );
    }

    if (status.resumeRequestSent) {
      this.markAskResumeSessionCompleted(key);
      return {
        status: "skip_sent",
        key,
        name,
        message: buildLog(aiContext, "跳过（简历请求已发送）"),
        logType: "info",
      };
    }

    // 1) 发送求简历话术
    if (resumeScript) {
      const alreadySent = this.hasScriptBeenSent(docs, resumeScript);
      if (!alreadySent) {
        if (!this.isAskResumeChatActionsEnabled()) {
          return {
            status: "ready_to_ask",
            key,
            name,
            message: buildLog(
              aiContext,
              "AI匹配，将发送求简历话术（操作暂未启用）",
            ),
            logType: "info",
          };
        }
        const sent = await this.sendChatMessage(docs, resumeScript);
        docs = this.collectAccessibleDocuments(true);
        await new Promise((r) => setTimeout(r, 500));
        if (!sent) {
          return {
            status: "wait_button",
            key,
            name,
            message: buildLog(aiContext, "求简历话术发送失败，等待下轮"),
            logType: "warning",
          };
        }
        try {
          chrome.runtime.sendMessage({
            type: "LOG_MESSAGE",
            data: {
              message: `${name}：已发送求简历话术`,
              type: "success",
            },
          });
        } catch {
          /* ignore */
        }
      }
    } else {
      try {
        chrome.runtime.sendMessage({
          type: "LOG_MESSAGE",
          data: {
            message: `${name}：未配置求简历话术，将直接点击求简历`,
            type: "warning",
          },
        });
      } catch {
        /* ignore */
      }
    }

    // 2) 点击求简历
    if (!this.isAskResumeClickEnabled()) {
      return {
        status: "ready_to_ask",
        key,
        name,
        message: buildLog(aiContext, "AI匹配，求简历点击暂未启用"),
        logType: "info",
      };
    }

    docs = this.collectAccessibleDocuments(true);
    status = this.assessSessionStatus(docs, sessionItem);
    if (status.resumeRequestSent) {
      this.markAskResumeSessionCompleted(key);
      return {
        status: "skip_sent",
        key,
        name,
        message: buildLog(aiContext, "跳过（简历请求已发送）"),
        logType: "info",
      };
    }

    const clickResult = await this.clickAskResume(docs);
    docs = this.collectAccessibleDocuments(true);
    status = this.assessSessionStatus(docs, sessionItem);

    if (clickResult.ok || status.resumeRequestSent) {
      this.markAskResumeSessionCompleted(key);
      return {
        status: "asked",
        key,
        name,
        message: buildLog(
          aiContext,
          `AI匹配，已求简历（${clickResult.detail || "完成"}）`,
        ),
        logType: "success",
        clickResult,
      };
    }

    return {
      status: "wait_button",
      key,
      name,
      message: buildLog(
        aiContext,
        `AI匹配，求简历未成功（${clickResult.detail || "未知"}），等待下轮`,
      ),
      logType: "warning",
      clickResult,
    };
  }

  /**
   * 阶段二：HR 主动场景处理
   * @param {{ element: Element, clickTarget?: Element }} sessionItem
   * @param {Document[]} documents
   */
  isAskResumeClickEnabled() {
    return window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG?.enableClick === true;
  }

  async processHrInitiatedSession(sessionItem, documents) {
    const name = this.getSessionDisplayName(sessionItem);
    const key = this.getSessionKey(sessionItem);

    const { initiator, source } = await this.identifySessionInitiator(
      documents,
      sessionItem,
    );
    const status = this.assessSessionStatus(documents, sessionItem);
    const logContext = { initiator, source, ...status };

    // 阶段二：仅处理明确判定为 HR 主动的会话，其余一律跳过
    if (initiator !== "hr") {
      const action =
        initiator === "candidate"
          ? "跳过（候选人主动，本阶段不处理）"
          : "跳过（未识别为HR主动）";
      return {
        status: "skip_initiator",
        key,
        name,
        message: this.formatSessionStatusLog(name, logContext, action),
        logType: "info",
      };
    }

    // 附件下载统一在 processAskResumeSession 入口处理；此处若仍为 true 且未 deny 再下
    if (
      status.resumeReceived &&
      !this.isResumeNotAttachment(key) &&
      !this.isResumeFileAlreadyCaptured(key)
    ) {
      const buildLog = (extra, action) =>
        this.formatSessionStatusLog(name, { ...logContext, ...extra }, action);
      const dl = await this.handleReceivedResumeFileDownload(
        sessionItem,
        documents,
        buildLog,
        key,
        logContext,
      );
      if (!dl?.resumeNotAttachment) return dl;
      // 非附件：继续后续求简历逻辑
    }

    if (status.resumeRequestSent) {
      return {
        status: "skip_sent",
        key,
        name,
        message: this.formatSessionStatusLog(
          name,
          logContext,
          "跳过（简历请求已发送）",
        ),
        logType: "info",
      };
    }

    if (!status.candidateReplied) {
      return {
        status: "wait_reply",
        key,
        name,
        message: this.formatSessionStatusLog(name, logContext, "等待候选人回复"),
        logType: "info",
      };
    }

    if (!status.askResumeButtonClickable) {
      return {
        status: "wait_button",
        key,
        name,
        message: this.formatSessionStatusLog(
          name,
          logContext,
          "求简历按钮暂不可点，等待下轮",
        ),
        logType: "warning",
      };
    }

    // 阶段二：真实点击默认关闭（config.js → ASK_RESUME_CONFIG.enableClick）
    if (!this.isAskResumeClickEnabled()) {
      return {
        status: "ready_to_ask",
        key,
        name,
        message: this.formatSessionStatusLog(
          name,
          logContext,
          "满足求简历条件（点击暂未启用）",
        ),
        logType: "info",
      };
    }

    // 将 enableClick 设为 true 后启用真实点击
    const clickResult = await this.clickAskResume(documents);
    const clicked = !!(
      clickResult === true ||
      (clickResult && typeof clickResult === "object" && clickResult.ok)
    );
    const freshDocuments = this.collectAccessibleDocuments();
    const freshStatus = this.assessSessionStatus(freshDocuments, sessionItem);
    const freshContext = { initiator, source, ...freshStatus };

    if (clicked || freshStatus.resumeRequestSent) {
      return {
        status: "asked",
        key,
        name,
        message: this.formatSessionStatusLog(name, freshContext, "已求简历"),
        logType: "success",
      };
    }

    return {
      status: "wait_button",
      key,
      name,
      message: this.formatSessionStatusLog(
        name,
        freshContext,
        "求简历未成功，等待下轮重试",
      ),
      logType: "warning",
    };
  }

  /**
   * 文本是否像已展开的在线简历面板（BOSS 部分页面无「工作经历」标题）
   * @param {string} text
   */
  looksLikeResumePanelText(text = "") {
    const normalized = text.replace(/\s+/g, " ").trim();
    if (!normalized || normalized.length < 80) return false;
    if (this.isColleagueOrChatOverlayText(normalized)) return false;

    if (
      /工作经历|教育经历|期望职位|个人优势|项目经历|专业技能|求职期望|自我描述|毕业院校|工作年限/.test(
        normalized,
      )
    ) {
      return true;
    }

    if (
      /\d{4}\.\d{2}-\d{4}\.\d{2}/.test(normalized) &&
      /·/.test(normalized) &&
      normalized.length > 100
    ) {
      return true;
    }

    if (/期望：|期望薪资|院校经历|岗位经验/.test(normalized)) {
      return true;
    }

    return false;
  }

  /**
   * 简历面板是否已展开（用于 UI 流程验证，不采集正文）
   * @param {Document[]} documents
   */
  isResumePanelVisible(documents) {
    return this.isOnlineResumeOverlayOpen(documents, "");
  }

  /**
   * 是否仍有简历层挡住切换（严格判定，排除左侧列表误报）
   * @param {Document[]} documents
   */
  isResumePanelBlocking(documents) {
    return !!this.getResumePanelVisibleReason(documents, { mode: "blocking" });
  }

  isResumePanelDomExcluded(el) {
    // 不排除 chat-side：沟通页在线简历经常在左侧详情栏
    return !!el?.closest?.(
      '[class*="friend-list"], [class*="geek-list"], [role="group"] [role="listitem"]',
    );
  }

  isInsideChatConversationArea(el) {
    return !!el?.closest?.(
      '[class*="chat-conversation"], [class*="chat-content"], [class*="chat-box"], [class*="im-chat"], [class*="chat-header"], [class*="top-info"], [class*="chat-toolbar"], [class*="chat-top"]',
    );
  }

  isInsideOnlineResumeOverlayRoot(el) {
    return !!el?.closest?.(
      '.resume-detail-wrap, [class*="resume-page"], [class*="resume-detail"], [class*="resume-dialog"], [class*="resume-box"], [class*="resume-page-wrap"], [class*="slide-content"], [class*="slide-wrap"], [class*="geek-detail"], .dialog-wrap.active, [class*="dialog-wrap"].active, [class*="boss-layer"]',
    );
  }

  resumePanelShowsCandidateInOverlay(documents, expectedName = "") {
    if (!expectedName) return false;
    const docs = documents || this.collectAccessibleDocuments(true);
    const overlaySelectors = [
      ".resume-detail-wrap",
      '[class*="resume-page"]',
      '[class*="resume-detail"]',
      '[class*="resume-dialog"]',
      '[class*="resume-content"]',
      '[class*="resume-box"]',
      '[class*="geek-detail"]',
      '[class*="geek-resume"]',
      '[class*="profile-content"]',
      '[class*="slide-content"]',
      '[class*="slide-wrap"]',
      '[class*="drawer"]',
      '[class*="boss-layer"]',
      '[class*="boss-dialog"]',
      ".dialog-wrap.active",
      '[class*="dialog-wrap"].active',
    ];

    for (const doc of docs) {
      for (const sel of overlaySelectors) {
        for (const el of doc.querySelectorAll(sel)) {
          if (!this.isElementVisible(el) || this.isResumePanelDomExcluded(el)) {
            continue;
          }
          const rect = el.getBoundingClientRect();
          if (rect.width < 120 || rect.height < 80) continue;
          const text = (el.innerText || el.textContent || "").trim();
          if (!text) continue;
          if (this.textMentionsCandidateName(text, expectedName)) return true;
        }
      }
    }

    const profile = this.scrapeResumeProfilePanel(docs, expectedName);
    if (profile) return true;
    const relaxed = this.scrapeResumeProfilePanel(docs, "");
    if (relaxed && this.textMentionsCandidateName(relaxed, expectedName)) {
      return true;
    }
    return false;
  }

  /**
   * 在线简历浮层是否真正打开（排除右侧聊天区顶部的简历摘要误报）
   * @param {Document[]} documents
   * @param {string} expectedName
   */
  isOnlineResumeOverlayOpen(documents, expectedName = "", options = {}) {
    const docs = documents || this.collectAccessibleDocuments(true);
    const trustCurrentChat = options.trustCurrentChat === true;
    const blockingReason = this.getResumePanelVisibleReason(docs, {
      mode: "blocking",
    });

    if (!expectedName) {
      if (blockingReason) return true;
    } else if (this.resumePanelShowsCandidateInOverlay(docs, expectedName)) {
      return true;
    }

    const overlaySelectors = [
      ".resume-detail-wrap",
      '[class*="resume-page"]',
      '[class*="resume-detail"]',
      '[class*="resume-dialog"]',
      '[class*="resume-content"]',
      '[class*="resume-box"]',
      '[class*="geek-detail"]',
      '[class*="boss-layer"]',
      ".resume-custom-close",
      '[class*="resume-custom-close"]',
    ];

    let anyOverlayVisible = !!blockingReason;
    for (const doc of docs) {
      for (const sel of overlaySelectors) {
        for (const el of doc.querySelectorAll(sel)) {
          if (!this.isElementVisible(el) || this.isResumePanelDomExcluded(el)) {
            continue;
          }
          if (
            this.isInsideChatConversationArea(el) &&
            !this.isInsideOnlineResumeOverlayRoot(el)
          ) {
            continue;
          }
          anyOverlayVisible = true;
          if (!expectedName) return true;

          const container =
            el.closest(
              '.resume-detail-wrap, [class*="resume-page"], [class*="resume-detail"], [class*="resume-dialog"], [class*="resume-box"], [class*="geek-detail"], [class*="boss-layer"], .dialog-wrap.active, [class*="dialog-wrap"].active',
            ) || el;
          const text = (container.innerText || container.textContent || "").trim();
          if (this.textMentionsCandidateName(text, expectedName)) return true;
        }
      }
    }

    if (!expectedName) return anyOverlayVisible;

    // 仅「刚点过在线简历」时：右侧已是这个人、浮层已开，即使文案里读不到姓名也认
    if (trustCurrentChat && anyOverlayVisible) {
      const panelName = this.getActiveChatPanelGeekName(docs);
      if (panelName && this.namesLikelyMatch(expectedName, panelName)) {
        return true;
      }
    }

    return false;
  }

  /**
   * @param {Document[]} documents
   * @param {{ mode?: 'open' | 'blocking' }} options
   * @returns {string}
   */
  getResumePanelVisibleReason(documents, options = {}) {
    const mode = options.mode === "blocking" ? "blocking" : "open";
    const docs = documents || this.collectAccessibleDocuments(true);
    const viewWidth = window.innerWidth || 1920;

    const closeSelectors = [
      ".resume-custom-close",
      '[class*="resume-custom-close"]',
      ".boss-popup__close",
      '[class*="boss-popup__close"]',
      '[class*="iboss-close"]',
    ];

    for (const doc of docs) {
      for (const sel of closeSelectors) {
        for (const el of doc.querySelectorAll(sel)) {
          if (!this.isElementVisible(el) || this.isResumePanelDomExcluded(el)) {
            continue;
          }
          return "resume-close-button";
        }
      }
    }

    const containerSelectors = [
      ".resume-detail-wrap",
      '[class*="resume-detail"]',
      '[class*="resume-page"]',
      '[class*="resume-content"]',
      '[class*="geek-detail"]',
      '[class*="resume-dialog"]',
      '[class*="resume-box"]',
      '[class*="resume-page-wrap"]',
      '[class*="cv-content"]',
      '[class*="slide-content"]',
    ];

    for (const doc of docs) {
      for (const sel of containerSelectors) {
        for (const el of doc.querySelectorAll(sel)) {
          if (!this.isElementVisible(el) || this.isResumePanelDomExcluded(el)) {
            continue;
          }
          const rect = el.getBoundingClientRect();
          if (rect.width < 160 || rect.height < 160) continue;
          const text = el.innerText?.trim() || "";
          if (this.looksLikeResumePanelText(text)) return `container:${sel}`;
          if (
            mode === "open" &&
            text.length > 180 &&
            rect.left < viewWidth * 0.65
          ) {
            return `container-size:${sel}`;
          }
        }
      }
    }

    for (const doc of docs) {
      for (const el of doc.querySelectorAll(
        '.dialog-wrap.active, [class*="dialog-wrap"].active, .dialog-wrap, [class*="boss-layer"]',
      )) {
        if (!this.isElementVisible(el) || this.isResumePanelDomExcluded(el)) {
          continue;
        }
        const rect = el.getBoundingClientRect();
        if (rect.width < 220 || rect.height < 220) continue;
        const text = el.innerText?.trim() || "";
        if (this.looksLikeResumePanelText(text) && rect.left < viewWidth * 0.7) {
          return "dialog-wrap";
        }
      }
    }

    if (mode === "open") {
      if (this.scrapeResumeProfilePanel(docs, "")) return "profile-text";

      for (const doc of docs) {
        for (const el of doc.querySelectorAll("div, section, article, main")) {
          if (!this.isElementVisible(el) || this.isResumePanelDomExcluded(el)) {
            continue;
          }
          if (
            this.isInsideChatConversationArea(el) &&
            !this.isInsideOnlineResumeOverlayRoot(el)
          ) {
            continue;
          }
          const rect = el.getBoundingClientRect();
          if (rect.left > viewWidth * 0.7 || rect.width < 180 || rect.height < 180) {
            continue;
          }
          const text = el.innerText?.trim() || "";
          if (this.looksLikeResumePanelText(text) && text.length >= 120) {
            return "left-panel-text";
          }
        }
      }
    }

    return "";
  }

  /**
   * 截图前门槛：当前会话是这个人，且在线简历浮层已打开并带上其姓名。
   * @param {string} expectedName
   * @param {Document[]} [documents]
   * @returns {{ ok: boolean, reason: string }}
   */
  isOnlineResumeReadyToCapture(expectedName, documents) {
    const docs = documents || this.collectAccessibleDocuments(true);
    const name = String(expectedName || "").trim();
    if (!name || name === "未知") {
      return { ok: false, reason: "候选人姓名未知，取消截图" };
    }

    const panelName = this.getActiveChatPanelGeekName(docs);
    if (panelName && !this.namesLikelyMatch(name, panelName)) {
      return {
        ok: false,
        reason: `右侧聊天仍为${panelName}，不是${name}，取消截图`,
      };
    }

    if (
      !this.isOnlineResumeOverlayOpen(docs, name, { trustCurrentChat: true })
    ) {
      return {
        ok: false,
        reason: "在线简历未打开或不属于当前候选人，取消截图",
      };
    }

    return { ok: true, reason: "" };
  }

  /**
   * 等到「当前候选人」的在线简历浮层出现。
   * @param {string} expectedName
   * @param {number} [timeout]
   */
  async waitForOnlineResumeOverlayForCandidate(expectedName, timeout = 8000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      if (this.isAskResumeAborted?.()) return false;
      const docs = this.collectAccessibleDocuments(true);
      if (
        this.isOnlineResumeOverlayOpen(docs, expectedName, {
          trustCurrentChat: true,
        })
      ) {
        return true;
      }
      await new Promise((resolve) => setTimeout(resolve, 400));
    }
    return this.isOnlineResumeOverlayOpen(
      this.collectAccessibleDocuments(true),
      expectedName,
      { trustCurrentChat: true },
    );
  }

  /**
   * @param {number} timeout
   * @param {string} [expectedName]
   */
  async waitForResumePanelVisible(timeout = 8000, expectedName = "") {
    if (expectedName) {
      return this.waitForOnlineResumeOverlayForCandidate(
        expectedName,
        timeout,
      );
    }
    const start = Date.now();
    while (Date.now() - start < timeout) {
      if (this.isResumePanelVisible(this.collectAccessibleDocuments(true))) {
        return true;
      }
      await new Promise((resolve) => setTimeout(resolve, 400));
    }
    return false;
  }

  /**
   * 等待在线简历面板消失（关闭后校验）
   * @param {number} timeout
   */
  async waitForResumePanelHidden(timeout = 4000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const documents = this.collectAccessibleDocuments(true);
      if (
        !this.isResumePanelBlocking(documents) &&
        !this.isResumePanelVisible(documents)
      ) {
        return true;
      }
      await new Promise((resolve) => setTimeout(resolve, 300));
    }
    return !this.isResumePanelBlocking(this.collectAccessibleDocuments(true));
  }

  /**
   * 收集简历面板关闭按钮（按优先级排序，优先左栏简历区内的关闭钮）
   * @param {Document[]} documents
   * @returns {Element[]}
   */
  collectResumePanelCloseTargets(documents) {
    const docs = documents || this.collectAccessibleDocuments(true);
    const viewWidth = window.innerWidth || 1920;
    const seen = new Set();
    const targets = [];

    const addTarget = (el, priority) => {
      if (!el || seen.has(el)) return;
      if (!this.isElementVisible(el)) return;
      seen.add(el);
      const rect = el.getBoundingClientRect();
      targets.push({
        el,
        priority,
        left: rect.left,
      });
    };

    const resumeContainerSelectors = [
      '[class*="resume-page"]',
      '[class*="resume-detail"]',
      '[class*="resume-content"]',
      '[class*="geek-detail"]',
      '[class*="resume-dialog"]',
      ".dialog-wrap.active",
      '[class*="dialog-wrap"].active',
      '[class*="boss-layer"]',
    ];

    const closeSelectors = [
      { sel: ".resume-custom-close", priority: 100 },
      { sel: '[class*="resume-custom-close"]', priority: 95 },
      { sel: '[class*="iboss-close"]', priority: 90 },
      { sel: '[class^="iboss iboss-close"]', priority: 88 },
      { sel: ".boss-popup__close", priority: 85 },
      { sel: '[class*="boss-popup__close"]', priority: 80 },
      { sel: ".boss-dialog__close", priority: 75 },
      { sel: '[class*="dialog-close"]', priority: 70 },
      { sel: ".dialog-wrap.active .close", priority: 65 },
      { sel: '.dialog-wrap.active [class*="close"]', priority: 60 },
      { sel: '[class*="close-btn"]', priority: 55 },
      { sel: 'button[aria-label="关闭"]', priority: 50 },
      { sel: '[class*="icon-close"]', priority: 45 },
      { sel: '[class*="sati-times"]', priority: 40 },
    ];

    for (const doc of docs) {
      for (const containerSel of resumeContainerSelectors) {
        for (const container of doc.querySelectorAll(containerSel)) {
          if (!this.isElementVisible(container)) continue;
          for (const { sel, priority } of closeSelectors) {
            for (const el of container.querySelectorAll(sel)) {
              addTarget(el, priority + 12);
            }
          }
          for (const el of container.querySelectorAll(
            '[class*="header"] [class*="close"], [class*="toolbar"] [class*="close"], [class*="top"] [class*="close"]',
          )) {
            addTarget(el, 82);
          }
        }
      }
    }

    for (const doc of docs) {
      for (const { sel, priority } of closeSelectors) {
        for (const el of doc.querySelectorAll(sel)) {
          const rect = el.getBoundingClientRect();
          const boost = rect.left < viewWidth * 0.65 ? 8 : 0;
          addTarget(el, priority + boost);
        }
      }
    }

    for (const doc of docs) {
      for (const xpath of this.detailSelectors.closeButtonXpath || []) {
        try {
          const el = doc.evaluate(
            xpath,
            doc,
            null,
            XPathResult.FIRST_ORDERED_NODE_TYPE,
            null,
          ).singleNodeValue;
          if (el) addTarget(el, 92);
        } catch (_) {
          /* ignore invalid xpath */
        }
      }
    }

    targets.sort((a, b) => b.priority - a.priority || a.left - b.left);
    return targets.map((item) => item.el);
  }

  /**
   * 阶段三 UI 验证：切换 → 打开在线简历 → 截图 → 关闭
   * @param {{ element: Element, clickTarget?: Element }} sessionItem
   * @param {Document[]} documents
   * @param {Function} buildLog
   * @param {string} key
   */
  async executeOnlineResumeUiFlow(sessionItem, documents, buildLog, key) {
    const name = this.getSessionDisplayName(sessionItem);
    const attempt = this.incrementSessionUiAttempt(key);
    const attemptNote = attempt > 1 ? `（第 ${attempt} 次尝试开关节历）` : "";
    const maxAttempts = this.getAskResumeTiming("maxSessionUiAttempts", 3);
    let ready = this.getChatSessionReadyReason(sessionItem, documents);

    if (attempt > maxAttempts) {
      this.markAskResumeSessionCompleted(key);
      return {
        status: "skip_done",
        key,
        name,
        message: buildLog(
          {},
          `跳过（本会话在线简历已尝试 ${attempt - 1} 次，暂停重复开关）`,
        ),
        logType: "warning",
      };
    }

    if (!ready.ready) {
      return {
        status: "wait_chat",
        key,
        name,
        message: buildLog(
          {},
          `${attemptNote}切换未确认（目标：${name}，右侧：${ready.current}，状态：${ready.via}），暂不打开简历`,
        ),
        logType: "warning",
      };
    }

    const activePanelName = this.getActiveChatPanelGeekName(documents);
    if (
      activePanelName &&
      !this.namesLikelyMatch(name, activePanelName)
    ) {
      return {
        status: "wait_chat",
        key,
        name,
        message: buildLog(
          {},
          `${attemptNote}右侧聊天区仍为 ${activePanelName}，尚未切换到 ${name}，暂不打开简历`,
        ),
        logType: "warning",
      };
    }

    if (this.isAskResumeRateLimited()) {
      const waitSec = Math.ceil(
        ((this._askResumeRateLimitedUntil || 0) - Date.now()) / 1000,
      );
      return {
        status: "wait_rate_limit",
        key,
        name,
        message: buildLog(
          {},
          `${attemptNote}BOSS 提示查看太频繁，暂停打开简历（约 ${Math.max(waitSec, 1)} 秒后恢复）`,
        ),
        logType: "warning",
      };
    }

    if (this.detectBossViewRateLimit(documents)) {
      this.markAskResumeRateLimited(documents);
      return {
        status: "wait_rate_limit",
        key,
        name,
        message: buildLog(
          {},
          `${attemptNote}检测到「查看太频繁」，暂停打开简历，等待下轮`,
        ),
        logType: "warning",
      };
    }

    // 仅本轮第一次：若配置了拒简历话术，先同步到 BOSS 后台，再判断简历 / 点不合适
    const rejectScriptEarly = String(
      this.getAskResumeSettings()?.rejectScript || "",
    ).trim();
    if (
      rejectScriptEarly &&
      !this.askResumeRunState?.bossRejectScriptSynced &&
      this.isAskResumeChatActionsEnabled()
    ) {
      const syncResult = await this.ensureBossRejectScriptSynced(
        this.collectAccessibleDocuments(true),
        rejectScriptEarly,
      );
      if (!syncResult.ok && !syncResult.skipped) {
        try {
          chrome.runtime.sendMessage({
            type: "LOG_MESSAGE",
            data: {
              message: `${name}：首次同步拒简历话术失败（${syncResult.reason}），将继续后续流程`,
              type: "warning",
            },
          });
        } catch {
          /* ignore */
        }
      }
    }

    let freshDocuments = this.collectAccessibleDocuments(true);
    let skipOpen = false;
    let clickedResumeButton = false;
    let openAction = "打开在线简历";

    if (this.isOnlineResumeOverlayOpen(freshDocuments, name)) {
      skipOpen = true;
      openAction = "简历已打开，跳过重复打开";
    } else if (this.isOnlineResumeOverlayOpen(freshDocuments, "")) {
      await this.dismissResumeViewToChat(sessionItem);
      await this.waitForResumePanelHidden(3000);
      freshDocuments = this.collectAccessibleDocuments(true);
      ready = this.getChatSessionReadyReason(sessionItem, freshDocuments);
      const stillOther =
        this.isOnlineResumeOverlayOpen(freshDocuments, "") &&
        !this.isOnlineResumeOverlayOpen(freshDocuments, name);
      if (!ready.ready || stillOther) {
        return {
          status: "wait_chat",
          key,
          name,
          message: buildLog(
            {},
            `${attemptNote}上一候选人简历仍挡在页面上，本轮不截图（右侧：${ready.current}，状态：${ready.via}）`,
          ),
          logType: "warning",
        };
      }
      if (this.isOnlineResumeOverlayOpen(freshDocuments, name)) {
        skipOpen = true;
        openAction = "关闭他人简历后确认当前人已打开";
      }
    }

    if (!skipOpen) {
      const resumeBtn = this.findOnlineResumeViewButton(freshDocuments);

      if (!resumeBtn) {
        return {
          status: "wait_resume_ui",
          key,
          name,
          message: buildLog(
            {},
            `${attemptNote}已切换到 ${ready.current}（${ready.via}）→ 未找到「在线简历」按钮，等待下轮`,
          ),
          logType: "warning",
        };
      }

      await this.waitForResumeViewCooldown();
      await this.gentleClickElement(resumeBtn);
      clickedResumeButton = true;
      this._lastResumeViewAt = Date.now();

      if (this.detectBossViewRateLimit(this.collectAccessibleDocuments(true))) {
        this.markAskResumeRateLimited();
        return {
          status: "wait_rate_limit",
          key,
          name,
          message: buildLog(
            {},
            `${attemptNote}点击在线简历后触发频率限制，已暂停`,
          ),
          logType: "warning",
        };
      }
    }

    const overlayDetected = skipOpen
      ? this.isOnlineResumeOverlayOpen(
          this.collectAccessibleDocuments(true),
          name,
        )
      : await this.waitForOnlineResumeOverlayForCandidate(name, 8000);
    const detectReason =
      this.getResumePanelVisibleReason(this.collectAccessibleDocuments(true), {
        mode: "blocking",
      }) ||
      this.getResumePanelVisibleReason(this.collectAccessibleDocuments(true), {
        mode: "open",
      }) ||
      (clickedResumeButton ? "resume-button-click" : "none");

    if (!overlayDetected) {
      return {
        status: "wait_resume_ui",
        key,
        name,
        message: buildLog(
          {},
          `${attemptNote}已切换到 ${ready.current}（${ready.via}）→ ${clickedResumeButton ? "已点在线简历，但" : ""}未确认当前候选人简历浮层已打开，本轮不截图`,
        ),
        logType: "warning",
      };
    }

    if (overlayDetected) {
      if (this.isAskResumeAborted()) {
        return {
          status: "skip_done",
          key,
          name,
          message: buildLog({}, `${attemptNote}已停止，取消简历截图流程`),
          logType: "warning",
        };
      }

      let screenshotSummary = "";
      const identityDocs = this.collectAccessibleDocuments(true);
      const captureGate = this.isOnlineResumeReadyToCapture(name, identityDocs);
      if (!captureGate.ok) {
        return {
          status: "wait_resume_ui",
          key,
          name,
          message: buildLog(
            {},
            `${attemptNote}${captureGate.reason}，本轮不截图`,
          ),
          logType: "warning",
        };
      }

      const identity = await this.getActiveChatEmployeeIdentity(
        sessionItem,
        identityDocs,
      );
      // 截图前再从简历浮层补一次性别
      if (!identity.gender || identity.gender === "未知") {
        const fromOverlay = this.extractGenderFromChatDocuments(identityDocs);
        if (fromOverlay) identity.gender = fromOverlay;
      }
      const captureGender = identity.gender || "未知";

      try {
        chrome.runtime.sendMessage({
          type: "LOG_MESSAGE",
          data: {
            message: `${name}：当前沟通员工 姓名=${name}，性别=${captureGender}`,
            type: "info",
          },
        });
      } catch {
        /* ignore */
      }

      // 附件下载仅在「候选人已提供简历」分支处理，截图流程不再下载
      const screenshotResult = await this.captureAndSaveOnlineResumeScreenshots(
        name,
        identityDocs,
        "ask_resume_ui_flow",
        { gender: captureGender },
      );
      if (screenshotResult.ok) {
        screenshotSummary = `，${screenshotResult.message}`;
      } else if (this.isAskResumeScreenshotEnabled()) {
        screenshotSummary = `，截图/回传失败（${screenshotResult.message}）`;
      }

      // 缓存图片分析后的 AI 匹配结果，供后续会话逻辑复用
      if (screenshotResult?.aiMatch) {
        this.setCachedAiDecision?.(key, screenshotResult.aiMatch);
      }

      await this.closeResumePanelOnly();
      const hidden = await this.waitForResumePanelHidden(5000);
      const stillReason =
        this.getResumePanelVisibleReason(this.collectAccessibleDocuments(true), {
          mode: "blocking",
        }) ||
        this.getResumePanelVisibleReason(this.collectAccessibleDocuments(true), {
          mode: "open",
        });

      const aiContext = screenshotResult?.aiMatch
        ? {
            aiMatched: !!screenshotResult.aiMatch.isok,
            aiReason: screenshotResult.aiMatch.msg || "",
          }
        : {};

      // AI 判定不符合（含调试强制为否）：关闭简历后悬停改话术并点「不合适」
      const forceNo =
        window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG?.forceAiDecisionNo === true;
      const shouldReject =
        forceNo ||
        (screenshotResult?.aiMatch && screenshotResult.aiMatch.isok === false);

      if (shouldReject) {
        const rejectContext = forceNo
          ? {
              aiMatched: false,
              aiReason:
                screenshotResult?.aiMatch?.msg ||
                "调试：强制判定为否（forceAiDecisionNo）",
            }
          : aiContext;
        const rejectResult = await this.executeRejectWithScript(
          sessionItem,
          this.collectAccessibleDocuments(true),
          buildLog,
          key,
          rejectContext,
        );
        const prefix = `${attemptNote}已切换到 ${ready.current}（${ready.via}）→ ${openAction}、截图分析（识别：${detectReason}）${screenshotSummary} → `;
        return {
          ...rejectResult,
          message: prefix + (rejectResult.message || ""),
          resumeInfoText: screenshotResult.resumeInfoText || "",
        };
      }

      // AI 判定符合：发求简历话术 + 点 operate-icon-item「求简历」+ 确认
      if (screenshotResult?.aiMatch && screenshotResult.aiMatch.isok === true) {
        const statusNow = this.assessSessionStatus(
          this.collectAccessibleDocuments(true),
          sessionItem,
        );
        if (statusNow.resumeRequestSent || statusNow.resumeReceived) {
          this.markAskResumeSessionCompleted(key);
          return {
            status: "skip_sent",
            key,
            name,
            message: buildLog(
              aiContext,
              statusNow.resumeReceived
                ? `${attemptNote}截图分析后跳过（聊天中已有简历）${screenshotSummary}`
                : `${attemptNote}截图分析后跳过（简历请求已发送）${screenshotSummary}`,
            ),
            logType: "info",
            aiMatch: screenshotResult.aiMatch,
          };
        }

        const askResult = await this.executeAskResumeWithScript(
          sessionItem,
          this.collectAccessibleDocuments(true),
          buildLog,
          key,
          aiContext,
        );
        const prefix = `${attemptNote}已切换到 ${ready.current}（${ready.via}）→ ${openAction}、截图分析（识别：${detectReason}）${screenshotSummary} → `;
        return {
          ...askResult,
          message: prefix + (askResult.message || ""),
          resumeInfoText: screenshotResult.resumeInfoText || "",
          aiMatch: screenshotResult.aiMatch,
        };
      }

      // 未得到 AI 匹配结果：结束本会话 UI 流程
      this.markAskResumeSessionCompleted(key);

      const logType = !screenshotResult.ok
        ? "warning"
        : screenshotResult.aiMatch?.isok
          ? "success"
          : screenshotResult.aiMatch
            ? "warning"
            : "success";

      if (hidden) {
        return {
          status: "resume_ui_done",
          key,
          name,
          message: buildLog(
            aiContext,
            `${attemptNote}已切换到 ${ready.current}（${ready.via}）→ ${openAction}、截图并关闭在线简历（识别：${detectReason}）${screenshotSummary}`,
          ),
          logType,
          aiMatch: screenshotResult.aiMatch || null,
          resumeInfoText: screenshotResult.resumeInfoText || "",
        };
      }

      return {
        status: "resume_ui_done",
        key,
        name,
        message: buildLog(
          aiContext,
          `${attemptNote}已切换到 ${ready.current}（${ready.via}）→ ${openAction}、截图并关闭在线简历（识别：${detectReason}）${screenshotSummary}${stillReason ? `，关闭校验未通过（仍可见：${stillReason}）` : ""}，继续下一个`,
        ),
        logType: logType === "success" ? "warning" : logType,
        aiMatch: screenshotResult.aiMatch || null,
        resumeInfoText: screenshotResult.resumeInfoText || "",
      };
    }

    if (clickedResumeButton) {
      await this.closeResumePanelOnly();
      return {
        status: "wait_resume_ui",
        key,
        name,
        message: buildLog(
          {},
          `${attemptNote}已切换到 ${ready.current}（${ready.via}）→ 已点击在线简历，未检测到简历浮层（识别：${detectReason}），等待下轮`,
        ),
        logType: "warning",
      };
    }

    return {
      status: "wait_resume_ui",
      key,
      name,
      message: buildLog(
        {},
        `${attemptNote}已切换到 ${ready.current}（${ready.via}）→ 未执行打开在线简历（识别：${detectReason}），等待下轮`,
      ),
      logType: "warning",
    };
  }

  /**
   * 沟通页顶部/侧栏「当前筛选职位」文案（一键求简历启动时同步插件岗位）
   * XPath 见 CONFIG.ASK_RESUME_CONFIG.chatFilterPositionXPath
   * @param {Document[]} [documents]
   * @returns {string}
   */
  getChatFilterPositionText(documents) {
    const cfg =
      (typeof window !== "undefined" &&
        window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG) ||
      {};
    const xpath =
      cfg.chatFilterPositionXPath ||
      '//*[@id="container"]/div[1]/div/div[2]/div[2]/div[1]/div[1]/div[1]/div/div[1]/div/div[1]';

    const docs =
      documents && documents.length
        ? documents
        : this.collectAccessibleDocuments?.(true) || [document];

    const readByXPath = (doc) => {
      if (!doc || !doc.evaluate) return "";
      try {
        const result = doc.evaluate(
          xpath,
          doc,
          null,
          XPathResult.FIRST_ORDERED_NODE_TYPE,
          null,
        );
        const node = result?.singleNodeValue;
        const text = node?.textContent?.replace(/\s+/g, " ")?.trim() || "";
        return text;
      } catch {
        return "";
      }
    };

    for (const doc of docs) {
      const t = readByXPath(doc);
      if (t) return t.slice(0, 80);
    }

    // 兜底：常见职位筛选展示节点
    const fallbackSels = [
      ".chat-top-job .job-name",
      ".chat-job-filter",
      '[class*="job-select"]',
      ".job-select-trigger",
    ];
    for (const doc of docs) {
      const root = doc?.body || doc;
      if (!root?.querySelector) continue;
      for (const sel of fallbackSels) {
        try {
          const el = root.querySelector(sel);
          const text = el?.textContent?.replace(/\s+/g, " ")?.trim() || "";
          if (text) return text.slice(0, 80);
        } catch {
          /* ignore */
        }
      }
    }
    return "";
  }

  /**
   * 从会话列表项 / 右侧聊天区读取 span.position-name 职位文案
   * @param {{ element?: Element }} sessionItem
   * @param {Document[]} documents
   */
  getSessionPositionNameText(sessionItem, documents) {
    const selectors = [
      "span.position-name",
      ".position-name",
      '[class*="position-name"]',
    ];
    const pickFrom = (root) => {
      if (!root || !root.querySelector) return "";
      for (const sel of selectors) {
        const el = root.querySelector(sel);
        const text = el?.textContent?.replace(/\s+/g, " ")?.trim() || "";
        if (text) return text.slice(0, 80);
      }
      return "";
    };

    const fromList = pickFrom(sessionItem?.element);
    if (fromList) return fromList;

    const docs = documents || this.collectAccessibleDocuments(true);
    for (const root of this.getChatPanelRoots(docs) || []) {
      const t = pickFrom(root);
      if (t) return t;
    }
    for (const doc of docs) {
      const t = pickFrom(doc.body || doc);
      if (t) return t;
    }
    return "";
  }

  /**
   * 读取插件岗位字典
   * 岗位权威数据在宣双云端 + chrome.storage.session（招聘速聊助手_positions）；
   * local.招聘速聊助手_settings 已不再持久化 positions（历史兼容兜底）。
   * @returns {Promise<Record<string, { keywords?: string[], excludeKeywords?: string[] }>>}
   */
  async loadPluginPositionsMap() {
    const pickMap = (raw) => {
      if (!raw || typeof raw !== "object") return null;
      // session / 云端：{ positions, activePosition }
      if (raw.positions && typeof raw.positions === "object") {
        return raw.positions;
      }
      // 直接是岗位字典
      const keys = Object.keys(raw);
      if (
        keys.length &&
        keys.every((k) => raw[k] && typeof raw[k] === "object")
      ) {
        return raw;
      }
      return null;
    };

    // 1) session 缓存（与弹窗 / plugin_auth 一致）
    try {
      if (chrome.storage?.session) {
        const sessionStored = await new Promise((resolve) => {
          chrome.storage.session.get(["招聘速聊助手_positions"], (result) => {
            resolve(result || {});
          });
        });
        const fromSession = pickMap(sessionStored.招聘速聊助手_positions);
        if (fromSession && Object.keys(fromSession).length) {
          return fromSession;
        }
      }
    } catch (error) {
      console.warn("[招聘速聊助手] 读取 session 岗位失败:", error);
    }

    // 2) 走 background 拉云端/session（force=false 优先缓存）
    try {
      const remote = await new Promise((resolve) => {
        try {
          chrome.runtime.sendMessage(
            { type: "plugin_positions_load", force: false },
            (response) => {
              if (chrome.runtime.lastError) {
                resolve(null);
                return;
              }
              resolve(response || null);
            },
          );
        } catch {
          resolve(null);
        }
      });
      if (remote?.success && remote.positions) {
        const fromRemote = pickMap({ positions: remote.positions });
        if (fromRemote && Object.keys(fromRemote).length) {
          return fromRemote;
        }
      }
    } catch (error) {
      console.warn("[招聘速聊助手] 拉取岗位列表失败:", error);
    }

    // 3) 兼容：历史 local.招聘速聊助手_settings.positions
    try {
      const localStored = await new Promise((resolve) => {
        chrome.storage.local.get(["招聘速聊助手_settings"], (result) => {
          resolve(result?.招聘速聊助手_settings || {});
        });
      });
      const fromLocal = pickMap(localStored);
      if (fromLocal && Object.keys(fromLocal).length) {
        return fromLocal;
      }
    } catch (error) {
      console.warn("[招聘速聊助手] 读取 local 岗位失败:", error);
    }

    return {};
  }

  /**
   * 用页面职位文案在插件岗位列表中反查岗位，取 keywords / excludeKeywords
   * （候选人主动专用；不依赖下拉框当前选中项）
   * @param {string} pagePositionText
   * @returns {Promise<{
   *   ok: boolean,
   *   reason?: string,
   *   positionName?: string,
   *   pagePositionText?: string,
   *   keywords?: string[],
   *   excludeKeywords?: string[],
   * }>}
   */
  async resolvePositionConfigByPageText(pagePositionText) {
    const pageText = String(pagePositionText || "")
      .replace(/\s+/g, " ")
      .trim();
    if (!pageText) {
      return { ok: false, reason: "未读到 position-name 职位文案", pagePositionText: "" };
    }

    let positions = {};
    try {
      positions = await this.loadPluginPositionsMap();
    } catch (error) {
      return {
        ok: false,
        reason: `读取岗位列表失败：${error?.message || error}`,
        pagePositionText: pageText,
      };
    }

    const names = Object.keys(positions || {}).filter(Boolean);
    if (!names.length) {
      return {
        ok: false,
        reason:
          "插件岗位列表为空，请先登录并在弹窗新增/同步岗位（保存条件后写入平台）",
        pagePositionText: pageText,
      };
    }

    const norm = (s) => String(s || "").replace(/\s+/g, " ").trim();
    const pageNorm = norm(pageText);

    // 1) 完全相等
    let hitName = names.find((n) => norm(n) === pageNorm) || "";

    // 2) 互相包含，优先更长岗位名，减少短名误匹配
    if (!hitName) {
      const scored = names
        .map((n) => {
          const nn = norm(n);
          if (!nn) return null;
          const pageHasJob = pageNorm.includes(nn);
          const jobHasPage = nn.includes(pageNorm) && pageNorm.length >= 2;
          if (!pageHasJob && !jobHasPage) return null;
          return { name: n, score: nn.length + (pageHasJob ? 100 : 0) };
        })
        .filter(Boolean)
        .sort((a, b) => b.score - a.score);
      hitName = scored[0]?.name || "";
    }

    if (!hitName || !positions[hitName]) {
      return {
        ok: false,
        reason: `职位文案未匹配到岗位列表（文案：${pageText}；已配置：${names.join("、")}）`,
        pagePositionText: pageText,
      };
    }

    const conf = positions[hitName] || {};
    return {
      ok: true,
      positionName: hitName,
      pagePositionText: pageText,
      keywords: Array.isArray(conf.keywords) ? conf.keywords : [],
      excludeKeywords: Array.isArray(conf.excludeKeywords)
        ? conf.excludeKeywords
        : [],
    };
  }

  /**
   * 阶段三：候选人主动场景处理
   * @param {{ element: Element, clickTarget?: Element }} sessionItem
   * @param {Document[]} documents
   */
  async processCandidateInitiatedSession(sessionItem, documents) {
    const name = this.getSessionDisplayName(sessionItem);
    const key = this.getSessionKey(sessionItem);
    const { source } = await this.identifySessionInitiator(
      documents,
      sessionItem,
    );
    const initiator = "candidate";
    let status = this.assessSessionStatus(documents, sessionItem);

    // 候选人主动：用页面 position-name 反查岗位列表，覆盖本会话 keywords/黑名单
    // 其余流程不变；查不到岗位则跳过
    const pagePositionText = this.getSessionPositionNameText(
      sessionItem,
      documents,
    );
    const resolved = await this.resolvePositionConfigByPageText(pagePositionText);
    if (!resolved.ok) {
      this.markAskResumeSessionCompleted(key);
      const buildLogFail = (extra, action) =>
        this.formatSessionStatusLog(
          name,
          { initiator, source, ...status, ...extra },
          action,
        );
      return {
        status: "skip_done",
        key,
        name,
        message: buildLogFail(
          {},
          `跳过（${resolved.reason || "职位未匹配岗位列表"}）`,
        ),
        logType: "info",
      };
    }

    const baseSettings = this.getAskResumeSettings() || {};
    this.askResumeSettings = {
      ...baseSettings,
      keywords: resolved.keywords || [],
      excludeKeywords: resolved.excludeKeywords || [],
      resolvedPositionName: resolved.positionName || "",
      pagePositionText: resolved.pagePositionText || pagePositionText,
    };

    try {
      chrome.runtime.sendMessage({
        type: "LOG_MESSAGE",
        data: {
          message: `${name}：职位文案=${resolved.pagePositionText} → 匹配岗位=${resolved.positionName}；关键词=[${(resolved.keywords || []).join(",") || "无"}]；黑名单=[${(resolved.excludeKeywords || []).join(",") || "无"}]`,
          type: "info",
        },
      });
    } catch {
      /* ignore */
    }

    const settings = this.getAskResumeSettings();

    const buildLog = (extra, action) =>
      this.formatSessionStatusLog(name, {
        initiator,
        source,
        ...status,
        ...extra,
      }, action);

    if (
      status.resumeReceived &&
      !this.isResumeNotAttachment(key) &&
      !this.isResumeFileAlreadyCaptured(key)
    ) {
      const dl = await this.handleReceivedResumeFileDownload(
        sessionItem,
        documents,
        buildLog,
        key,
        { initiator, source, ...status },
      );
      if (!dl?.resumeNotAttachment) return dl;
      // 非附件：继续截图/求简历常规流程
    }

    if (status.resumeRequestSent) {
      this.markAskResumeSessionCompleted(key);
      return {
        status: "skip_sent",
        key,
        name,
        message: buildLog({}, "跳过（简历请求已发送）"),
        logType: "info",
      };
    }

    if (this.isAskResumeSessionCompleted(key)) {
      return {
        status: "skip_done",
        key,
        name,
        message: buildLog({}, "跳过（本会话已处理）"),
        logType: "info",
      };
    }

    if (this.detectInappropriateMarked(documents, sessionItem)) {
      this.markAskResumeSessionCompleted(key);
      return {
        status: "skip_done",
        key,
        name,
        message: buildLog({}, "跳过（已标记不合适）"),
        logType: "info",
      };
    }

    if (!this.isAskResumeCollectEnabled()) {
      return this.executeOnlineResumeUiFlow(
        sessionItem,
        documents,
        buildLog,
        key,
      );
    }

    const candidateInfo = await this.collectCandidateInfoForAskResume(
      documents,
      sessionItem,
    );

    if (candidateInfo.includes("【采集失败】")) {
      return {
        status: "wait_chat",
        key,
        name,
        message: buildLog({}, "聊天区尚未切换完成，等待下轮"),
        logType: "warning",
      };
    }

    if (!this.hasMeaningfulResumeContent(candidateInfo, name)) {
      return {
        status: "wait_chat",
        key,
        name,
        message: buildLog(
          {},
          `简历详情未抓取完整（当前聊天区：${this.getActiveChatPanelGeekName(documents) || "未知"}），等待下轮`,
        ),
        logType: "warning",
      };
    }

    if (!this.isAskResumeAiMatchEnabled()) {
      if (this.isAskResumeSessionCompleted(key)) {
        return {
          status: "skip_done",
          key,
          name,
          message: buildLog({}, "跳过（本会话简历信息已保存）"),
          logType: "info",
        };
      }

      const saveResult = await this.saveAskResumeCandidateInfo(
        name,
        this.buildAskResumeSavePayload(candidateInfo),
      );
      this.markAskResumeSessionCompleted(key);

      return {
        status: "info_saved",
        key,
        name,
        message: buildLog({}, "简历信息已保存（AI匹配暂未启用）"),
        logType: saveResult.ok ? "success" : "warning",
        saveResult,
      };
    }

    let aiResult = this.getCachedAiDecision(key);
    if (!aiResult) {
      if (
        typeof this.matchesAskResumeExcludeKeywords === "function" &&
        this.matchesAskResumeExcludeKeywords(candidateInfo)
      ) {
        aiResult = { isok: false, msg: "命中排除关键词" };
      } else if (typeof this.performAskResumeAIDecision !== "function") {
        return {
          status: "ai_error",
          key,
          name,
          message: buildLog({}, "AI 决策不可用"),
          logType: "error",
        };
      } else {
        aiResult = await this.performAskResumeAIDecision(candidateInfo);
      }
      this.setCachedAiDecision(key, aiResult);
    }

    const aiContext = {
      aiMatched: aiResult.isok,
      aiReason: aiResult.msg,
    };

    if (!aiResult.isok) {
      // 点「不合适」并使用已同步的拒简历话术
      return this.executeRejectWithScript(
        sessionItem,
        documents,
        buildLog,
        key,
        aiContext,
      );
    }

    // AI 匹配：发话术 + 点求简历 + 确认
    return this.executeAskResumeWithScript(
      sessionItem,
      documents,
      buildLog,
      key,
      aiContext,
    );
  }

  collectAccessibleDocuments(forceRefresh = false) {
    const now = Date.now();
    if (
      !forceRefresh &&
      this._accessibleDocumentsCache &&
      now - (this._accessibleDocumentsCacheAt || 0) < 180
    ) {
      return this._accessibleDocumentsCache;
    }

    const documents = [];
    const visited = new Set();

    const walk = (doc) => {
      if (!doc || visited.has(doc)) return;
      visited.add(doc);
      documents.push(doc);

      doc.querySelectorAll("iframe").forEach((frame) => {
        try {
          if (frame.contentDocument) walk(frame.contentDocument);
        } catch {
          /* ignore cross-origin */
        }
      });
    };

    try {
      walk(window.top.document);
    } catch {
      /* ignore */
    }
    if (!visited.has(document)) {
      walk(document);
    }

    this._accessibleDocumentsCache = documents;
    this._accessibleDocumentsCacheAt = now;
    return documents;
  }

  buildFastSkipResult(sessionItem, action) {
    const name = this.getSessionDisplayName(sessionItem);
    const key = this.getSessionKey(sessionItem);
    const cached = this.getInitiatorFromFriendCache(name);
    const initiator =
      cached.initiator !== "unknown" ? cached.initiator : "unknown";
    return {
      status: "skip_done",
      key,
      name,
      message: this.formatSessionStatusLog(
        name,
        {
          initiator,
          source: cached.source || "cache",
          candidateReplied: false,
          resumeRequestSent: false,
          resumeReceived: false,
        },
        action,
      ),
      logType: "info",
    };
  }

  /**
   * 当前沟通页任务是否已停止。
   * 必须按 chatTaskMode 区分：求简历点停止后 shouldAbortAskResume 会一直为 true，
   * 若不区分，一键简历回传会误判已停止，切会话循环直接 break，表现为不点会话。
   * 停止时不要清空 chatTaskMode，否则这里会落到 false，正在跑的人停不掉。
   */
  isChatTaskAborted() {
    const mode = this.chatTaskMode;
    try {
      if (mode === "resume_upload") {
        return typeof this.shouldAbortResumeUpload === "function"
          ? !!this.shouldAbortResumeUpload()
          : false;
      }
      if (mode === "ask_resume") {
        return typeof this.shouldAbortAskResume === "function"
          ? !!this.shouldAbortAskResume()
          : false;
      }
    } catch {
      /* ignore */
    }
    return false;
  }

  /** 求简历 / 简历回传共用：是否应中止切会话等长流程 */
  isAskResumeAborted() {
    return this.isChatTaskAborted();
  }

  /**
   * 一键简历回传：仅处理「聊天中已有附件简历」的会话
   * 复用 handleReceivedResumeFileDownload，不点求简历/不合适、不做 AI
   * @param {{ element: Element, clickTarget?: Element }} sessionItem
   */
  async processResumeUploadSession(sessionItem) {
    const name = this.getSessionDisplayName(sessionItem);
    const key = this.getSessionKey(sessionItem);

    const aborted = () => this.isChatTaskAborted();

    if (aborted()) {
      return {
        status: "skip_done",
        key,
        name,
        message: `${name}：已停止回传，跳过后续处理`,
        logType: "warning",
      };
    }

    if (this.resumeUploadCompletedKeys?.has(key)) {
      return {
        status: "skip_done",
        key,
        name,
        message: `${name}：跳过（本回传任务已处理）`,
        logType: "info",
      };
    }

    let documents = await this.ensureChatSessionReadyForCollect(sessionItem);
    if (aborted()) {
      return {
        status: "skip_done",
        key,
        name,
        message: `${name}：已停止回传，跳过后续处理`,
        logType: "warning",
      };
    }

    const readyInfo = this.getChatSessionReadyReason(sessionItem, documents);
    if (!readyInfo.ready) {
      const resumeBlocking = readyInfo.via === "resume-panel-blocking";
      return {
        status: "wait_chat",
        key,
        name,
        message: `${name}：切换未确认（右侧：${readyInfo.current || "未知"}，${readyInfo.via}${resumeBlocking ? "，需先关闭上一人简历" : ""}），等待下轮`,
        logType: "warning",
      };
    }

    const consent = await this.acceptResumeConsentIfPresent(documents, name);
    documents = consent.documents || documents;
    const { initiator, source } = await this.identifySessionInitiator(
      documents,
      sessionItem,
    );
    const status = this.assessSessionStatus(documents, sessionItem);
    const logContext = { initiator, source, ...status };
    const buildLog = (extra, action) =>
      this.formatSessionStatusLog(name, { ...logContext, ...extra }, action);

    if (!status.resumeReceived) {
      if (consent.foundPrompt) {
        return {
          status: "wait_chat",
          key,
          name,
          message: buildLog(
            {},
            consent.clicked
              ? "已点同意接收附件，等待简历出现"
              : "聊天中有附件发送确认，等待下轮再试",
          ),
          logType: "info",
        };
      }
      // 本任务内标记：无附件则下轮不再反复刷同一人
      if (!this.resumeUploadCompletedKeys) {
        this.resumeUploadCompletedKeys = new Set();
      }
      this.resumeUploadCompletedKeys.add(key);
      return {
        status: "skip_no_resume",
        key,
        name,
        message: buildLog({}, "跳过（未识别到聊天中已有附件简历）"),
        logType: "info",
      };
    }

    await this.waitHumanStep("回传：开始处理附件");
    if (aborted()) {
      return {
        status: "skip_done",
        key,
        name,
        message: `${name}：已停止回传，跳过后续处理`,
        logType: "warning",
      };
    }
    await this.maybeWaitHumanThinkPause("回传前确认");
    if (aborted()) {
      return {
        status: "skip_done",
        key,
        name,
        message: `${name}：已停止回传，跳过后续处理`,
        logType: "warning",
      };
    }
    const result = await this.handleReceivedResumeFileDownload(
      sessionItem,
      documents,
      buildLog,
      key,
      logContext,
    );

    // 终态：成功/已存在/明确跳过 → 本任务不再处理
    const doneStatuses = new Set([
      "skip_done",
      "info_saved",
      "resume_ui_done",
    ]);
    if (
      result &&
      (doneStatuses.has(result.status) ||
        result.status === "skip_no_resume" ||
        (result.status !== "wait_resume_ui" &&
          result.status !== "wait_chat" &&
          result.status !== "wait_button" &&
          !result.resumeNotAttachment))
    ) {
      if (!this.resumeUploadCompletedKeys) {
        this.resumeUploadCompletedKeys = new Set();
      }
      // wait / 失败重试：不 mark；明确完成或无需再做：mark
      if (
        result.status === "skip_done" ||
        result.status === "info_saved" ||
        result.status === "resume_ui_done" ||
        result.status === "skip_no_resume"
      ) {
        this.resumeUploadCompletedKeys.add(key);
      }
    }

    // 非附件回退：回传任务无后续常规流程，记为跳过
    if (result?.resumeNotAttachment) {
      if (!this.resumeUploadCompletedKeys) {
        this.resumeUploadCompletedKeys = new Set();
      }
      this.resumeUploadCompletedKeys.add(key);
      return {
        ...result,
        status: "skip_no_resume",
        message:
          result.message ||
          buildLog({}, "跳过（非附件简历或无法下载附件）"),
        logType: result.logType || "warning",
      };
    }

    return result;
  }

  /**
   * @param {{ element: Element, clickTarget?: Element }} sessionItem
   */
  async processAskResumeSession(sessionItem) {
    if (this.isAskResumeAborted()) {
      const name = this.getSessionDisplayName(sessionItem);
      return {
        status: "skip_done",
        key: this.getSessionKey(sessionItem),
        name,
        message: `${name}：已停止，跳过后续处理`,
        logType: "warning",
      };
    }

    let documents = await this.ensureChatSessionReadyForCollect(sessionItem);
    if (this.isAskResumeAborted()) {
      const name = this.getSessionDisplayName(sessionItem);
      return {
        status: "skip_done",
        key: this.getSessionKey(sessionItem),
        name,
        message: `${name}：已停止，跳过后续处理`,
        logType: "warning",
      };
    }

    const readyInfo = this.getChatSessionReadyReason(sessionItem, documents);
    if (!readyInfo.ready) {
      const name = this.getSessionDisplayName(sessionItem);
      const resumeBlocking = readyInfo.via === "resume-panel-blocking";
      return {
        status: "wait_chat",
        key: this.getSessionKey(sessionItem),
        name,
        message: `${name}：切换未确认（目标：${name}，右侧：${readyInfo.current || "未知"}，状态：${readyInfo.via}${resumeBlocking ? "，需先关闭上一人简历" : ""}），等待下轮`,
        logType: "warning",
      };
    }

    const name = this.getSessionDisplayName(sessionItem);
    const key = this.getSessionKey(sessionItem);
    await this.waitHumanStep("识别会话状态");
    await this.maybeWaitHumanThinkPause("看聊天进度");
    const consent = await this.acceptResumeConsentIfPresent(documents, name);
    documents = consent.documents || documents;
    const { initiator, source } = await this.identifySessionInitiator(
      documents,
      sessionItem,
    );
    let status = this.assessSessionStatus(documents, sessionItem);

    // 公共优先：仅当「附件简历」证据充分时，下载转 base64（不论谁主动）
    // 若下载失败判定非附件，则 resumeNotAttachment，继续走 HR/候选人常规流程
    const tryAttachmentDownload = async (docs) => {
      const st = this.assessSessionStatus(docs, sessionItem);
      if (!st.resumeReceived) return null;
      const logContext = { initiator, source, ...st };
      const buildLog = (extra, action) =>
        this.formatSessionStatusLog(name, { ...logContext, ...extra }, action);
      await this.waitHumanStep("处理附件简历");
      await this.maybeWaitHumanThinkPause("是否下载附件");
      return this.handleReceivedResumeFileDownload(
        sessionItem,
        docs,
        buildLog,
        key,
        logContext,
      );
    };

    {
      const dl = await tryAttachmentDownload(documents);
      if (dl && !dl.resumeNotAttachment) {
        return dl;
      }
      if (dl?.resumeNotAttachment) {
        documents = this.collectAccessibleDocuments(true);
      }
    }

    if (consent.foundPrompt && !status.resumeReceived) {
      return {
        status: "wait_chat",
        key,
        name,
        message: this.formatSessionStatusLog(
          name,
          { initiator, source, ...status },
          consent.clicked
            ? "已点同意接收附件，等待简历出现"
            : "聊天中有附件发送确认，等待下轮再试",
        ),
        logType: "info",
      };
    }

    let result;
    if (initiator === "hr") {
      result = await this.processHrInitiatedSession(sessionItem, documents);
      if (result.status === "wait_reply") {
        await new Promise((resolve) => setTimeout(resolve, 400));
        documents = this.collectAccessibleDocuments(true);
        const dl = await tryAttachmentDownload(documents);
        if (dl && !dl.resumeNotAttachment) return dl;
        result = await this.processHrInitiatedSession(sessionItem, documents);
      }
    } else if (initiator === "candidate") {
      result = await this.processCandidateInitiatedSession(
        sessionItem,
        documents,
      );
      if (result.status === "wait_button") {
        await new Promise((resolve) => setTimeout(resolve, 800));
        documents = this.collectAccessibleDocuments(true);
        const dl = await tryAttachmentDownload(documents);
        if (dl && !dl.resumeNotAttachment) return dl;
        result = await this.processCandidateInitiatedSession(
          sessionItem,
          documents,
        );
      }
    } else {
      // 发起方未知：无简历时才跳过；有简历已在上方处理
      result = {
        status: "skip_initiator",
        key,
        name,
        message: this.formatSessionStatusLog(
          name,
          { initiator, source, ...status },
          "跳过（未识别发起方）",
        ),
        logType: "info",
      };
    }

    return result;
  }

  /**
   * 点开会话并等待聊天区加载
   * force 时也会先判断是否已就绪，避免同一会话被反复点击
   * @param {{ element: Element, clickTarget?: Element }} sessionItem
   * @param {{ force?: boolean }} [options]
   */
  async openChatSession(sessionItem, options = {}) {
    const documents = this.collectAccessibleDocuments(true);
    const resumeBlocking =
      this.isResumePanelBlocking(documents) ||
      this.isResumePanelVisible(documents);
    // 仅调用方显式 force 时强制点；简历浮层挡着时先关再判断，不无脑 force 点列表
    const force = options.force === true;

    // 仅「右侧已确认是目标人」才跳过点击。
    // 不能用 isChatSessionReady：panel-text 误判会跳过点击，表现为不点会话。
    if (this.isAskResumeSessionAlreadyReady(sessionItem, documents)) {
      return this.getSessionDisplayName(sessionItem);
    }

    // 列表已选中且右侧已是目标人：跳过
    const expected = this.getSessionDisplayName(sessionItem);
    const activeName = this.getActiveChatPanelGeekName(documents);
    if (
      activeName &&
      this.namesLikelyMatch(expected, activeName) &&
      this.isSessionListItemSelected(sessionItem) &&
      !resumeBlocking
    ) {
      return expected;
    }

    const element = sessionItem.element;
    if (!element) return this.getSessionDisplayName(sessionItem);

    const target =
      sessionItem.clickTarget ||
      element.querySelector?.('[class*="geek-item-wrap"]') ||
      element.querySelector?.(".geek-item-wrap") ||
      element;

    if (force) {
      await this.forceClickElement(target);
    } else {
      await this.gentleClickElement(target);
    }
    await new Promise((resolve) => setTimeout(resolve, force ? 1100 : 900));

    return this.getSessionDisplayName(sessionItem);
  }

  shouldLogAskResumeOnce(key, status) {
    if (!this.askResumeRunState) {
      this.askResumeRunState = {
        loggedOnce: new Set(),
        aiDecisions: new Map(),
        completedSessions: new Set(),
        sessionUiAttempts: new Map(),
        bossRejectScriptSynced: false,
      };
    }
    const cacheKey = `${key}:${status}`;
    if (this.askResumeRunState.loggedOnce.has(cacheKey)) return false;
    this.askResumeRunState.loggedOnce.add(cacheKey);
    return true;
  }

  resetAskResumeRunState() {
    this.askResumeRunState = {
      loggedOnce: new Set(),
      aiDecisions: new Map(),
      completedSessions: new Set(),
      sessionUiAttempts: new Map(),
      bossRejectScriptSynced: false,
    };
    this._resumeNotAttachmentKeys = new Set();
    this.clearAskResumeRuntimeCaches();
  }

  /**
   * 检查是否有消息提示，有就开始处理
   * @param {*} element
   * @returns
   */
  async checkMessageTip(element, phone, wechat, resume) {
    //暂时不处理
    return true;

    let messageTip = window.parent.document.getElementsByClassName(
      this.detailSelectors.messageTip,
    );
    if (messageTip.length > 0) {
      messageTip = messageTip[0];
    }
    console.log("消息数量:", messageTip.textContent.trim());
    let messageCount = 0;
    try {
      messageCount = parseInt(messageTip.textContent.trim()) || 0;
    } catch (error) {
      console.error("解析消息数量失败:", error);
    }
    if (messageCount <= 0) {
      return false;
    }
    //开始处理消息
    // 1. 点击消息提示

    messageTip.click();
    await new Promise((resolve) => setTimeout(resolve, 2500));

    // 3. 查找出待处理的列表
    let messageListItems =
      window.parent.document.getElementsByClassName("friend-list-item");
    console.log("消息列表元素数量:", messageListItems);

    for (let i = 0; i < messageListItems.length; i++) {
      console.log(messageListItems[i].textContent.trim());
      let messageCount = 0;
      try {
        messageCount =
          parseInt(
            messageListItems[i]
              .getElementsByClassName("badge-count badge-count-common-less")[0]
              .textContent.trim(),
          ) || 0;
      } catch (error) {}
      if (messageCount <= 0) {
        continue;
      }
      //点击消息
      messageListItems[i].click();
      await new Promise((resolve) => setTimeout(resolve, 1000));
      // 点击索要绑定手机号
      await this.clickPhoneButton(phone, wechat, resume);
    }

    // 3. 点击索要绑定手机号
    // 4. 关闭列表
    messageTip.click();

    return false;
  }

  /**
   * 点击索要绑定手机号按钮
   * @param {是否索要手机号} phone
   * @param {是否索要微信} wechat
   * @param {是否索要简历} resume
   */
  async clickPhoneButton(phone, wechat, resume) {
    const suoyaolist = window.parent.document.querySelectorAll(
      `[class^="${this.selectors.phoneButton}"]`,
    );

    if (!suoyaolist) {
      console.error("未找到索要信息的按钮");
      return null;
    }

    if (suoyaolist.length <= 3) {
      console.error("未找到索要手机号按钮");
      return null;
    }

    console.log("索要手机号按钮:", suoyaolist);

    if (phone) {
      suoyaolist[3].click();
      await new Promise((resolve) => setTimeout(resolve, 200));
      const confirmphoneButton = document.querySelector(
        `[class^="boss-btn-primary boss-btn"]`,
      );

      if (confirmphoneButton) {
        confirmphoneButton.click();
      }
    }
    if (wechat) {
      suoyaolist[4].click();
      await new Promise((resolve) => setTimeout(resolve, 200));

      const confirmphoneButton = document.querySelector(
        `[class^="boss-btn-primary boss-btn"]`,
      );

      if (confirmphoneButton) {
        confirmphoneButton.click();
      }
    }
    if (resume) {
      suoyaolist[2].click();
      await new Promise((resolve) => setTimeout(resolve, 200));

      const confirmphoneButton = document.querySelector(
        `[class^="boss-btn-primary boss-btn"]`,
      );
      if (confirmphoneButton) {
        confirmphoneButton.click();
      }
    }
  }

  //索要绑定手机号
  async collectPhoneWechatResume(phone, wechat, resume, candidate, element) {
    try {
      //等等1秒
      await new Promise((resolve) => setTimeout(resolve, 1000));

      for (let i = 0; i < this.selectors.continueButton.length; i++) {
        //先点击继续沟通
        const continueButton = element.querySelectorAll(
          `[class^="${this.selectors.continueButton[i]}"]`,
        );
        for (let j = 0; j < continueButton.length; j++) {
          // console.log(continueButton[j].textContent.trim());
          // console.log(continueButton[j]);
          continueButton[j].click();
          await new Promise((resolve) => setTimeout(resolve, 500));
          //  console.log(continueButton[j]);
          continueButton[j].click();
        }
      }
      // await randomDelay("索要信息");
      await new Promise((resolve) => setTimeout(resolve, 1000));

      await this.clickPhoneButton(phone, wechat, resume);

      //等待2秒
      await new Promise((resolve) => setTimeout(resolve, 1000));
      // console.log('等待2秒');

      //点击确认按钮
      const closeButton = document.querySelector(
        `[class^="iboss iboss-close"]`,
      );
      // console.log("关闭按钮",closeButton);

      if (closeButton) {
        closeButton.click();
      }

      const closeButton2 = document.querySelector(
        `[class^="km-icon sati ignore-im-widget-click sati-times"]`,
      );
      // console.log("关闭按钮2",closeButton2);
      if (closeButton2) {
        closeButton2.click();
      }
    } catch (error) {
      console.error("索要手机号失败:", error);
      return null;
    }
  }

  // 初始化数据拦截监听
  initDataInterceptor() {
    // 监听来自 boss_interceptor.js 的拦截数据（含子 frame 转发到 top 的消息）
    const handleInterceptMessage = (event) => {
      if (!event.data || event.data.source !== "boss-plugin") return;
      if (event.origin && !/zhipin\.com/.test(event.origin)) {
        return;
      }

      if (event.data.type === "geek-detail" && event.data.data) {
        this.processGeekDetailData(event.data.data);
      }

      if (event.data.type === "geek-list" && event.data.data) {
        const payload = event.data.data;
        const zpData = payload?.zpData || payload || {};
        const list = zpData.geekList || zpData.geeks;
        if (Array.isArray(list) && list.length > 0) {
          this.processInterceptedData(list);
        } else {
          this.processGeekDetailData(payload);
        }
      }

      if (event.data.type === "friend-list" && event.data.data) {
        this.processFriendListData(event.data.data);
      }

      if (event.data.type === "chat-history" && event.data.data) {
        this.processChatHistoryData(event.data.data);
      }
    };

    window.addEventListener("message", handleInterceptMessage);
    try {
      if (window.top && window.top !== window) {
        window.top.addEventListener("message", handleInterceptMessage);
      }
    } catch {
      /* ignore */
    }
  }

  /**
   * 从 bossGetGeek 等单条简历接口响应中提取候选人
   * @param {object} payload
   */
  extractGeekDetailCandidate(payload) {
    const zpData = payload?.zpData || payload?.data?.zpData || payload || {};

    if (zpData.geekCard) {
      return { ...zpData, geekCard: zpData.geekCard };
    }

    if (zpData.geekDetail?.geekCard) {
      return { geekCard: zpData.geekDetail.geekCard, ...zpData.geekDetail };
    }

    if (zpData.geekDetail?.geekName) {
      return { geekCard: zpData.geekDetail };
    }

    if (zpData.geekInfo?.geekCard) {
      return { geekCard: zpData.geekInfo.geekCard, ...zpData.geekInfo };
    }

    if (zpData.geekInfo?.geekName) {
      return { geekCard: zpData.geekInfo };
    }

    const nested = zpData.data || payload?.data;
    if (nested?.geekCard) {
      return { geekCard: nested.geekCard, ...nested };
    }

    if (
      zpData.geekName &&
      (zpData.geekWorks || zpData.geekEdus || zpData.geekDegree || zpData.ageDesc)
    ) {
      return { geekCard: zpData };
    }

    const list = zpData.geekList || zpData.geeks;
    if (Array.isArray(list) && list.length > 0) {
      const first = list[0];
      if (first?.geekCard) return first;
      if (first?.geekName) return { geekCard: first };
    }

    return null;
  }

  /**
   * 处理沟通页「在线简历」触发的单条简历接口数据
   * @param {object} payload
   */
  async processGeekDetailData(payload) {
    try {
      const candidate = this.extractGeekDetailCandidate(payload);
      if (!candidate?.geekCard) return;

      const geekName =
        candidate.geekCard.geekName || candidate.name || candidate.geekCard.name;
      const key = this.normalizePersonName(geekName);
      if (!key) return;

      this.geekDetailCache.set(key, candidate);
      this._bossCandidatesCache = null;

      const cachedData = await this.getCachedCandidateData();
      const list = Array.isArray(cachedData) ? [...cachedData] : [];
      const existingIndex = list.findIndex((item) => {
        const itemName = item?.geekCard?.geekName || item?.name || "";
        return this.namesLikelyMatch(geekName, itemName);
      });

      if (existingIndex >= 0) {
        list[existingIndex] = { ...list[existingIndex], ...candidate };
      } else {
        list.unshift(candidate);
      }

      await new Promise((resolve, reject) => {
        chrome.storage.local.set({ bossZhipinCandidates: list }, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
            return;
          }
          this._bossCandidatesCache = list;
          resolve();
        });
      });

      this.resolveGeekDetailWaiters(candidate, geekName);
      console.log("沟通页简历接口数据已缓存:", geekName);
    } catch (error) {
      console.error("处理简历详情接口失败:", error);
    }
  }

  /**
   * @param {object} candidate
   * @param {string} geekName
   */
  resolveGeekDetailWaiters(candidate, geekName) {
    if (!this._geekDetailWaiters.length) return;

    const pending = [...this._geekDetailWaiters];
    for (const waiter of pending) {
      if (!this.namesLikelyMatch(waiter.name, geekName)) continue;
      clearTimeout(waiter.timer);
      waiter.resolve(candidate);
      this._geekDetailWaiters = this._geekDetailWaiters.filter(
        (item) => item !== waiter,
      );
    }
  }

  /**
   * 等待点击「在线简历」后触发的接口返回
   * @param {string} candidateName
   * @param {number} timeout
   */
  async waitForGeekDetailApi(candidateName, timeout = 8000) {
    const key = this.normalizePersonName(candidateName);
    if (!key) return null;

    const cached = this.geekDetailCache.get(key);
    if (cached?.geekCard) return cached;

    const fromStorage = this.findCandidateFromCache(
      await this.getCachedCandidateData(true),
      candidateName,
    );
    if (fromStorage?.geekCard) {
      this.geekDetailCache.set(key, fromStorage);
      return fromStorage;
    }

    return new Promise((resolve) => {
      const waiterId = Symbol("geek-detail-waiter");
      let settled = false;

      const finish = (value) => {
        if (settled) return;
        settled = true;
        clearInterval(poll);
        clearTimeout(timer);
        this._geekDetailWaiters = this._geekDetailWaiters.filter(
          (item) => item.id !== waiterId,
        );
        resolve(value);
      };

      const poll = window.setInterval(async () => {
        const hit = this.geekDetailCache.get(key);
        if (hit?.geekCard) {
          finish(hit);
          return;
        }
        const fresh = this.findCandidateFromCache(
          await this.getCachedCandidateData(true),
          candidateName,
        );
        if (fresh?.geekCard) {
          this.geekDetailCache.set(key, fresh);
          finish(fresh);
        }
      }, 250);

      const timer = window.setTimeout(() => finish(null), timeout);

      this._geekDetailWaiters.push({
        id: waiterId,
        name: candidateName,
        resolve: finish,
        timer,
      });
    });
  }

  /**
   * 将接口简历数据合并到候选人对象
   * @param {object} candidate
   * @param {object|null} apiCandidate
   * @param {string} fallbackName
   */
  mergeGeekDetailCandidate(candidate, apiCandidate, fallbackName = "") {
    if (!apiCandidate?.geekCard) return candidate;
    return this.enrichCandidateGender(
      this.normalizeCandidateName(
        {
          ...candidate,
          ...apiCandidate,
          geekCard: {
            ...(candidate?.geekCard || {}),
            ...apiCandidate.geekCard,
          },
        },
        fallbackName,
      ),
    );
  }

  // 处理拦截到的数据
  async processInterceptedData(apiData) {
    try {
      if (apiData) {
        const candidates = apiData;

        // 直接存储拦截到的数据
        await new Promise((resolve, reject) => {
          chrome.storage.local.set(
            {
              bossZhipinCandidates: candidates,
            },
            () => {
              if (chrome.runtime.lastError) {
                console.error("保存缓存数据失败:", chrome.runtime.lastError);
                reject(chrome.runtime.lastError);
              } else {
                console.log("候选人数据直接缓存完成");
                resolve();
              }
            },
          );
        });
      }
    } catch (error) {
      console.error("处理拦截数据失败:", error);
    }
  }

  // 删除不再需要的合并方法

  // 添加一个新的查找元素的方法
  findElements() {
    let items = [];

    // 1. 首先尝试使用完整的 class 名称
    // items = document.getElementsByClassName(this.fullClasses.items);
    for (const item of this.fullClasses.items) {
      items = document.getElementsByClassName(item);
      if (items.length > 0) {
        break;
      }
    }

    if (items.length === 0) {
      for (const item of this.selectors.items) {
        items = document.getElementsByClassName(item);
        if (items.length > 0) {
          break;
        }
      }
      // 2. 尝试使用简单的 class 名称
      // items = document.getElementsByClassName(this.selectors.items);
    }

    if (items.length === 0) {
      for (const item of this.fullClasses.items) {
        items = document.querySelectorAll(`[class*="${item}"]`);
        if (items.length > 0) {
          break;
        }
      }
      // 3. 尝试使用模糊匹配
    }

    if (items.length === 0) {
      for (const item of this.fullClasses.items) {
        items = document.querySelectorAll(
          `[class^="${item}"], [class*=" ${this.selectors.items}"]`,
        );
        if (items.length > 0) {
          break;
        }
      }
      // 4. 尝试使用前缀匹配
    }

    return items;
  }

  // 从缓存中获取候选人数据
  async getCachedCandidateData(forceRefresh = false) {
    if (!forceRefresh && Array.isArray(this._bossCandidatesCache)) {
      return this._bossCandidatesCache;
    }

    return new Promise((resolve) => {
      chrome.storage.local.get(["bossZhipinCandidates"], (result) => {
        if (chrome.runtime.lastError) {
          console.error("获取缓存数据失败:", chrome.runtime.lastError);
          resolve([]);
          return;
        }
        const list = result.bossZhipinCandidates || [];
        this._bossCandidatesCache = list;
        resolve(list);
      });
    });
  }

  // 根据候选人姓名从缓存中查找完整信息
  findCandidateFromCache(cachedData, candidateName) {
    if (!cachedData || !candidateName) return null;

    for (const candidate of cachedData) {
      const names = [
        candidate?.geekCard?.geekName,
        candidate?.geekCard?.name,
        candidate?.name,
      ];
      for (const n of names) {
        if (n && this.namesLikelyMatch(candidateName, n)) {
          return candidate;
        }
      }
    }

    return null;
  }

  /**
   * 是否为同事沟通/聊天工具栏等非简历弹层
   * @param {string} text
   */
  isColleagueOrChatOverlayText(text = "") {
    const normalized = text.replace(/\s+/g, " ").trim();
    if (!normalized) return false;

    return /同事沟通进度|合作专享|合作客户专享|我的沟通进度|了解同事沟通进度|Ta向\s*.+\s*发起沟通|向您发起沟通，沟通职位|继续沟通[\s\S]{0,40}未处理/.test(
      normalized,
    );
  }

  /**
   * 文本是否像在线简历详情（排除同事沟通等干扰面板）
   * @param {string} text
   */
  isResumeDetailText(text = "") {
    const normalized = text.replace(/\s+/g, " ").trim();
    if (!normalized || normalized.length < 60) return false;
    if (this.isColleagueOrChatOverlayText(normalized)) return false;

    const hasToolbarOnly =
      /收藏/.test(normalized) &&
      /转发/.test(normalized) &&
      /举报/.test(normalized) &&
      /继续沟通/.test(normalized);
    const hasResumeBody =
      /工作经历|教育经历|求职期望|个人优势|项目经历|专业技能|毕业院校|期望职位|期望薪资|工作年限|自我描述|个人总结|岗位经验|院校经历/.test(
        normalized,
      );

    if (hasToolbarOnly && !hasResumeBody) return false;
    return hasResumeBody;
  }

  /**
   * @param {string} text
   */
  scoreResumeDetailText(text = "") {
    if (!this.isResumeDetailText(text)) return 0;

    let score = Math.min(text.length, 4000);
    const markers = [
      "工作经历",
      "教育经历",
      "求职期望",
      "个人优势",
      "项目经历",
      "专业技能",
      "毕业院校",
      "期望职位",
    ];
    for (const marker of markers) {
      if (text.includes(marker)) score += 800;
    }
    if (this.isColleagueOrChatOverlayText(text)) score -= 10000;
    return score;
  }

  /**
   * 收集页面上所有可能的简历详情容器（含 iframe）
   * @param {Document[]} documents
   */
  collectResumeDetailCandidates(documents) {
    const containers = [
      '[class*="resume-page"]',
      '[class*="resume-detail"]',
      '[class*="resume-content"]',
      '[class*="resume-dialog"]',
      '[class*="geek-resume"]',
      '[class*="geek-detail"]',
      '[class*="resume-box"]',
      ".resume-detail-wrap",
      ".boss-dialog",
      ".dialog-wrap.active",
      '[class*="dialog-wrap"]',
      '[class*="boss-popup"]',
      '[class*="layer-container"]',
      '[class*="dialog-container"]',
    ];
    const docs = documents || this.collectAccessibleDocuments();
    const candidates = [];
    const seen = new Set();

    const pushCandidate = (el, source) => {
      if (!el || seen.has(el) || !this.isElementVisible(el)) return;
      const text = el.innerText?.trim();
      if (!text || text.length < 60) return;
      seen.add(el);
      candidates.push({
        el,
        text,
        source,
        score: this.scoreResumeDetailText(text),
      });
    };

    for (const doc of docs) {
      for (const sel of containers) {
        doc.querySelectorAll(sel).forEach((el) => pushCandidate(el, sel));
      }

      doc.querySelectorAll("iframe").forEach((frame) => {
        try {
          const frameDoc = frame.contentDocument;
          if (!frameDoc) return;
          pushCandidate(frameDoc.body, "iframe-body");
          for (const sel of containers) {
            frameDoc
              .querySelectorAll(sel)
              .forEach((el) => pushCandidate(el, `iframe:${sel}`));
          }
        } catch {
          /* cross-origin iframe */
        }
      });
    }

    return candidates.sort((a, b) => b.score - a.score);
  }

  /**
   * @param {Document[]} documents
   */
  extractChatHeaderInfo(documents) {
    const selectors = [
      '[class*="chat-header"]',
      '[class*="im-top"]',
      '[class*="top-info"]',
      '[class*="user-info"]',
      '[class*="base-info"]',
      '[class*="geek-info"]',
      '[class*="job-info"]',
    ];
    const parts = [];
    const seen = new Set();

    for (const doc of documents) {
      for (const selector of selectors) {
        doc.querySelectorAll(selector).forEach((el) => {
          if (el.closest('[class*="friend-list"], [role="group"] [role="listitem"]')) {
            return;
          }
          const text = el.innerText?.replace(/\s+/g, " ").trim();
          if (!text || text.length < 4 || text.length > 600) return;
          if (/收藏|转发|举报|继续沟通|同事沟通进度|合作专享/.test(text)) return;
          if (seen.has(text)) return;
          seen.add(text);
          parts.push(text);
        });
      }
    }

    return parts.join("\n");
  }

  async waitForDetailPopup(timeout = 3000, documents) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const candidates = this.collectResumeDetailCandidates(documents);
      if (candidates.some((item) => item.score > 0)) return true;
      await new Promise((resolve) => setTimeout(resolve, 200));
    }
    return false;
  }

  /**
   * 抓取点击「在线简历」后左侧展开的简历面板（BOSS 沟通页为左栏详情，非右侧聊天区）
   * @param {Document[]} documents
   * @param {string} expectedName
   */
  scrapeResumeProfilePanel(documents, expectedName = "") {
    const docs = documents || this.collectAccessibleDocuments();
    const candidates = [];
    const seen = new Set();
    const selectors = [
      '[class*="resume-page"]',
      '[class*="resume-detail"]',
      '[class*="resume-content"]',
      '[class*="geek-detail"]',
      '[class*="geek-resume"]',
      '[class*="geek-card"]',
      '[class*="profile-wrap"]',
      '[class*="profile-content"]',
      '[class*="slide-wrap"]',
      '[class*="drawer"]',
      '[class*="boss-dialog"]',
      '[class*="dialog-wrap"]',
      "section",
      "article",
      "main",
    ];

    const pushCandidate = (el, source) => {
      if (!el || seen.has(el) || !this.isElementVisible(el)) return;
      if (
        this.isInsideChatConversationArea(el) &&
        !this.isInsideOnlineResumeOverlayRoot(el)
      ) {
        return;
      }
      const text = el.innerText?.trim();
      if (!text || text.length < 80) return;
      if (this.isColleagueOrChatOverlayText(text)) return;
      if (!this.looksLikeResumePanelText(text)) return;
      if (
        expectedName &&
        !this.textMentionsCandidateName(text, expectedName) &&
        !/个人优势|自我描述|项目经历/.test(text)
      ) {
        return;
      }

      const rect = el.getBoundingClientRect();
      const viewWidth =
        el.ownerDocument?.defaultView?.innerWidth || window.innerWidth || 1920;
      let score = this.scoreResumeDetailText(text) || Math.min(text.length, 3000);
      if (rect.left < viewWidth * 0.55) score += 1500;
      if (/工作经历/.test(text)) score += 1200;
      if (/期望职位/.test(text)) score += 600;
      if (/个人优势|项目经历/.test(text)) score += 500;
      if (text.length > 500) score += 400;
      if (/继续沟通/.test(text) && !/工作经历/.test(text)) score -= 5000;

      seen.add(el);
      candidates.push({ text, score, source });
    };

    for (const doc of docs) {
      for (const sel of selectors) {
        doc.querySelectorAll(sel).forEach((el) => pushCandidate(el, sel));
      }

      doc.querySelectorAll("div, section, article").forEach((el) => {
        const label = el.textContent?.replace(/\s+/g, " ").trim() || "";
        if (!/^工作经历/.test(label.slice(0, 12))) return;
        let container = el;
        for (let depth = 0; depth < 8 && container; depth += 1) {
          pushCandidate(container, "section:工作经历");
          container = container.parentElement;
        }
      });
    }

    candidates.sort((a, b) => b.score - a.score);
    return candidates[0]?.text || null;
  }

  /**
   * @param {Document[]} documents
   * @param {string} expectedName
   * @param {number} timeout
   */
  async waitForResumeProfileText(documents, expectedName, timeout = 10000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const freshDocuments = this.collectAccessibleDocuments(true);
      const strict = this.scrapeResumeProfilePanel(freshDocuments, expectedName);
      if (strict) return strict;

      const relaxed = this.scrapeResumeProfilePanel(freshDocuments, "");
      if (
        relaxed &&
        (!expectedName || this.textMentionsCandidateName(relaxed, expectedName))
      ) {
        return relaxed;
      }

      await new Promise((resolve) => setTimeout(resolve, 350));
    }
    return null;
  }

  /**
   * 右侧聊天区顶部的简历摘要（在线简历按钮附近）
   * @param {Document[]} documents
   * @param {string} expectedName
   */
  extractChatResumeSummaryFromPanel(documents, expectedName) {
    const viewWidth = window.innerWidth || 1920;
    const minLeft = viewWidth * 0.28;
    const parts = [];
    const seen = new Set();

    for (const doc of documents) {
      const panelSelectors = [
        '[class*="chat-conversation"]',
        '[class*="chat-content"]',
        '[class*="chat-box"]',
        '[class*="im-chat"]',
        '[class*="chat-header"]',
        '[class*="top-info"]',
      ];

      for (const selector of panelSelectors) {
        doc.querySelectorAll(selector).forEach((el) => {
          if (el.closest('[class*="friend-list"], [role="group"] [role="listitem"]')) {
            return;
          }
          const rect = el.getBoundingClientRect();
          if (rect.left < minLeft || rect.width < 180) return;

          const text = el.innerText?.replace(/\s+/g, " ").trim();
          if (!text || text.length < 40 || text.length > 3000) return;
          if (!this.textMentionsCandidateName(text, expectedName)) return;
          if (!/在线简历|附件简历|\d{4}\.\d{2}-\d{4}\.\d{2}|·/.test(text)) {
            return;
          }
          if (seen.has(text)) return;
          seen.add(text);
          parts.push(text);
        });
      }
    }

    return parts.join("\n");
  }

  /**
   * @param {string} text
   * @param {string} expectedName
   */
  hasMeaningfulResumeContent(text = "", expectedName = "") {
    if (!text || text.includes("【采集失败】")) return false;
    if (/【在线简历详情】[\s\S]{80,}工作经历/.test(text)) return true;
    if (
      this.textMentionsCandidateName(text, expectedName) &&
      /工作经历/.test(text) &&
      text.length > 280
    ) {
      return true;
    }
    if (
      this.textMentionsCandidateName(text, expectedName) &&
      /\d{4}\.\d{2}-\d{4}\.\d{2}/.test(text) &&
      /·/.test(text) &&
      text.length > 180
    ) {
      return true;
    }
    return false;
  }

  scrapeDetailPopupText(documents) {
    const candidates = this.collectResumeDetailCandidates(documents);
    const best = candidates.find((item) => item.score > 0);
    return best?.text || null;
  }

  /**
   * 沟通页：查找「查看简历 / 在线简历」入口（对齐简历下载器）
   * @param {Document[]} documents
   */
  /**
   * 查找「附件简历」打开入口（文案须含附件，避免点到在线简历）
   * @param {Document[]} documents
   */
  findAttachmentResumeOpenButton(documents) {
    const docs = documents || this.collectAccessibleDocuments(true);
    const viewWidth = window.innerWidth || 1920;
    const minLeft = viewWidth * 0.2;
    let best = null;
    let bestScore = 0;

    for (const doc of docs) {
      const nodes = doc.querySelectorAll(
        "a, button, span, div, [role='button'], [class*='btn']",
      );
      for (const el of nodes) {
        if (el.closest('[class*="friend-list"], [role="group"]')) continue;
        const text = (el.textContent || "").replace(/\s+/g, "");
        if (!text || text.length > 24) continue;
        if (!/附件/.test(text)) continue;
        if (!/简历|附件简历|简历附件/.test(text)) continue;
        if (/在线/.test(text) && !/附件/.test(text)) continue;
        if (!this.isElementClickable(el) && !this.isElementVisible?.(el)) {
          continue;
        }
        const rect = el.getBoundingClientRect?.();
        if (rect && rect.left < minLeft) continue;
        let score = 10;
        if (text === "附件简历" || text === "简历附件") score += 20;
        if (/resume-btn-file/.test(el.className || "")) score += 5;
        if (score > bestScore) {
          bestScore = score;
          best = el;
        }
      }
    }
    return best;
  }

  findChatResumeViewButton(documents) {
    return (
      this.findOnlineResumeViewButton(documents) ||
      this.findAttachmentResumeOpenButton(documents)
    );
  }

  /**
   * 只找「在线简历」入口，不点附件简历。
   * @param {Document[]} documents
   */
  findOnlineResumeViewButton(documents) {
    const docs = documents || this.collectAccessibleDocuments(true);
    const viewWidth = window.innerWidth || 1920;
    const minLeft = viewWidth * 0.25;

    const pickClickable = (el) => {
      if (!el) return null;
      if (this.isElementClickable(el)) return el;
      const parent = el.parentElement;
      if (parent && this.isElementClickable(parent)) return parent;
      return el;
    };

    for (const doc of docs) {
      const nodes = doc.querySelectorAll(
        'button, [role="button"], a, span, div, [class*="btn"], [class*="resume"]',
      );
      for (const el of nodes) {
        if (
          el.closest(
            '[class*="friend-list"], [class*="geek-list"], [role="group"] [role="listitem"]',
          )
        ) {
          continue;
        }

        const rect = el.getBoundingClientRect();
        if (rect.width < 1 || rect.left < minLeft) continue;

        const text = el.textContent?.replace(/\s+/g, "") || "";
        if (/附件/.test(text)) continue;
        if (!/^(在线简历|查看在线简历|查看简历)$/.test(text)) continue;

        const clickTarget = pickClickable(el);
        if (clickTarget) return clickTarget;
      }
    }

    return null;
  }

  /**
   * @param {Document[]} documents
   */
  async clickChatResumeDetail(documents, expectedName = "") {
    if (this.isAskResumeRateLimited()) return false;

    await this.waitForResumeViewCooldown();
    const resumeBtn = this.findOnlineResumeViewButton(documents);
    if (!resumeBtn) return false;

    await this.gentleClickElement(resumeBtn);
    this._lastResumeViewAt = Date.now();
    if (expectedName) {
      return this.waitForOnlineResumeOverlayForCandidate(expectedName, 8000);
    }
    await new Promise((resolve) => setTimeout(resolve, 1200));
    return this.isOnlineResumeOverlayOpen(
      this.collectAccessibleDocuments(true),
      "",
    );
  }

  normalizeGender(raw) {
    if (raw == null || raw === "") return "";
    if (typeof raw === "number") {
      if (raw === 1) return "男";
      if (raw === 0 || raw === 2) return "女";
    }
    const s = String(raw).trim().toLowerCase();
    if (s === "男" || s === "male" || s === "m" || s === "1") return "男";
    if (s === "女" || s === "female" || s === "f" || s === "0" || s === "2") {
      return "女";
    }
    return "";
  }

  /**
   * @param {string} source
   */
  formatGenderSourceLabel(source) {
    const map = {
      api_field: "推荐名单接口",
      api_age_desc: "名单里的年龄描述",
      card_icon: "卡片上的男女图标",
      card_label: "卡片上的标签文字",
      extra: "卡片上的其它短信息",
      unknown: "未能识别",
    };
    return map[source] || "未能识别";
  }

  emitRuntimeLog(message, type = "info") {
    const text = String(message || "").trim();
    if (!text) return;
    try {
      chrome.runtime.sendMessage(
        { type: "LOG_MESSAGE", data: { message: text, type } },
        () => {
          void chrome.runtime.lastError;
        },
      );
    } catch {
      /* ignore */
    }
  }

  logGenderRecognition(candidate) {
    // const name = candidate?.name || candidate?.geekCard?.geekName || "未知";
    // const gender = candidate?.gender || "未知";
    // const label = this.formatGenderSourceLabel(candidate?.genderSource);
    // this.emitRuntimeLog(
    //   `性别识别：${name} → ${gender}（${label}）`,
    //   gender === "未知" ? "warning" : "info",
    // );
    void candidate;
  }

  /**
   * 只从推荐名单接口字段读性别，不看卡片画面。
   * @param {object|null} candidate
   * @returns {{ gender: string, source: string }}
   */
  inspectApiGender(candidate) {
    if (!candidate) return { gender: "", source: "" };

    const gc = candidate.geekCard;
    if (gc) {
      const fromField =
        this.normalizeGender(gc.geekGender) ||
        this.normalizeGender(gc.gender) ||
        this.normalizeGender(gc.geekSex) ||
        this.normalizeGender(gc.sex);
      if (fromField) return { gender: fromField, source: "api_field" };
    }

    const fromRootField = this.normalizeGender(candidate.geekGender);
    if (fromRootField) return { gender: fromRootField, source: "api_field" };

    if (gc) {
      const fromAge = this.extractGenderFromText(gc.ageDesc);
      if (fromAge) return { gender: fromAge, source: "api_age_desc" };
    }

    return { gender: "", source: "" };
  }

  /**
   * 只从当前卡片的男女 SVG 图标读性别，不看接口、不看标签文字。
   * @param {Element|null} cardEl
   * @returns {{ gender: string, source: string }}
   */
  inspectRecommendCardIcon(cardEl) {
    if (!cardEl || typeof cardEl.querySelector !== "function") {
      return { gender: "", source: "" };
    }
    const fromIcon = this.extractGenderFromSvgIcons(cardEl, {
      preferRightPanel: false,
    });
    if (fromIcon) return { gender: fromIcon, source: "card_icon" };
    return { gender: "", source: "" };
  }

  /**
   * 从推荐牛人「当前这张卡片」取性别及来源。
   * 只扫卡片根节点：先 SVG 男女图标，再姓名行/标签短文本（不扫自我介绍长文）。
   * 必须 preferRightPanel:false，避免沿用沟通页「偏右侧」打分漏掉左/中卡片。
   * @param {Element|null} cardEl
   * @returns {{ gender: string, source: string }}
   */
  inspectRecommendCardGender(cardEl) {
    if (!cardEl || typeof cardEl.querySelector !== "function") {
      return { gender: "", source: "" };
    }

    const fromIcon = this.inspectRecommendCardIcon(cardEl);
    if (fromIcon.gender) return fromIcon;

    const labelRoots = [];
    try {
      const nameEl = this.findElement(
        this.fullClasses.name,
        this.selectors.name,
      )(cardEl);
      if (nameEl) labelRoots.push(nameEl.parentElement || nameEl);
    } catch {
      /* ignore */
    }
    try {
      const ageEl = this.findElement(
        this.fullClasses.age,
        this.selectors.age,
      )(cardEl);
      if (ageEl) labelRoots.push(ageEl);
    } catch {
      /* ignore */
    }
    try {
      cardEl
        .querySelectorAll(
          '[class*="label"], [class*="base-info"], [class*="geek-info"], [class*="name"]',
        )
        .forEach((el) => labelRoots.push(el));
    } catch {
      /* ignore */
    }

    const seen = new Set();
    for (const root of labelRoots) {
      if (!root || seen.has(root)) continue;
      seen.add(root);
      const text = String(root.textContent || "")
        .replace(/\s+/g, " ")
        .trim();
      if (!text || text.length > 80) continue;
      const fromText = this.extractGenderFromText(text);
      if (fromText) return { gender: fromText, source: "card_label" };
    }
    return { gender: "", source: "" };
  }

  /**
   * 从推荐牛人「当前这张卡片」取性别。
   * @param {Element|null} cardEl
   */
  extractGenderFromRecommendCard(cardEl) {
    return this.inspectRecommendCardGender(cardEl).gender || "";
  }

  extractGenderFromText(text) {
    if (!text) return "";
    const t = String(text);
    // 兼容误把图标 href 当文本传入
    const fromHref = this.parseGenderFromIconHref(t);
    if (fromHref) return fromHref;

    const collapsed = t.replace(/\s+/g, "");
    if (collapsed === "女") return "女";
    if (collapsed === "男") return "男";

    const delimFemale = /(?:^|[·|/，,、\s])女(?:[·|/，,、\s]|$)/;
    const delimMale = /(?:^|[·|/，,、\s])男(?:[·|/，,、\s]|$)/;
    if (
      delimFemale.test(t) ||
      /[·\s]女[·\s]|^女[·\s]|女·/.test(t) ||
      /\d+岁女/.test(collapsed)
    ) {
      return "女";
    }
    if (
      delimMale.test(t) ||
      /[·\s]男[·\s]|^男[·\s]|男·/.test(t) ||
      /\d+岁男/.test(collapsed)
    ) {
      return "男";
    }
    if (/\b女\b/.test(t)) return "女";
    if (/\b男\b/.test(t)) return "男";
    return "";
  }

  /**
   * @param {object|null} candidate
   * @param {Element|null} [cardEl]
   * @returns {{ gender: string, source: string }}
   */
  resolveCandidateGenderDetail(candidate, cardEl = null) {
    if (!candidate) return { gender: "未知", source: "unknown" };

    const fromApi = this.inspectApiGender(candidate);
    if (fromApi.gender) {
      return { gender: fromApi.gender, source: fromApi.source };
    }

    if (cardEl) {
      const fromCard = this.inspectRecommendCardGender(cardEl);
      if (fromCard.gender) {
        return { gender: fromCard.gender, source: fromCard.source };
      }
    }

    if (candidate.ageLabelText) {
      const fromLabel = this.extractGenderFromText(candidate.ageLabelText);
      if (fromLabel) return { gender: fromLabel, source: "card_label" };
    }

    if (Array.isArray(candidate.extraInfo)) {
      for (const item of candidate.extraInfo) {
        const value = String(item?.value || "").trim();
        if (!value || value.length > 80) continue;
        const fromExtra = this.extractGenderFromText(value);
        if (fromExtra) return { gender: fromExtra, source: "extra" };
      }
    }

    const preset = this.normalizeGender(candidate.gender);
    if (preset) {
      return {
        gender: preset,
        source: candidate.genderSource || "card_label",
      };
    }

    return { gender: "未知", source: "unknown" };
  }

  resolveCandidateGender(candidate) {
    return this.resolveCandidateGenderDetail(candidate).gender;
  }

  enrichCandidateGender(candidate) {
    if (!candidate) return candidate;
    const detail = this.resolveCandidateGenderDetail(candidate);
    if (detail.gender !== "未知") {
      candidate.gender = detail.gender;
      if (!candidate.genderSource) candidate.genderSource = detail.source;
    }
    return candidate;
  }

  async extractCandidates2(candidate, documents) {
    try {
      const docs = documents || this.collectAccessibleDocuments();
      await this.waitForDetailPopup(5000, docs);
      const popupText = this.scrapeDetailPopupText(docs);
      if (popupText) {
        const popupGender = this.extractGenderFromText(popupText);
        if (popupGender) {
          candidate.gender = popupGender;
        }
      }
      const baseInfo = this.getSimpleCandidateInfo(candidate);
      if (popupText && this.isResumeDetailText(popupText)) {
        return `${baseInfo}\n\n【在线简历详情】\n${popupText}`;
      }
      return baseInfo;
    } catch (error) {
      console.error("extractCandidates2 失败:", error);
      return this.getSimpleCandidateInfo(candidate);
    }
  }

  sanitizeFilename(name) {
    return (name || "unknown").replace(/[\\/:*?"<>|]/g, "_").trim();
  }

  formatSaveTimestamp() {
    const d = new Date();
    const pad = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
  }

  async appendResumeToStorage(record) {
    return new Promise((resolve) => {
      chrome.storage.local.get(["招聘速聊助手_saved_resumes"], (result) => {
        if (chrome.runtime.lastError) {
          resolve(false);
          return;
        }
        const list = result.招聘速聊助手_saved_resumes || [];
        list.push(record);
        chrome.storage.local.set({ 招聘速聊助手_saved_resumes: list }, () => {
          resolve(!chrome.runtime.lastError);
        });
      });
    });
  }

  async downloadResumeJson(filename, jsonContent) {
    // 【本机落盘已关闭】不写下载夹 txt/json
    void filename;
    void jsonContent;
    return { success: true, skipped: true, message: "本机 JSON/TXT 落盘已关闭" };
    // try {
    //   const response = await chrome.runtime.sendMessage({
    //     action: "SAVE_RESUME_JSON",
    //     filename,
    //     content: jsonContent,
    //   });
    //   return response;
    // } catch (error) {
    //   return { success: false, error: error.message || String(error) };
    // }
  }

  buildAITextContent(record) {
    const rawResponse =
      record.aiResponseRaw == null
        ? "（无回复）"
        : typeof record.aiResponseRaw === "object"
          ? JSON.stringify(record.aiResponseRaw, null, 2)
          : String(record.aiResponseRaw);

    const lines = [
      "【简历信息】",
      record.input_text_0 || "",
      "",
      "【包含关键词】",
      record.input_text_1 || "（未设置）",
      "",
      "【排除关键词】",
      record.input_text_2 || "（未设置）",
      "",
      "【AI 回复】",
      rawResponse,
    ];
    if (record.aiDecision) {
      lines.push("", `【AI 结论】${record.aiDecision}（${record.aiReason || ""}）`);
    }
    if (record.greeted) {
      lines.push("", "【是否已打招呼】是");
    }
    return lines.join("\n");
  }

  async saveAIRecordToLocal(candidate, payload = {}) {
    try {
      const name = this.normalizeCandidateName(candidate).name || "未知";
      const record = {
        savedAt: new Date().toISOString(),
        name,
        type: "yili_ai_request",
        input_text_0: payload.input_text_0 || "",
        input_text_1: payload.input_text_1 || "",
        input_text_2: payload.input_text_2 || "",
        aiResponseRaw: payload.aiResponseRaw || null,
        aiDecision: payload.aiDecision || null,
        aiReason: payload.aiReason || null,
        greeted: !!payload.greeted,
        greetedAt: payload.greeted ? new Date().toISOString() : null,
      };

      const base = `${this.sanitizeFilename(name)}_${this.formatSaveTimestamp()}`;
      const txtFilename = `招聘速聊助手_resumes/${base}.txt`;
      // const jsonFilename = `招聘速聊助手_resumes/${base}.json`;
      // const textContent = this.buildAITextContent(record);
      // const jsonContent = JSON.stringify(record, null, 2);

      // 仅写扩展内存储；不下载到本机文件夹
      const storageOk = await this.appendResumeToStorage(record);
      // const txtDownload = await this.downloadResumeJson(txtFilename, textContent);
      // const jsonDownload = await this.downloadResumeJson(jsonFilename, jsonContent);
      // const downloadOk = !!(txtDownload?.success || jsonDownload?.success);
      const downloadOk = false;

      const status = {
        ok: !!storageOk,
        storageOk,
        downloadOk,
        filename: txtFilename,
        error: null,
      };

      await new Promise((resolve) => {
        chrome.storage.local.set(
          {
            招聘速聊助手_last_resume_save: {
              ...status,
              name,
              savedAt: record.savedAt,
            },
          },
          resolve,
        );
      });

      // if (storageOk && downloadOk) {
      //   status.message = `AI 分析内容已保存：下载目录/${txtFilename}`;
      // } else if (storageOk) {
      //   status.message = `AI 分析内容已写入插件存储（下载失败: ${status.error || "未知"}）`;
      // } else if (downloadOk) {
      //   status.message = `AI 分析内容已下载：${txtFilename}`;
      // } else {
      //   status.message = `AI 分析内容保存失败: ${status.error || "未知错误"}`;
      // }
      if (storageOk) {
        // status.message = "AI 分析内容已写入插件存储（未写入下载夹）";
      } else {
        status.message = "AI 分析内容保存失败：插件存储写入失败";
      }

      return status;
    } catch (error) {
      console.error("saveAIRecordToLocal 失败:", error);
      return {
        ok: false,
        message: `AI 分析内容保存失败: ${error.message || String(error)}`,
      };
    }
  }

  async markAIRecordGreeted(candidateName) {
    return new Promise((resolve) => {
      chrome.storage.local.get(["招聘速聊助手_saved_resumes"], (result) => {
        const list = result.招聘速聊助手_saved_resumes || [];
        for (let i = list.length - 1; i >= 0; i--) {
          const type = list[i].type;
          if (
            list[i].name === candidateName &&
            (type === "yili_ai_request" || type === "deepseek_ai_request")
          ) {
            list[i].greeted = true;
            list[i].greetedAt = new Date().toISOString();
            break;
          }
        }
        chrome.storage.local.set({ 招聘速聊助手_saved_resumes: list }, () => {
          resolve(!chrome.runtime.lastError);
        });
      });
    });
  }

  //提取信息
  async extractCandidates(elements = null) {
    try {
      const candidates = [];
      let items = elements || (await this.findElements());

      if (!items || items.length === 0) {
        console.warn("未找到任何候选人元素");
        return [];
      }

      // 异步获取缓存数据
      const cachedData = await this.getCachedCandidateData();

      // 使用for循环顺序处理元素，确保所有异步操作完成
      for (const item of Array.from(items)) {
        try {
          // this.highlightElement(item, 'processing');

          // 提取候选人姓名
          const nameElement = await this.findNameElement(item);
          const candidateName = nameElement?.textContent?.trim() || "";
          if (!candidateName) {
            this.clearHighlight(item);
            continue;
          }
          console.log("查找:" + candidateName);

          // 查找缓存或创建新候选人
          const candidate = await this.processCandidate(
            item,
            candidateName,
            cachedData,
          );
          if (candidate) {
            candidates.push(candidate);
            // this.highlightElement(item, 'matched');
          }
        } catch (error) {
          console.error("处理候选人元素失败:", error);
          this.clearHighlight(item);
        }
      }

      return candidates;
    } catch (error) {
      console.error("提取候选人失败:", error);
      return []; // 出错时返回空数组
    }
  }

  // 查找元素方法
  findElement(fullClass, partialClass) {
    return (item) => {
      if (Array.isArray(partialClass)) {
        for (const className of partialClass) {
          const element =
            item.getElementsByClassName(className)[0] ||
            item.querySelector(`[class*="${className}"]`);
          if (element) return element;
        }
      } else {
        return (
          item.getElementsByClassName(fullClass)[0] ||
          item.getElementsByClassName(partialClass)[0] ||
          item.querySelector(`[class*="${partialClass}"]`)
        );
      }
      return null;
    };
  }

  // 辅助方法：查找姓名元素
  async findNameElement(item) {
    return this.findElement(this.fullClasses.name, this.selectors.name)(item);
  }

  // 辅助方法：处理单个候选人
  // 从页面更新候选人信息
  async updateCandidateFromPage(candidate, item) {
    try {
      // 获取页面上的实时状态
      const pageActiveText =
        (await this.findElement(
          this.fullClasses.activeText,
          this.selectors.activeText,
        )(item)?.textContent?.trim()) || "离线";

      if (pageActiveText && pageActiveText !== "离线") {
        candidate.activeText = pageActiveText;
      }
      return candidate;
    } catch (error) {
      console.error("更新候选人页面信息失败:", error);
      return candidate;
    }
  }

  // 创建新候选人
  async createNewCandidate(item, candidateName) {
    try {
      const ageLabelText =
        (
          await this.findElement(this.fullClasses.age, this.selectors.age)(item)
        )?.textContent?.trim() || "";
      let gender = this.extractGenderFromText(ageLabelText);
      if (!gender) {
        gender = this.extractGenderFromRecommendCard(item);
      }

      return {
        name: candidateName,
        gender,
        ageLabelText,
        age: this.extractAge(ageLabelText),
        education:
          (await this.findElement(
            this.fullClasses.education,
            this.selectors.education,
          )(item)?.textContent?.trim()) || "",
        university:
          (await this.findElement(
            this.fullClasses.university,
            this.selectors.university,
          )(item)?.textContent?.trim()) || "",
        description:
          (await this.findElement(
            this.fullClasses.description,
            this.selectors.description,
          )(item)?.textContent?.trim()) || "",
        activeText: await this.getActiveText(item),
        extraInfo: await this.extractExtraInfo(
          item,
          this.selectors.extraSelectors,
        ),
        timestamp: Date.now(),
      };
    } catch (error) {
      console.error("创建新候选人失败:", error);
      return null;
    }
  }

  /** 统一候选人姓名字段（API 缓存用 geekCard.geekName，DOM 兜底用 name） */
  normalizeCandidateName(candidate, fallbackName = "") {
    if (!candidate) return candidate;
    const name =
      candidate.name ||
      candidate.geekCard?.geekName ||
      fallbackName ||
      "未知";
    if (candidate.name !== name) {
      candidate.name = name;
    }
    return candidate;
  }

  async processCandidate(item, candidateName, cachedData) {
    const cachedCandidate = this.findCandidateFromCache(
      cachedData,
      candidateName,
    );
    let candidate = cachedCandidate
      ? this.normalizeCandidateName(cachedCandidate, candidateName)
      : await this.createNewCandidate(item, candidateName);
    if (!candidate) return candidate;

    const detail = this.resolveCandidateGenderDetail(candidate, item);
    candidate.gender = detail.gender;
    candidate.genderSource = detail.source;
    this.logGenderRecognition(candidate);
    return candidate;
  }

  // 获取在线状态文本
  getActiveText(item) {
    try {
      const find = this.findElement(
        this.fullClasses.activeText,
        this.selectors.activeText,
      );
      const activeTextElement = find(item);
      if (!activeTextElement) {
        const findMarker = this.findElement("online-marker", "online-marker");
        const onlineMarker = findMarker(item);
        return onlineMarker ? "在线" : "离线";
      }
      return activeTextElement.textContent?.trim() || "离线";
    } catch (error) {
      console.warn("获取在线状态失败:", error);
      return "离线";
    }
  }

  /**
   * 点击打招呼后验收：按钮是否仍显示「打招呼」
   * @param {Element} element
   */
  confirmGreetClick(element) {
    if (!element) return false;
    const cardText = String(element.textContent || "").replace(/\s+/g, "");
    if (/继续沟通/.test(cardText)) return true;
    if (element.querySelector?.('[class*="btn-continue"]')) return true;

    for (const className of this.selectors.clickTarget || []) {
      const first = String(className || "")
        .trim()
        .split(/\s+/)[0];
      if (!first) continue;
      let nodes = [];
      try {
        nodes = element.querySelectorAll(`[class*="${first}"]`);
      } catch {
        continue;
      }
      for (const node of nodes) {
        const t = String(node.textContent || "").replace(/\s+/g, "");
        if (/打招呼/.test(t) && !/已打招呼/.test(t)) {
          return false;
        }
      }
    }
    return true;
  }

  extractAge(text) {
    if (!text) return 0;
    const matches = text.match(/(\d+)岁/);
    return matches ? parseInt(matches[1]) : 0;
  }

  async clickMatchedItem(element) {
    try {
      await this.waitHumanStep("点击打招呼");
      let clickedAny = false;

      element.dispatchEvent(
        new MouseEvent("mouseover", {
          view: window,
          bubbles: true,
          cancelable: true,
        }),
      );

      for (const className of this.selectors.clickTarget) {
        const nodes = element.querySelectorAll(`[class*="${className}"]`);
        for (const node of nodes) {
          node.click();
          clickedAny = true;
        }
      }

      return clickedAny;
    } catch (error) {
      console.error("点击元素时出错:", error);
      return false;
    }
  }

  // 实现点击候选人详情方法
  async clickCandidateDetail(element) {
    console.log("点击候选人详情:");
    try {
      let detailLink = null;
      //this.detailSelectors.detailLink 是数组
      for (const className of this.detailSelectors.detailLink) {
        let element2 = element.getElementsByClassName(className)[0];
        if (element2) {
          detailLink = element2;
        }
      }

      //console.log(detailLink);
      if (detailLink) {
        detailLink.click();
        // console.log('点击候选人详情成功');
        return true;
      } else {
        console.error("无法查找到详情class:", this.detailSelectors.detailLink);
      }
      return false;
    } catch (error) {
      alert(
        "招聘速聊助手提醒您 插件打招呼失败,请联系作者。错误原因为 找不到打招呼按钮",
      );
      console.error("点击候选人详情失败:", error);
      return false;
    }
  }

  getAllAccessibleDocuments() {
    const docs = new Set();
    const visit = (doc) => {
      if (!doc || docs.has(doc)) return;
      docs.add(doc);
      try {
        for (const frame of doc.querySelectorAll("iframe")) {
          try {
            if (frame.contentDocument) visit(frame.contentDocument);
          } catch (_) {
            /* cross-origin iframe */
          }
        }
      } catch (_) {
        /* ignore */
      }
    };

    visit(document);
    try {
      if (window.top?.document) visit(window.top.document);
    } catch (_) {
      /* ignore */
    }
    try {
      if (window.parent?.document && window.parent !== window) {
        visit(window.parent.document);
      }
    } catch (_) {
      /* ignore */
    }

    return Array.from(docs);
  }

  isElementVisible(el) {
    if (!el) return false;
    const view = el.ownerDocument?.defaultView || window;
    const style = view.getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden") return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  async forceClickElement(el) {
    if (!el) return false;
    if (this.isChatTaskAborted()) return false;
    try {
      await this.waitHumanStep();
      if (this.isChatTaskAborted()) return false;
      el.scrollIntoView?.({ block: "center", inline: "center" });
      const events = ["pointerdown", "mousedown", "pointerup", "mouseup", "click"];
      for (const type of events) {
        el.dispatchEvent(
          new MouseEvent(type, {
            view: el.ownerDocument?.defaultView || window,
            bubbles: true,
            cancelable: true,
          }),
        );
      }
      el.click?.();
      for (const child of el.querySelectorAll("i, svg, use, span, button")) {
        child.click?.();
      }
      return true;
    } catch (error) {
      console.warn("forceClickElement 失败:", error);
      return false;
    }
  }

  async dispatchEscapeKey(doc) {
    try {
      const target = doc.body || doc.documentElement;
      if (!target) return;
      target.dispatchEvent(
        new KeyboardEvent("keydown", {
          key: "Escape",
          code: "Escape",
          keyCode: 27,
          which: 27,
          bubbles: true,
          cancelable: true,
        }),
      );
    } catch (_) {
      /* ignore */
    }
  }

  async clickCloseButtons() {
    const docs = this.getAllAccessibleDocuments();
    const closeSelectors = [
      ".boss-popup__close",
      '[class*="boss-popup__close"]',
      ".resume-custom-close",
      '[class*="resume-custom-close"]',
      '[class*="iboss-close"]',
      '[class^="iboss iboss-close"]',
      ".dialog-close",
      '[class*="dialog-close"]',
      '[class*="icon-close"]',
      ".boss-dialog__close",
      '[class*="close-btn"]',
      'button[aria-label="关闭"]',
      '[class*="sati-times"]',
      '[class*="km-icon"][class*="times"]',
      ".dialog-wrap.active .close",
      ".dialog-wrap.active [class*='close']",
    ];

    let clickedAny = false;

    for (const doc of docs) {
      for (const sel of closeSelectors) {
        for (const el of doc.querySelectorAll(sel)) {
          if (!this.isElementVisible(el)) continue;
          if (await this.forceClickElement(el)) {
            clickedAny = true;
            await new Promise((resolve) => setTimeout(resolve, 200));
          }
        }
      }

      for (const xpath of this.detailSelectors.closeButtonXpath) {
        try {
          const element = doc.evaluate(
            xpath,
            doc,
            null,
            XPathResult.FIRST_ORDERED_NODE_TYPE,
            null,
          ).singleNodeValue;
          if (element && (await this.forceClickElement(element))) {
            clickedAny = true;
            await new Promise((resolve) => setTimeout(resolve, 200));
          }
        } catch (_) {
          /* ignore invalid xpath in this document */
        }
      }

      await this.dispatchEscapeKey(doc);
    }

    return clickedAny;
  }

  /**
   * 仅关闭在线简历面板（收集所有可见关闭钮 + forceClick，并校验是否真正关闭）
   * @param {number} maxRetries
   */
  isResumePanelDismissed(documents) {
    const docs = documents || this.collectAccessibleDocuments(true);
    return !this.isResumePanelBlocking(docs) && !this.isResumePanelVisible(docs);
  }

  async closeResumePanelOnly(maxRetries = 5) {
    // 首次关闭前模拟阅读（短时间重复调用会自动跳过）
    await this.waitResumeReadPause("");

    for (let attempt = 0; attempt < maxRetries; attempt += 1) {
      const documents = this.collectAccessibleDocuments(true);
      if (this.isResumePanelDismissed(documents)) {
        return true;
      }

      const closeTargets = this.collectResumePanelCloseTargets(documents);
      let clicked = false;

      for (const el of closeTargets) {
        if (await this.forceClickElement(el)) {
          clicked = true;
          await new Promise((resolve) => setTimeout(resolve, 350));
          if (this.isResumePanelDismissed(this.collectAccessibleDocuments(true))) {
            return true;
          }
        }
      }

      if (!clicked) {
        for (const doc of this.getAllAccessibleDocuments()) {
          await this.dispatchEscapeKey(doc);
        }
        await new Promise((resolve) => setTimeout(resolve, 400));
        if (this.isResumePanelDismissed(this.collectAccessibleDocuments(true))) {
          return true;
        }

        const resumeBtn = this.findChatResumeViewButton(documents);
        if (resumeBtn && this.isResumePanelBlocking(documents)) {
          await this.gentleClickElement(resumeBtn);
          await new Promise((resolve) => setTimeout(resolve, 600));
          if (this.isResumePanelDismissed(this.collectAccessibleDocuments(true))) {
            return true;
          }
        }
      }

      await new Promise((resolve) => setTimeout(resolve, 500));
    }

    return this.isResumePanelDismissed(this.collectAccessibleDocuments(true));
  }

  // 实现关闭详情方法
  async closeDetail(maxRetries = 6) {
    try {
      if (maxRetries <= 0) {
        console.warn("关闭详情已达到最大重试次数");
        return false;
      }

      await this.clickCloseButtons();
      await new Promise((resolve) => setTimeout(resolve, 600));

      const stillHasModals = this.checkForRemainingModals();
      if (stillHasModals) {
        console.log("检测到还有未关闭的弹框，继续尝试关闭");
        return await this.closeDetail(maxRetries - 1);
      }

      return true;
    } catch (error) {
      console.error("关闭详情失败:", error);
      return false;
    }
  }

  // 检查是否还有未关闭的弹框
  checkForRemainingModals() {
    const modalSelectors = [
      ".boss-popup__close",
      ".resume-custom-close",
      ".dialog-wrap.active",
      '[class*="boss-dialog"]:not([style*="display: none"])',
      ".boss-layer",
      '[class*="dialog-container"]',
      '[class*="resume-dialog"]',
      '[class*="geek-detail-dialog"]',
    ];

    for (const doc of this.getAllAccessibleDocuments()) {
      for (const sel of modalSelectors) {
        for (const el of doc.querySelectorAll(sel)) {
          if (this.isElementVisible(el)) {
            console.log(`发现未关闭的弹框: ${sel}`);
            return true;
          }
        }
      }
    }

    return false;
  }

  //查询同事沟通过候选人的信息
  async queryColleagueContactedInfo(candidate) {
    try {
      //参考boss_resume_downloader.js中的processNextCandidate方法
      for (let i = 0; i <= this.selectors.isContacted.length; i++) {
        let aaa = document.getElementsByClassName(
          this.selectors.isContacted[i],
        );
        if (aaa.length > 0) {
          return aaa[0].textContent.trim();
        } else {
        }
      }
    } catch (error) {
      console.error("查询同事沟通过候选人的信息失败:", error);
    }
  }

  // 获取候选人简单信息（用于AI决策）
  getSimpleCandidateInfo(candidate) {
    if (!candidate) return "候选人信息为空";

    const info = [];
    const gender = this.resolveCandidateGender(candidate);

    // 基本信息
    if (candidate.geekCard) {
      const gc = candidate.geekCard;
      info.push(`姓名: ${gc.geekName || "未知"}`);
      info.push(`性别: ${gender}`);
      info.push(`年龄: ${gc.ageDesc || "未知"}`);
      info.push(`学历: ${gc.geekDegree || "未知"}`);
      info.push(`毕业院校: ${gc.geekEdu?.school || "未知"}`);
      info.push(`专业: ${gc.geekEdu?.major || "未知"}`);
      info.push(`工作年限: ${gc.geekWorkYear || "未知"}`);
      info.push(`当前状态: ${gc.applyStatusDesc || "未知"}`);
      info.push(`期望薪资: ${gc.salary || "未知"}`);
      info.push(`期望职位: ${gc.expectPositionName || "未知"}`);
      info.push(`期望地点: ${gc.expectLocationName || "未知"}`);

      if (gc.geekDesc?.content) {
        info.push(`自我介绍: ${gc.geekDesc.content}`);
      }
    }

    if (!candidate.geekCard) {
      info.push(`姓名: ${candidate.name || "未知"}`);
      info.push(`性别: ${gender}`);
      info.push(`年龄: ${candidate.age || "未知"}`);
      info.push(`学历: ${candidate.education || "未知"}`);
      info.push(`院校: ${candidate.university || "未知"}`);
      if (candidate.description) {
        info.push(`描述: ${candidate.description}`);
      }
    }

    // 工作经历
    if (candidate.geekCard?.geekWorks?.length > 0) {
      info.push("\n工作经历:");
      candidate.geekCard.geekWorks.forEach((work) => {
        info.push(
          `- ${work.company || "未知公司"} · ${work.positionName || "未知职位"}`,
        );
        info.push(`  时间: ${work.startDate} 至 ${work.endDate || "至今"}`);
        info.push(`  职责: ${work.responsibility || "无描述"}`);
        //工作时长 workTime
        info.push(`  工作时长: ${work.workTime || "无描述"}`);
        info.push(`  关键词: ${work.workEmphasisList || "无描述"}`);
      });
    }

    // 教育经历
    if (candidate.geekCard?.geekEdus?.length > 0) {
      info.push("\n教育经历:");
      candidate.geekCard.geekEdus.forEach((edu) => {
        info.push(`- ${edu.school || "未知学校"} · ${edu.major || "未知专业"}`);
        info.push(
          `  学历: ${edu.degreeName || "未知"} (${edu.startDate} 至 ${
            edu.endDate
          })`,
        );
      });
    }

    // 其他信息
    info.push(`\n最后活跃: ${candidate.activeTimeDesc || "未知"}`);
    info.push(`当前日期: ${new Date().toLocaleDateString()}`);

    return info.join("\n");
  }
}

export { BossParser };
