// 招聘速聊助手 配置文件（纯本地版）
const CONFIG = {
  VERSION: "5.3.3",

  /**
   * 过程明细日志（调试用）。true：弹窗显示全部过程。
   * false：只保留已处理 / 已跳过 / 任务结束人数汇总。
   */
  VERBOSE_RUNTIME_LOGS: false,

  /**
   * 操作节奏（打招呼 / 求简历 / 简历回传共用）
   * - step：单个候选人内部各步骤之间
   * - candidate：处理完一个候选人再处理下一个
   * - think：随机「思考停顿」（更长、更稀）
   * - rest：每 N 人强制长休
   * - browse：推荐牛人处理前浏览感
   * - resumeRead：沟通页打开在线简历后模拟阅读
   */
  TIMING: {
    stepDelayMinMs: 500,
    stepDelayMaxMs: 2000,
    candidateGapMinMs: 3000,
    candidateGapMaxMs: 5000,

    thinkPauseMinMs: 2000,
    thinkPauseMaxMs: 6000,
    thinkPauseChance: 0.25,

    restEveryN: 10,
    restMinMs: 45000,
    restMaxMs: 120000,

    browseScrollMinPx: 80,
    browseScrollMaxPx: 220,
    browsePauseMinMs: 800,
    browsePauseMaxMs: 2500,
    /** 从未处理前几张里随机选一张（0~2），避免永远秒点第一张 */
    browsePickAmongFirst: 3,

    resumeReadMinMs: 3000,
    resumeReadMaxMs: 8000,

    /** 打招呼启动时：列表缓存为空则最多等这一次（不是每个人都等） */
    greetCacheWaitMs: 1500,
  },

  /**
   * 窗口不在前台时的打招呼：立即滚动 + 等到读到姓名
   * （Chrome 会暂停平滑动画，不能再依赖 smooth scroll）
   */
  BACKGROUND_GREET: {
    nameWaitTimeoutMs: 4000,
    nameWaitIntervalMs: 250,
    cardRetryMax: 3,
  },

  // 推荐牛人页头部当前岗位文案（一键打招呼一致性校验）
  recommendHeaderPositionXPath:
    '//*[@id="headerWrap"]/div/div/div[2]/div[1]',

  // 推荐牛人页遮挡层/引导节点：存在则优先点击后再打招呼
  // 用户提供：/html/body/div/div/div/div[1]/div/div/div/div/div[2]/span[2]
  recommendPriorityClickXPath:
    "/html/body/div/div/div/div[1]/div/div/div/div/div[2]/span[2]",

  /**
   * 打招呼 / 求简历 文本 AI 匹配
   * 走宣双平台代理：POST /ai_agent/execute_text/（API_EXECUTE_TEXT.md）
   * token 与图片分析共用弹窗「简历回传接口」AccessToken
   */
  EXECUTE_TEXT_API: {
    baseUrl: "https://upims.yili.com",
    path: "/ai_agent/execute_text/",
    token: "",
    timeoutMs: 180000,
  },

  // 兼容旧字段名：逻辑已切到 EXECUTE_TEXT_API，勿再直连上游
  YILI_AI_AGENT: {
    baseUrl: "https://upims.yili.com",
    path: "/ai_agent/execute_text/",
    token: "",
    timeoutMs: 180000,
  },

  // 宣双平台：插件登录（账号来自 UserProfile）
  // baseUrl 可在登录页覆盖，存 chrome.storage.local
  PLUGIN_AUTH: {
    baseUrl: "https://upims.yili.com",
    loginPath: "/plugin_auth/login/",
    mePath: "/plugin_auth/me/",
    logoutPath: "/plugin_auth/logout/",
    positionsPath: "/plugin_auth/positions/",
    // 简历查重 / Base64 上传（见 plugin_auth/API_RESUME.md）
    resumeCheckPath: "/plugin_auth/resumes/check/",
    resumeUploadPath: "/plugin_auth/resumes/upload/",
    timeoutMs: 30000,
    resumeUploadTimeoutMs: 120000,
  },

  // 宣双平台：简历截图拼接后上传分析
  // baseUrl / token 可在插件弹窗覆盖，存 chrome.storage.local
  ANALYZE_IMAGE_API: {
    baseUrl: "https://upims.yili.com",
    path: "/ai_agent/analyze_image/",
    token: "",
    timeoutMs: 180000,
  },

  DEFAULTS: {
    matchLimit: 200,
    scrollDelayMin: 3,
    scrollDelayMax: 5,
    enableSound: true,
    analyzeImageBaseUrl: "https://upims.yili.com",
    analyzeImageToken: "",
  },

  COMMUNICATION_CONFIG: {
    enabled: false,
    collectPhone: false,
    collectWechat: false,
    collectResume: false,
  },

  // 求简历：阶段二/三先只做判断与日志，确认无误后再改为 true
  ASK_RESUME_CONFIG: {
    // AI 匹配时真实点击「求简历」
    enableClick: true,
    // 发求简历话术 / 拒简历相关聊天操作
    enableChatActions: true,
    // 图片分析成功后会自动走简历匹配 AI（与一键打招呼同接口）
    enableAiMatch: true,
    // 调试：强制简历匹配结果为「否」（正式使用请保持 false）
    forceAiDecisionNo: false,
    // 调试：强制简历匹配结果为「是」，便于测求简历（正式使用请保持 false）
    // 若与 forceAiDecisionNo 同时为 true，以「否」优先
    forceAiDecisionYes: false,
    // 阶段三 UI 验证：仅切换会话 + 打开/关闭在线简历；暂不采集保存简历正文
    enableResumeCollect: false,
    // 打开在线简历后自动截图（长简历最多 5 张）
    enableResumeScreenshot: true,
    // 聊天中识别到已有简历时：打开 resume-btn-file → 点下载 → base64（求简历 / 一键简历回传共用）
    enableResumeFileDownload: true,
    // 识别到已有简历后：先抓五要素 → 查重 → 未回传再 upload base64（求简历 / 一键简历回传共用）
    enableResumePlatformUpload: true,
    // 沟通页左侧「当前筛选职位」文案（一键求简历启动时同步到插件岗位选择）
    // 用户提供：//*[@id="container"]/div[1]/div/div[2]/div[2]/div[1]/div[1]/div[1]/div/div[1]/div/div[1]
    chatFilterPositionXPath:
      '//*[@id="container"]/div[1]/div/div[2]/div[2]/div[1]/div[1]/div[1]/div/div[1]/div/div[1]',
    // 沟通页候选人基础信息 XPath（年龄 / 工龄 / 学历）
    chatCandidateAgeXPath:
      "/html/body/div[3]/div[3]/div[1]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]",
    chatCandidateWorkYearsXPath:
      "/html/body/div[3]/div[3]/div[1]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]",
    chatCandidateEducationXPath:
      "/html/body/div[3]/div[3]/div[1]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]",
    // 截获 BOSS 原生下载后取消，不把简历 PDF 落到本机
    cancelNativeDownload: true,
    // 是否再导出一份原文件（PDF 等）到下载夹 —— 本机落盘已关闭
    saveResumeFileToDownloads: false,
    // 把 base64 原文写入下载夹 txt —— 本机落盘已关闭（base64 仍在扩展存储，供上传）
    saveResumeBase64ToTxt: false,
    resumeFileCaptureTimeoutMs: 30000,
    resumeFileExtWhitelist: [
      "pdf",
      "doc",
      "docx",
      "png",
      "jpg",
      "jpeg",
      "html",
      "htm",
      "zip",
      "rar",
    ],
    resumeDownloadButtonText: "下载",
    // 聊天出现「对方想发送附件简历给您，您是否同意」时点同意
    // 用户提供：//*[@id="container"]/div[1]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div/div/div[2]/a[2]
    resumeConsentPromptText: "对方想发送附件简历给您，您是否同意",
    resumeConsentAgreeXPath:
      '//*[@id="container"]/div[1]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div/div/div[2]/a[2]',
    resumeConsentAgreeText: "同意",
    // 打开附件/在线简历：a.btn.resume-btn-file（findChatResumeViewButton 已优先匹配）
    resumeFileOpenButtonSelector: "a.btn.resume-btn-file, .btn.resume-btn-file",
    // 简历弹窗内下载图标（dialog id 动态，用 starts-with 兼容）
    // 用户提供结构：//*[@id="boss-dynamic-dialog-…"]/div[1]/div/div/div/div/div[1]/div/div[1]/div/div/div[3]/span/svg
    resumeFileDownloadSvgXPath:
      '//*[starts-with(@id,"boss-dynamic-dialog")]/div[1]/div/div/div/div/div[1]/div/div[1]/div/div/div[3]/span/svg',
    resumeFileDownloadSpanXPath:
      '//*[starts-with(@id,"boss-dynamic-dialog")]/div[1]/div/div/div/div/div[1]/div/div[1]/div/div/div[3]/span',
    screenshotRenderWaitMs: 1200,
    chatReadyTimeoutMs: 5000,
    // 切换会话最多尝试次数：先轻点再 force，避免同一会话连点 3 次
    sessionSwitchMaxAttempts: 2,
    // 会话间隔已改由 TIMING.candidateGap* 随机 3–5 秒，以下字段仅作兼容兜底
    sessionGapMs: 4000,
    resumeViewGapMs: 15000,
    rateLimitCooldownMs: 90000,
    // 整轮扫描间隔：沿用候选人间节奏量级
    roundGapMs: 4000,
    maxSessionUiAttempts: 3,
    // 文本 AI（execute_text）建议 ≥180s，与 API 文档一致
    aiTimeoutMs: 180000,
    // 沟通页「不合适」按钮与悬停话术节点（BOSS 当前 DOM）
    // 不合适按钮：class=operate-icon-item，文案=不合适
    inappropriateButtonXPath:
      '//*[@id="container"]//*[contains(@class,"operate-icon-item") and contains(normalize-space(.),"不合适")]',
    inappropriateButtonSelector:
      ".operate-icon-item, [class*='operate-icon-item']",
    // 求简历按钮：class=operate-icon-item，文案=求简历
    askResumeButtonSelector:
      ".operate-icon-item, [class*='operate-icon-item']",
    askResumeButtonXPath:
      '//*[@id="container"]//*[contains(@class,"operate-icon-item") and contains(normalize-space(.),"求简历")]',
    // 点击求简历后的确认节点
    askResumeConfirmXPath:
      '//*[@id="container"]/div[1]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div/div/span[2]',
    // 聊天输入框旁「发送」按钮（输入话术后要点击）
    chatSendButtonXPath:
      '//*[@id="container"]/div[1]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[2]/div[2]/div',
    // 悬停气泡容器 class
    inappropriateHoverWrapSelector: ".not-fit-wrap, [class*='not-fit-wrap']",
    inappropriateHoverMessageXPath:
      '//*[@id="container"]//*[contains(@class,"not-fit-wrap")]//p',
    // 仅第一个候选人：打开「修改话术后台」并写入拒简历话术
    // dialog id 动态变化，运行时用 starts-with(@id,"boss-dynamic-dialog") 兼容
    rejectScriptEditEntryXPath:
      '//*[@id="container"]//*[contains(@class,"not-fit-wrap")]//span[2]',
    // 打开后台后：
    // ① 点下拉 .ui-select-inner
    // ② 选「发送统一消息」.ui-select-item
    // ③ 点 .radiov2-item（进入可改话术状态，避免只落在默认第一条）
    // ④ 写入编辑区
    rejectScriptSelectInnerSelector: ".ui-select-inner, [class*='ui-select-inner']",
    rejectScriptSelectItemSelector: ".ui-select-item, [class*='ui-select-item'], li[class*='ui-select-item']",
    rejectScriptSelectItemText: "发送统一消息",
    rejectScriptRadioItemSelector:
      "span.radiov2-item, span[class*='radiov2-item'], .radiov2-item, [class*='radiov2-item']",
    // 必须点文案为「自定义回复语」的 radio，才能进入可改话术
    rejectScriptRadioItemText: "自定义回复语",
    // 话术编辑区：div.boss-chat-editor-input / textarea / input / contenteditable
    rejectScriptTextareaXPath:
      '//*[starts-with(@id,"boss-dynamic-dialog")]//*[contains(@class,"boss-chat-editor-input")] | //*[starts-with(@id,"boss-dynamic-dialog")]//textarea | //*[starts-with(@id,"boss-dynamic-dialog")]//input[not(@type) or @type="text" or @type="search" or @type=""] | //*[starts-with(@id,"boss-dynamic-dialog")]//form//textarea | //*[starts-with(@id,"boss-dynamic-dialog")]//*[@contenteditable="true"]',
    rejectScriptEditorSelector:
      ".boss-chat-editor-input, [class*='boss-chat-editor-input'], textarea, [contenteditable='true']",
    rejectScriptConfirmXPath:
      '//*[starts-with(@id,"boss-dynamic-dialog")]//*[contains(@class,"dialog") or contains(@class,"footer") or self::div][last()]//span[contains(normalize-space(.),"确定") or contains(normalize-space(.),"完成") or contains(normalize-space(.),"保存")] | //*[starts-with(@id,"boss-dynamic-dialog")]//div[3]/span',
  },
};

if (typeof window !== "undefined") {
  window.招聘速聊助手_CONFIG = CONFIG;
}

// Service Worker / importScripts 环境
if (typeof self !== "undefined") {
  self.招聘速聊助手_CONFIG = CONFIG;
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = CONFIG;
}