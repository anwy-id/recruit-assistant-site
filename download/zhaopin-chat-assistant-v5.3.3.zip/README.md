# 招聘速聊助手 — Boss直聘 Chrome 插件

纯前端 Chrome 扩展，帮助 HR 在 Boss 直聘「推荐牛人」页面自动筛选和打招呼。

## 功能

- **关键词筛选**：按包含/排除关键词过滤候选人
- **AI 智能筛选**：使用 [DeepSeek](https://platform.deepseek.com/) API 分析候选人是否匹配岗位
- **API 数据增强**：拦截 Boss 接口，获取较完整的候选人信息（工作经历、教育经历等）
- **简历下载**（可选）：批量模拟点击下载简历文件

## 安装

1. 打开 Chrome → `chrome://extensions`
2. 开启「开发者模式」
3. 点击「加载已解压的扩展程序」，选择本项目根目录

## 使用

1. 打开 [Boss 直聘推荐牛人](https://www.zhipin.com/web/chat/recommend)
2. 点击扩展图标，配置岗位和筛选条件
3. **AI 模式**：在 [DeepSeek 开放平台](https://platform.deepseek.com/) 申请 API Key 并填入设置
4. 点击「开始」

所有配置保存在本机浏览器（`chrome.storage.local`），不依赖任何第三方商业服务器。

## 目录结构

```
manifest.json          # 扩展清单
background.js          # 后台 Service Worker（DeepSeek 请求）
config.js              # 默认配置
popup/                 # 设置弹窗
content_scripts/       # 页面自动化逻辑
  index.js             # 主循环
  sites/boss.js        # Boss 解析器
  sites/boss_interceptor.js
icons/
sounds/
```

## 版本

4.0.0 — 移除商业后端依赖，改为 DeepSeek 直连

## 许可

Apache License 2.0