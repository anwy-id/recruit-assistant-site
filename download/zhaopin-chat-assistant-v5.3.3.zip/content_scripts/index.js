let currentParser = null;
let scrollInterval = null;
let lastProcessedPosition = 0;
let isRunning = false;
/** 打招呼循环代数：停止时 +1，进行中的 async 链发现代数变化即退出 */
let greetLoopToken = 0;
/** 打招呼循环 owner（多 frame 只跑一条链） */
let greetOwnerId = null;
const GREET_OWNER_KEY = "招聘速聊助手_greet_owner";
let isAskResumeRunning = false;
let askResumeLoopToken = 0;
let askResumeOwnerId = null;
const ASK_RESUME_OWNER_KEY = "招聘速聊助手_ask_resume_owner";
/** 一键简历回传（独立任务，与求简历互斥） */
let isResumeUploadRunning = false;
let resumeUploadLoopToken = 0;
let resumeUploadOwnerId = null;
const RESUME_UPLOAD_OWNER_KEY = "招聘速聊助手_resume_upload_owner";
let currentDelay = 3000;
let matchLimit = 0;
let scrollDelayMin = 3000;
let scrollDelayMax = 6000;
let port = null;
let matchCount = 0;
let currentPrompt = null;

let enableSound = false;

let ParserName = null;

/** 本轮打招呼是否已点过引导层（只允许一次） */
let greetPriorityClicked = false;
/** 已处理过的候选人姓名，避免坐标漂移后重复处理 */
const processedGreetNames = new Set();
/** 最近一次是否处于后台模式（用于日志去重） */
let lastBackgroundMode = null;
/** 本轮求简历成功次数（状态日志） */
let askResumeCount = 0;
/** 本轮回传成功次数（状态日志） */
let resumeUploadCount = 0;
/** 本轮各任务跳过次数（结束汇总用） */
let greetSkipCount = 0;
let askResumeSkipCount = 0;
let resumeUploadSkipCount = 0;

/** 三个任务只保留：已处理 / 已跳过 / 结束人数汇总 */
function isStatusRuntimeLog(message) {
  const t = String(message || "")
    .replace(/<[^>]+>/g, "")
    .trim();
  return (
    /^已处理/.test(t) ||
    /^已跳过/.test(t) ||
    /^成功打招呼/.test(t) ||
    /^成功求简历/.test(t) ||
    /^成功简历回传/.test(t) ||
    /^日志已清空/.test(t)
  );
}

function displayCandidateName(value) {
  const n = String(value || "")
    .replace(/<[^>]+>/g, "")
    .trim();
  return n || "未知";
}

function logReached(name) {
  sendMessage({
    type: "LOG_MESSAGE",
    data: { message: `已处理${displayCandidateName(name)}`, type: "success" },
  });
}

function logSkipped(name) {
  if (isResumeUploadRunning) resumeUploadSkipCount += 1;
  else if (isAskResumeRunning) askResumeSkipCount += 1;
  else if (isRunning) greetSkipCount += 1;
  sendMessage({
    type: "LOG_MESSAGE",
    data: { message: `已跳过${displayCandidateName(name)}`, type: "info" },
  });
}

function isAskResumeReachedStatus(status) {
  return (
    status === "asked" ||
    status === "ready_to_ask" ||
    status === "rejected" ||
    status === "ready_to_reject" ||
    status === "info_saved" ||
    status === "resume_ui_done"
  );
}

function isAskResumeSkippedStatus(status) {
  return (
    status === "skip_sent" ||
    status === "skip_done" ||
    status === "skip_initiator" ||
    status === "skip_no_resume" ||
    status === "ai_error"
  );
}

function isResumeUploadReachedStatus(status) {
  return status === "info_saved" || status === "resume_ui_done";
}

function isResumeUploadSkippedStatus(status) {
  return status === "skip_done" || status === "skip_no_resume";
}

/** 打招呼任务是否应继续（含代数校验，避免停后旧链复活） */
function shouldContinueGreet(token) {
  return isRunning && token === greetLoopToken;
}

/** 求简历任务是否应继续 */
function shouldContinueAskResume(token) {
  return isAskResumeRunning && token === askResumeLoopToken;
}

/** 一键简历回传是否应继续 */
function shouldContinueResumeUpload(token) {
  return isResumeUploadRunning && token === resumeUploadLoopToken;
}

/** 求简历进度日志去重（防多 frame / 重入导致「本轮汇总」刷多条） */
let lastAskResumeProgressLog = { key: "", at: 0 };
/** 简历回传进度日志去重 */
let lastResumeUploadProgressLog = { key: "", at: 0 };

/**
 * 仅循环 owner 输出进度类日志，并做短时去重
 * @param {string} message
 * @param {string} [type]
 * @param {number} [dedupeMs]
 */
function logAskResumeProgress(message, type = "info", dedupeMs = 2500) {
  // 只有真正跑循环的 frame 才记进度（含本轮汇总）
  if (!askResumeOwnerId || !isAskResumeRunning) return;

  const key = `${type}::${message}`;
  const now = Date.now();
  if (
    lastAskResumeProgressLog.key === key &&
    now - lastAskResumeProgressLog.at < dedupeMs
  ) {
    return;
  }
  lastAskResumeProgressLog = { key, at: now };

  sendMessage({
    type: "LOG_MESSAGE",
    data: { message, type },
  });
}

/**
 * 简历回传 owner 进度日志
 * @param {string} message
 * @param {string} [type]
 * @param {number} [dedupeMs]
 */
function logResumeUploadProgress(message, type = "info", dedupeMs = 2500) {
  if (!resumeUploadOwnerId || !isResumeUploadRunning) return;

  const key = `${type}::${message}`;
  const now = Date.now();
  if (
    lastResumeUploadProgressLog.key === key &&
    now - lastResumeUploadProgressLog.at < dedupeMs
  ) {
    return;
  }
  lastResumeUploadProgressLog = { key, at: now };

  sendMessage({
    type: "LOG_MESSAGE",
    data: { message, type },
  });
}

function resolveMatchLimit(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 200;
  const i = Math.floor(n);
  if (i < 1 || i > 200) return 200;
  return i;
}

function syncMatchLimitFromSettings() {
  if (!currentParser) return;
  matchLimit = resolveMatchLimit(currentParser.aiSettings?.matchLimit);
}

// 显示提示信息
function showNotification(message, type = "status") {
  if (!isExtensionValid()) {
    console.warn("扩展上下文已失效，无法发送通知");
    return;
  }

  const notification = document.createElement("div");

  // 基础样式
  let baseStyle = `
        position: fixed;
        padding: 12px 20px;
        background: rgba(51, 51, 51, 0.9);
        color: white;
        border-radius: 6px;
        z-index: 9999;
        font-size: 14px;
        box-shadow: 0 2px 12px rgba(0,0,0,0.2);
        pointer-events: none;
    `;

  // 根据类型设置不同的位置样式
  if (type === "status") {
    baseStyle += `
            left: 50%;
            top: 20px;
            transform: translateX(-50%);
        `;
  } else {
    baseStyle += `
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
        `;
  }

  notification.style.cssText = baseStyle;
  notification.textContent = message;
  document.body.appendChild(notification);

  setTimeout(() => {
    notification.remove();
  }, 1500);
}

/** 最近一次解析器初始化失败原因（便于弹窗展示） */
let lastParserInitError = "";

/**
 * 根据当前网站 URL 初始化 Boss 解析器
 * @param {{ force?: boolean }} [options]
 * @returns {Promise<{ ok: boolean, error?: string }>}
 */
async function initializeParser(options = {}) {
  const force = options.force === true;

  if (currentParser && !force) {
    return { ok: true };
  }

  lastParserInitError = "";

  try {
    if (!isExtensionValid()) {
      lastParserInitError = "扩展上下文已失效，请刷新页面后重试";
      currentParser = null;
      return { ok: false, error: lastParserInitError };
    }

    let url = "";
    try {
      url = window.location.href || "";
    } catch {
      url = "";
    }
    // iframe 可能拿不到完整 href，尝试 top
    if (!url || url === "about:blank") {
      try {
        url = window.top?.location?.href || url;
      } catch {
        /* ignore */
      }
    }

    if (!/zhipin\.com/i.test(url) && !/zhipin\.com/i.test(String(location?.hostname || ""))) {
      lastParserInitError = "当前不在 Boss 直聘页面";
      currentParser = null;
      return { ok: false, error: lastParserInitError };
    }

    ParserName = "boss";
    const version =
      (chrome.runtime.getManifest && chrome.runtime.getManifest()?.version) ||
      "0";
    const moduleUrl =
      chrome.runtime.getURL("content_scripts/sites/boss.js") +
      `?v=${encodeURIComponent(version)}`;

    let BossParserCtor = null;
    let importError = null;
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        const mod = await import(moduleUrl);
        BossParserCtor = mod?.BossParser || mod?.default || null;
        if (BossParserCtor) break;
        importError = new Error("模块未导出 BossParser");
      } catch (err) {
        importError = err;
        console.warn(
          `[招聘速聊助手] 加载 BossParser 失败 (第 ${attempt}/3 次):`,
          err,
        );
        await new Promise((r) => setTimeout(r, 200 * attempt));
      }
    }

    if (!BossParserCtor) {
      lastParserInitError =
        importError?.message ||
        String(importError || "动态加载 boss.js 失败");
      currentParser = null;
      console.error("初始化解析器失败:", lastParserInitError);
      return { ok: false, error: lastParserInitError };
    }

    currentParser = new BossParserCtor();
    currentParser.aiMode = true;
    await currentParser.loadSettings();
    console.log("[招聘速聊助手] 解析器初始化完成", {
      href: url,
      frame: isTopFrame() ? "top" : "iframe",
    });
    lastParserInitError = "";
    return { ok: true };
  } catch (error) {
    lastParserInitError = error?.message || String(error);
    console.error("初始化解析器失败:", error);
    try {
      showNotification("⚠️ 初始化解析器失败: " + lastParserInitError, "status");
    } catch {
      /* ignore */
    }
    currentParser = null;
    return { ok: false, error: lastParserInitError };
  }
}

/** 确保解析器可用；失败时返回错误文案 */
async function ensureParserReady() {
  if (currentParser) return { ok: true };
  const result = await initializeParser();
  if (currentParser) return { ok: true };
  return {
    ok: false,
    error:
      result?.error ||
      lastParserInitError ||
      "解析器未初始化，请刷新 Boss 页面后重试",
  };
}

/** 各任务已处理人数（用于每 N 人长休） */
let greetHumanCount = 0;
let askResumeHumanCount = 0;
let resumeUploadHumanCount = 0;

/**
 * 读取 TIMING 配置（毫秒）
 * @param {"step"|"candidate"|"think"|"rest"|"browsePause"|"resumeRead"} kind
 */
function getHumanTimingRange(kind) {
  const t = window.招聘速聊助手_CONFIG?.TIMING || {};
  const pick = (minKey, maxKey, dMin, dMax) => {
    const min = Number(t[minKey]);
    const max = Number(t[maxKey]);
    return {
      minMs: Number.isFinite(min) && min > 0 ? min : dMin,
      maxMs: Number.isFinite(max) && max > 0 ? max : dMax,
    };
  };
  if (kind === "step") return pick("stepDelayMinMs", "stepDelayMaxMs", 500, 2000);
  if (kind === "think") return pick("thinkPauseMinMs", "thinkPauseMaxMs", 2000, 6000);
  if (kind === "rest") return pick("restMinMs", "restMaxMs", 45000, 120000);
  if (kind === "browsePause")
    return pick("browsePauseMinMs", "browsePauseMaxMs", 800, 2500);
  if (kind === "resumeRead")
    return pick("resumeReadMinMs", "resumeReadMaxMs", 3000, 8000);
  return pick("candidateGapMinMs", "candidateGapMaxMs", 3000, 5000);
}

/** @param {number} minMs @param {number} maxMs */
function randomBetweenMs(minMs, maxMs) {
  const lo = Math.min(minMs, maxMs);
  const hi = Math.max(minMs, maxMs);
  return lo + Math.floor(Math.random() * (hi - lo + 1));
}

function isPageInBackground() {
  try {
    if (document.hidden || document.visibilityState === "hidden") return true;
    if (typeof document.hasFocus === "function" && !document.hasFocus()) {
      return true;
    }
  } catch {
    /* ignore */
  }
  return false;
}

function logBackgroundModeIfChanged() {
  if (!isRunning) return;
  const bg = isPageInBackground();
  if (lastBackgroundMode === bg) return;
  lastBackgroundMode = bg;
  sendMessage({
    type: "LOG_MESSAGE",
    data: {
      message: bg
        ? "窗口不在前台，已切换为立即滚动"
        : "窗口回到前台，已恢复平滑滚动",
      type: "info",
    },
  });
}

function getGreetBackgroundConfig() {
  return window.招聘速聊助手_CONFIG?.BACKGROUND_GREET || {};
}

function readCardName(element) {
  if (!element) return "";
  try {
    const exact = element.getElementsByClassName?.("name")?.[0];
    const text = exact?.textContent?.replace(/\s+/g, " ").trim();
    if (text) return text.slice(0, 40);
    const fuzzy = element.querySelector?.('[class*="name"]');
    const fuzzyText = fuzzy?.textContent?.replace(/\s+/g, " ").trim();
    if (fuzzyText) return fuzzyText.slice(0, 40);
  } catch {
    /* ignore */
  }
  return "";
}

function markGreetCardConsumed(element, name) {
  const n = String(name || readCardName(element) || "").trim();
  if (n) processedGreetNames.add(n);
  try {
    const rect = element?.getBoundingClientRect?.();
    if (!rect) return;
    const y =
      rect.top +
      rect.height +
      (typeof window.pageYOffset === "number" ? window.pageYOffset : 0);
    if (Number.isFinite(y) && y > lastProcessedPosition) {
      lastProcessedPosition = y;
    }
  } catch {
    /* ignore */
  }
}

function forceLayout(element) {
  try {
    if (element && "offsetHeight" in element) {
      void element.offsetHeight;
      return;
    }
    void document.body?.offsetHeight;
  } catch {
    /* ignore */
  }
}

/**
 * 把卡片滚入视口并等到能读到姓名。
 * 后台窗口用立即滚动（smooth 会被 Chrome 暂停）。
 */
async function scrollCardIntoPlace(element, shouldContinue) {
  if (!element) return { ok: false, name: "" };
  logBackgroundModeIfChanged();
  const behavior = isPageInBackground() ? "auto" : "smooth";
  try {
    element.scrollIntoView({
      behavior,
      block: "center",
      inline: "nearest",
    });
  } catch {
    try {
      const rect = element.getBoundingClientRect();
      const top = Math.max(0, rect.top + (window.pageYOffset || 0) - 100);
      window.scrollTo(0, top);
    } catch {
      /* ignore */
    }
  }
  forceLayout(element);

  const cfg = getGreetBackgroundConfig();
  const timeoutMs =
    Number(cfg.nameWaitTimeoutMs) > 0 ? Number(cfg.nameWaitTimeoutMs) : 4000;
  const intervalMs =
    Number(cfg.nameWaitIntervalMs) > 0 ? Number(cfg.nameWaitIntervalMs) : 250;
  const started = Date.now();
  let name = readCardName(element);
  while (!name && Date.now() - started < timeoutMs) {
    if (typeof shouldContinue === "function" && !shouldContinue()) {
      return { ok: false, name: "", aborted: true };
    }
    await new Promise((r) => setTimeout(r, intervalMs));
    try {
      element.scrollIntoView({
        behavior: "auto",
        block: "center",
        inline: "nearest",
      });
    } catch {
      /* ignore */
    }
    forceLayout(element);
    name = readCardName(element);
  }
  return { ok: !!name, name };
}

function setTabKeepAlive(keep) {
  try {
    chrome.runtime.sendMessage(
      { action: "SET_TAB_KEEP_ALIVE", keep: !!keep },
      () => {
        void chrome.runtime.lastError;
      },
    );
  } catch {
    /* ignore */
  }
}

/**
 * 单个候选人内部：步骤间隔 0.5–2 秒随机
 * @param {string} [label]
 */
async function humanStepDelay(label = "") {
  const { minMs, maxMs } = getHumanTimingRange("step");
  const delayMs = randomBetweenMs(minMs, maxMs);
  // const sec = (delayMs / 1000).toFixed(1);
  // if (label) {
  //   sendMessage({
  //     type: "LOG_MESSAGE",
  //     data: {
  //       message: `步骤间隔 ${sec} 秒${label ? `（${label}）` : ""}`,
  //       type: "info",
  //     },
  //   });
  // }
  void label;
  await new Promise((resolve) => setTimeout(resolve, delayMs));
}

/**
 * 换下一个候选人：间隔 3–5 秒随机
 * @param {string} [label]
 */
async function humanCandidateGap(label = "") {
  const { minMs, maxMs } = getHumanTimingRange("candidate");
  const delayMs = randomBetweenMs(minMs, maxMs);
  // const sec = (delayMs / 1000).toFixed(1);
  // sendMessage({
  //   type: "LOG_MESSAGE",
  //   data: {
  //     message: `候选人间隔 ${sec} 秒${label ? `（${label}）` : ""}`,
  //     type: "info",
  //   },
  // });
  void label;
  await new Promise((resolve) => setTimeout(resolve, delayMs));
}

/**
 * 滑动到指定候选人卡片，确保其在屏幕可见（视觉反馈）
 * 用于打招呼时让被打招呼的人出现在屏幕上，匹配「控制侧边滚动条向下滚动」需求
 */
async function scrollToCandidate(element, doc) {
  void doc;
  if (!element) return;
  const place = await scrollCardIntoPlace(element, () =>
    shouldContinueGreet(greetLoopToken),
  );
  if (place.aborted) return;
  if (!isPageInBackground()) {
    await humanStepDelay("滑动到候选人卡片");
  }
}

/**
 * 向下滚动加载新的候选人批次
 * 在分析完当前批次候选人后调用，触发页面加载更多卡片，匹配「当开始检测到的所有候选人都已经分析完后，向下滚动到加载出新的候选人，再进行分析」
 */
async function scrollToNextBatch() {
  console.log("[scrollToNextBatch] 开始滚动加载新批次");
  try {
    const scrollAmount = window.innerHeight * 0.8; // 向下滚动约80% 高度加载新批次
    window.scrollBy({
      top: scrollAmount,
      behavior: 'smooth'
    });
    await new Promise(r => setTimeout(r, 2000)); // 等待页面加载新卡片
    // 额外检查是否加载到新卡片
    if (currentParser) {
      await currentParser.loadSettings();
    }
    await humanCandidateGap("加载新候选人批次，继续分析");
  } catch (e) {
    console.warn("[scrollToNextBatch] 滚动加载失败:", e.message);
  }
}

/**
 * 思考停顿：2–6 秒随机（模拟看一眼再决定）
 * @param {string} [label]
 */
async function humanThinkPause(label = "") {
  const { minMs, maxMs } = getHumanTimingRange("think");
  const delayMs = randomBetweenMs(minMs, maxMs);
  // sendMessage({
  //   type: "LOG_MESSAGE",
  //   data: {
  //     message: `思考停顿 ${(delayMs / 1000).toFixed(1)} 秒${label ? `（${label}）` : ""}`,
  //     type: "info",
  //   },
  // });
  void label;
  await new Promise((resolve) => setTimeout(resolve, delayMs));
}

/**
 * 按概率插入思考停顿
 * @param {string} [label]
 * @param {number} [chanceOverride]
 */
async function maybeHumanThinkPause(label = "", chanceOverride) {
  const t = window.招聘速聊助手_CONFIG?.TIMING || {};
  let chance = Number(chanceOverride);
  if (!Number.isFinite(chance)) {
    chance = Number(t.thinkPauseChance);
  }
  if (!Number.isFinite(chance)) chance = 0.25;
  if (Math.random() >= chance) return false;
  await humanThinkPause(label);
  return true;
}

/**
 * 分段等待，便于停止时尽快响应
 * @param {number} totalMs
 * @param {() => boolean} shouldContinue
 */
async function interruptibleSleep(totalMs, shouldContinue) {
  const end = Date.now() + Math.max(0, totalMs);
  while (Date.now() < end) {
    if (typeof shouldContinue === "function" && !shouldContinue()) return false;
    await new Promise((r) =>
      setTimeout(r, Math.min(300, Math.max(0, end - Date.now()))),
    );
  }
  return true;
}

/**
 * 每 N 人强制长休
 * @param {"greet"|"ask"|"upload"} task
 * @param {() => boolean} shouldContinue
 */
async function forcedRestIfNeeded(task, shouldContinue) {
  const t = window.招聘速聊助手_CONFIG?.TIMING || {};
  const everyN = Number(t.restEveryN);
  const n = Number.isFinite(everyN) && everyN > 0 ? everyN : 10;

  let count = 0;
  if (task === "greet") {
    greetHumanCount += 1;
    count = greetHumanCount;
  } else if (task === "ask") {
    askResumeHumanCount += 1;
    count = askResumeHumanCount;
  } else {
    resumeUploadHumanCount += 1;
    count = resumeUploadHumanCount;
  }

  if (count <= 0 || count % n !== 0) return false;

  const { minMs, maxMs } = getHumanTimingRange("rest");
  const delayMs = randomBetweenMs(minMs, maxMs);
  // const sec = Math.round(delayMs / 1000);
  // sendMessage({
  //   type: "LOG_MESSAGE",
  //   data: {
  //     message: `已处理 ${count} 人，休息 ${sec} 秒`,
  //     type: "warning",
  //   },
  // });
  await interruptibleSleep(delayMs, shouldContinue);
  return true;
}

/**
 * 推荐牛人：处理前随机小幅滚动 + 停顿（浏览感）
 * @param {() => boolean} [shouldContinue]
 */
async function browseBeforeProcessCard(shouldContinue) {
  if (isPageInBackground()) return;
  const t = window.招聘速聊助手_CONFIG?.TIMING || {};
  const minPx = Number(t.browseScrollMinPx);
  const maxPx = Number(t.browseScrollMaxPx);
  const lo = Number.isFinite(minPx) ? minPx : 80;
  const hi = Number.isFinite(maxPx) ? maxPx : 220;
  const delta =
    randomBetweenMs(Math.abs(lo), Math.abs(hi)) *
    (Math.random() < 0.2 ? -1 : 1);

  window.scrollBy({ top: delta, behavior: "smooth" });
  const { minMs, maxMs } = getHumanTimingRange("browsePause");
  const pauseMs = randomBetweenMs(minMs, maxMs);
  if (typeof shouldContinue === "function" && !shouldContinue()) return;
  await interruptibleSleep(pauseMs, shouldContinue || (() => true));
}

// 兼容旧调用：默认按「候选人间隔 3–5 秒」；步骤请用 humanStepDelay
function randomDelay(message2 = "无") {
  return humanCandidateGap(message2 === "无" ? "" : message2);
}

// 递归收集当前页及所有嵌套 iframe 的 document（从顶层窗口出发）
function getAllDocuments() {
  const documents = [];
  const visited = new Set();

  function walk(doc) {
    if (!doc || visited.has(doc)) return;
    visited.add(doc);
    documents.push(doc);

    const iframes = doc.querySelectorAll("iframe");
    for (const frame of iframes) {
      try {
        if (frame.contentDocument) {
          walk(frame.contentDocument);
        }
      } catch (error) {
        console.warn("无法访问 iframe:", error);
      }
    }
  }

  try {
    walk(window.top.document);
  } catch (error) {
    console.warn("无法访问顶层 document:", error);
  }

  if (!visited.has(document)) {
    walk(document);
  }

  return documents;
}

async function claimGreetLoopOwner() {
  await new Promise((resolve) =>
    setTimeout(resolve, 50 + Math.floor(Math.random() * 200)),
  );

  const stored = await chrome.storage.local.get([GREET_OWNER_KEY]);
  const existing = stored[GREET_OWNER_KEY];
  if (existing?.id && Date.now() - (existing.at || 0) < 60000) {
    return false;
  }

  const myId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  await chrome.storage.local.set({
    [GREET_OWNER_KEY]: {
      id: myId,
      at: Date.now(),
      href: String(window.location.href || "").slice(0, 200),
    },
  });

  await new Promise((resolve) => setTimeout(resolve, 220));
  const check = await chrome.storage.local.get([GREET_OWNER_KEY]);
  if (check[GREET_OWNER_KEY]?.id !== myId) {
    return false;
  }

  greetOwnerId = myId;
  return true;
}

async function refreshGreetLoopOwner() {
  if (!greetOwnerId || !isRunning) return false;
  const stored = await chrome.storage.local.get([GREET_OWNER_KEY]);
  if (stored[GREET_OWNER_KEY]?.id !== greetOwnerId) {
    return false;
  }
  await chrome.storage.local.set({
    [GREET_OWNER_KEY]: {
      ...stored[GREET_OWNER_KEY],
      at: Date.now(),
    },
  });
  return true;
}

function releaseGreetLoopOwner() {
  if (!greetOwnerId) return;
  const myId = greetOwnerId;
  greetOwnerId = null;
  chrome.storage.local.get([GREET_OWNER_KEY], (stored) => {
    if (stored[GREET_OWNER_KEY]?.id === myId) {
      chrome.storage.local.remove([GREET_OWNER_KEY]);
    }
  });
}

// 修改自动滚动功能（多 frame 仅 owner 跑一条链）
async function startAutoScroll() {
  if (isRunning) {
    return { status: "success", message: "打招呼任务已在运行" };
  }
  if (isAskResumeRunning || isResumeUploadRunning) {
    const msg = isAskResumeRunning
      ? "请先停止求简历再开始打招呼"
      : "请先停止简历回传再开始打招呼";
    if (isTopFrame()) {
      sendMessage({
        type: "LOG_MESSAGE",
        data: { message: msg, type: "warning" },
      });
    }
    return { status: "error", message: msg };
  }

  // 无解析器的子 frame 不参与抢 owner
  if (!currentParser) {
    return { status: "ignored" };
  }

  if (!(await claimGreetLoopOwner())) {
    return { status: "ignored" };
  }

  try {
    isRunning = true;
    greetLoopToken += 1;
    const loopToken = greetLoopToken;
    lastProcessedPosition = -1;
    matchCount = 0;
    greetSkipCount = 0;
    greetHumanCount = 0;
    greetPriorityClicked = false;
    processedGreetNames.clear();
    lastBackgroundMode = null;
    setTabKeepAlive(true);
    logBackgroundModeIfChanged();

    syncMatchLimitFromSettings();
    scrollDelayMin = currentParser?.aiSettings?.scrollDelayMin || 3;
    scrollDelayMax = currentParser?.aiSettings?.scrollDelayMax || 5;

    try {
      chrome.storage.local.set({ isRunning: true });
    } catch {
      /* ignore */
    }

    window.scrollTo(0, 0);

    // 有遮挡/引导节点时优先点击，再开始扫卡片
    if (shouldContinueGreet(loopToken)) {
      await clickRecommendPriorityElementIfPresent();
    }
    if (!shouldContinueGreet(loopToken)) {
      releaseGreetLoopOwner();
      setTabKeepAlive(false);
      return { status: "stopped" };
    }

    if (shouldContinueGreet(loopToken)) {
      await waitForGreetCandidateCache(() => shouldContinueGreet(loopToken));
    }
    if (!shouldContinueGreet(loopToken)) {
      releaseGreetLoopOwner();
      setTabKeepAlive(false);
      return { status: "stopped" };
    }

    sendMessage({
      type: "LOG_MESSAGE",
      data: {
        message: `开始滚动，匹配上限: ${matchLimit}`,
        type: "info",
      },
    });

    executeScroll(loopToken);
    showNotification("开始自动滚动", "status");
    return { status: "success" };
  } catch (error) {
    isRunning = false;
    releaseGreetLoopOwner();
    setTabKeepAlive(false);
    console.error("启动失败:", error);
    if (isTopFrame()) {
      showNotification("⚠️ " + error.message, "status");
    }
    return { status: "error", message: error.message || String(error) };
  }
}

/**
 * 打招呼启动时：若推荐列表接口尚未写入缓存，最多短等一次。
 * 已有列表则立即返回；超时后仍继续，改走卡片图标/文字。
 * @param {() => boolean} [shouldContinue]
 */
async function waitForGreetCandidateCache(shouldContinue) {
  const maxMs = Number(window.招聘速聊助手_CONFIG?.TIMING?.greetCacheWaitMs);
  const timeoutMs = Number.isFinite(maxMs) && maxMs > 0 ? maxMs : 1500;
  if (!currentParser?.getCachedCandidateData) return;

  const hasList = (list) => Array.isArray(list) && list.length > 0;
  try {
    const first = await currentParser.getCachedCandidateData(true);
    if (hasList(first)) return;
  } catch {
    return;
  }

  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    if (typeof shouldContinue === "function" && !shouldContinue()) return;
    await new Promise((r) => setTimeout(r, 200));
    try {
      const list = await currentParser.getCachedCandidateData(true);
      if (hasList(list)) return;
    } catch {
      return;
    }
  }
}

/** 将 "a b" / "a" 转为合法 class 选择器 ".a.b" / ".a" */
function toClassSelector(className) {
  const parts = String(className || "")
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  if (!parts.length) return null;
  return "." + parts.join(".");
}

/** 规范化 items 配置为字符串数组 */
function normalizeItemClassList(items) {
  if (Array.isArray(items)) {
    return items.map((x) => String(x || "").trim()).filter(Boolean);
  }
  if (typeof items === "string" && items.trim()) {
    return [items.trim()];
  }
  return [];
}

/**
 * 在 document 中收集候选人卡片（支持多个 class 配置）
 * 旧代码用 typeof === "array"（永远为 false）+ 直接拼接数组，导致几乎找不到卡片
 */
function collectCandidateCardElements(doc, itemsConfig) {
  const found = [];
  const seen = new Set();
  const itemList = normalizeItemClassList(itemsConfig);

  const pushAll = (nodes) => {
    for (const el of nodes) {
      if (el && !seen.has(el)) {
        seen.add(el);
        found.push(el);
      }
    }
  };

  for (const item of itemList) {
    const classSelector = toClassSelector(item);
    if (classSelector) {
      try {
        pushAll(doc.querySelectorAll(classSelector));
      } catch (error) {
        console.warn("候选人选择器无效:", classSelector, error);
      }
    }

    // 宽松匹配：取第一个 class 片段做 contains（兼容动态 hash class）
    const firstToken = item.split(/\s+/)[0];
    if (firstToken) {
      try {
        pushAll(doc.querySelectorAll(`[class*="${firstToken}"]`));
      } catch (error) {
        console.warn("宽松选择器无效:", firstToken, error);
      }
    }
  }

  return found;
}

/** 从当前节点向上找到卡片根节点 */
function findCandidateCardRoot(element, itemsConfig) {
  if (!element || !element.closest) return null;
  const itemList = normalizeItemClassList(itemsConfig);

  for (const item of itemList) {
    const classSelector = toClassSelector(item);
    if (!classSelector) continue;
    try {
      const root = element.closest(classSelector);
      if (root) return root;
    } catch (_) {
      /* ignore */
    }
  }

  for (const item of itemList) {
    const firstToken = item.split(/\s+/)[0];
    if (!firstToken) continue;
    try {
      const root = element.closest(`[class*="${firstToken}"]`);
      if (root) return root;
    } catch (_) {
      /* ignore */
    }
  }

  return element;
}

// 将滚动逻辑提取为单独的函数
async function executeScroll(loopToken = greetLoopToken) {
  if (!shouldContinueGreet(loopToken) || !currentParser) {
    if (scrollInterval) {
      clearInterval(scrollInterval);
      scrollInterval = null;
    }
    if (loopToken === greetLoopToken) {
      isRunning = false;
    }
    return;
  }

  try {
    // 与 storage 对齐：用户点停止后即使消息丢了也能在下一轮停
    try {
      const st = await chrome.storage.local.get(["isRunning"]);
      if (st.isRunning === false && isRunning) {
        stopAutoScroll("已停止自动滚动", { silent: true });
        return;
      }
    } catch {
      /* ignore */
    }

    if (!shouldContinueGreet(loopToken)) return;

    // 多 frame：仅 owner 继续；丢 owner 则静默退出
    if (!(await refreshGreetLoopOwner())) {
      isRunning = false;
      return;
    }
    if (!shouldContinueGreet(loopToken)) return;

    // 引导层只尝试一次，避免每轮点击常驻节点把滚动拽走
    if (!greetPriorityClicked) {
      await clickRecommendPriorityElementIfPresent();
    }
    if (!shouldContinueGreet(loopToken)) return;

    await currentParser.loadSettings();
    if (!shouldContinueGreet(loopToken)) return;

    const documents = getAllDocuments();
    let totalFound = 0;

    for (const doc of documents) {
      if (!shouldContinueGreet(loopToken)) return;

      const elements = collectCandidateCardElements(
        doc,
        currentParser.selectors?.items,
      );
      totalFound += elements.length;

      const unprocessedElements = elements.filter((el) => {
        const name = readCardName(el);
        if (name && processedGreetNames.has(name)) return false;
        const rect = el.getBoundingClientRect();
        const pageY =
          doc === document
            ? window.pageYOffset
            : doc.defaultView?.pageYOffset || 0;
        const absoluteTop = rect.top + pageY;
        return absoluteTop > lastProcessedPosition;
      });

      if (unprocessedElements.length > 0) {
        // 从未处理前几张里随机选一张，避免永远秒点第一张
        const tCfg = window.招聘速聊助手_CONFIG?.TIMING || {};
        let among = Number(tCfg.browsePickAmongFirst);
        if (!Number.isFinite(among) || among < 1) among = 3;
        const pickPool = unprocessedElements.slice(
          0,
          Math.min(among, unprocessedElements.length),
        );
        const element =
          pickPool[Math.floor(Math.random() * pickPool.length)] ||
          unprocessedElements[0];

        try {
          await browseBeforeProcessCard(() => shouldContinueGreet(loopToken));
          if (!shouldContinueGreet(loopToken)) return;

          const cfg = getGreetBackgroundConfig();
          const maxRetry =
            Number(cfg.cardRetryMax) > 0 ? Number(cfg.cardRetryMax) : 3;
          let result = { status: "no_name" };

          for (let attempt = 1; attempt <= maxRetry; attempt++) {
            if (!shouldContinueGreet(loopToken)) return;
            const place = await scrollCardIntoPlace(element, () =>
              shouldContinueGreet(loopToken),
            );
            if (place.aborted) return;
            if (!place.ok) continue;

            await humanStepDelay("对准候选人卡片");
            if (!shouldContinueGreet(loopToken)) return;

            result = await processElement(element, doc, loopToken);
            if (result?.status === "aborted") return;
            if (result?.status !== "no_name") break;
          }

          const consumedName = result?.name || readCardName(element);
          if (!result || result.status === "no_name") {
            logSkipped(consumedName);
            sendMessage({
              type: "LOG_MESSAGE",
              data: {
                message: consumedName
                  ? `${consumedName}：未能组装候选人信息，已跳过`
                  : "未能读取候选人姓名，已跳过",
                type: "warning",
              },
            });
          }
          markGreetCardConsumed(element, consumedName);

          if (!shouldContinueGreet(loopToken)) return;

          await humanCandidateGap("下一位候选人");
          if (!shouldContinueGreet(loopToken)) return;
          await forcedRestIfNeeded("greet", () => shouldContinueGreet(loopToken));
          if (shouldContinueGreet(loopToken)) executeScroll(loopToken);
          return;
        } catch (error) {
          console.error("处理元素失败:", error);
          markGreetCardConsumed(element, readCardName(element));
          await humanCandidateGap("处理失败后继续");
          if (shouldContinueGreet(loopToken)) executeScroll(loopToken);
          return;
        }
      }
    }

    if (!shouldContinueGreet(loopToken)) return;

    // 当前视口没有未处理卡片：向下滚动并延迟，避免无延迟死循环卡死页面
    if (totalFound === 0) {
      sendMessage({
        type: "LOG_MESSAGE",
        data: {
          message:
            "未找到候选人卡片，请确认在「推荐牛人」列表页且页面已加载出简历",
          type: "warning",
        },
      });
    }

    window.scrollBy({
      top: 200,
      behavior: isPageInBackground() ? "auto" : "smooth",
    });

    await randomDelay(totalFound === 0 ? "无候选人卡片" : "继续寻找下一位");
    if (shouldContinueGreet(loopToken)) executeScroll(loopToken);
  } catch (error) {
    console.error("滚动处理失败:", error);
    showNotification("⚠️ 滚动处理出错", "status");
    stopAutoScroll();
  }
}

// 添加高亮原因标签函数
function addHighlightReason(element, reason, color) {
  // 移除旧的原因标签
  element.querySelector(".招聘速聊助手-highlight-reason")?.remove();

  const reasonEl = document.createElement("div");
  reasonEl.className = "招聘速聊助手-highlight-reason";
  reasonEl.textContent = reason;
  reasonEl.style.cssText = `
                position: absolute;
                top: 0;
                left: 0;
                background-color: ${color};
                color: white;
                padding: 1px 12px;
                font-size: 10px;
                border-bottom-right-radius: 8px;
                z-index: 1;
            `;
  element.style.position = "relative";
  element.appendChild(reasonEl);

  // 根据状态设置不同高亮
  if (reason.includes("已打招呼")) {
    // 已打招呼状态（绿色）
    const contactedStyles = {
      "background-color": "#e8f5e9",
      border: "2px solid #4caf50",
      "box-shadow": "0 0 10px rgba(76, 175, 80, 0.3)",
    };
    Object.entries(contactedStyles).forEach(([property, value]) => {
      element.style.setProperty(property, value, "important");
    });
  } else {
    // 未打招呼状态（灰色）
    const notContactedStyles = {
      "background-color": "#f5f5f5",
      border: "2px solid #9e9e9e",
      "box-shadow": "0 0 10px rgba(158, 158, 158, 0.3)",
    };
    Object.entries(notContactedStyles).forEach(([property, value]) => {
      element.style.setProperty(property, value, "important");
    });
  }
}

// 处理单个元素的函数
async function processElement(element, doc, loopToken = greetLoopToken) {
  if (!shouldContinueGreet(loopToken)) return { status: "aborted" };

  // 只补默认沟通配置，切勿整体覆盖 aiSettings（否则岗位关键词/上限会丢失）
  if (!currentParser.aiSettings) {
    currentParser.aiSettings = {};
  }
  if (!currentParser.aiSettings.communicationConfig) {
    currentParser.aiSettings.communicationConfig = {
      collectPhone: false,
      collectWechat: false,
      collectResume: false,
    };
  }
  console.log("是否收集手机号:", currentParser.aiSettings.communicationConfig);

  //处理消息提示
  await currentParser.checkMessageTip(
    element,
    currentParser.aiSettings.communicationConfig.collectPhone || false,
    currentParser.aiSettings.communicationConfig.collectWechat || false,
    currentParser.aiSettings.communicationConfig.collectResume || false,
  );
  if (!shouldContinueGreet(loopToken)) return { status: "aborted" };

  try {
    // 首先检查是否已达到匹配限制
    if (matchCount >= matchLimit) {
      stopAutoScroll(`已达到匹配上限 ${matchLimit}，自动停止`);
      return { status: "aborted" };
    }

    await currentParser.loadSettings();
    if (!shouldContinueGreet(loopToken)) return { status: "aborted" };
    syncMatchLimitFromSettings();

    let targetElement = findCandidateCardRoot(
      element,
      currentParser.selectors?.items,
    );

    if (!targetElement) return { status: "no_name" };

    // 先清除之前的样式
    targetElement.removeAttribute("style");

    // 清除之前的高亮和原因标签
    targetElement.querySelector(".招聘速聊助手-highlight-reason")?.remove();

    const candidates = await currentParser.extractCandidates([element]);
    if (!shouldContinueGreet(loopToken)) return { status: "aborted" };

    const resolvedCandidates = candidates;
    if (!resolvedCandidates.length) {
      return { status: "no_name", name: readCardName(element) };
    }

    if (resolvedCandidates.length > 0) {
      for (let candidate of candidates) {
        if (!shouldContinueGreet(loopToken)) return;

        let simpleCandidateInfo = null;
        // 再次检查是否已达到匹配限制
        if (matchCount >= matchLimit) {
          stopAutoScroll(`已达到匹配上限 ${matchLimit}，自动停止`);
          return;
        }

        let shouldSkipDelay = false;

        // 第一个决策点：决定是否查看候选人详细信息
        let clickCandidate = false;
        simpleCandidateInfo =
          await currentParser.getSimpleCandidateInfo(candidate);
        if (!shouldContinueGreet(loopToken)) return;

        if (matchesExcludeKeywords(simpleCandidateInfo)) {
          addHighlightReason(targetElement, "未打招呼", "#9e9e9e");
          logSkipped(candidate.name);
          await humanStepDelay("命中排除关键词");
          continue;
        }

        await humanStepDelay("AI 判断前");
        await humanThinkPause("看简历信息");
        if (!shouldContinueGreet(loopToken)) return;

        let { isok, saveResult } = await performAIClickDecision(
          simpleCandidateInfo,
          candidate,
        );
        if (!shouldContinueGreet(loopToken)) return;
        clickCandidate = isok;

        if (saveResult?.message) {
          sendMessage({
            type: "LOG_MESSAGE",
            data: {
              message: saveResult.message,
              type: saveResult.ok ? "success" : "error",
            },
          });
        }

        if (clickCandidate) {
          addHighlightReason(targetElement, "已打招呼", "#4caf50");
        } else {
          addHighlightReason(targetElement, "未打招呼", "#9e9e9e");
        }

        // 判断是否应该联系候选人
        let shouldContact = false;
        if (clickCandidate) {
          // 检查是否有打开的候选人页面
          //关闭候选人弹框
          // await currentParser.closeCandidateDetail();

          await humanStepDelay("打开详情前");
          await maybeHumanThinkPause("是否打开详情");
          if (!shouldContinueGreet(loopToken)) return;
          await currentParser.closeDetail();

          // 点击查看候选人详细信息
          if (!shouldContinueGreet(loopToken)) return;
          let clicked = await currentParser.clickCandidateDetail(element);

          if (clicked) {
            shouldSkipDelay = true;
            let colleagueContactedInfo = null;

            try {
              await humanStepDelay(`查看详情: ${candidate.name}`);
              if (!shouldContinueGreet(loopToken)) return;

              try {
                colleagueContactedInfo =
                  await currentParser.queryColleagueContactedInfo(candidate);
                if (colleagueContactedInfo) {
                  simpleCandidateInfo += colleagueContactedInfo;
                }
              } catch (error) {
                console.error("查询同事沟通过候选人的信息失败:", error);
              }

              try {
                const data2 =
                  await currentParser.extractCandidates2(candidate);
                if (data2) {
                  simpleCandidateInfo = data2;
                }
              } catch (error) {
                console.error("第二次组装信息失败:", error);
              }

              shouldContact = !!clickCandidate;
            } finally {
              await currentParser.closeDetail();
              await humanStepDelay("关闭详情");
            }
          }
        } else {
          await humanStepDelay("不查看详情");
        }

        if (!shouldContinueGreet(loopToken)) return;

        if (shouldContact) {
          // 再次检查是否已达到匹配限制
          if (matchCount >= matchLimit) {
            stopAutoScroll(`已达到匹配上限 ${matchLimit}，自动停止`);
            return;
          }

          await humanStepDelay("打招呼点击前");
          await humanThinkPause("决定打招呼");
          if (!shouldContinueGreet(loopToken)) return;
          await currentParser.closeDetail();

          addHighlightReason(targetElement, "已打招呼", "#4caf50");

          if (!shouldContinueGreet(loopToken)) return { status: "aborted" };
          const clicked = await currentParser.clickMatchedItem(element);
          await new Promise((r) => setTimeout(r, 500));
          const confirmed = clicked
            ? currentParser.confirmGreetClick
              ? currentParser.confirmGreetClick(element)
              : true
            : false;
          if (clicked && confirmed) {
            try {
              if (
                currentParser.aiSettings.communicationConfig.collectPhone ||
                currentParser.aiSettings.communicationConfig.collectWechat ||
                currentParser.aiSettings.communicationConfig.collectResume
              ) {
                await currentParser.collectPhoneWechatResume(
                  currentParser.aiSettings.communicationConfig.collectPhone,
                  currentParser.aiSettings.communicationConfig.collectWechat,
                  currentParser.aiSettings.communicationConfig.collectResume,
                  candidate,
                  element,
                );
              }
            } catch (error) {
              console.error(
                "索要配置异常:",
                error,
                currentParser.aiSettings.communicationConfig,
              );
            }

            matchCount++;
            console.log(`打招呼成功，当前计数: ${matchCount}/${matchLimit}`);

            await currentParser.markAIRecordGreeted(candidate.name);

            logReached(candidate.name);

            playNotificationSound();

            try {
              if (
                currentParser.processCommunication &&
                typeof currentParser.processCommunication === "function"
              ) {
                await currentParser.processCommunication(candidate);
              }
            } catch (error) {
              console.error("处理沟通功能时出错:", error);
            }
          } else {
            logSkipped(candidate.name);
            sendMessage({
              type: "LOG_MESSAGE",
              data: {
                message: `${candidate.name || "候选人"}：已判断匹配，但打招呼点击未生效（窗口不在前台时可能被网站拦截）`,
                type: "error",
              },
            });
          }

          await sendMessage({
            type: "MATCH_SUCCESS",
            data: {
              name: candidate.name,
              age: candidate.age,
              education: candidate.education,
              university: candidate.university,
              extraInfo: candidate.extraInfo,
              matchTime: new Date().toLocaleTimeString("zh-CN", {
                hour12: false,
                hour: "2-digit",
                minute: "2-digit",
                second: "2-digit",
              }),
              clicked: confirmed,
            },
          });

          await currentParser.closeDetail();

          // 最后再次检查是否需要停止
          if (matchCount >= matchLimit) {
            stopAutoScroll(`已达到匹配上限 ${matchLimit}，自动停止`);
            return { status: "done", name: candidate.name };
          }
        } else {
          if (clickCandidate) {
            await currentParser.closeDetail();
          }
          addHighlightReason(targetElement, "未打招呼", "#9e9e9e");
          logSkipped(candidate.name);
        }
      }
      if (matchCount < matchLimit && !shouldContinueGreet(loopToken)) {
        await scrollToNextBatch();
      }
      return {
        status: "done",
        name: resolvedCandidates[0]?.name || readCardName(element),
      };
    }
  } catch (error) {
    console.error("处理元素失败:", error);
    element.removeAttribute("style");
    return { status: "no_name", name: readCardName(element) };
  }
  return { status: "no_name", name: readCardName(element) };
}

function playNotificationSound() {
  if (enableSound) {
    const audio = new Audio(chrome.runtime.getURL("sounds/notification2.mp3"));
    audio.volume = 0.5; // 设置音量
    audio.play().catch((error) => console.error("播放提示音失败:", error));
  }
}

// 仅「开始」限制顶层；停止必须全 frame 响应
const TOP_FRAME_ACTIONS = new Set([
  "START_AI_SCROLL",
  "GET_CHAT_FILTER_POSITION",
]);

/** 压缩空白，便于岗位名比对 */
function normalizePositionText(text) {
  return String(text || "")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * 读取推荐牛人页头部当前岗位文案
 * 主路径：//*[@id="headerWrap"]/div/div/div[2]/div[1]
 */
function getRecommendPageHeaderPositionText() {
  const xpath =
    window.招聘速聊助手_CONFIG?.recommendHeaderPositionXPath ||
    window.招聘速聊助手_CONFIG?.DEFAULTS?.recommendHeaderPositionXPath ||
    '//*[@id="headerWrap"]/div/div/div[2]/div[1]';

  const docs = [];
  try {
    if (typeof getAllDocuments === "function") {
      docs.push(...getAllDocuments());
    }
  } catch {
    /* ignore */
  }
  if (!docs.length) {
    docs.push(document);
    try {
      if (window.top?.document && window.top.document !== document) {
        docs.push(window.top.document);
      }
    } catch {
      /* ignore */
    }
  }

  for (const doc of docs) {
    if (!doc) continue;
    try {
      const node = doc.evaluate(
        xpath,
        doc,
        null,
        XPathResult.FIRST_ORDERED_NODE_TYPE,
        null,
      ).singleNodeValue;
      const text = normalizePositionText(node?.textContent || node?.innerText);
      if (text) return text;
    } catch {
      /* ignore invalid xpath / cross-origin */
    }

    // 兜底：#headerWrap 内前几段可见文本
    try {
      const wrap = doc.querySelector("#headerWrap");
      if (wrap) {
        const candidate =
          wrap.querySelector("div > div > div:nth-child(2) > div:first-child") ||
          wrap.querySelector('[class*="job"], [class*="position"], [class*="title"]');
        const text = normalizePositionText(
          candidate?.textContent || wrap.textContent?.slice(0, 80),
        );
        if (text) return text;
      }
    } catch {
      /* ignore */
    }
  }

  return "";
}

/**
 * 推荐牛人页：若存在优先点击节点（遮挡/引导），先点再继续
 * XPath 默认：/html/body/div/div/div/div[1]/div/div/div/div/div[2]/span[2]
 * @returns {Promise<{ clicked: boolean, detail?: string }>}
 */
async function clickRecommendPriorityElementIfPresent() {
  if (greetPriorityClicked) {
    return { clicked: false, detail: "already" };
  }

  const xpath =
    window.招聘速聊助手_CONFIG?.recommendPriorityClickXPath ||
    "/html/body/div/div/div/div[1]/div/div/div/div/div[2]/span[2]";

  const docs = [];
  try {
    if (typeof getAllDocuments === "function") {
      docs.push(...getAllDocuments());
    }
  } catch {
    /* ignore */
  }
  if (!docs.length) {
    docs.push(document);
    try {
      if (window.top?.document && window.top.document !== document) {
        docs.push(window.top.document);
      }
    } catch {
      /* ignore */
    }
  }

  let target = null;
  for (const doc of docs) {
    if (!doc) continue;
    try {
      const node = doc.evaluate(
        xpath,
        doc,
        null,
        XPathResult.FIRST_ORDERED_NODE_TYPE,
        null,
      ).singleNodeValue;
      if (!node) continue;
      // 可见性粗判
      const el = node.nodeType === 1 ? node : node.parentElement;
      if (!el) continue;
      const style = doc.defaultView?.getComputedStyle?.(el);
      if (style && (style.display === "none" || style.visibility === "hidden")) {
        continue;
      }
      const rect = el.getBoundingClientRect?.();
      if (rect && rect.width <= 0 && rect.height <= 0) continue;
      target = el;
      break;
    } catch {
      /* ignore */
    }
  }

  if (!target) {
    return { clicked: false };
  }

  const guideText = String(target.textContent || "").replace(/\s+/g, "");
  const looksLikeGuide =
    /知道了|跳过|我知道了|关闭引导|不再提示|我已了解/.test(guideText);
  if (!looksLikeGuide) {
    greetPriorityClicked = true;
    return { clicked: false, detail: "not-guide" };
  }

  try {
    const clickable =
      target.closest?.("span, a, button, [role='button'], div") || target;
    clickable.dispatchEvent?.(
      new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }),
    );
    clickable.dispatchEvent?.(
      new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }),
    );
    clickable.click?.();
    clickable.dispatchEvent?.(
      new MouseEvent("click", { bubbles: true, cancelable: true, view: window }),
    );
    greetPriorityClicked = true;
    await new Promise((r) => setTimeout(r, 500));
    sendMessage({
      type: "LOG_MESSAGE",
      data: {
        message: "已优先点击推荐页引导/遮挡节点，继续后续操作",
        type: "info",
      },
    });
    return { clicked: true, detail: "priority-xpath" };
  } catch (error) {
    greetPriorityClicked = true;
    console.warn("优先点击节点失败:", error);
    return { clicked: false, detail: error?.message || String(error) };
  }
}

/**
 * 插件岗位选择是否出现在页面头部岗位文案中
 * @param {string} positionName
 */
function validatePagePositionMatchesSelection(positionName) {
  const selected = normalizePositionText(positionName);
  if (!selected) {
    return { ok: false, message: "请先选择岗位" };
  }

  const pageText = normalizePositionText(getRecommendPageHeaderPositionText());
  if (!pageText) {
    return {
      ok: false,
      message:
        "未能识别当前页面岗位，请确认已在推荐牛人页并刷新后重试",
      pageText: "",
      selected,
    };
  }

  if (!pageText.includes(selected)) {
    return {
      ok: false,
      message:
        "当前页面岗位与岗位选择框内容不一致，无法进行一键打招呼",
      pageText,
      selected,
    };
  }

  return { ok: true, pageText, selected };
}

// 处理来自popup的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (TOP_FRAME_ACTIONS.has(message.action) && !isTopFrame()) {
    return false;
  }

  (async () => {
    try {
      switch (message.action) {
        case "START_AI_SCROLL": {
          if (isAskResumeRunning || isResumeUploadRunning) {
            if (isTopFrame()) {
              sendResponse({
                status: "error",
                message: isAskResumeRunning
                  ? "一键求简历正在运行中，请先停止"
                  : "一键简历回传正在运行中，请先停止",
              });
            }
            return;
          }

          {
            const ready = await ensureParserReady();
            if (!ready.ok) {
              // 子 frame 解析失败勿回 error，否则弹窗会当成整次失败
              if (isTopFrame()) {
                console.error("解析器未初始化，无法启动AI滚动:", ready.error);
                sendResponse({
                  status: "error",
                  message: `解析器未初始化：${ready.error}。请刷新推荐牛人页后重试`,
                });
              }
              return;
            }
          }

          const data = message.data || {};
          const positionCheck = validatePagePositionMatchesSelection(
            data.positionName,
          );
          if (!positionCheck.ok) {
            console.warn(
              "[招聘速聊助手] 岗位校验失败:",
              positionCheck.message,
              "页面=",
              positionCheck.pageText,
              "选择=",
              positionCheck.selected,
            );
            // 仅顶层报错，避免多 frame 刷日志
            if (isTopFrame()) {
              showNotification(positionCheck.message, "status");
              sendMessage({
                type: "LOG_MESSAGE",
                data: {
                  message: positionCheck.message,
                  type: "error",
                },
              });
              sendResponse({
                status: "error",
                message: positionCheck.message,
              });
            }
            return;
          }

          currentParser.aiMode = true;
          currentParser.aiSettings = {
            positionName: data.positionName,
            keywords: data.keywords || [],
            excludeKeywords: data.excludeKeywords || [],
            matchLimit: data.matchLimit,
            scrollDelayMin: data.scrollDelayMin,
            scrollDelayMax: data.scrollDelayMax,
            enableSound: data.enableSound,
            communicationEnabled: data.communicationEnabled,
            communicationConfig:
              data.communicationConfig ||
              window.招聘速聊助手_CONFIG?.COMMUNICATION_CONFIG || {
                collectPhone: false,
                collectWechat: false,
                collectResume: false,
              },
          };
          enableSound = data.enableSound !== false;

          {
            const scrollResult = await startAutoScroll();
            // 多 iframe：owner 回 success；顶层在 ignored 时稍等，看是否已有其它 frame 在跑
            if (scrollResult?.status === "success") {
              sendResponse(scrollResult);
            } else if (isTopFrame()) {
              if (scrollResult?.status === "ignored") {
                await new Promise((r) => setTimeout(r, 450));
                try {
                  const st = await chrome.storage.local.get(["isRunning"]);
                  if (st.isRunning === true) {
                    sendResponse({ status: "success" });
                    return;
                  }
                } catch {
                  /* ignore */
                }
              }
              sendResponse(
                scrollResult?.status === "error"
                  ? scrollResult
                  : {
                      status: "error",
                      message:
                        scrollResult?.message ||
                        "未能启动打招呼（请刷新推荐牛人页重试）",
                    },
              );
            }
          }
          break;
        }
        case "STOP_SCROLL":
          // 所有 frame 停循环；仅顶层可提示，日志由弹窗统一写
          stopAutoScroll("已停止自动滚动", { silent: !isTopFrame() });
          sendResponse({ status: "stopped" });
          break;
        case "GET_CHAT_FILTER_POSITION": {
          // 已在 TOP_FRAME_ACTIONS 中限制仅顶层处理
          const ready = await ensureParserReady();
          if (!ready.ok || !currentParser) {
            sendResponse({
              status: "error",
              message: ready.error || lastParserInitError || "解析器未就绪",
            });
            break;
          }
          if (!isBossChatPage()) {
            sendResponse({
              status: "error",
              message:
                "请先进入 Boss 直聘沟通页面（https://www.zhipin.com/web/chat/index）",
            });
            break;
          }
          const docs = getAllDocuments();
          const text = String(
            currentParser.getChatFilterPositionText?.(docs) || "",
          ).trim();
          sendResponse({
            status: "success",
            positionText: text,
          });
          break;
        }
        case "START_ASK_RESUME": {
          const result = await startAskResume(message.data || {});
          // 重要：多 iframe 时，未初始化的 frame 不能回 error，否则会抢先报「解析器未初始化」
          // 仅「成功启动」的 frame，或顶层 frame（汇总失败/忽略）回包
          if (result.status === "success") {
            sendResponse(result);
          } else if (isTopFrame()) {
            sendResponse(result);
          }
          break;
        }
        case "STOP_ASK_RESUME": {
          // 所有 frame 停循环；提示仅顶层，日志由弹窗统一写
          stopAskResume("已停止求简历", { silent: !isTopFrame() });
          sendResponse({ status: "stopped" });
          break;
        }
        case "START_RESUME_UPLOAD": {
          const result = await startResumeUpload(message.data || {});
          if (result.status === "success") {
            sendResponse(result);
          } else if (isTopFrame()) {
            sendResponse(result);
          }
          break;
        }
        case "STOP_RESUME_UPLOAD": {
          stopResumeUpload("已停止简历回传", { silent: !isTopFrame() });
          sendResponse({ status: "stopped" });
          break;
        }
        case "COMMUNICATION_PROCESS":
          if (currentParser) {
            if (message.data.companyInfo) {
              currentParser.companyInfo = message.data.companyInfo;
            }
            if (message.data.jobInfo) {
              currentParser.jobInfo = message.data.jobInfo;
            }
            if (message.data.communicationConfig) {
              currentParser.aiSettings.communicationConfig =
                message.data.communicationConfig;
            }
            if (message.data.runModeConfig) {
              currentParser.runModeConfig = message.data.runModeConfig;
            }

            sendResponse({ status: "success" });
          } else {
            sendResponse({ status: "error", message: "解析器未初始化" });
          }
          break;
        default:
          console.error("未知的消息类型:", message.action);
          sendResponse({ status: "error", message: "未知的消息类型" });
      }
    } catch (error) {
      console.error("处理消息时出错:", error);
      isRunning = false;
      sendResponse({ status: "error", message: error.message });
    }
  })();

  return true;
});

/**
 * @param {string} [reason]
 * @param {{ silentLog?: boolean }} [options]
 */
function notifyRunStateStopped(reason = "已停止", options = {}) {
  chrome.storage.local.set({ isRunning: false });
  try {
    chrome.runtime.sendMessage({
      type: "RUN_STATE_CHANGED",
      running: false,
      // silentLog：弹窗只更新按钮状态，不因 reason 再写一条日志
      reason: options.silentLog ? "" : reason,
      silentLog: options.silentLog === true,
    });
  } catch (_) {
    /* popup 可能未打开 */
  }
}

function notifyAskResumeStateChanged(running) {
  chrome.storage.local.set({ isAskResumeRunning: running });
  try {
    chrome.runtime.sendMessage({
      type: "ASK_RESUME_STATE_CHANGED",
      running,
      silentLog: true,
    });
  } catch (_) {
    /* popup 可能未打开 */
  }
}

function isTopFrame() {
  try {
    return window.self === window.top;
  } catch {
    return false;
  }
}

function resolveActiveUrl() {
  try {
    return window.top?.location?.href || window.location.href;
  } catch {
    return window.location.href;
  }
}

/** 沟通页：仅 /web/chat/index */
function isBossChatPage() {
  const url = resolveActiveUrl();
  return (
    /zhipin\.com/.test(url) &&
    /\/web\/chat\/index(?:[/?#]|$)/i.test(String(url || ""))
  );
}

async function claimAskResumeLoopOwner(sessionCount) {
  if (sessionCount <= 0) return false;

  await new Promise((resolve) =>
    setTimeout(resolve, 50 + Math.floor(Math.random() * 200)),
  );

  const stored = await chrome.storage.local.get([ASK_RESUME_OWNER_KEY]);
  const existing = stored[ASK_RESUME_OWNER_KEY];
  if (existing?.id && Date.now() - (existing.at || 0) < 60000) {
    return false;
  }

  const myId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  await chrome.storage.local.set({
    [ASK_RESUME_OWNER_KEY]: {
      id: myId,
      at: Date.now(),
      sessions: sessionCount,
      href: window.location.href,
    },
  });

  await new Promise((resolve) => setTimeout(resolve, 220));
  const check = await chrome.storage.local.get([ASK_RESUME_OWNER_KEY]);
  if (check[ASK_RESUME_OWNER_KEY]?.id !== myId) {
    return false;
  }

  askResumeOwnerId = myId;
  return true;
}

async function refreshAskResumeLoopOwner() {
  if (!askResumeOwnerId || !isAskResumeRunning) return false;

  const stored = await chrome.storage.local.get([ASK_RESUME_OWNER_KEY]);
  if (stored[ASK_RESUME_OWNER_KEY]?.id !== askResumeOwnerId) {
    return false;
  }

  await chrome.storage.local.set({
    [ASK_RESUME_OWNER_KEY]: {
      ...stored[ASK_RESUME_OWNER_KEY],
      at: Date.now(),
    },
  });
  return true;
}

function releaseAskResumeLoopOwner() {
  if (!askResumeOwnerId) return;

  chrome.storage.local.get([ASK_RESUME_OWNER_KEY], (stored) => {
    if (stored[ASK_RESUME_OWNER_KEY]?.id === askResumeOwnerId) {
      chrome.storage.local.remove([ASK_RESUME_OWNER_KEY]);
    }
  });
  askResumeOwnerId = null;
}

async function startAskResume(messageData = {}) {
  if (isRunning) {
    return { status: "error", message: "一键打招呼正在运行中，请先停止" };
  }
  if (isResumeUploadRunning) {
    return { status: "error", message: "一键简历回传正在运行中，请先停止" };
  }

  // 先初始化；子 frame 初始化失败不要当成全局错误
  const ready = await ensureParserReady();
  if (!ready.ok || !currentParser) {
    if (!isTopFrame()) {
      return { status: "ignored" };
    }
    return {
      status: "error",
      message: `解析器未初始化：${ready.error || lastParserInitError || "未知原因"}。请刷新沟通页后重试`,
    };
  }

  if (!isBossChatPage()) {
    if (!isTopFrame()) {
      return { status: "ignored" };
    }
    return {
      status: "error",
      message:
        "请先进入 Boss 直聘沟通页面（https://www.zhipin.com/web/chat/index）",
    };
  }

  const documents = getAllDocuments();
  const sessionCount = currentParser.collectChatSessionItems(documents).length;

  if (sessionCount === 0) {
    return { status: "ignored" };
  }

  if (!(await claimAskResumeLoopOwner(sessionCount))) {
    return { status: "ignored" };
  }

  if (isAskResumeRunning) {
    releaseAskResumeLoopOwner();
    return { status: "success", message: "求简历任务已在运行" };
  }

  currentParser.askResumeSettings = {
    positionName: messageData.positionName || "",
    keywords: messageData.keywords || [],
    excludeKeywords: messageData.excludeKeywords || [],
    resumeScript: messageData.resumeScript || "",
    rejectScript: messageData.rejectScript || "",
    pagePositionText: messageData.pagePositionText || "",
    isAllPositions: messageData.isAllPositions === true,
  };
  // 与一键打招呼共用同一套伊利 AI 判断逻辑
  currentParser.performAskResumeAIDecision = performAskResumeAIDecision;
  currentParser.performGreetAIDecision = async (simpleCandidateInfo) => {
    const { isok, msg } = await performAIClickDecision(simpleCandidateInfo, {
      name: "求简历图片分析",
    });
    return { isok, msg };
  };
  currentParser.matchesAskResumeExcludeKeywords = matchesAskResumeExcludeKeywords;
  await currentParser.primeAskResumeCaches?.();

  isAskResumeRunning = true;
  askResumeLoopToken += 1;
  const loopToken = askResumeLoopToken;
  askResumeHumanCount = 0;
  askResumeCount = 0;
  askResumeSkipCount = 0;
  currentParser.resetAskResumeRunState?.();
  currentParser.chatTaskMode = "ask_resume";
  // 供 boss.js 长流程中途感知停止
  currentParser.shouldAbortAskResume = () => !shouldContinueAskResume(loopToken);

  notifyAskResumeStateChanged(true);
  sendMessage({
    type: "LOG_MESSAGE",
    data: {
      message: messageData.isAllPositions
        ? "求简历任务已启动（沟通页：全部职位，不按单一岗位关键词筛选）"
        : `求简历任务已启动（岗位：${messageData.positionName || "未指定"}）`,
      type: "success",
    },
  });

  executeAskResumeLoop(loopToken);
  return { status: "success" };
}

/**
 * @param {string} [reason]
 * @param {{ silent?: boolean }} [options] silent=true 时不打日志/不弹提示（storage 二次触发用）
 */
function stopAskResume(reason = "已停止求简历", options = {}) {
  const silent = options.silent === true;
  const wasRunning = isAskResumeRunning;
  const isOwner = !!askResumeOwnerId;
  const count = askResumeCount;
  const skipCount = askResumeSkipCount;
  isAskResumeRunning = false;
  askResumeLoopToken += 1;
  releaseAskResumeLoopOwner();
  if (currentParser) {
    // 保留 chatTaskMode，让进行中的切会话/下载能读到「已停止」
    currentParser.shouldAbortAskResume = () => true;
  }

  // 始终同步 storage；notify 仅在真正从运行→停止时，且非 silent
  if (wasRunning) {
    notifyAskResumeStateChanged(false);
  } else if (!silent) {
    // 未在本 frame 运行时也写 false，避免状态残留（不重复 notify 弹窗）
    try {
      chrome.storage.local.set({ isAskResumeRunning: false });
    } catch {
      /* ignore */
    }
  }

  if (wasRunning && isOwner && isExtensionValid()) {
    sendMessage({
      type: "LOG_MESSAGE",
      data: {
        message: `成功求简历${count}人，跳过${skipCount}人`,
        type: "success",
      },
    });
    if (isTopFrame()) {
      showNotification(`成功求简历${count}人，跳过${skipCount}人`, "status");
    }
  } else if (wasRunning && !silent && isTopFrame() && isExtensionValid()) {
    showNotification(reason, "status");
  }

  return { status: "stopped" };
}

function notifyResumeUploadStateChanged(running) {
  chrome.storage.local.set({ isResumeUploadRunning: running });
  try {
    chrome.runtime.sendMessage({
      type: "RESUME_UPLOAD_STATE_CHANGED",
      running,
      silentLog: true,
    });
  } catch (_) {
    /* popup 可能未打开 */
  }
}

async function claimResumeUploadLoopOwner(sessionCount) {
  if (sessionCount <= 0) return false;

  await new Promise((resolve) =>
    setTimeout(resolve, 50 + Math.floor(Math.random() * 200)),
  );

  const stored = await chrome.storage.local.get([RESUME_UPLOAD_OWNER_KEY]);
  const existing = stored[RESUME_UPLOAD_OWNER_KEY];
  if (existing?.id && Date.now() - (existing.at || 0) < 60000) {
    return false;
  }

  const myId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  await chrome.storage.local.set({
    [RESUME_UPLOAD_OWNER_KEY]: {
      id: myId,
      at: Date.now(),
      sessions: sessionCount,
      href: window.location.href,
    },
  });

  await new Promise((resolve) => setTimeout(resolve, 220));
  const check = await chrome.storage.local.get([RESUME_UPLOAD_OWNER_KEY]);
  if (check[RESUME_UPLOAD_OWNER_KEY]?.id !== myId) {
    return false;
  }

  resumeUploadOwnerId = myId;
  return true;
}

async function refreshResumeUploadLoopOwner() {
  if (!resumeUploadOwnerId || !isResumeUploadRunning) return false;

  const stored = await chrome.storage.local.get([RESUME_UPLOAD_OWNER_KEY]);
  if (stored[RESUME_UPLOAD_OWNER_KEY]?.id !== resumeUploadOwnerId) {
    return false;
  }

  await chrome.storage.local.set({
    [RESUME_UPLOAD_OWNER_KEY]: {
      ...stored[RESUME_UPLOAD_OWNER_KEY],
      at: Date.now(),
    },
  });
  return true;
}

function releaseResumeUploadLoopOwner() {
  if (!resumeUploadOwnerId) return;

  chrome.storage.local.get([RESUME_UPLOAD_OWNER_KEY], (stored) => {
    if (stored[RESUME_UPLOAD_OWNER_KEY]?.id === resumeUploadOwnerId) {
      chrome.storage.local.remove([RESUME_UPLOAD_OWNER_KEY]);
    }
  });
  resumeUploadOwnerId = null;
}

/**
 * 一键简历回传：只扫会话里「已有附件简历」并查重上传
 */
async function startResumeUpload(messageData = {}) {
  if (isRunning) {
    return { status: "error", message: "一键打招呼正在运行中，请先停止" };
  }
  if (isAskResumeRunning) {
    return { status: "error", message: "一键求简历正在运行中，请先停止" };
  }

  const ready = await ensureParserReady();
  if (!ready.ok || !currentParser) {
    if (!isTopFrame()) {
      return { status: "ignored" };
    }
    return {
      status: "error",
      message: `解析器未初始化：${ready.error || lastParserInitError || "未知原因"}。请刷新沟通页后重试`,
    };
  }

  if (!isBossChatPage()) {
    if (!isTopFrame()) {
      return { status: "ignored" };
    }
    return {
      status: "error",
      message:
        "请先进入 Boss 直聘沟通页面（https://www.zhipin.com/web/chat/index）",
    };
  }

  const documents = getAllDocuments();
  const sessionCount = currentParser.collectChatSessionItems(documents).length;

  if (sessionCount === 0) {
    return { status: "ignored" };
  }

  if (!(await claimResumeUploadLoopOwner(sessionCount))) {
    return { status: "ignored" };
  }

  if (isResumeUploadRunning) {
    releaseResumeUploadLoopOwner();
    return { status: "success", message: "简历回传任务已在运行" };
  }

  await currentParser.primeAskResumeCaches?.();

  isResumeUploadRunning = true;
  resumeUploadLoopToken += 1;
  const loopToken = resumeUploadLoopToken;
  resumeUploadHumanCount = 0;
  resumeUploadCount = 0;
  resumeUploadSkipCount = 0;
  currentParser.resumeUploadCompletedKeys = new Set();
  currentParser.chatTaskMode = "resume_upload";
  currentParser.shouldAbortResumeUpload = () =>
    !shouldContinueResumeUpload(loopToken);

  notifyResumeUploadStateChanged(true);
  sendMessage({
    type: "LOG_MESSAGE",
    data: {
      message:
        "简历回传任务已启动：仅处理聊天中已有附件简历的会话；稍后简历将回传大易",
      type: "success",
    },
  });

  executeResumeUploadLoop(loopToken);
  return { status: "success" };
}

/**
 * @param {string} [reason]
 * @param {{ silent?: boolean }} [options]
 */
function stopResumeUpload(reason = "已停止简历回传", options = {}) {
  const silent = options.silent === true;
  const wasRunning = isResumeUploadRunning;
  const isOwner = !!resumeUploadOwnerId;
  const count = resumeUploadCount;
  const skipCount = resumeUploadSkipCount;
  isResumeUploadRunning = false;
  resumeUploadLoopToken += 1;
  releaseResumeUploadLoopOwner();
  if (currentParser) {
    // 保留 chatTaskMode=resume_upload：若清空，isChatTaskAborted 会返回 false，
    // 正在切会话/下附件的流程会当成没停止，继续点人。
    currentParser.shouldAbortResumeUpload = () => true;
  }

  if (wasRunning) {
    notifyResumeUploadStateChanged(false);
  } else if (!silent) {
    try {
      chrome.storage.local.set({ isResumeUploadRunning: false });
    } catch {
      /* ignore */
    }
  }

  if (wasRunning && isOwner && isExtensionValid()) {
    sendMessage({
      type: "LOG_MESSAGE",
      data: {
        message: `成功简历回传${count}人，跳过${skipCount}人`,
        type: "success",
      },
    });
    if (isTopFrame()) {
      showNotification(`成功简历回传${count}人，跳过${skipCount}人`, "status");
    }
  } else if (wasRunning && !silent && isTopFrame() && isExtensionValid()) {
    showNotification(reason, "status");
  }

  return { status: "stopped" };
}

async function executeResumeUploadLoop(loopToken) {
  while (shouldContinueResumeUpload(loopToken)) {
    try {
      if (!currentParser) break;

      try {
        const st = await chrome.storage.local.get(["isResumeUploadRunning"]);
        if (st.isResumeUploadRunning === false) {
          stopResumeUpload("已停止简历回传", { silent: true });
          break;
        }
      } catch {
        /* ignore */
      }
      if (!shouldContinueResumeUpload(loopToken)) break;

      if (!(await refreshResumeUploadLoopOwner())) {
        isResumeUploadRunning = false;
        break;
      }
      if (!shouldContinueResumeUpload(loopToken)) break;

      const documents = getAllDocuments();
      const sessions = currentParser.collectChatSessionItems(documents);

      if (sessions.length === 0) {
        const diag = currentParser.diagnoseChatSessionScan?.(documents) || {};
        logResumeUploadProgress(
          `未找到会话（扫描 ${diag.documents ?? "?"} 个文档）`,
          "warning",
          3000,
        );
      } else {
        logResumeUploadProgress(
          `简历回传：扫描会话列表，共 ${sessions.length} 个`,
          "info",
          3000,
        );
      }

      let roundUploaded = 0;
      let roundSkipped = 0;
      let roundWaiting = 0;
      let roundFailed = 0;
      const processedKeysThisRound = new Set();

      for (let i = 0; i < sessions.length; i++) {
        if (!shouldContinueResumeUpload(loopToken)) break;

        const session = sessions[i];
        const previewName = currentParser.getSessionDisplayName(session);

        try {
          const sessionKey = currentParser.getSessionKey(session);
          if (processedKeysThisRound.has(sessionKey)) {
            roundSkipped += 1;
            continue;
          }
          processedKeysThisRound.add(sessionKey);

          if (currentParser.resumeUploadCompletedKeys?.has(sessionKey)) {
            roundSkipped += 1;
            await humanCandidateGap("回传跳过已处理");
            continue;
          }

          logResumeUploadProgress(
            `简历回传：正在处理第 ${i + 1}/${sessions.length} 个会话：${previewName}`,
            "info",
            2000,
          );

          if (!shouldContinueResumeUpload(loopToken)) break;
          const result =
            await currentParser.processResumeUploadSession(session);
          if (!shouldContinueResumeUpload(loopToken)) break;

          if (result) {
            const personName = result.name || previewName;
            if (result.message) {
              logResumeUploadProgress(
                result.message,
                result.logType || "info",
                1500,
              );
            }
            if (isResumeUploadReachedStatus(result.status)) {
              logReached(personName);
              resumeUploadCount += 1;
            } else if (isResumeUploadSkippedStatus(result.status)) {
              logSkipped(personName);
            }

            if (
              result.status === "info_saved" ||
              result.status === "resume_ui_done"
            ) {
              roundUploaded += 1;
            } else if (
              result.status === "skip_done" ||
              result.status === "skip_no_resume"
            ) {
              roundSkipped += 1;
            } else if (
              result.status === "wait_chat" ||
              result.status === "wait_resume_ui" ||
              result.status === "wait_button"
            ) {
              roundWaiting += 1;
            } else if (result.logType === "error") {
              roundFailed += 1;
            }
          }
        } catch (sessionError) {
          roundFailed += 1;
          logSkipped(previewName);
          logResumeUploadProgress(
            `${previewName}：回传处理失败 ${sessionError.message}`,
            "error",
            1000,
          );
        }

        if (!shouldContinueResumeUpload(loopToken)) break;

        if (currentParser.cleanupBetweenAskResumeSessions) {
          try {
            await currentParser.cleanupBetweenAskResumeSessions(
              previewName,
              session,
            );
          } catch {
            /* ignore */
          }
        }

        if (!shouldContinueResumeUpload(loopToken)) break;
        {
          const { minMs, maxMs } = getHumanTimingRange("candidate");
          await interruptibleSleep(
            randomBetweenMs(minMs, maxMs),
            () => shouldContinueResumeUpload(loopToken),
          );
        }
        if (!shouldContinueResumeUpload(loopToken)) break;
        await forcedRestIfNeeded("upload", () =>
          shouldContinueResumeUpload(loopToken),
        );
      }

      if (sessions.length > 0) {
        logResumeUploadProgress(
          `回传本轮汇总：已处理（稍后回传大易） ${roundUploaded}，已跳过 ${roundSkipped}，等待中 ${roundWaiting}，失败 ${roundFailed}`,
          "info",
          4000,
        );
      }

      if (!shouldContinueResumeUpload(loopToken)) break;

      await humanCandidateGap("回传本轮结束");
      logResumeUploadProgress("回传本轮扫描完成，继续下一轮…", "info", 4000);
    } catch (error) {
      console.error("简历回传轮询出错:", error);
      logResumeUploadProgress(
        `简历回传轮询出错: ${error.message}`,
        "error",
        1000,
      );
      for (let t = 0; t < 10 && shouldContinueResumeUpload(loopToken); t++) {
        await new Promise((resolve) => setTimeout(resolve, 300));
      }
    }
  }
}

async function executeAskResumeLoop(loopToken) {
  while (shouldContinueAskResume(loopToken)) {
    try {
      if (!currentParser) break;

      // storage 兜底：停止信号可能只到了别的 frame
      try {
        const st = await chrome.storage.local.get(["isAskResumeRunning"]);
        if (st.isAskResumeRunning === false) {
          stopAskResume("已停止求简历", { silent: true });
          break;
        }
      } catch {
        /* ignore */
      }
      if (!shouldContinueAskResume(loopToken)) break;

      if (!(await refreshAskResumeLoopOwner())) {
        isAskResumeRunning = false;
        break;
      }
      if (!shouldContinueAskResume(loopToken)) break;

      const documents = getAllDocuments();
      const sessions = currentParser.collectChatSessionItems(documents);

      if (sessions.length === 0) {
        const diag = currentParser.diagnoseChatSessionScan(documents);
        sendMessage({
          type: "LOG_MESSAGE",
          data: {
            message: `未找到会话（扫描 ${diag.documents} 个文档；friend-list:${diag.friendList} listitem:${diag.roleList} geek-wrap:${diag.geekWrap}）`,
            type: "warning",
          },
        });
      } else {
        logAskResumeProgress(
          `扫描会话列表，共 ${sessions.length} 个会话`,
          "info",
          3000,
        );
      }

      let roundAsked = 0;
      let roundRejected = 0;
      let roundSaved = 0;
      let roundSkipped = 0;
      let roundWaiting = 0;
      const processedKeysThisRound = new Set();

      for (let i = 0; i < sessions.length; i++) {
        if (!shouldContinueAskResume(loopToken)) break;

        const session = sessions[i];
        const previewName = currentParser.getSessionDisplayName(session);

        try {
          const sessionKey = currentParser.getSessionKey(session);
          // 本轮同一 key 只处理一次（列表重复节点 / 重扫不刷「正在处理」）
          if (processedKeysThisRound.has(sessionKey)) {
            roundSkipped += 1;
            continue;
          }
          processedKeysThisRound.add(sessionKey);

          if (currentParser.isAskResumeSessionCompleted?.(sessionKey)) {
            const result = currentParser.buildFastSkipResult?.(
              session,
              "跳过（本会话已处理）",
            );
            if (result) {
              logAskResumeProgress(
                result.message,
                result.logType || "info",
                2000,
              );
              roundSkipped += 1;
              await humanCandidateGap("求简历跳过已处理");
              continue;
            }
          }

          // 真正要处理时才打「正在处理」，并短时去重（防多 frame / 重入刷屏）
          logAskResumeProgress(
            `正在处理第 ${i + 1}/${sessions.length} 个会话：${previewName}`,
            "info",
            2000,
          );

          if (!shouldContinueAskResume(loopToken)) break;
          const result = await currentParser.processAskResumeSession(session);
          if (!shouldContinueAskResume(loopToken)) break;

          if (result) {
            const personName = result.name || previewName;
            if (result.message) {
              sendMessage({
                type: "LOG_MESSAGE",
                data: {
                  message: result.message,
                  type: result.logType || "info",
                },
              });
            }
            if (result.saveResult?.message) {
              sendMessage({
                type: "LOG_MESSAGE",
                data: {
                  message: result.saveResult.message,
                  type: result.saveResult.ok ? "success" : "error",
                },
              });
            }
            if (isAskResumeReachedStatus(result.status)) {
              if (
                currentParser.shouldLogAskResumeOnce?.(result.key, "reached") !==
                false
              ) {
                logReached(personName);
                askResumeCount += 1;
              }
            } else if (isAskResumeSkippedStatus(result.status)) {
              if (
                currentParser.shouldLogAskResumeOnce?.(result.key, "skipped") !==
                false
              ) {
                logSkipped(personName);
              }
            }

            if (
              result.status === "asked" ||
              result.status === "ready_to_ask"
            ) {
              roundAsked += 1;
            } else if (
              result.status === "rejected" ||
              result.status === "ready_to_reject"
            ) {
              roundRejected += 1;
            } else if (
              result.status === "info_saved" ||
              result.status === "resume_ui_done"
            ) {
              roundSaved += 1;
            } else if (
              result.status === "skip_sent" ||
              result.status === "skip_done" ||
              result.status === "skip_initiator"
            ) {
              roundSkipped += 1;
            } else if (
              result.status === "wait_reply" ||
              result.status === "wait_button" ||
              result.status === "wait_chat" ||
              result.status === "wait_resume_ui" ||
              result.status === "wait_rate_limit"
            ) {
              roundWaiting += 1;
            }
          }
        } catch (sessionError) {
          logSkipped(previewName);
          sendMessage({
            type: "LOG_MESSAGE",
            data: {
              message: `${previewName}：处理失败 ${sessionError.message}`,
              type: "error",
            },
          });
        }

        if (currentParser.cleanupBetweenAskResumeSessions) {
          try {
            const cleanup = await currentParser.cleanupBetweenAskResumeSessions(
              previewName,
              session,
            );
            if (cleanup?.closed) {
              sendMessage({
                type: "LOG_MESSAGE",
                data: {
                  message: cleanup.hidden
                    ? `${previewName}：处理完毕，已关闭简历面板再切下一个`
                    : `${previewName}：处理完毕，简历面板未完全收起（${cleanup.stillReason || cleanup.reason || "未知"}），可能影响切换`,
                  type: cleanup.hidden ? "info" : "warning",
                },
              });
            }
          } catch (cleanupError) {
            sendMessage({
              type: "LOG_MESSAGE",
              data: {
                message: `${previewName}：切下一个前关闭简历失败 ${cleanupError.message}`,
                type: "warning",
              },
            });
          }
        }

        await humanCandidateGap("求简历下一位");
        if (!shouldContinueAskResume(loopToken)) break;
        await forcedRestIfNeeded("ask", () => shouldContinueAskResume(loopToken));
      }

      if (sessions.length > 0) {
        logAskResumeProgress(
          `本轮汇总：已求简历 ${roundAsked}，已保存简历信息 ${roundSaved}，已拒绝 ${roundRejected}，已跳过 ${roundSkipped}，等待中 ${roundWaiting}`,
          "info",
          4000,
        );
      }

      if (!shouldContinueAskResume(loopToken)) break;

      await humanCandidateGap("求简历本轮结束");
      logAskResumeProgress("本轮扫描完成，继续下一轮…", "info", 4000);
    } catch (error) {
      console.error("求简历轮询出错:", error);
      sendMessage({
        type: "LOG_MESSAGE",
        data: {
          message: `求简历轮询出错: ${error.message}`,
          type: "error",
        },
      });
      for (let t = 0; t < 10 && shouldContinueAskResume(loopToken); t++) {
        await new Promise((resolve) => setTimeout(resolve, 300));
      }
    }
  }
}

/**
 * @param {string} [reason]
 * @param {{ silent?: boolean }} [options]
 */
function stopAutoScroll(reason = "已停止自动滚动", options = {}) {
  const silent = options.silent === true;
  const wasRunning = isRunning;
  const isOwner = !!greetOwnerId;
  const count = matchCount;
  const skipCount = greetSkipCount;
  isRunning = false;
  // 使所有进行中的 executeScroll/processElement 立即失效
  greetLoopToken += 1;
  releaseGreetLoopOwner();
  lastBackgroundMode = null;
  setTabKeepAlive(false);

  // 只在真正停止运行时同步状态；弹窗点停止时 silent，避免与按钮日志重复
  if (wasRunning) {
    notifyRunStateStopped(reason, { silentLog: true });
  } else if (!silent) {
    try {
      chrome.storage.local.set({ isRunning: false });
    } catch {
      /* ignore */
    }
  }

  try {
    if (scrollInterval) {
      clearInterval(scrollInterval);
      scrollInterval = null;
    }
    lastProcessedPosition = -1;
    greetPriorityClicked = false;
    processedGreetNames.clear();

    if (currentParser) {
      try {
        document
          .querySelectorAll(
            `[class^="${currentParser.selectors.items}"], [class*=" ${currentParser.selectors.items}"]`,
          )
          .forEach((el) => {
            el.style.cssText = "";
          });
      } catch {
        /* ignore */
      }
    }

    if (wasRunning && isOwner && isExtensionValid()) {
      sendMessage({
        type: "LOG_MESSAGE",
        data: {
          message: `成功打招呼${count}人，跳过${skipCount}人`,
          type: "success",
        },
      });
      if (isTopFrame()) {
        showNotification(`成功打招呼${count}人，跳过${skipCount}人`, "status");
      }
    } else if (wasRunning && !isExtensionValid()) {
      console.warn("扩展已重新加载，自动滚动已停止");
    }
  } catch (error) {
    console.error("停止失败:", error);
  }
}

// 获取候选人详细信息
async function getCandidateInfo(candidate) {
  try {
    // 构建候选人信息字符串
    let info = `姓名：${candidate.name}\n`;

    const gender =
      currentParser?.resolveCandidateGender?.(candidate) ||
      candidate.gender ||
      "未知";
    info += `性别：${gender}\n`;

    if (candidate.age) info += `年龄：${candidate.age}\n`;
    if (candidate.education) info += `学历：${candidate.education}\n`;
    if (candidate.university) info += `学校：${candidate.university}\n`;
    if (candidate.experience) info += `经验：${candidate.experience}\n`;
    if (candidate.salary) info += `期望薪资：${candidate.salary}\n`;
    if (candidate.location) info += `期望地点：${candidate.location}\n`;

    // 添加额外信息
    if (candidate.extraInfo && candidate.extraInfo.length > 0) {
      info += `其他信息：\n`;
      candidate.extraInfo.forEach((item) => {
        info += `- ${item.type}: ${item.value}\n`;
      });
    }
    if (candidate.colleagueContactedInfo) {
      info += `同事沟通过候选人的信息：\n${candidate.colleagueContactedInfo}\n`;
    }

    if (candidate.activeText) {
      info += `在线状态：${candidate.activeText}\n`;
    }

    return info;
  } catch (error) {
    console.error("获取候选人信息失败:", error);
    return `姓名：${candidate.name}`;
  }
}

function formatKeywordList(keywords) {
  return (keywords || []).filter(Boolean).join("、");
}

function ensureAgentText(value) {
  if (value == null) return "";
  if (typeof value === "string") return value.trim();
  if (typeof value === "object") {
    try {
      return JSON.stringify(value);
    } catch {
      return "";
    }
  }
  return String(value).trim();
}

function buildAIAgentInput(simpleCandidateInfo) {
  const settings = currentParser.aiSettings || {};
  const resume = ensureAgentText(simpleCandidateInfo);
  // 空关键词不要传 ""，部分工作流会当成「未检测到输入」
  const includeKeywords = formatKeywordList(settings.keywords) || "无";
  const excludeKeywords = formatKeywordList(settings.excludeKeywords) || "无";
  return {
    input_text_0: resume,
    input_text_1: includeKeywords,
    input_text_2: excludeKeywords,
  };
}

function buildAskResumeAIAgentInput(simpleCandidateInfo) {
  const settings = currentParser.askResumeSettings || {};
  const resume = ensureAgentText(simpleCandidateInfo);
  const includeKeywords = formatKeywordList(settings.keywords) || "无";
  const excludeKeywords = formatKeywordList(settings.excludeKeywords) || "无";
  return {
    input_text_0: resume,
    input_text_1: includeKeywords,
    input_text_2: excludeKeywords,
  };
}

/** AI 不可用时，用本地关键词做兜底判断（有关键词才生效） */
function localKeywordDecision(simpleCandidateInfo, settingsOverride = null) {
  const settings =
    settingsOverride ||
    currentParser?.askResumeSettings ||
    currentParser?.aiSettings ||
    {};
  const text = ensureAgentText(simpleCandidateInfo).toLowerCase();
  if (!text) {
    return { isok: false, msg: "候选人信息为空，无法本地判断" };
  }

  const excludeKeywords = settings.excludeKeywords || [];
  const hitExclude = excludeKeywords.filter(
    (k) => k && text.includes(String(k).toLowerCase()),
  );
  if (hitExclude.length) {
    return {
      isok: false,
      msg: `本地排除：${hitExclude.slice(0, 3).join("、")}`,
    };
  }

  const keywords = settings.keywords || [];
  if (!keywords.length) {
    return {
      isok: false,
      msg: "AI不可用，且未配置筛选关键词，无法本地匹配",
    };
  }

  const hit = keywords.filter(
    (k) => k && text.includes(String(k).toLowerCase()),
  );
  if (hit.length) {
    return {
      isok: true,
      msg: `本地匹配：${hit.slice(0, 5).join("、")}`,
    };
  }
  return { isok: false, msg: "本地匹配：未命中筛选关键词" };
}

function matchesAskResumeExcludeKeywords(text) {
  const excludeKeywords = currentParser.askResumeSettings?.excludeKeywords || [];
  if (!excludeKeywords.length || !text) return false;
  const lowerText = String(text).toLowerCase();
  return excludeKeywords.some(
    (keyword) => keyword && lowerText.includes(String(keyword).toLowerCase()),
  );
}

async function performAskResumeAIDecision(simpleCandidateInfo) {
  if (window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG?.forceAiDecisionNo === true) {
    sendMessage({
      type: "LOG_MESSAGE",
      data: {
        message: "调试：强制判定为否（forceAiDecisionNo）",
        type: "warning",
      },
    });
    return {
      isok: false,
      msg: "调试：强制判定为否（forceAiDecisionNo）",
    };
  }
  if (window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG?.forceAiDecisionYes === true) {
    sendMessage({
      type: "LOG_MESSAGE",
      data: {
        message: "调试：强制判定为是（forceAiDecisionYes）",
        type: "warning",
      },
    });
    return {
      isok: true,
      msg: "调试：强制判定为是（forceAiDecisionYes）",
    };
  }

  const agentInput = buildAskResumeAIAgentInput(simpleCandidateInfo);
  if (!agentInput.input_text_0) {
    return { isok: false, msg: "简历文本为空，跳过 AI" };
  }

  const timeoutMs =
    window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG?.aiTimeoutMs ??
    window.招聘速聊助手_CONFIG?.EXECUTE_TEXT_API?.timeoutMs ??
    180000;

  sendMessage({
    type: "LOG_MESSAGE",
    data: {
      message: `提交AI分析（execute_text，简历 ${agentInput.input_text_0.length} 字，关键词: ${agentInput.input_text_1}）`,
      type: "info",
    },
  });

  const result = await sendYiliAgentRequest({ ...agentInput, timeoutMs });
  if (!result.success) {
    const local = localKeywordDecision(
      simpleCandidateInfo,
      currentParser?.askResumeSettings,
    );
    sendMessage({
      type: "LOG_MESSAGE",
      data: {
        message: `AI失败后本地判断：${local.msg}`,
        type: local.isok ? "success" : "warning",
      },
    });
    return {
      isok: local.isok,
      msg: `AI失败后本地判断：${local.msg}`,
    };
  }

  const decision = parseAIResponse(result.response);
  if (
    decision.msg === "解析失败" ||
    /未检测到输入文本|AI 业务错误|请求失败/i.test(decision.msg || "")
  ) {
    const local = localKeywordDecision(
      simpleCandidateInfo,
      currentParser?.askResumeSettings,
    );
    sendMessage({
      type: "LOG_MESSAGE",
      data: {
        message: `AI失败后本地判断：${local.msg}`,
        type: local.isok ? "success" : "warning",
      },
    });
    return {
      isok: local.isok,
      msg: `AI失败后本地判断：${local.msg}`,
    };
  }

  return decision;
}

async function sendYiliAgentRequest(agentInput) {
  try {
    const result = await chrome.runtime.sendMessage({
      action: "YILI_AGENT_REQUEST",
      ...agentInput,
    });

    if (!result?.success) {
      const errorMsg = result?.error || "AI 请求失败";
      sendMessage({
        type: "LOG_MESSAGE",
        data: { message: errorMsg, type: "error" },
      });
      return { success: false, error: errorMsg };
    }

    return {
      success: true,
      response: result.response,
    };
  } catch (error) {
    console.error("AI请求失败:", error);
    return {
      success: false,
      error: error.message || "AI请求失败",
    };
  }
}

/** 从伊利/影刀风格响应里提取业务错误文案 */
function extractAgentBusinessError(response) {
  if (!response || typeof response !== "object") return "";
  if (response.success === false || response.ok === false) {
    return (
      response.msg ||
      response.message ||
      response.error?.message ||
      response.error ||
      ""
    );
  }
  const code = response.code;
  if (
    code != null &&
    code !== 0 &&
    code !== 200 &&
    code !== "0" &&
    code !== "200"
  ) {
    return (
      response.msg ||
      response.message ||
      `AI 业务错误 code=${code}`
    );
  }
  return "";
}

function normalizeAIResponseText(response) {
  if (response == null) return "";
  if (typeof response === "string") return response;

  const businessError = extractAgentBusinessError(response);
  if (businessError) return String(businessError);

  const visit = (value, depth = 0) => {
    if (depth > 6 || value == null) return "";
    if (typeof value === "string") return value;
    if (typeof value !== "object") return String(value);

    if (value.decision != null) {
      return JSON.stringify(value);
    }

    // 优先读工作流标准输出字段
    for (const key of [
      "output_text_0",
      "output_text_1",
      "output",
      "data",
      "result",
      "text",
      "message",
      "msg",
      "content",
      "answer",
      "response",
    ]) {
      if (value[key] != null) {
        const nested = visit(value[key], depth + 1);
        if (nested) return nested;
      }
    }

    // 兼容 output_text_* 动态字段
    for (const key of Object.keys(value)) {
      if (/^output_text_\d+$/i.test(key) && value[key] != null) {
        const nested = visit(value[key], depth + 1);
        if (nested) return nested;
      }
    }

    return JSON.stringify(value);
  };

  return visit(response);
}

function matchesExcludeKeywords(text) {
  const excludeKeywords = currentParser.aiSettings?.excludeKeywords || [];
  if (!excludeKeywords.length || !text) return false;
  const lowerText = String(text).toLowerCase();
  return excludeKeywords.some(
    (keyword) => keyword && lowerText.includes(String(keyword).toLowerCase()),
  );
}

// 第一个AI决策点：决定是否查看候选人详细信息
async function performAIClickDecision(simpleCandidateInfo, candidate) {
  const agentInput = buildAIAgentInput(simpleCandidateInfo);

  if (!agentInput.input_text_0) {
    const msg = "简历文本为空，跳过 AI";
    sendMessage({
      type: "LOG_MESSAGE",
      data: { message: msg, type: "error" },
    });
    return { isok: false, msg };
  }

  try {
    showAIDecisionModal();

    const timeoutMs =
      window.招聘速聊助手_CONFIG?.EXECUTE_TEXT_API?.timeoutMs ??
      window.招聘速聊助手_CONFIG?.ASK_RESUME_CONFIG?.aiTimeoutMs ??
      180000;

    sendMessage({
      type: "LOG_MESSAGE",
      data: {
        message: `提交AI分析（execute_text，简历 ${agentInput.input_text_0.length} 字，关键词: ${agentInput.input_text_1}）`,
        type: "info",
      },
    });

    const result = await sendYiliAgentRequest({ ...agentInput, timeoutMs });

    hideAIDecisionModal();

    if (result.success) {
      const decision = parseAIResponse(result.response);
      // 业务失败被 parse 成「解析失败」时，走本地关键词兜底
      if (
        decision.msg === "解析失败" ||
        /未检测到输入文本|AI 业务错误|请求失败/i.test(decision.msg || "")
      ) {
        const local = localKeywordDecision(simpleCandidateInfo);
        sendMessage({
          type: "LOG_MESSAGE",
          data: {
            message: `AI不可用，改用本地判断: ${local.msg}`,
            type: local.isok ? "success" : "warning",
          },
        });
        const saveResult = await currentParser.saveAIRecordToLocal(candidate, {
          ...agentInput,
          aiResponseRaw: result.response,
          aiDecision: local.isok ? "是" : "否",
          aiReason: `AI失败后本地判断：${local.msg}`,
          greeted: false,
        });
        return { ...local, saveResult };
      }

      const saveResult = await currentParser.saveAIRecordToLocal(candidate, {
        ...agentInput,
        aiResponseRaw: result.response,
        aiDecision: decision.isok ? "是" : "否",
        aiReason: decision.msg,
        greeted: false,
      });
      return { ...decision, saveResult };
    }

    console.error("AI点击决策失败:", result.error);
    const local = localKeywordDecision(simpleCandidateInfo);
    sendMessage({
      type: "LOG_MESSAGE",
      data: {
        message: `AI请求失败（${result.error || "未知"}），改用本地判断: ${local.msg}`,
        type: local.isok ? "success" : "warning",
      },
    });
    const saveResult = await currentParser.saveAIRecordToLocal(candidate, {
      ...agentInput,
      aiResponseRaw: result.error || "AI 请求失败",
      aiDecision: local.isok ? "是" : "否",
      aiReason: `AI失败后本地判断：${local.msg}`,
      greeted: false,
    });
    return { ...local, saveResult };
  } catch (error) {
    hideAIDecisionModal();
    console.error("AI点击决策异常:", error);
    const local = localKeywordDecision(simpleCandidateInfo);
    return {
      isok: local.isok,
      msg: `AI异常后本地判断：${local.msg}`,
    };
  }
}

// 解析AI响应
function parseAIResponse(response) {
  const businessError = extractAgentBusinessError(response);
  if (businessError) {
    sendMessage({
      type: "LOG_MESSAGE",
      data: {
        message: `AI业务错误: ${businessError}`,
        type: "error",
      },
    });
    return { isok: false, msg: businessError };
  }

  const text = normalizeAIResponseText(response);

  try {
    const jsonMatch = text.match(/\{[\s\S]*?"decision"[\s\S]*?\}/);
    if (jsonMatch) {
      const aiResponse = JSON.parse(jsonMatch[0]);
      const decision = String(aiResponse.decision || "").includes("是");
      const reason = aiResponse.reason || "未提供原因";

      sendMessage({
        type: "LOG_MESSAGE",
        data: {
          message: `AI决策: ${aiResponse.decision} (${reason})`,
          type: decision ? "success" : "info",
        },
      });

      return { isok: decision, msg: reason };
    }
  } catch (error) {
    console.warn("解析JSON失败:", error);
  }

  const cleanResponse = text.trim().toLowerCase();
  // 避免把「未检测到」里的无关字误判成是/否
  if (/未检测|失败|错误|error|exception/.test(cleanResponse)) {
    sendMessage({
      type: "LOG_MESSAGE",
      data: {
        message: `AI返回异常: ${text.trim().slice(0, 160)}`,
        type: "error",
      },
    });
    return { isok: false, msg: text.trim().slice(0, 80) || "AI返回异常" };
  }

  if (
    (cleanResponse.includes("是") || cleanResponse.includes("yes")) &&
    !cleanResponse.includes("否")
  ) {
    sendMessage({
      type: "LOG_MESSAGE",
      data: { message: "AI决策: 是", type: "success" },
    });
    return { isok: true, msg: "AI 决策通过" };
  }

  if (cleanResponse.includes("否") || cleanResponse.includes("no")) {
    sendMessage({
      type: "LOG_MESSAGE",
      data: { message: "AI决策: 否", type: "info" },
    });
    return { isok: false, msg: "AI 决策不通过" };
  }

  console.warn("AI响应格式异常:", text);
  sendMessage({
    type: "LOG_MESSAGE",
    data: {
      message: `格式异常 原文: ${text.trim().slice(0, 200)}`,
      type: "error",
    },
  });
  return { isok: false, msg: "解析失败" };
}

// 创建AI决策动画弹框
function createAIDecisionModal() {
  // 检查是否已存在
  if (document.getElementById("ai-decision-modal")) {
    return document.getElementById("ai-decision-modal");
  }

  const modal = document.createElement("div");
  modal.id = "ai-decision-modal";
  modal.style.cssText = `
		position: fixed;
		top: 20px;
		right: 20px;
		width: 200px;
		height: 120px;
		background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
		border-radius: 15px;
		box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
		z-index: 10000;
		display: none;
		animation: none;
		overflow: hidden;
	`;

  modal.innerHTML = `
		<div style="
			position: relative;
			width: 100%;
			height: 100%;
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			color: white;
			font-family: 'Arial', sans-serif;
		">
			<div style="
				width: 40px;
				height: 40px;
				border: 3px solid rgba(255, 255, 255, 0.3);
				border-top: 3px solid white;
				border-radius: 50%;
				animation: spin 1s linear infinite;
				margin-bottom: 10px;
			"></div>
			<div style="
				font-size: 14px;
				font-weight: bold;
				margin-bottom: 5px;
				text-align: center;
			">AI正在思考...</div>
			<div style="
				font-size: 12px;
				opacity: 0.8;
				text-align: center;
			">请稍候</div>
		</div>
	`;

  // 添加CSS动画
  const style = document.createElement("style");
  style.textContent = `
		@keyframes slideInRight {
			from {
				transform: translateX(100%);
				opacity: 0;
			}
			to {
				transform: translateX(0);
				opacity: 1;
			}
		}

		@keyframes slideOutRight {
			from {
				transform: translateX(0);
				opacity: 1;
			}
			to {
				transform: translateX(100%);
				opacity: 0;
			}
		}

		@keyframes spin {
			0% { transform: rotate(0deg); }
			100% { transform: rotate(360deg); }
		}

		@keyframes pulse {
			0%, 100% { transform: scale(1); }
			50% { transform: scale(1.05); }
		}
	`;

  document.head.appendChild(style);
  document.body.appendChild(modal);

  return modal;
}

// 显示AI决策动画
function showAIDecisionModal() {
  const modal = createAIDecisionModal();
  if (modal) {
    // 重置状态
    modal.style.display = "block";
    modal.style.animation = "none";
    modal.style.transform = "translateX(100%)";
    modal.style.opacity = "0";

    // 强制重绘
    modal.offsetHeight;

    // 开始动画
    modal.style.animation = "slideInRight 0.5s ease-out";
    modal.style.transform = "";
    modal.style.opacity = "";
  }
}

// 隐藏AI决策动画
function hideAIDecisionModal() {
  const modal = document.getElementById("ai-decision-modal");
  if (modal) {
    modal.style.animation = "slideOutRight 0.5s ease-out";
    setTimeout(() => {
      modal.style.display = "none";
      // 重置动画状态，为下次显示做准备
      modal.style.animation = "none";
      modal.style.transform = "";
      modal.style.opacity = "";
    }, 500);
  }
}

// 添加一个检查扩展状态的函数
function isExtensionValid() {
  return chrome.runtime && chrome.runtime.id;
}

// 初始化连接
function initializeConnection() {
  try {
    port = chrome.runtime.connect({ name: "content-script-connection" });
    // port.onDisconnect.addListener(() => {
    //     console.log('连接断开，尝试重新连接');
    //     port = null;
    //     setTimeout(initializeConnection, 1000);
    // });
    return true;
  } catch (error) {
    console.error("建立连接失败:", error);
    return false;
  }
}

// 封装消息发送函数
async function sendMessage(message) {
  if (
    message?.type === "LOG_MESSAGE" &&
    window.招聘速聊助手_CONFIG?.VERBOSE_RUNTIME_LOGS === false &&
    !isStatusRuntimeLog(message.data?.message)
  ) {
    return { ok: true, muted: true };
  }

  const MAX_RETRIES = 3;
  let retryCount = 0;

  while (retryCount < MAX_RETRIES) {
    try {
      if (!isExtensionValid()) {
        console.warn("扩展上下文已失效，请刷新页面");
        throw new Error("扩展上下文已失效");
      }

      // 确保连接存在
      if (!port && !initializeConnection()) {
        throw new Error("无法建立连接");
      }

      return await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(message, function (response) {
          const lastError = chrome.runtime.lastError;
          if (lastError) {
            const errText = lastError.message || "";
            // 日志/状态广播无回包时不要重发，否则同一条会刷 2～3 遍
            if (
              message?.type === "LOG_MESSAGE" ||
              message?.type === "MATCH_SUCCESS" ||
              message?.type === "RUN_STATE_CHANGED" ||
              /The message port closed|Receiving end does not exist/i.test(
                errText,
              )
            ) {
              resolve(response || { ok: true, ignored: true });
              return;
            }
            console.error("发送消息失败:", lastError);
            reject(lastError);
            return;
          }
          resolve(response);
        });
      });
    } catch (error) {
      retryCount++;
      console.error(`发送消息失败 (尝试 ${retryCount}/${MAX_RETRIES}):`, error);

      if (retryCount === MAX_RETRIES) {
        throw error;
      }

      // 等待后重试
      await new Promise((resolve) => setTimeout(resolve, 1000 * retryCount));
    }
  }
}

function createDraggablePrompt() {
  return;
  // 如果已经存在询问框，先移除它
  if (currentPrompt) {
    currentPrompt.remove();
  }

  const prompt = document.createElement("div");
  currentPrompt = prompt; // 设置全局变量
  prompt.className = "招聘速聊助手-prompt";
  prompt.style.position = "fixed";
  prompt.style.top = "20px";
  prompt.style.right = "20px";
  prompt.style.padding = "10px";
  prompt.style.backgroundColor = "#f9f9f9";
  prompt.style.border = "1px solid #ddd";
  prompt.style.borderRadius = "10px";
  prompt.style.boxShadow = "0 6px 20px rgba(0,0,0,0.5)";
  prompt.style.zIndex = "9999";
  prompt.style.transition = "opacity 0.3s ease, transform 0.3s ease";
  prompt.style.opacity = "0";
  prompt.style.transform = "translateY(-10px)";
  prompt.innerHTML = `
        <div style='cursor: move; display: flex; justify-content: space-between; align-items: center;'>
            <div style='display: flex; align-items: center;'>
                <strong style='color: #1a73e8; margin-right: 5px; font-size: 16px;'>招聘速聊助手</strong>
                <span style='background-color: #e8f0fe; color: #1a73e8; padding: 2px 6px; border-radius: 10px; font-size: 12px;'>v${window.招聘速聊助手_CONFIG ? window.招聘速聊助手_CONFIG.VERSION : chrome.runtime.getManifest().version}</span>
            </div>
            <span style='font-size: 12px; color: #999;'>拖动</span>
        </div>
        <div style='margin-top: 15px; text-align: center;'>
            <div style='margin-bottom: 15px; font-size: 14px;'>是否打开招聘速聊助手？</div>
            <div>
                <button id='open-plugin' style='
                    padding: 5px 20px;
                    background-color: #1a73e8;
                    color: white;
                    border: none;
                    border-radius: 5px;
                    cursor: pointer;
                    transition: background-color 0.2s, transform 0.2s;
                    font-weight: 500;
                '>是</button>
                <button id='close-prompt' style='
                    padding: 5px 20px;
                    background-color: #ff4444;
                    color: white;
                    border: none;
                    border-radius: 5px;
                    cursor: pointer;
                    margin-left: 10px;
                    transition: background-color 0.2s, transform 0.2s;
                    font-weight: 500;
                '>取消 (10s)</button>
            </div>
        </div>
    `;

  document.body.appendChild(prompt);

  // 添加按钮悬停效果
  const buttons = prompt.querySelectorAll("button");
  buttons.forEach((button) => {
    button.addEventListener("mouseover", () => {
      button.style.opacity = "0.9";
      button.style.transform = "translateY(-1px)";
    });
    button.addEventListener("mouseout", () => {
      button.style.opacity = "1";
      button.style.transform = "translateY(0)";
    });
  });

  // 弹出动画
  setTimeout(() => {
    prompt.style.opacity = "1";
    prompt.style.transform = "translateY(0)";
  }, 10);

  // 倒计时功能
  let countdown = 10;
  const closeButton = prompt.querySelector("#close-prompt");
  const countdownInterval = setInterval(() => {
    countdown--;
    if (countdown >= 0) {
      closeButton.textContent = `取消 (${countdown}s)`;
    }
    if (countdown === 0) {
      clearInterval(countdownInterval);
      prompt.style.opacity = "0";
      prompt.style.transform = "translateY(-10px)";
      setTimeout(() => {
        prompt.remove();
        currentPrompt = null; // 清除全局变量
      }, 300);
    }
  }, 1000);

  // 拖拽功能
  let isDragging = false;
  let offsetX, offsetY;

  const dragHandle = prompt.querySelector('div[style*="cursor: move"]');
  dragHandle.addEventListener("mousedown", (e) => {
    isDragging = true;
    offsetX = e.clientX - prompt.getBoundingClientRect().left;
    offsetY = e.clientY - prompt.getBoundingClientRect().top;

    // 添加拖动时的视觉反馈
    prompt.style.boxShadow = "0 8px 28px rgba(0,0,0,0.28)";
  });

  document.addEventListener("mousemove", (e) => {
    if (isDragging) {
      prompt.style.left = e.clientX - offsetX + "px";
      prompt.style.top = e.clientY - offsetY + "px";
      prompt.style.right = "auto"; // 清除right属性以防止定位冲突
    }
  });

  document.addEventListener("mouseup", () => {
    if (isDragging) {
      isDragging = false;
      // 恢复原来的阴影
      prompt.style.boxShadow = "0 4px 20px rgba(0,0,0,0.2)";
    }
  });

  // 事件监听器
  const openButton = prompt.querySelector("#open-plugin");

  openButton.addEventListener("click", () => {
    clearInterval(countdownInterval); // 清除倒计时
    // 添加点击动画
    prompt.style.transform = "scale(0.95)";
    setTimeout(() => {
      // 打开插件的逻辑
      chrome.runtime.sendMessage({ action: "OPEN_PLUGIN" }, (response) => {
        if (chrome.runtime.lastError) {
          console.error("发送消息失败:", chrome.runtime.lastError);
        } else {
          console.log("插件已打开");
        }
      });
      // 淡出动画
      prompt.style.opacity = "0";
      prompt.style.transform = "translateY(-10px)";
      setTimeout(() => {
        prompt.remove();
        currentPrompt = null; // 清除全局变量
      }, 300);
    }, 150);
  });

  closeButton.addEventListener("click", () => {
    clearInterval(countdownInterval); // 清除倒计时
    // 添加关闭动画
    prompt.style.opacity = "0";
    prompt.style.transform = "translateY(-10px)";
    setTimeout(() => {
      prompt.remove();
      currentPrompt = null; // 清除全局变量
    }, 300);
  });
}

// 初始化（异步，启动任务时还会 ensureParserReady 再试一次）
initializeParser().then((result) => {
  if (!result?.ok && isTopFrame()) {
    console.warn("[招聘速聊助手] 首屏解析器未就绪:", result?.error || lastParserInitError);
  }
});

// 监听窗口可见性变化，检测最小化状态
document.addEventListener("visibilitychange", function () {
  if (isRunning) {
    handleWindowMinimized();
  }
});
window.addEventListener("blur", () => {
  if (isRunning) handleWindowMinimized();
});
window.addEventListener("focus", () => {
  if (isRunning) handleWindowMinimized();
});

// 处理窗口最小化的函数
function handleWindowMinimized() {
  try {
    if (isRunning) {
      logBackgroundModeIfChanged();
    }
  } catch (error) {
    console.error("处理窗口可见性变化时出错:", error);
  }
}

// 初始化连接
initializeConnection();

/**
 * 停止信号跨 frame 广播：
 * 弹窗 / 其他 frame 写入 storage 后，本 frame 立即停循环
 * （tabs.sendMessage 不一定到达所有 frame，这是主修复点）
 */
try {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;

    // storage 广播只负责停循环，不再打日志（弹窗点停止时已写一条）
    if (
      Object.prototype.hasOwnProperty.call(changes, "isRunning") &&
      changes.isRunning.newValue === false &&
      isRunning
    ) {
      stopAutoScroll("已停止自动滚动", { silent: true });
    }

    if (
      Object.prototype.hasOwnProperty.call(changes, "isAskResumeRunning") &&
      changes.isAskResumeRunning.newValue === false &&
      isAskResumeRunning
    ) {
      stopAskResume("已停止求简历", { silent: true });
    }

    if (
      Object.prototype.hasOwnProperty.call(changes, "isResumeUploadRunning") &&
      changes.isResumeUploadRunning.newValue === false &&
      isResumeUploadRunning
    ) {
      stopResumeUpload("已停止简历回传", { silent: true });
    }
  });
} catch (error) {
  console.warn("注册 storage 停止监听失败:", error);
}
