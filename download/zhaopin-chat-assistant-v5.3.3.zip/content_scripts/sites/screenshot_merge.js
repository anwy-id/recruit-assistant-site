/**
 * 将多张简历截图按文件名末尾 _数字 排序后纵向拼接为一张长图
 */

/**
 * 从文件名或标签中解析末尾序号，如 name_20250625120000_3.png → 3
 * @param {string|number} value
 */
function parseTrailingIndex(value) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value;
  }
  const text = String(value || "");
  const match = text.match(/_(\d+)(?:\.[^./\\]+)?$/);
  return match ? parseInt(match[1], 10) : 0;
}

/**
 * @param {Array<string|{ dataUrl: string, index?: number, filename?: string }>} parts
 */
function normalizeScreenshotParts(parts) {
  return (parts || []).map((part, arrayIndex) => {
    if (typeof part === "string") {
      return {
        dataUrl: part,
        index: arrayIndex + 1,
      };
    }
    return {
      dataUrl: part.dataUrl || "",
      index:
        part.index ?? (parseTrailingIndex(part.filename) || arrayIndex + 1),
      filename: part.filename || "",
    };
  });
}

/**
 * @param {Array<{ dataUrl: string, index: number }>} parts
 */
function sortScreenshotParts(parts) {
  return [...parts].sort((a, b) => a.index - b.index);
}

function loadImageFromDataUrl(dataUrl) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("截图加载失败"));
    img.src = dataUrl;
  });
}

/**
 * 纵向拼接多张截图，返回 PNG data URL（base64）
 * @param {Array<string|{ dataUrl: string, index?: number, filename?: string }>} parts
 * @param {{ background?: string }} [options]
 * @returns {Promise<string>}
 */
async function stitchScreenshotParts(parts, options = {}) {
  const normalized = sortScreenshotParts(
    normalizeScreenshotParts(parts).filter((item) => item.dataUrl),
  );

  if (!normalized.length) {
    throw new Error("没有可拼接的截图");
  }

  if (normalized.length === 1) {
    return normalized[0].dataUrl;
  }

  const images = await Promise.all(
    normalized.map((item) => loadImageFromDataUrl(item.dataUrl)),
  );

  const width = Math.max(
    ...images.map((img) => img.naturalWidth || img.width || 0),
  );
  const totalHeight = images.reduce(
    (sum, img) => sum + (img.naturalHeight || img.height || 0),
    0,
  );

  if (!width || !totalHeight) {
    throw new Error("截图尺寸无效，无法拼接");
  }

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = totalHeight;
  const ctx = canvas.getContext("2d");
  if (!ctx) {
    throw new Error("无法创建画布上下文");
  }

  ctx.fillStyle = options.background || "#ffffff";
  ctx.fillRect(0, 0, width, totalHeight);

  let offsetY = 0;
  for (const img of images) {
    const imgWidth = img.naturalWidth || img.width;
    const imgHeight = img.naturalHeight || img.height;
    ctx.drawImage(img, 0, offsetY, imgWidth, imgHeight);
    offsetY += imgHeight;
  }

  return canvas.toDataURL("image/png");
}

/**
 * 根据截图文件名列表生成带序号的拼接输入
 * @param {string[]} dataUrls
 * @param {string[]} filenames
 */
function buildPartsFromFilenames(dataUrls, filenames) {
  return (dataUrls || []).map((dataUrl, index) => ({
    dataUrl,
    filename: filenames?.[index] || `${index + 1}`,
    index: parseTrailingIndex(filenames?.[index]) || index + 1,
  }));
}

export {
  parseTrailingIndex,
  normalizeScreenshotParts,
  sortScreenshotParts,
  stitchScreenshotParts,
  buildPartsFromFilenames,
};

if (typeof window !== "undefined") {
  window.招聘速聊助手ScreenshotMerge = {
    parseTrailingIndex,
    stitchScreenshotParts,
    buildPartsFromFilenames,
  };
}