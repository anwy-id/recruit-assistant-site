/**
 * 在线简历截图模块
 * 使用 chrome.tabs.captureVisibleTab 绕过 Canvas 跨域限制，
 * 再按简历区域裁剪，避免把整页（聊天列表等）回传给图片分析接口。
 */

const LOG_PREFIX = "[招聘速聊助手截图]";

const SCROLL_CONTAINER_SELECTORS = [
  ".resume-detail-main",
  ".resume-content",
  ".resume-detail-wrap",
  ".resume-detail-content",
  '[class*="resume-detail-main"]',
  '[class*="resume-detail-wrap"]',
  '[class*="resume-detail-content"]',
  '[class*="resume-content"]',
  '[class*="resume-page"]',
  '[class*="resume-dialog"]',
  '[class*="slide-content"]',
  '[class*="slide-wrap"]',
  '[class*="geek-detail"]',
  '[class*="cv-content"]',
  '[class*="profile-content"]',
];

const RESUME_ROOT_SELECTORS = [
  ".resume-detail-wrap",
  '[class*="resume-page"]',
  '[class*="resume-detail"]',
  '[class*="resume-dialog"]',
  '[class*="resume-box"]',
  '[class*="slide-content"]',
  '[class*="slide-wrap"]',
  '[class*="geek-detail"]',
  ".dialog-wrap.active",
  '[class*="dialog-wrap"].active',
  '[class*="boss-layer"]',
];

const RESUME_CLASS_RE =
  /resume-detail|resume-page|resume-content|resume-dialog|resume-box|geek-detail|geek-resume|cv-content|profile-content|slide-content|slide-wrap/i;

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function normalizeDoc(doc) {
  try {
    if (doc && doc.tagName === "IFRAME" && doc.contentDocument) {
      return doc.contentDocument;
    }
    if (doc && doc.document && typeof doc.querySelector !== "function") {
      return doc.document;
    }
  } catch (e) {
    console.warn(`${LOG_PREFIX} 规范化文档对象失败:`, e);
  }

  if (!doc || typeof doc.querySelector !== "function") {
    return typeof document !== "undefined" ? document : null;
  }

  return doc;
}

function collectDocuments(rootDocs, depth = 0, bucket = []) {
  const items = Array.isArray(rootDocs) ? rootDocs : [rootDocs];
  for (const item of items) {
    const doc = normalizeDoc(item);
    if (!doc || bucket.includes(doc)) continue;
    bucket.push(doc);
    if (depth >= 3) continue;

    doc.querySelectorAll("iframe").forEach((iframe) => {
      try {
        const iframeDoc =
          iframe.contentDocument ||
          (iframe.contentWindow && iframe.contentWindow.document);
        if (iframeDoc) {
          collectDocuments(iframeDoc, depth + 1, bucket);
        }
      } catch (e) {
        console.warn(`${LOG_PREFIX} 访问 iframe 时出错，跳过该节点:`, e);
      }
    });
  }
  return bucket;
}

function isElementVisible(el) {
  if (!el || !el.getBoundingClientRect) return false;
  const rect = el.getBoundingClientRect();
  if (rect.width < 80 || rect.height < 80) return false;
  const style = el.ownerDocument?.defaultView?.getComputedStyle?.(el);
  if (!style) return rect.width > 0 && rect.height > 0;
  return style.display !== "none" && style.visibility !== "hidden";
}

function isExcludedCropTarget(el) {
  return !!el?.closest?.(
    '[class*="friend-list"], [class*="geek-list"], [role="group"] [role="listitem"]',
  );
}

function getOverflowScrollScore(el) {
  if (!el || !isElementVisible(el)) return -1;
  const extra = el.scrollHeight - el.clientHeight;
  if (extra <= 10 || el.clientHeight < 120) return -1;

  const style = el.ownerDocument?.defaultView?.getComputedStyle?.(el);
  const overflowY = style?.overflowY || "";
  const canScroll =
    overflowY === "auto" ||
    overflowY === "scroll" ||
    overflowY === "overlay";

  return extra + (canScroll ? 100000 : 0) + Math.min(el.clientHeight, 3000);
}

function collectResumeRoots(doc) {
  const roots = [];
  const seen = new Set();

  const pushRoot = (el, source) => {
    if (!el || seen.has(el) || !isElementVisible(el)) return;
    if (isExcludedCropTarget(el)) return;
    const rect = el.getBoundingClientRect();
    if (rect.width < 160 || rect.height < 160) return;
    seen.add(el);
    roots.push({ el, source });
  };

  for (const selector of RESUME_ROOT_SELECTORS) {
    doc.querySelectorAll(selector).forEach((el) => pushRoot(el, selector));
  }

  return roots;
}

function findBestScrollableInSubtree(root, source = "subtree") {
  let best = null;
  let bestScore = -1;
  let bestSource = source;
  const stack = [root];

  while (stack.length) {
    const el = stack.pop();
    if (!el || el.nodeType !== 1) continue;

    const score = getOverflowScrollScore(el);
    if (score > bestScore) {
      bestScore = score;
      best = el;
      bestSource = `${source}>${el.className || el.tagName}`;
    }

    for (const child of el.children) {
      stack.push(child);
    }
  }

  return best ? { element: best, source: bestSource, score: bestScore } : null;
}

function resolveScrollContainer(rootDocs) {
  const docs = collectDocuments(rootDocs);
  let best = null;
  let bestScore = -1;
  let bestSource = "";

  for (const doc of docs) {
    for (const selector of SCROLL_CONTAINER_SELECTORS) {
      doc.querySelectorAll(selector).forEach((el) => {
        if (isExcludedCropTarget(el)) return;
        const score = getOverflowScrollScore(el);
        if (score > bestScore) {
          bestScore = score;
          best = el;
          bestSource = `selector:${selector}`;
        }
      });
    }

    for (const { el, source } of collectResumeRoots(doc)) {
      const found = findBestScrollableInSubtree(el, `root:${source}`);
      if (found && found.score > bestScore) {
        bestScore = found.score;
        best = found.element;
        bestSource = found.source;
      }
    }
  }

  if (best) {
    return { element: best, source: bestSource, score: bestScore };
  }

  return null;
}

function getTopWindow() {
  try {
    if (window.top && window.top.innerWidth) return window.top;
  } catch {
    /* 跨域顶层窗口读不到 */
  }
  return window;
}

/**
 * 把元素矩形映射到标签页顶层视口坐标（处理同域 iframe 偏移）
 * @param {Element} el
 */
function mapElementRectToTopViewport(el) {
  if (!el || !el.getBoundingClientRect) return null;
  const rect = el.getBoundingClientRect();
  let left = rect.left;
  let top = rect.top;
  let win = el.ownerDocument?.defaultView;
  const topWin = getTopWindow();

  while (win && win !== topWin) {
    let frame = null;
    try {
      frame = win.frameElement;
    } catch {
      break;
    }
    if (!frame || !frame.getBoundingClientRect) break;
    const frameRect = frame.getBoundingClientRect();
    left += frameRect.left;
    top += frameRect.top;
    try {
      win = win.parent;
    } catch {
      break;
    }
  }

  return {
    left,
    top,
    width: rect.width,
    height: rect.height,
  };
}

function intersectWithViewport(rect, vw, vh) {
  if (!rect) {
    return { left: 0, top: 0, width: 0, height: 0 };
  }
  const left = Math.max(0, rect.left);
  const top = Math.max(0, rect.top);
  const right = Math.min(vw, rect.left + rect.width);
  const bottom = Math.min(vh, rect.top + rect.height);
  return {
    left,
    top,
    width: Math.max(0, right - left),
    height: Math.max(0, bottom - top),
  };
}

function elementClassText(el) {
  if (!el) return "";
  if (typeof el.className === "string") return el.className;
  return el.getAttribute?.("class") || "";
}

function isResumeLikeElement(el) {
  if (!el || el.nodeType !== 1) return false;
  if (RESUME_CLASS_RE.test(elementClassText(el))) return true;
  try {
    return !!el.matches?.(RESUME_ROOT_SELECTORS.join(","));
  } catch {
    return false;
  }
}

function classBonus(el, source) {
  const text = `${source || ""} ${elementClassText(el)}`.toLowerCase();
  if (text.includes("resume-detail-main")) return 16000;
  if (text.includes("resume-detail-wrap")) return 15000;
  if (text.includes("resume-content")) return 14000;
  if (text.includes("resume-page")) return 13000;
  if (text.includes("geek-detail")) return 12000;
  if (RESUME_CLASS_RE.test(text)) return 10000;
  return 0;
}

/**
 * 选出真正的「简历面板」作为裁剪目标，避开整页 / 好友列表。
 * @param {Element|null} scrollContainer
 * @param {Document|Document[]} rootDocs
 */
function resolveResumeCropTarget(scrollContainer, rootDocs) {
  const topWin = getTopWindow();
  const vw = topWin.innerWidth || 1920;
  const vh = topWin.innerHeight || 1080;
  const candidates = [];

  const consider = (el, source) => {
    if (!el || !isElementVisible(el) || isExcludedCropTarget(el)) return;
    const mapped = mapElementRectToTopViewport(el);
    const visible = intersectWithViewport(mapped, vw, vh);
    if (visible.width < 200 || visible.height < 160) return;

    const widthRatio = visible.width / vw;
    const heightRatio = visible.height / vh;
    let score = classBonus(el, source);
    score += Math.min(visible.width, 720) + Math.min(visible.height, 1400);

    // 典型简历栏：偏左/居中、宽度不是整屏
    if (widthRatio <= 0.8) score += 20000;
    if (widthRatio >= 0.18 && widthRatio <= 0.7) score += 8000;
    if (visible.left < vw * 0.7) score += 2500;
    if (widthRatio > 0.88 && heightRatio > 0.85) score -= 60000;
    if (widthRatio > 0.92) score -= 40000;

    candidates.push({
      el,
      source,
      visible,
      vw,
      vh,
      score,
      widthRatio,
    });
  };

  if (scrollContainer) {
    consider(scrollContainer, "scroll-container");
    let parent = scrollContainer.parentElement;
    let depth = 0;
    while (parent && depth < 14) {
      if (isResumeLikeElement(parent)) {
        const cls = elementClassText(parent).slice(0, 80);
        consider(parent, `ancestor:${cls || parent.tagName}`);
      }
      parent = parent.parentElement;
      depth += 1;
    }
  }

  for (const doc of collectDocuments(rootDocs)) {
    for (const { el, source } of collectResumeRoots(doc)) {
      consider(el, `root:${source}`);
    }
  }

  if (!candidates.length) return null;

  const compact = candidates.filter((item) => item.widthRatio <= 0.88);
  const pool = compact.length ? compact : candidates;
  pool.sort((a, b) => b.score - a.score);
  const best = pool[0];
  return {
    el: best.el,
    source: best.source,
    vw: best.vw,
    vh: best.vh,
  };
}

function getVisibleCropRect(el) {
  const topWin = getTopWindow();
  const vw = topWin.innerWidth || 1920;
  const vh = topWin.innerHeight || 1080;
  const mapped = mapElementRectToTopViewport(el);
  return {
    rect: intersectWithViewport(mapped, vw, vh),
    vw,
    vh,
  };
}

function loadImageFromDataUrl(dataUrl) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("截图加载失败"));
    img.src = dataUrl;
  });
}

/**
 * 按 CSS 视口矩形从整页截图中裁出简历区域
 * @param {string} dataUrl
 * @param {{ left: number, top: number, width: number, height: number }} cssRect
 * @param {{ width: number, height: number }} viewport
 */
async function cropTabScreenshotToRect(dataUrl, cssRect, viewport) {
  const img = await loadImageFromDataUrl(dataUrl);
  const vw = viewport?.width || 0;
  const vh = viewport?.height || 0;
  if (!vw || !vh || !img.naturalWidth || !img.naturalHeight) {
    throw new Error("截图或视口尺寸无效，无法裁剪");
  }
  if (!cssRect || cssRect.width < 80 || cssRect.height < 80) {
    throw new Error("简历裁剪区域过小");
  }

  const scaleX = img.naturalWidth / vw;
  const scaleY = img.naturalHeight / vh;
  let sx = Math.round(cssRect.left * scaleX);
  let sy = Math.round(cssRect.top * scaleY);
  let sw = Math.round(cssRect.width * scaleX);
  let sh = Math.round(cssRect.height * scaleY);

  sx = Math.max(0, Math.min(sx, img.naturalWidth - 1));
  sy = Math.max(0, Math.min(sy, img.naturalHeight - 1));
  sw = Math.max(1, Math.min(sw, img.naturalWidth - sx));
  sh = Math.max(1, Math.min(sh, img.naturalHeight - sy));

  const canvas = document.createElement("canvas");
  canvas.width = sw;
  canvas.height = sh;
  const ctx = canvas.getContext("2d");
  if (!ctx) {
    throw new Error("无法创建画布上下文");
  }
  ctx.drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
  return canvas.toDataURL("image/png");
}

async function probeScrollMetrics(scrollContainer) {
  const originalScrollTop = scrollContainer.scrollTop;
  let totalHeight = scrollContainer.scrollHeight;
  let viewportHeight = scrollContainer.clientHeight;

  scrollContainer.scrollTop = Math.max(0, totalHeight - viewportHeight);
  await sleep(500);
  totalHeight = Math.max(totalHeight, scrollContainer.scrollHeight);
  viewportHeight = scrollContainer.clientHeight;

  scrollContainer.scrollTop = originalScrollTop;
  await sleep(200);

  return { totalHeight, viewportHeight, originalScrollTop };
}

function buildImageSignature(dataUrl) {
  if (!dataUrl) return "";
  const len = dataUrl.length;
  if (len <= 240) return dataUrl;
  const quarter = Math.floor(len / 4);
  return `${len}:${dataUrl.slice(quarter, quarter + 80)}:${dataUrl.slice(-80)}`;
}

async function captureVisibleTab() {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ action: "captureVisibleTab" }, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (response && response.success) {
        resolve(response.imageData);
        return;
      }
      reject(new Error(response?.error || "截图失败"));
    });
  });
}

async function captureFullPageScreenshot() {
  console.log(`${LOG_PREFIX} 使用扩展 API 截取整个页面...`);
  try {
    const dataUrl = await captureVisibleTab();
    if (!dataUrl) {
      throw new Error("未获取到截图数据");
    }
    console.log(`${LOG_PREFIX} 页面截图成功，数据长度:`, dataUrl.length);
    return dataUrl;
  } catch (e) {
    console.error(`${LOG_PREFIX} 页面截图失败:`, e);
    return null;
  }
}

/**
 * 截当前标签页，并裁成简历区域。找不到有效区域则返回 null（不回传整页）。
 * @param {{ el: Element, source?: string }|null} cropTarget
 */
async function captureResumeArea(cropTarget) {
  if (!cropTarget?.el) {
    console.warn(`${LOG_PREFIX} 无简历裁剪目标，跳过整页截图`);
    return null;
  }

  let dataUrl = null;
  try {
    dataUrl = await captureVisibleTab();
  } catch (e) {
    console.warn(`${LOG_PREFIX} 截图失败:`, e.message);
    return null;
  }
  if (!dataUrl) return null;

  const { rect, vw, vh } = getVisibleCropRect(cropTarget.el);
  if (rect.width < 160 || rect.height < 120) {
    console.warn(
      `${LOG_PREFIX} 简历可见区域过小: ${Math.round(rect.width)}x${Math.round(rect.height)}`,
    );
    return null;
  }

  try {
    const cropped = await cropTabScreenshotToRect(dataUrl, rect, {
      width: vw,
      height: vh,
    });
    console.log(
      `${LOG_PREFIX} 已裁剪简历区域 ${Math.round(rect.width)}x${Math.round(rect.height)} @ (${Math.round(rect.left)},${Math.round(rect.top)})，来源=${cropTarget.source || "未知"}，数据长度=${cropped.length}`,
    );
    return cropped;
  } catch (e) {
    console.warn(`${LOG_PREFIX} 裁剪简历区域失败:`, e.message || e);
    return null;
  }
}

/**
 * @param {Document|Document[]} rootDocs
 * @param {{ onDiagnostic?: (info: object) => void, renderWaitMs?: number }} [options]
 * @returns {Promise<string[]>}
 */
async function captureFullResumeScreenshot(rootDocs, options = {}) {
  const debug = {
    branch: "unknown",
    containerSource: "",
    totalHeight: 0,
    viewportHeight: 0,
    imageCount: 0,
    cropSource: "",
    cropWidth: 0,
    cropHeight: 0,
  };

  const report = (patch = {}) => {
    Object.assign(debug, patch);
    if (typeof options.onDiagnostic === "function") {
      options.onDiagnostic({ ...debug });
    }
  };

  const rememberCrop = (cropTarget) => {
    if (!cropTarget?.el) return;
    const { rect } = getVisibleCropRect(cropTarget.el);
    report({
      cropSource: cropTarget.source || "",
      cropWidth: Math.round(rect.width),
      cropHeight: Math.round(rect.height),
    });
  };

  console.log(`${LOG_PREFIX} 准备截取简历区域...`);

  const resolved = resolveScrollContainer(rootDocs);
  const scrollContainer = resolved?.element || null;
  report({
    containerSource: resolved?.source || "none",
    containerScore: resolved?.score || 0,
  });

  const cropTarget = resolveResumeCropTarget(scrollContainer, rootDocs);
  rememberCrop(cropTarget);

  if (!scrollContainer) {
    if (cropTarget) {
      report({ branch: "crop-only-no-scroll" });
      const singleImg = await captureResumeArea(cropTarget);
      rememberCrop(cropTarget);
      report({ imageCount: singleImg ? 1 : 0 });
      return singleImg ? [singleImg] : [];
    }
    if (options.allowFullPageFallback === false) {
      console.warn(`${LOG_PREFIX} 未找到简历区域，取消整页截图以免截错人`);
      report({ branch: "no-container-abort" });
      report({ imageCount: 0 });
      return [];
    }
    console.warn(`${LOG_PREFIX} 未找到简历区域，尝试直接截取页面`);
    report({ branch: "full-page-fallback" });
    try {
      const screenshot = await captureFullPageScreenshot();
      if (screenshot) {
        report({ imageCount: 1 });
        return [screenshot];
      }
    } catch (e) {
      console.error(`${LOG_PREFIX} 截屏失败:`, e);
    }
    report({ imageCount: 0 });
    return [];
  }

  if (!cropTarget) {
    console.warn(`${LOG_PREFIX} 找到滚动容器但无法定位简历裁剪区域，取消截图`);
    report({ branch: "no-crop-target" });
    report({ imageCount: 0 });
    return [];
  }

  const metrics = await probeScrollMetrics(scrollContainer);
  const originalScrollTop = metrics.originalScrollTop;
  const totalHeight = metrics.totalHeight;
  const viewportHeight = metrics.viewportHeight;

  console.log(
    `${LOG_PREFIX} 简历总高度: ${totalHeight}, 视口高度: ${viewportHeight}, 来源: ${resolved.source}`,
  );
  report({ totalHeight, viewportHeight, branch: "scroll-container" });

  if (totalHeight <= viewportHeight + 10) {
    report({ branch: "single-viewport" });
    const singleImg = await captureResumeArea(cropTarget);
    rememberCrop(cropTarget);
    report({ imageCount: singleImg ? 1 : 0 });
    return singleImg ? [singleImg] : [];
  }

  try {
    const finalImages = [];
    let currentScroll = 0;
    const scrollStep = Math.max(120, Math.floor(viewportHeight * 0.8));
    let index = 0;
    let lastImageSignature = null;

    report({ branch: "multi-scroll" });

    while (currentScroll < totalHeight && finalImages.length < 5) {
      console.log(
        `${LOG_PREFIX} 正在截取第 ${index + 1} 屏，滚动位置: ${currentScroll}...`,
      );
      scrollContainer.scrollTop = currentScroll;
      await sleep(options.renderWaitMs || 800);

      const image = await captureResumeArea(cropTarget);
      rememberCrop(cropTarget);
      if (image) {
        const imageSignature = buildImageSignature(image);
        if (lastImageSignature && imageSignature === lastImageSignature) {
          console.log(`${LOG_PREFIX} 第 ${index + 1} 屏与上一张重复，跳过`);
        } else {
          finalImages.push(image);
          lastImageSignature = imageSignature;
          console.log(
            `${LOG_PREFIX} 第 ${index + 1} 屏截图成功，共 ${finalImages.length} 张`,
          );
        }
      }

      currentScroll += scrollStep;
      index += 1;

      if (scrollContainer.scrollTop + viewportHeight >= totalHeight - 10) {
        break;
      }
    }

    console.log(`${LOG_PREFIX} 共截取 ${finalImages.length} 张不重复的简历区域截图`);
    report({ imageCount: finalImages.length });
    return finalImages;
  } catch (e) {
    console.error(`${LOG_PREFIX} 滚动截图失败:`, e);
    report({ branch: "multi-scroll-error" });
    const fallback = await captureResumeArea(cropTarget);
    rememberCrop(cropTarget);
    report({ imageCount: fallback ? 1 : 0 });
    return fallback ? [fallback] : [];
  } finally {
    scrollContainer.scrollTop = originalScrollTop;
  }
}

export {
  captureFullResumeScreenshot,
  captureVisibleTab,
  captureFullPageScreenshot,
  resolveScrollContainer,
  resolveResumeCropTarget,
};

if (typeof window !== "undefined") {
  window.招聘速聊助手ResumeScreenshot = {
    captureFullResumeScreenshot,
    resolveScrollContainer,
    resolveResumeCropTarget,
  };
}
