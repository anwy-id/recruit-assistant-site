const DB_NAME = "招聘速聊助手_screenshot_db";
const DB_VERSION = 1;
const STORE_NAME = "batches";

function openScreenshotDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error || new Error("打开截图数据库失败"));
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, {
          keyPath: "id",
          autoIncrement: true,
        });
        store.createIndex("savedAt", "savedAt", { unique: false });
        store.createIndex("name", "name", { unique: false });
      }
    };
  });
}

/**
 * @param {{ name: string, source?: string, savedAt?: string, images: string[] }} batch
 */
async function saveScreenshotBatch(batch) {
  const db = await openScreenshotDb();
  const record = {
    name: batch.name || "未知",
    source: batch.source || "unknown",
    savedAt: batch.savedAt || new Date().toISOString(),
    images: Array.isArray(batch.images) ? batch.images : [],
    mergedImage: batch.mergedImage || null,
    exportedAt: null,
  };

  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    const request = store.add(record);
    request.onsuccess = () => resolve({ id: request.result, ...record });
    request.onerror = () => reject(request.error || new Error("保存截图批次失败"));
  });
}

async function listAllScreenshotBatches() {
  const db = await openScreenshotDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const store = tx.objectStore(STORE_NAME);
    const request = store.getAll();
    request.onsuccess = () => resolve(request.result || []);
    request.onerror = () => reject(request.error || new Error("读取截图批次失败"));
  });
}

async function markScreenshotBatchExported(id) {
  const db = await openScreenshotDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    const getReq = store.get(id);
    getReq.onsuccess = () => {
      const record = getReq.result;
      if (!record) {
        resolve(false);
        return;
      }
      record.exportedAt = new Date().toISOString();
      const putReq = store.put(record);
      putReq.onsuccess = () => resolve(true);
      putReq.onerror = () => reject(putReq.error || new Error("更新导出状态失败"));
    };
    getReq.onerror = () => reject(getReq.error || new Error("读取截图批次失败"));
  });
}

async function countScreenshotImages(batches) {
  const list = batches || (await listAllScreenshotBatches());
  return list.reduce((sum, item) => sum + (item.images?.length || 0), 0);
}

async function updateScreenshotBatchMergedImage(id, mergedImage) {
  if (id == null || !mergedImage) return false;
  const db = await openScreenshotDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    const getReq = store.get(id);
    getReq.onsuccess = () => {
      const record = getReq.result;
      if (!record) {
        resolve(false);
        return;
      }
      record.mergedImage = mergedImage;
      const putReq = store.put(record);
      putReq.onsuccess = () => resolve(true);
      putReq.onerror = () =>
        reject(putReq.error || new Error("更新拼接截图失败"));
    };
    getReq.onerror = () =>
      reject(getReq.error || new Error("读取截图批次失败"));
  });
}

const 招聘速聊助手ScreenshotStore = {
  saveScreenshotBatch,
  listAllScreenshotBatches,
  markScreenshotBatchExported,
  countScreenshotImages,
  updateScreenshotBatchMergedImage,
};

export {
  saveScreenshotBatch,
  listAllScreenshotBatches,
  markScreenshotBatchExported,
  countScreenshotImages,
  updateScreenshotBatchMergedImage,
  招聘速聊助手ScreenshotStore,
};

if (typeof window !== "undefined") {
  window.招聘速聊助手ScreenshotStore = 招聘速聊助手ScreenshotStore;
}