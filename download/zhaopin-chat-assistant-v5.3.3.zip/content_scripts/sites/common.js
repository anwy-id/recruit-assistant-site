// 基础解析器类
class BaseParser {
    constructor() {
        this.settings = null;
        this.aiMode = true;
        // 添加高亮样式
        this.highlightStyles = {
            processing: `
                background-color: #fff3e0 !important;
                transition: background-color 0.3s ease;
                outline: 2px solid #ffa726 !important;
            `,
            matched: `
                background-color: #e8f5e9 !important;
                transition: background-color 0.3s ease;
                outline: 2px solid #4caf50 !important;
                box-shadow: 0 0 10px rgba(76, 175, 80, 0.3) !important;
            `
        };
    }

    async loadSettings() {
        return new Promise((resolve, reject) => {
            chrome.storage.local.get(['招聘速聊助手_settings'], (result) => {
                if (chrome.runtime.lastError) {
                    reject(chrome.runtime.lastError);
                    return;
                }
                this.settings = result.招聘速聊助手_settings || null;
                resolve(result);
            });
        });
    }

     /**
     * 在元素里查找元素。重复五次，每次间隔1秒
     * @param {*} candidate 要查找的元素
     * @param {*} selector 要查找的元素的选择器
     * @returns 
     */
    async CommonQuerySelector(candidate, selector) {
        for (let attempt = 0; attempt < 5; attempt++) {
            const element = candidate.querySelector(selector);
            if (element) {
                return element;
            }
            await new Promise(resolve => setTimeout(resolve, 1000)); // 等待1秒
        }
        return null; // 5次尝试后仍未找到
    }

    /**
     * 在元素里查找元素。重复五次，每次间隔1秒
     * @param {*} candidate 要查找的元素
     * @param {*} selector 要查找的元素的选择器
     * @returns 
     */
    async CommonQuerySelectorAll(candidate, selector) {
        for (let attempt = 0; attempt < 5; attempt++) {
            const elements = candidate.querySelectorAll(selector);
            if (elements.length > 0) {
                return elements;
            }
            await new Promise(resolve => setTimeout(resolve, 1000)); // 等待1秒
        }
        return []; // 5次尝试后仍未找到
    }

    /**
     * 在元素里查找类名5次 每次间隔1秒
     * @param {*} element 
     * @param {*} selector 
     * @returns 
     */
   async  CommonGetElementsByClassName(element, selector) {
       for (let attempt = 0; attempt < 5; attempt++) {
            const elements = element.getElementsByClassName(selector);
            if (elements.length > 0) {
                return elements;
            }
            await new Promise(resolve => setTimeout(resolve, 1000)); // 等待1秒
        }
        return []; // 5次尝试后仍未找到
    }

    // 添加提取额外信息的方法
    extractExtraInfo(element, extraSelectors) {
        const extraInfo = [];
        if (Array.isArray(extraSelectors)) {
            extraSelectors.forEach(selector => {
                const elements = this.getElementsByClassPrefix(element, selector.prefix);
                if (elements.length > 0) {
                    elements.forEach(el => {
                        const info = el.textContent?.trim();
                        if (info) {
                            extraInfo.push({
                                type: selector.type || 'unknown',
                                value: info
                            });
                        }
                    });
                }
            });
        }
        return extraInfo;
    }

    // 获取所有匹配前缀的元素
    getElementsByClassPrefix(parent, prefix) {
        const elements = [];
        // 使用前缀开头匹配
        const startsWith = Array.from(parent.querySelectorAll(`[class^="${prefix}"]`));
        // 使用包含匹配
        const contains = Array.from(parent.querySelectorAll(`[class*=" ${prefix}"]`));

        return [...new Set([...startsWith, ...contains])];
    }

    // 添加基础的点击方法
    clickMatchedItem(element) {
        console.warn('未实现点击方法');
        return false;
    }

    // 基础的点击候选人方法（需要被子类重写）
    async clickCandidateDetail(element) {
        throw new Error('clickCandidateDetail method must be implemented by child class');
    }

    // 基础的关闭详情方法（需要被子类重写）
    async closeDetail() {
        throw new Error('closeDetail method must be implemented by child class');
    }
}

export { BaseParser };