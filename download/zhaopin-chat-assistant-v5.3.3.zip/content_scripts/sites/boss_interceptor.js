// Boss直聘API拦截器 - 在document_start时注入
(function () {
    'use strict';

    const TARGET_PATTERNS = [
        '/wapi/zprelation/interaction/bossGetGeek',
        '/wapi/zpgeek/geek/detail',
        '/wapi/zpgeek/resume/detail',
        '/wapi/zpitem/web/geek/card',
        '/wapi/zpjob/rec/geek/list',
        '/wapi/zpitem/web/refinedGeek/list',
        '/wapi/zpitem/web/boss/search',
        'getBossFriendListV2',
        'getBossFriendList',
        'filterByLabel',
        'historyMsg',
        'bossHistoryMsg',
    ];

    function resolveMessageType(url) {
        if (!url) return 'geek-list';
        if (
            url.includes('bossGetGeek') ||
            url.includes('/geek/detail') ||
            url.includes('geek/info') ||
            url.includes('resume/detail') ||
            url.includes('geek/card')
        ) {
            return 'geek-detail';
        }
        if (
            url.includes('getBossFriendList') ||
            url.includes('filterByLabel')
        ) {
            return 'friend-list';
        }
        if (url.includes('historyMsg') || url.includes('bossHistoryMsg')) {
            return 'chat-history';
        }
        return 'geek-list';
    }


    // Hook fetch API
    const originalFetch = window.fetch;
    window.fetch = async function (...args) {
        const [input, init] = args;
        const url = typeof input === 'string' ? input : input && input.url;
        const res = await originalFetch.apply(this, args);

        try {

            let isTarget = false;
            if (url) {
                for (const pattern of TARGET_PATTERNS) {
                    if (url.includes(pattern)) {
                        isTarget = true;
                        break;
                    }
                }
            }

            if (isTarget) {
                const cloned = res.clone();
                const contentType = cloned.headers.get('content-type') || '';


                if (contentType.includes('application/json')) {
                    const data = await cloned.json();

                    const payload = {
                        source: 'boss-plugin',
                        type: resolveMessageType(url),
                        transport: 'fetch',
                        url: cloned.url,
                        ok: cloned.ok,
                        status: cloned.status,
                        data
                    };
                    window.postMessage(payload, '*');
                    try {
                        if (window.top && window.top !== window) {
                            window.top.postMessage(payload, '*');
                        }
                    } catch (_) {
                        /* ignore */
                    }
                } else {
                    const text = await cloned.text();
                }
            }
        } catch (e) {
            console.error('❌ 拦截fetch请求时出错:', e);
        }
        return res;
    };

    // Hook XHR API
    const OriginalXHR = window.XMLHttpRequest;

    function WrappedXHR() {
        const xhr = new OriginalXHR();
        let requestUrl = '';

        const open = xhr.open;
        xhr.open = function (method, url, ...rest) {
            requestUrl = url;
            return open.call(xhr, method, url, ...rest);
        };

        xhr.addEventListener('load', function () {
            try {
                let isTarget = false;
                if (requestUrl) {
                    for (const pattern of TARGET_PATTERNS) {
                        if (requestUrl.includes(pattern)) {
                            isTarget = true;
                            break;
                        }
                    }
                }

                if (isTarget) {
                    const contentType = xhr.getResponseHeader('content-type') || '';

                    if (contentType.includes('application/json')) {
                        let data;
                        try {
                            data = JSON.parse(xhr.responseText);
                        } catch (e) {
                            data = null;
                            console.error('❌ 解析JSON失败:', e);
                        }

                        const payload = {
                            source: 'boss-plugin',
                            type: resolveMessageType(requestUrl),
                            transport: 'xhr',
                            url: requestUrl,
                            status: xhr.status,
                            data
                        };
                        window.postMessage(payload, '*');
                        try {
                            if (window.top && window.top !== window) {
                                window.top.postMessage(payload, '*');
                            }
                        } catch (_) {
                            /* ignore */
                        }
                    } else {
                        const text = xhr.responseText;
                    }
                }
            } catch (e) {
                console.error('❌ 拦截XHR请求时出错:', e);
            }
        });

        return xhr;
    }
    window.XMLHttpRequest = WrappedXHR;

})();