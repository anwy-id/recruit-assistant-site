// Boss直聘拦截器注入器 - 在 document_start 时运行
(function injectBossInterceptor() {
  "use strict";

  const interceptorScript = document.createElement("script");
  interceptorScript.src = chrome.runtime.getURL(
    "content_scripts/sites/boss_interceptor.js",
  );
  interceptorScript.async = false;

  (document.head || document.documentElement).appendChild(interceptorScript);
  interceptorScript.onload = function () {
    interceptorScript.parentNode &&
      interceptorScript.parentNode.removeChild(interceptorScript);
  };

  interceptorScript.onerror = function () {
    console.error("Boss直聘 API 拦截器注入失败");
  };
})();