# 一键打招呼：补齐候选人性别 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 一键打招呼在问 AI 之前，尽量从「当前这张推荐牛人卡片」读到男/女；读不到时仍可打招呼，但不再轻易写成「未知」。

**Architecture:** 不改打招呼节奏，不提前点开详情。在现有「接口缓存优先 + 卡片文字兜底」上，增加「只扫这一张卡片上的男女图标」，并在接口命中但性别仍空时回头看卡片。沟通页求简历的性别逻辑不动。

**Tech Stack:** Chrome 扩展 Manifest V3，`content_scripts/sites/boss.js` 主改，`content_scripts/index.js` 仅作启动时一次缓存等待。无现成单测，以推荐牛人页手工验收为准。

**当前版本:** 5.1.2（本项为 bug 修复，实施时应改为 5.1.3）

---

## 背景（现状）

打招呼在推荐牛人页处理每张卡时，顺序是：抽人 → 拼简要信息（含性别）→ 发给 AI。性别在 AI 之前就定死。

现在只走两条路：

1. 拦截推荐列表接口，按姓名从缓存取 `geekGender` / `gender` / `sex`
2. 卡片左侧标签区纯文字里找「男」「女」

求简历已经会认 SVG 男女图标；打招呼不用这套。推荐卡上性别经常是姓名旁图标，不是文字，所以会「有时未知」。

AI 判匹配后才会点开详情。详情里即使能补性别，也来不及进这一次 AI。

---

## 明确不做

- 不先点开简历再问 AI（变慢、多点击、容易被风控）
- 不因为性别未知就跳过打招呼（仍发给 AI，只是性别写未知）
- 不改求简历 / 简历回传
- 不改弹窗界面、不新增设置项
- 不把整张卡片的自我介绍拿去扫「男」「女」（避免「男女装」这类误判）

---

## 方案对比

### 方案 A：只补当前卡片（推荐）

接口仍优先。若性别未知，只在**这一张卡**上：

1. 读 SVG 男女图标（`#icon-icon-men` / `#icon-icon-women` 等）
2. 读姓名行 + 标签行文字（放宽「男/女」识别）

**好处：** 不增加点击、几乎不拖慢、对准最常见漏抓原因。  
**代价：** 页面既没图标也没字、接口也没字段时，仍会未知。

### 方案 B：每个人都等接口

处理前等到列表接口里出现这个人的性别。

**好处：** 字段更权威。  
**代价：** 每人多等；接口经常本来就不带性别；缓存被后一次列表整份覆盖时仍会空。

### 方案 C：先点开详情再问 AI

**好处：** 信息最全。  
**代价：** 节奏大变，不采用。

### 采用

**以 A 为主，只吸收 B 的一点点：** 整轮打招呼开始时，若本地还没有任何列表缓存，最多等约 1.5 秒一次，不是每个人都等。

---

## 改完后的读取顺序（打招呼）

对每个候选人，问 AI 前按此顺序，找到就停：

1. 接口缓存里的性别字段（`geekGender` / `gender` / `geekSex` / `sex`，含 0/1/2 换算）
2. **当前这张卡片上的男女 SVG 图标**（新增，且只扫这一张卡）
3. 卡片姓名行 + 标签行文字里的「男」「女」（放宽规则）
4. 接口 `ageDesc`、卡片 extraInfo 里较像标签的短文本
5. 仍没有 → `未知`，照常问 AI

关键约束：

- 扫图标时必须传入**卡片根节点**，并关闭「偏向右侧聊天区」（现有函数默认偏向右侧，直接复用会扫错）
- 即使姓名已经在接口缓存里对上了，只要性别仍是未知，也要回头扫这张卡（现在对上缓存就不再看画面）
- 不扫自我介绍、职位描述长文

---

## 将改哪些文件

| 文件 | 职责 |
|------|------|
| `content_scripts/sites/boss.js` | 卡片图标/文字补性别；缓存命中仍补扫；姓名匹配；文字规则 |
| `content_scripts/index.js` | 打招呼启动时，缓存为空则短等一次 |
| `config.js` | 短等时长；`VERSION` |
| `package.json` | 版本 5.1.2 → 5.1.3 |
| `manifest.json` | 同上 |
| `dist/manifest.json` | 同上 |

不新增源文件。可复用已有：`parseGenderFromIconHref`、`extractGenderFromUseNode`、`extractGenderFromSvgIcons`、`normalizeGender`、`namesLikelyMatch`。

---

## Task 1: 只扫当前卡片的性别

**Files:**
- Modify: `content_scripts/sites/boss.js`（`extractGenderFromSvgIcons` 附近新增；改 `createNewCandidate` / `processCandidate` / `resolveCandidateGender` / `extractGenderFromText` / `findCandidateFromCache`）

- [ ] **Step 1: 新增「从推荐卡取性别」**

在 `BossParser` 上新增，只接受卡片根节点：

```javascript
extractGenderFromRecommendCard(cardEl) {
  if (!cardEl) return "";

  const fromIcon = this.extractGenderFromSvgIcons(cardEl, {
    preferRightPanel: false,
  });
  if (fromIcon) return fromIcon;

  const labelRoots = [];
  const nameEl = this.findElement(this.fullClasses.name, this.selectors.name)(cardEl);
  if (nameEl) labelRoots.push(nameEl.parentElement || nameEl);

  const ageEl = this.findElement(this.fullClasses.age, this.selectors.age)(cardEl);
  if (ageEl) labelRoots.push(ageEl);

  cardEl
    .querySelectorAll?.(
      '[class*="label"], [class*="base-info"], [class*="geek-info"], [class*="name"]',
    )
    ?.forEach((el) => labelRoots.push(el));

  const seen = new Set();
  for (const root of labelRoots) {
    if (!root || seen.has(root)) continue;
    seen.add(root);
    const text = String(root.textContent || "").replace(/\s+/g, " ").trim();
    if (!text || text.length > 80) continue;
    const fromText = this.extractGenderFromText(text);
    if (fromText) return fromText;
  }
  return "";
}
```

必须：`extractGenderFromSvgIcons(cardEl, { preferRightPanel: false })`。默认 `preferRightPanel === true` 会给屏幕右侧加分，推荐卡在左/中会被漏掉。

- [ ] **Step 2: 放宽标签文字，避免扫长文**

改 `extractGenderFromText`：

- 保留现有 `·` / 空格规则
- 增加：整段去掉空白后等于 `男`/`女`，或匹配 `/(?:^|[·\|/，,、\s])男(?:[·\|/，,、\s]|$)/`（女同理）
- 不在这里对整张卡的长描述做 `includes('男')`

- [ ] **Step 3: 接口对上了但没性别时，仍扫这张卡**

改 `processCandidate`：缓存命中也把当前 `item` 交给补齐。伪代码：

```javascript
async processCandidate(item, candidateName, cachedData) {
  const cachedCandidate = this.findCandidateFromCache(cachedData, candidateName);
  let candidate = cachedCandidate
    ? this.normalizeCandidateName(cachedCandidate, candidateName)
    : await this.createNewCandidate(item, candidateName);
  if (!candidate) return candidate;

  candidate = this.enrichCandidateGender(candidate);
  if (this.resolveCandidateGender(candidate) === "未知") {
    const fromCard = this.extractGenderFromRecommendCard(item);
    if (fromCard) candidate.gender = fromCard;
  }
  return this.enrichCandidateGender(candidate);
}
```

`createNewCandidate` 在读 `ageLabelText` 之后，若文字没有性别，立刻 `extractGenderFromRecommendCard(item)`。

- [ ] **Step 4: `resolveCandidateGender` 插入图标结果位**

顺序改为：已有 `candidate.gender` → 接口字段 → **`candidate` 上已写入的卡片图标结果** → `ageDesc` / `ageLabelText` / 短 extraInfo。  
不在 `resolveCandidateGender` 里对 `document` 全局扫图标。

- [ ] **Step 5: 姓名对缓存改用已有模糊匹配**

`findCandidateFromCache` 不要再用 `geekName.toLowerCase().includes(卡片名)`。改为对 `geekCard.geekName` / `candidate.name` 走 `namesLikelyMatch`（与沟通页同一套）。对不上再退回扫卡片，不要错用别人的性别。

---

## Task 2: 整轮只短等一次列表缓存

**Files:**
- Modify: `content_scripts/index.js`（`startAutoScroll` 在 `executeScroll` 之前）
- Modify: `config.js`（`TIMING` 或问候相关）

- [ ] **Step 1: 配置一次等待**

在 `config.js` 的 `TIMING` 增加：

```javascript
greetCacheWaitMs: 1500,
```

- [ ] **Step 2: 启动打招呼时缓存为空才等**

在 `startAutoScroll` 里、`executeScroll(loopToken)` 之前：

- 读 `currentParser.getCachedCandidateData(true)`
- 已有列表则不等
- 否则最多等 `greetCacheWaitMs`，期间每 200ms 再读一次
- 超时照常开始，走卡片图标/文字
- 每人处理前不再等接口

---

## Task 3: 版本号

**Files:**
- Modify: `package.json` `version`
- Modify: `manifest.json` `version`
- Modify: `dist/manifest.json` `version`
- Modify: `config.js` `VERSION`

- [ ] **Step 1:** 三处 manifest/package 与 `CONFIG.VERSION` 一并改为 `5.1.3`（修订号 +1，bug 修复）

---

## 怎么验收（实施后）

无自动化测试。请在 BOSS「推荐牛人」页开一键打招呼，抽查约 10 人：

1. 卡片上只有男女图标、标签里没有「男/女」字 → AI 入参应是男或女，不是未知  
2. 接口能对上姓名且带性别字段 → 与页面一致  
3. 图标和文字都没有 → 允许未知，但仍会进入 AI，不会因此跳过  
4. 打招呼速度、是否乱点详情、是否误伤求简历：应与现在一致  
5. 点「停止」仍能马上停

开发自查（控制台，不给 HR 看）：对 `extractGenderFromRecommendCard(卡片节点)` 抽 2～3 张卡，确认返回「男」或「女」。

---

## 风险

| 风险 | 处理 |
|------|------|
| 默认 `preferRightPanel` 扫到聊天区 | 必须传卡片根节点 + `preferRightPanel: false` |
| 卡片里其它图标（在线、VIP） | 现有解析已先认 women/men；无 men/women 的 use 不当性别 |
| 职位描述里的「男女」 | 只扫姓名行/标签短文本（≤80 字），不扫长描述 |
| 接口仍无性别且是图片不是 SVG | 本轮不覆盖；仍可能未知，属明确残留 |
| 等缓存 1.5 秒 | 仅整轮一次且仅缓存为空时 |

---

## 实施时不要做的「顺手改」

- 不要改 `processInterceptedData` 整份覆盖缓存（另起需求）
- 不要把求简历的 `extractGenderFromChatDocuments` 接到打招呼主循环
- 不要为未知性别弹窗打断
- 不要恢复本机简历落盘
