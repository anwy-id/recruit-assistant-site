/**
 * 宣双平台插件登录客户端（Service Worker 中运行）
 * POST {baseUrl}/plugin_auth/login/
 * GET  {baseUrl}/plugin_auth/me/
 * POST {baseUrl}/plugin_auth/logout/
 */

const PLUGIN_AUTH_DEFAULTS = {
  baseUrl: "https://upims.yili.com",
  loginPath: "/plugin_auth/login/",
  mePath: "/plugin_auth/me/",
  logoutPath: "/plugin_auth/logout/",
  positionsPath: "/plugin_auth/positions/",
  resumeCheckPath: "/plugin_auth/resumes/check/",
  resumeUploadPath: "/plugin_auth/resumes/upload/",
  timeoutMs: 30000,
  resumeUploadTimeoutMs: 120000,
};

const PLUGIN_AUTH_STORAGE_KEY = "招聘速聊助手_auth";
const PLUGIN_AUTH_BASEURL_KEY = "招聘速聊助手_auth_base_url";
/** 岗位配置仅存 session，关浏览器清空 */
const PLUGIN_POSITIONS_STORAGE_KEY = "招聘速聊助手_positions";

/**
 * @param {string} baseUrl
 * @param {string} path
 */
function pluginAuthJoinUrl(baseUrl, path) {
  const base = String(baseUrl || "").trim().replace(/\/+$/, "");
  const p = String(path || "").trim();
  if (!base) {
    throw new Error("未配置宣双平台地址");
  }
  const normalizedPath = p.startsWith("/") ? p : `/${p}`;
  return `${base}${normalizedPath}`;
}

/**
 * @returns {Promise<string>}
 */
async function getPluginAuthBaseUrl() {
  try {
    const stored = await chrome.storage.local.get([
      PLUGIN_AUTH_BASEURL_KEY,
      "招聘速聊助手_settings",
    ]);
    if (stored[PLUGIN_AUTH_BASEURL_KEY]) {
      return String(stored[PLUGIN_AUTH_BASEURL_KEY]).trim();
    }
    const settings = stored.招聘速聊助手_settings || {};
    if (settings.analyzeImageBaseUrl) {
      return String(settings.analyzeImageBaseUrl).trim();
    }
  } catch (_) {
    /* ignore */
  }
  const cfg =
    typeof CONFIG !== "undefined" && CONFIG.PLUGIN_AUTH
      ? CONFIG.PLUGIN_AUTH
      : PLUGIN_AUTH_DEFAULTS;
  return cfg.baseUrl || PLUGIN_AUTH_DEFAULTS.baseUrl;
}

/**
 * @param {string} baseUrl
 */
async function setPluginAuthBaseUrl(baseUrl) {
  const url = String(baseUrl || "").trim();
  if (!url) return;
  await chrome.storage.local.set({ [PLUGIN_AUTH_BASEURL_KEY]: url });
}

/**
 * @returns {Promise<{ token?: string, user?: object, loginAt?: string } | null>}
 */
async function getPluginAuthSession() {
  if (!chrome.storage.session) return null;
  try {
    const stored = await chrome.storage.session.get([PLUGIN_AUTH_STORAGE_KEY]);
    const data = stored[PLUGIN_AUTH_STORAGE_KEY];
    if (!data || !data.token) return null;
    return data;
  } catch (_) {
    return null;
  }
}

/**
 * @param {{ token: string, user: object, loginAt?: string }} session
 */
async function setPluginAuthSession(session) {
  if (!chrome.storage.session) {
    throw new Error("当前浏览器不支持 session 存储，无法保持登录态");
  }
  await chrome.storage.session.set({
    [PLUGIN_AUTH_STORAGE_KEY]: {
      token: session.token,
      user: session.user || {},
      loginAt: session.loginAt || new Date().toISOString(),
    },
  });
}

async function clearPluginAuthSession() {
  if (!chrome.storage.session) return;
  try {
    await chrome.storage.session.remove([PLUGIN_AUTH_STORAGE_KEY]);
  } catch (_) {
    /* ignore */
  }
}

/**
 * @param {object} options
 * @param {string} options.username
 * @param {string} options.password
 * @param {string} [options.baseUrl]
 * @param {number} [options.timeoutMs]
 */
async function pluginLogin(options = {}) {
  const username = String(options.username || "").trim();
  const password = String(options.password || "");
  if (!username || !password) {
    throw new Error("请输入用户名和密码");
  }

  const cfg =
    typeof CONFIG !== "undefined" && CONFIG.PLUGIN_AUTH
      ? CONFIG.PLUGIN_AUTH
      : PLUGIN_AUTH_DEFAULTS;
  const baseUrl = String(
    options.baseUrl || (await getPluginAuthBaseUrl()),
  ).trim();
  const timeoutMs = options.timeoutMs || cfg.timeoutMs || PLUGIN_AUTH_DEFAULTS.timeoutMs;
  const url = pluginAuthJoinUrl(
    baseUrl,
    cfg.loginPath || PLUGIN_AUTH_DEFAULTS.loginPath,
  );

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const resp = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({ username, password }),
      signal: controller.signal,
    });

    let body = null;
    try {
      body = await resp.json();
    } catch (_) {
      body = null;
    }

    if (!resp.ok) {
      const errMsg =
        (body && (body.error || body.message)) ||
        `登录失败（HTTP ${resp.status}）`;
      const error = new Error(errMsg);
      error.status = resp.status;
      error.response = body;
      throw error;
    }

    const token = body && body.token;
    if (!token) {
      throw new Error("登录响应缺少 token");
    }

    const user = (body && body.user) || { username };
    await setPluginAuthBaseUrl(baseUrl);
    await setPluginAuthSession({
      token,
      user,
      loginAt: new Date().toISOString(),
    });

    return {
      success: true,
      token,
      user,
      expires_in: body.expires_in,
      baseUrl,
    };
  } catch (err) {
    if (err && err.name === "AbortError") {
      throw new Error("登录请求超时，请检查网络或平台地址");
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * 校验当前 session token 是否仍有效
 * @param {object} [options]
 * @param {string} [options.baseUrl]
 * @param {boolean} [options.clearOnFail=true]
 */
async function pluginAuthCheck(options = {}) {
  const session = await getPluginAuthSession();
  if (!session || !session.token) {
    return { authenticated: false, reason: "no_session" };
  }

  const cfg =
    typeof CONFIG !== "undefined" && CONFIG.PLUGIN_AUTH
      ? CONFIG.PLUGIN_AUTH
      : PLUGIN_AUTH_DEFAULTS;
  const baseUrl = String(
    options.baseUrl || (await getPluginAuthBaseUrl()),
  ).trim();
  const timeoutMs = options.timeoutMs || cfg.timeoutMs || PLUGIN_AUTH_DEFAULTS.timeoutMs;
  const url = pluginAuthJoinUrl(baseUrl, cfg.mePath || PLUGIN_AUTH_DEFAULTS.mePath);

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const resp = await fetch(url, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${session.token}`,
        Accept: "application/json",
      },
      signal: controller.signal,
    });

    let body = null;
    try {
      body = await resp.json();
    } catch (_) {
      body = null;
    }

    if (!resp.ok) {
      if (options.clearOnFail !== false) {
        await clearPluginAuthSession();
      }
      return {
        authenticated: false,
        reason: "invalid_token",
        status: resp.status,
        error: (body && body.error) || `校验失败（HTTP ${resp.status}）`,
      };
    }

    const user = (body && body.user) || session.user || {};
    // 刷新本地用户信息
    await setPluginAuthSession({
      token: session.token,
      user,
      loginAt: session.loginAt,
    });

    return {
      authenticated: true,
      user,
      token: session.token,
      baseUrl,
      expires_at: body && body.expires_at,
    };
  } catch (err) {
    // 网络错误时：保留本地 session，避免误踢；但标记为未确认
    if (err && err.name === "AbortError") {
      return {
        authenticated: false,
        reason: "timeout",
        error: "校验登录超时，请检查网络",
        user: session.user,
        offline: true,
      };
    }
    return {
      authenticated: !!session.token,
      reason: "network_error",
      error: err.message || String(err),
      user: session.user,
      token: session.token,
      offline: true,
    };
  } finally {
    clearTimeout(timer);
  }
}

/**
 * @param {object} [options]
 * @param {string} [options.baseUrl]
 */
async function pluginLogout(options = {}) {
  const session = await getPluginAuthSession();
  const token = session && session.token;

  if (token) {
    const cfg =
      typeof CONFIG !== "undefined" && CONFIG.PLUGIN_AUTH
        ? CONFIG.PLUGIN_AUTH
        : PLUGIN_AUTH_DEFAULTS;
    const baseUrl = String(
      options.baseUrl || (await getPluginAuthBaseUrl()),
    ).trim();
    const url = pluginAuthJoinUrl(
      baseUrl,
      cfg.logoutPath || PLUGIN_AUTH_DEFAULTS.logoutPath,
    );
    try {
      await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: "application/json",
        },
      });
    } catch (_) {
      /* 服务端失败不影响本地清除 */
    }
  }

  await clearPluginAuthSession();
  await clearPluginPositionsSession();
  return { success: true };
}

/**
 * 仅检查本地 session 是否存在（不做网络请求）
 */
async function pluginAuthHasLocalSession() {
  const session = await getPluginAuthSession();
  return !!(session && session.token);
}

/**
 * 规范化岗位配置
 * @param {object} raw
 */
function normalizePositionsData(raw) {
  const positions = {};
  const src =
    raw && typeof raw.positions === "object" && raw.positions
      ? raw.positions
      : {};
  for (const [name, conf] of Object.entries(src)) {
    const n = String(name || "").trim();
    if (!n) continue;
    const c = conf && typeof conf === "object" ? conf : {};
    positions[n] = {
      keywords: Array.isArray(c.keywords)
        ? c.keywords.map((x) => String(x).trim()).filter(Boolean)
        : [],
      excludeKeywords: Array.isArray(c.excludeKeywords)
        ? c.excludeKeywords.map((x) => String(x).trim()).filter(Boolean)
        : Array.isArray(c.exclude_keywords)
          ? c.exclude_keywords.map((x) => String(x).trim()).filter(Boolean)
          : [],
    };
  }
  let activePosition = raw?.activePosition ?? raw?.active_position ?? null;
  if (activePosition != null) {
    activePosition = String(activePosition).trim() || null;
  }
  if (activePosition && !positions[activePosition]) {
    activePosition = Object.keys(positions)[0] || null;
  }
  if (!activePosition && Object.keys(positions).length) {
    activePosition = Object.keys(positions)[0];
  }
  return {
    positions,
    activePosition,
    updated_at: raw?.updated_at || null,
  };
}

/**
 * @returns {Promise<{ positions: object, activePosition: string|null } | null>}
 */
async function getPluginPositionsSession() {
  if (!chrome.storage.session) return null;
  try {
    const stored = await chrome.storage.session.get([
      PLUGIN_POSITIONS_STORAGE_KEY,
    ]);
    const data = stored[PLUGIN_POSITIONS_STORAGE_KEY];
    if (!data || typeof data !== "object") return null;
    return normalizePositionsData(data);
  } catch (_) {
    return null;
  }
}

/**
 * @param {{ positions: object, activePosition?: string|null }} data
 */
async function setPluginPositionsSession(data) {
  if (!chrome.storage.session) return;
  const normalized = normalizePositionsData(data);
  await chrome.storage.session.set({
    [PLUGIN_POSITIONS_STORAGE_KEY]: {
      positions: normalized.positions,
      activePosition: normalized.activePosition,
      updated_at: data?.updated_at || null,
    },
  });
  return normalized;
}

async function clearPluginPositionsSession() {
  if (!chrome.storage.session) return;
  try {
    await chrome.storage.session.remove([PLUGIN_POSITIONS_STORAGE_KEY]);
  } catch (_) {
    /* ignore */
  }
}

/**
 * 从平台拉取岗位配置
 */
async function fetchPluginPositions(options = {}) {
  const session = await getPluginAuthSession();
  const token = options.token || session?.token;
  if (!token) {
    throw new Error("请先登录");
  }

  const cfg =
    typeof CONFIG !== "undefined" && CONFIG.PLUGIN_AUTH
      ? CONFIG.PLUGIN_AUTH
      : PLUGIN_AUTH_DEFAULTS;
  const baseUrl = String(
    options.baseUrl || (await getPluginAuthBaseUrl()),
  ).trim();
  const timeoutMs =
    options.timeoutMs || cfg.timeoutMs || PLUGIN_AUTH_DEFAULTS.timeoutMs;
  const url = pluginAuthJoinUrl(
    baseUrl,
    cfg.positionsPath || PLUGIN_AUTH_DEFAULTS.positionsPath,
  );

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const resp = await fetch(url, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
      signal: controller.signal,
    });
    let body = null;
    try {
      body = await resp.json();
    } catch (_) {
      body = null;
    }
    if (!resp.ok) {
      const err = new Error(
        (body && body.error) || `拉取岗位失败（HTTP ${resp.status}）`,
      );
      err.status = resp.status;
      throw err;
    }
    const normalized = normalizePositionsData(body || {});
    await setPluginPositionsSession(normalized);
    return { success: true, ...normalized };
  } catch (err) {
    if (err && err.name === "AbortError") {
      throw new Error("拉取岗位超时");
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * 去掉 data URL / 说明前缀，得到纯 Base64
 * @param {string} raw
 */
function normalizeFileBase64(raw) {
  let s = String(raw || "").trim();
  if (!s) return "";
  // data:application/pdf;base64,xxxx
  const dataIdx = s.indexOf("base64,");
  if (/^data:/i.test(s) && dataIdx >= 0) {
    s = s.slice(dataIdx + "base64,".length);
  }
  // 文档兼容：可能带说明前缀
  s = s.replace(/^\[PDF attachment removed[^\]]*\]\s*/i, "");
  return s.replace(/\s+/g, "");
}

/**
 * 组装五要素请求体（check / upload 共用）
 * @param {object} meta
 */
function buildResumeFiveKeysPayload(meta = {}) {
  return {
    candidate_name: String(
      meta.candidate_name ?? meta.name ?? meta.candidateName ?? "",
    ).trim(),
    job_name: String(meta.job_name ?? meta.jobName ?? meta.position ?? "").trim(),
    age: meta.age != null ? String(meta.age).trim() : "",
    education: String(meta.education ?? "").trim(),
    work_years: String(
      meta.work_years ?? meta.workYears ?? meta.work_year ?? "",
    ).trim(),
  };
}

/**
 * 简历查重：是否已在平台入库
 * POST /plugin_auth/resumes/check/
 * @param {object} options
 * @param {object} options.meta - 五要素
 * @param {string} [options.token]
 * @param {string} [options.baseUrl]
 * @param {number} [options.timeoutMs]
 * @returns {Promise<{ exists: boolean, resume_uuid?: string|null, message?: string, ok?: boolean }>}
 */
async function pluginResumeCheck(options = {}) {
  const session = await getPluginAuthSession();
  const token = options.token || session?.token;
  if (!token) {
    const err = new Error("请先登录后再查重简历");
    err.status = 401;
    err.authRequired = true;
    throw err;
  }

  const payload = buildResumeFiveKeysPayload(options.meta || options);
  const missing = [];
  if (!payload.candidate_name) missing.push("候选人姓名");
  if (!payload.job_name) missing.push("职位");
  if (!payload.age) missing.push("年龄");
  if (!payload.education) missing.push("学历");
  if (!payload.work_years) missing.push("工龄");
  if (missing.length) {
    const err = new Error(`查重缺少字段: ${missing.join("、")}`);
    err.status = 400;
    throw err;
  }

  const cfg =
    typeof CONFIG !== "undefined" && CONFIG.PLUGIN_AUTH
      ? CONFIG.PLUGIN_AUTH
      : PLUGIN_AUTH_DEFAULTS;
  const baseUrl = String(
    options.baseUrl || (await getPluginAuthBaseUrl()),
  ).trim();
  const timeoutMs =
    options.timeoutMs || cfg.timeoutMs || PLUGIN_AUTH_DEFAULTS.timeoutMs;
  const url = pluginAuthJoinUrl(
    baseUrl,
    cfg.resumeCheckPath || PLUGIN_AUTH_DEFAULTS.resumeCheckPath,
  );

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const resp = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
    let body = null;
    try {
      body = await resp.json();
    } catch (_) {
      body = null;
    }
    if (!resp.ok) {
      const err = new Error(
        (body && (body.error || body.message)) ||
          `简历查重失败（HTTP ${resp.status}）`,
      );
      err.status = resp.status;
      err.response = body;
      if (resp.status === 401) err.authRequired = true;
      throw err;
    }
    return {
      ok: true,
      exists: !!body?.exists,
      resume_uuid: body?.resume_uuid ?? null,
      message: body?.message || (body?.exists ? "已存在" : "不存在，可上传"),
      raw: body,
    };
  } catch (err) {
    if (err && err.name === "AbortError") {
      throw new Error("简历查重超时，请检查网络");
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * 简历上传：PDF Base64 入库
 * POST /plugin_auth/resumes/upload/
 * @param {object} options
 * @param {object} options.meta - 五要素 + 可选 dayee_post_id 等
 * @param {string} options.file_base64
 * @param {string} [options.token]
 * @param {string} [options.baseUrl]
 * @param {number} [options.timeoutMs]
 */
async function pluginResumeUpload(options = {}) {
  const session = await getPluginAuthSession();
  const token = options.token || session?.token;
  if (!token) {
    const err = new Error("请先登录后再上传简历");
    err.status = 401;
    err.authRequired = true;
    throw err;
  }

  const five = buildResumeFiveKeysPayload(options.meta || options);
  const fileBase64 = normalizeFileBase64(
    options.file_base64 || options.pdf_base64 || options.base64 || "",
  );
  if (!fileBase64) {
    throw new Error("缺少 file_base64");
  }

  const missing = [];
  if (!five.candidate_name) missing.push("候选人姓名");
  if (!five.job_name) missing.push("职位");
  if (!five.age) missing.push("年龄");
  if (!five.education) missing.push("学历");
  if (!five.work_years) missing.push("工龄");
  if (missing.length) {
    throw new Error(`上传缺少字段: ${missing.join("、")}`);
  }

  const meta = options.meta || options;
  const bodyPayload = {
    ...five,
    file_base64: fileBase64,
    source_platform: String(
      meta.source_platform || meta.sourcePlatform || "boss",
    ),
    dayee_post_id: String(
      meta.dayee_post_id || meta.dayeePostId || meta.post_id || "",
    ),
    dayee_post_code: String(
      meta.dayee_post_code || meta.dayeePostCode || meta.post_code || "",
    ),
    phone: String(meta.phone || ""),
    remark: String(meta.remark || ""),
    is_suitable: String(meta.is_suitable ?? meta.isSuitable ?? ""),
  };

  const cfg =
    typeof CONFIG !== "undefined" && CONFIG.PLUGIN_AUTH
      ? CONFIG.PLUGIN_AUTH
      : PLUGIN_AUTH_DEFAULTS;
  const baseUrl = String(
    options.baseUrl || (await getPluginAuthBaseUrl()),
  ).trim();
  const timeoutMs =
    options.timeoutMs ||
    cfg.resumeUploadTimeoutMs ||
    PLUGIN_AUTH_DEFAULTS.resumeUploadTimeoutMs ||
    120000;
  const url = pluginAuthJoinUrl(
    baseUrl,
    cfg.resumeUploadPath || PLUGIN_AUTH_DEFAULTS.resumeUploadPath,
  );

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const resp = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(bodyPayload),
      signal: controller.signal,
    });
    let body = null;
    try {
      body = await resp.json();
    } catch (_) {
      body = null;
    }
    if (!resp.ok) {
      const err = new Error(
        (body && (body.error || body.message)) ||
          `简历上传失败（HTTP ${resp.status}）`,
      );
      err.status = resp.status;
      err.response = body;
      if (resp.status === 401) err.authRequired = true;
      throw err;
    }
    return {
      ok: body?.ok !== false,
      created: !!body?.created,
      exists: !!body?.exists,
      resume_uuid: body?.resume_uuid ?? null,
      pdf_path: body?.pdf_path || "",
      message: body?.message || (body?.created ? "上传成功" : "已处理"),
      raw: body,
    };
  } catch (err) {
    if (err && err.name === "AbortError") {
      throw new Error("简历上传超时，请检查网络或文件大小");
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * 整包保存岗位配置到平台
 * @param {{ positions: object, activePosition?: string|null, baseUrl?: string }} options
 */
async function savePluginPositions(options = {}) {
  const session = await getPluginAuthSession();
  const token = options.token || session?.token;
  if (!token) {
    throw new Error("请先登录");
  }

  const payload = normalizePositionsData({
    positions: options.positions || {},
    activePosition: options.activePosition ?? null,
  });

  const cfg =
    typeof CONFIG !== "undefined" && CONFIG.PLUGIN_AUTH
      ? CONFIG.PLUGIN_AUTH
      : PLUGIN_AUTH_DEFAULTS;
  const baseUrl = String(
    options.baseUrl || (await getPluginAuthBaseUrl()),
  ).trim();
  const timeoutMs =
    options.timeoutMs || cfg.timeoutMs || PLUGIN_AUTH_DEFAULTS.timeoutMs;
  const url = pluginAuthJoinUrl(
    baseUrl,
    cfg.positionsPath || PLUGIN_AUTH_DEFAULTS.positionsPath,
  );

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const resp = await fetch(url, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        positions: payload.positions,
        activePosition: payload.activePosition,
      }),
      signal: controller.signal,
    });
    let body = null;
    try {
      body = await resp.json();
    } catch (_) {
      body = null;
    }
    if (!resp.ok) {
      const err = new Error(
        (body && body.error) || `保存岗位失败（HTTP ${resp.status}）`,
      );
      err.status = resp.status;
      throw err;
    }
    const normalized = normalizePositionsData(body || payload);
    await setPluginPositionsSession(normalized);
    return { success: true, ...normalized };
  } catch (err) {
    if (err && err.name === "AbortError") {
      throw new Error("保存岗位超时");
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}
