/**
 * 简历文件本地存储（IndexedDB）
 * 用于一键求简历：下载附件 → base64 → 本地存档（暂不上传）
 */

const DB_NAME = "招聘速聊助手_resume_file_db";
const DB_VERSION = 1;
const STORE_NAME = "files";
const META_STORAGE_KEY = "招聘速聊助手_resume_files_meta";
const META_MAX = 100;

function openResumeFileDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () =>
      reject(request.error || new Error("打开简历文件数据库失败"));
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, {
          keyPath: "id",
          autoIncrement: true,
        });
        store.createIndex("createdAt", "createdAt", { unique: false });
        store.createIndex("name", "name", { unique: false });
        store.createIndex("sessionKey", "sessionKey", { unique: false });
      }
    };
  });
}

/**
 * @param {object} record
 * @param {string} record.name
 * @param {string} [record.sessionKey]
 * @param {string} record.filename
 * @param {string} [record.mime]
 * @param {number} [record.size]
 * @param {string} record.base64 - 纯 base64，无 data: 前缀
 * @param {string} [record.source]
 * @param {string} [record.createdAt]
 * @param {string} [record.url]
 */
async function saveResumeFile(record) {
  if (!record || !record.base64) {
    throw new Error("缺少简历文件 base64 数据");
  }

  const db = await openResumeFileDb();
  const entry = {
    name: record.name || "未知",
    sessionKey: record.sessionKey || "",
    filename: record.filename || "resume.bin",
    mime: record.mime || "application/octet-stream",
    size: Number(record.size) || 0,
    base64: record.base64,
    source: record.source || "online_resume_download",
    createdAt: record.createdAt || new Date().toISOString(),
    url: record.url || "",
  };

  const saved = await new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    const request = store.add(entry);
    request.onsuccess = () => resolve({ id: request.result, ...entry });
    request.onerror = () =>
      reject(request.error || new Error("保存简历文件失败"));
  });

  await appendResumeFileMeta({
    id: saved.id,
    name: saved.name,
    sessionKey: saved.sessionKey,
    filename: saved.filename,
    mime: saved.mime,
    size: saved.size,
    source: saved.source,
    createdAt: saved.createdAt,
  });

  return {
    id: saved.id,
    name: saved.name,
    sessionKey: saved.sessionKey,
    filename: saved.filename,
    mime: saved.mime,
    size: saved.size,
    source: saved.source,
    createdAt: saved.createdAt,
  };
}

/**
 * @param {number|string} id
 */
async function getResumeFile(id) {
  const db = await openResumeFileDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const store = tx.objectStore(STORE_NAME);
    const request = store.get(typeof id === "string" ? Number(id) : id);
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () =>
      reject(request.error || new Error("读取简历文件失败"));
  });
}

/**
 * 仅 meta，不含 base64
 */
async function listResumeFileMetaFromDb() {
  const db = await openResumeFileDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const store = tx.objectStore(STORE_NAME);
    const request = store.getAll();
    request.onsuccess = () => {
      const rows = request.result || [];
      resolve(
        rows.map((r) => ({
          id: r.id,
          name: r.name,
          sessionKey: r.sessionKey,
          filename: r.filename,
          mime: r.mime,
          size: r.size,
          source: r.source,
          createdAt: r.createdAt,
        })),
      );
    };
    request.onerror = () =>
      reject(request.error || new Error("列出简历文件失败"));
  });
}

function appendResumeFileMeta(meta) {
  return new Promise((resolve) => {
    if (typeof chrome === "undefined" || !chrome.storage?.local) {
      resolve(false);
      return;
    }
    chrome.storage.local.get([META_STORAGE_KEY], (result) => {
      if (chrome.runtime.lastError) {
        resolve(false);
        return;
      }
      const list = Array.isArray(result[META_STORAGE_KEY])
        ? result[META_STORAGE_KEY]
        : [];
      list.push(meta);
      while (list.length > META_MAX) list.shift();
      chrome.storage.local.set({ [META_STORAGE_KEY]: list }, () => {
        resolve(!chrome.runtime.lastError);
      });
    });
  });
}

function listResumeFileMetaFromStorage() {
  return new Promise((resolve) => {
    if (typeof chrome === "undefined" || !chrome.storage?.local) {
      resolve([]);
      return;
    }
    chrome.storage.local.get([META_STORAGE_KEY], (result) => {
      if (chrome.runtime.lastError) {
        resolve([]);
        return;
      }
      resolve(
        Array.isArray(result[META_STORAGE_KEY]) ? result[META_STORAGE_KEY] : [],
      );
    });
  });
}

const ResumeFileStore = {
  DB_NAME,
  STORE_NAME,
  META_STORAGE_KEY,
  openResumeFileDb,
  saveResumeFile,
  getResumeFile,
  listResumeFileMetaFromDb,
  listResumeFileMetaFromStorage,
  appendResumeFileMeta,
};

if (typeof module !== "undefined" && module.exports) {
  module.exports = ResumeFileStore;
} else if (typeof self !== "undefined") {
  self.ResumeFileStore = ResumeFileStore;
}
