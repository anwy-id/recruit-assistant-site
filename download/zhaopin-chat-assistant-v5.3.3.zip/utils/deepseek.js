/**
 * DeepSeek Chat Completions API 客户端（在 Service Worker 中运行）
 */

const DEFAULT_CONFIG = {
  baseUrl: "https://api.deepseek.com/v1/chat/completions",
  defaultModel: "deepseek-chat",
  maxTokens: 512,
  temperature: 0.1,
};

/**
 * @param {object} options
 * @param {string} options.apiKey
 * @param {string} options.systemPrompt
 * @param {string} options.userContent
 * @param {string} [options.model]
 * @param {object} [options.config]
 */
async function chatCompletion({
  apiKey,
  systemPrompt,
  userContent,
  model,
  config = {},
}) {
  if (!apiKey || !apiKey.trim()) {
    throw new Error("未配置 DeepSeek API Key，请在插件设置中填写");
  }

  const merged = { ...DEFAULT_CONFIG, ...config };
  const response = await fetch(merged.baseUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey.trim()}`,
    },
    body: JSON.stringify({
      model: model || merged.defaultModel,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userContent },
      ],
      max_tokens: merged.maxTokens,
      temperature: merged.temperature,
    }),
  });

  let data = null;
  try {
    data = await response.json();
  } catch {
    // ignore parse error
  }

  if (!response.ok) {
    const msg =
      data?.error?.message ||
      data?.message ||
      `DeepSeek API 请求失败 (HTTP ${response.status})`;
    throw new Error(msg);
  }

  const content = data?.choices?.[0]?.message?.content;
  if (!content) {
    throw new Error("DeepSeek 返回内容为空");
  }

  return content.trim();
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { chatCompletion, DEFAULT_CONFIG };
} else if (typeof self !== "undefined") {
  self.DeepSeekClient = { chatCompletion, DEFAULT_CONFIG };
}