/**
 * 宣双平台 AI Agent 纯文本 Flow 客户端（Service Worker）
 * POST {baseUrl}/ai_agent/execute_text/
 *
 * 文档：upims_pro/ai_agent/API_EXECUTE_TEXT.md
 * 鉴权：本平台 AccessToken（与 analyze_image 同一套，非插件登录 Token）
 * 成功时原样返回上游 Flow JSON。
 */

const DEFAULT_CONFIG = {
  baseUrl: "https://upims.yili.com",
  path: "/ai_agent/execute_text/",
  token: "",
  timeoutMs: 180000,
};

function toText(value, fallback = "") {
  if (value == null) return fallback;
  if (typeof value === "string") {
    const trimmed = value.trim();
    return trimmed || fallback;
  }
  if (typeof value === "number" || typeof value === "boolean") {
    return String(value);
  }
  try {
    return JSON.stringify(value);
  } catch {
    return fallback;
  }
}

/**
 * 规范化三项入参（简历 / 包含关键词 / 排除关键词）
 * @param {object} input
 */
function normalizeFlowFields(input = {}) {
  const resume = toText(input.input_text_0, "");
  const includeKeywords = toText(input.input_text_1, "无");
  const excludeKeywords = toText(input.input_text_2, "无");

  return {
    input_text_0: resume,
    input_text_1: includeKeywords,
    input_text_2: excludeKeywords,
  };
}

function extractErrorMessage(data, httpStatus) {
  if (!data || typeof data !== "object") {
    return httpStatus
      ? `文本 AI 接口请求失败 (HTTP ${httpStatus})`
      : "文本 AI 接口请求失败";
  }
  const msg =
    data.msg ||
    data.message ||
    data.error?.message ||
    data.error ||
    data.data?.msg ||
    data.data?.message;
  if (typeof msg === "string" && msg.trim()) return msg.trim();
  if (msg != null) return String(msg);
  return httpStatus
    ? `文本 AI 接口请求失败 (HTTP ${httpStatus})`
    : "文本 AI 接口业务失败";
}

/**
 * 判断开放 API 业务层是否失败（HTTP 200 但 success=false / code=500）
 */
function isBusinessFailure(data) {
  if (!data || typeof data !== "object") return false;
  // 本平台 4xx/5xx 已在 HTTP 层处理；此处处理上游包在 200 里的业务失败
  if (data.success === false) return true;
  if (data.ok === false) return true;
  const code = data.code;
  if (code == null || code === "") return false;
  if (typeof code === "number" && code !== 0 && code !== 200) return true;
  if (typeof code === "string") {
    const n = Number(code);
    if (Number.isFinite(n) && n !== 0 && n !== 200) return true;
    if (/^(fail|error|500)$/i.test(code)) return true;
  }
  return false;
}

/**
 * @param {string} baseUrl
 * @param {string} path
 */
function joinUrl(baseUrl, path) {
  const base = String(baseUrl || "").trim().replace(/\/+$/, "");
  const p = String(path || DEFAULT_CONFIG.path).trim();
  if (!base) {
    throw new Error("未配置宣双平台 AI 文本接口地址");
  }
  // 已是完整 execute_text 路径
  if (/\/ai_agent\/execute_text\/?$/i.test(base)) {
    return base.endsWith("/") ? base : `${base}/`;
  }
  // 误传了 analyze_image 路径时纠正
  if (/\/ai_agent\/analyze_image\/?$/i.test(base)) {
    return base.replace(
      /\/ai_agent\/analyze_image\/?$/i,
      "/ai_agent/execute_text/",
    );
  }
  const normalizedPath = p.startsWith("/") ? p : `/${p}`;
  return `${base}${normalizedPath}`;
}

/**
 * 调用宣双平台 /ai_agent/execute_text/
 * @param {object} input
 * @param {string} input.input_text_0 简历信息
 * @param {string} input.input_text_1 包含关键词
 * @param {string} input.input_text_2 排除关键词
 * @param {object} [config]
 * @param {string} [config.baseUrl]
 * @param {string} [config.path]
 * @param {string} [config.token]
 * @param {number} [config.timeoutMs]
 */
async function executeFlow(input, config = {}) {
  const merged = { ...DEFAULT_CONFIG, ...config };
  const token = String(merged.token || merged.bearerToken || "").trim();
  if (!token) {
    throw new Error(
      "缺少 AI 访问 Token：请先登录插件，或配置 AccessToken",
    );
  }

  const baseUrl = String(merged.baseUrl || DEFAULT_CONFIG.baseUrl).trim();
  if (!baseUrl) {
    throw new Error("请先登录插件");
  }

  const fields = normalizeFlowFields(input);
  if (!toText(input.input_text_0) && !fields.input_text_0) {
    throw new Error("简历文本为空，无法调用 AI");
  }

  const url = joinUrl(baseUrl, merged.path || DEFAULT_CONFIG.path);
  const timeoutMs =
    Number(config.timeoutMs) > 0
      ? Number(config.timeoutMs)
      : Number(merged.timeoutMs) > 0
        ? Number(merged.timeoutMs)
        : DEFAULT_CONFIG.timeoutMs;

  // 文档推荐结构 A：与上游一致
  const body = {
    input: {
      input_text_0: fields.input_text_0,
      input_text_1: fields.input_text_1,
      input_text_2: fields.input_text_2,
    },
  };

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    console.log(
      "[ExecuteText] POST",
      url,
      `t0=${fields.input_text_0.length}`,
      `t1=${fields.input_text_1.length}`,
      `t2=${fields.input_text_2.length}`,
      `timeout=${timeoutMs}ms`,
    );

    const response = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json; charset=utf-8",
        Accept: "application/json",
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    });

    let data = null;
    try {
      data = await response.json();
    } catch {
      /* ignore */
    }

    if (!response.ok) {
      const err = new Error(extractErrorMessage(data, response.status));
      err.status = response.status;
      err.response = data;
      throw err;
    }

    if (isBusinessFailure(data)) {
      throw new Error(extractErrorMessage(data));
    }

    // 成功：原样返回上游 Flow JSON
    return data;
  } catch (error) {
    if (error?.name === "AbortError") {
      throw new Error(`文本 AI 接口请求超时（${timeoutMs}ms）`);
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    executeFlow,
    DEFAULT_CONFIG,
    normalizeFlowFields,
    isBusinessFailure,
    extractErrorMessage,
    joinUrl,
  };
} else if (typeof self !== "undefined") {
  self.YiliAgentClient = {
    executeFlow,
    DEFAULT_CONFIG,
    normalizeFlowFields,
    isBusinessFailure,
    extractErrorMessage,
    joinUrl,
  };
}
