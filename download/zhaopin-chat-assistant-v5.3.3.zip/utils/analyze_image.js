/**
 * 宣双平台 AI Agent 图片分析接口客户端（Service Worker 中运行）
 * POST {baseUrl}/ai_agent/analyze_image/
 * multipart: file + input_text_0
 */

const ANALYZE_IMAGE_DEFAULTS = {
  baseUrl: "https://upims.yili.com",
  path: "/ai_agent/analyze_image/",
  timeoutMs: 180000,
};

/**
 * @param {string} dataUrl
 * @returns {Blob}
 */
function dataUrlToBlob(dataUrl) {
  if (!dataUrl || typeof dataUrl !== "string") {
    throw new Error("无效的图片数据");
  }
  if (!dataUrl.startsWith("data:")) {
    throw new Error("图片数据不是 data URL 格式");
  }

  const comma = dataUrl.indexOf(",");
  if (comma < 0) {
    throw new Error("图片 data URL 格式错误");
  }

  const header = dataUrl.slice(0, comma);
  const data = dataUrl.slice(comma + 1);
  const isBase64 = /;base64/i.test(header);
  const mimeMatch = header.match(/^data:([^;]+)/i);
  const mime = mimeMatch ? mimeMatch[1] : "image/png";

  if (isBase64) {
    const binary = atob(data);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return new Blob([bytes], { type: mime });
  }

  return new Blob([decodeURIComponent(data)], { type: mime });
}

/**
 * @param {string} baseUrl
 * @param {string} path
 */
function joinUrl(baseUrl, path) {
  const base = String(baseUrl || "").trim().replace(/\/+$/, "");
  const p = String(path || ANALYZE_IMAGE_DEFAULTS.path).trim();
  if (!base) {
    throw new Error("未配置图片分析接口地址");
  }
  if (/\/ai_agent\/analyze_image\/?$/i.test(base)) {
    return base.endsWith("/") ? base : `${base}/`;
  }
  const normalizedPath = p.startsWith("/") ? p : `/${p}`;
  return `${base}${normalizedPath}`;
}

/**
 * @param {object} options
 * @param {string} options.baseUrl
 * @param {string} options.token
 * @param {string} [options.path]
 * @param {string} [options.dataUrl]
 * @param {Blob} [options.fileBlob]
 * @param {string} [options.filename]
 * @param {string} [options.inputText0]
 * @param {number} [options.timeoutMs]
 */
async function uploadAnalyzeImage(options = {}) {
  const token = String(options.token || "").trim();
  if (!token) {
    throw new Error("缺少 AI 访问 Token：请先登录插件，或配置 AccessToken");
  }

  const baseUrl =
    String(options.baseUrl || "").trim() || ANALYZE_IMAGE_DEFAULTS.baseUrl;
  const url = joinUrl(baseUrl, options.path || ANALYZE_IMAGE_DEFAULTS.path);
  const timeoutMs =
    Number(options.timeoutMs) > 0
      ? Number(options.timeoutMs)
      : ANALYZE_IMAGE_DEFAULTS.timeoutMs;

  const blob =
    options.fileBlob ||
    (options.dataUrl ? dataUrlToBlob(options.dataUrl) : null);
  if (!blob || !blob.size) {
    throw new Error("上传图片为空");
  }

  const filename =
    String(options.filename || "").trim() ||
    `resume_${Date.now()}.png`;
  const inputText0 =
    options.inputText0 != null ? String(options.inputText0) : "";

  const form = new FormData();
  form.append("file", blob, filename);
  form.append("input_text_0", inputText0);

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: form,
      signal: controller.signal,
    });

    let data = null;
    try {
      data = await response.json();
    } catch {
      /* ignore non-json */
    }

    if (!response.ok) {
      const errMsg =
        (data && (data.error || data.message || data.msg)) ||
        `图片分析接口请求失败 (HTTP ${response.status})`;
      const error = new Error(String(errMsg));
      error.status = response.status;
      error.response = data;
      throw error;
    }

    return {
      success: true,
      status: response.status,
      data,
      url,
      filename,
    };
  } catch (error) {
    if (error?.name === "AbortError") {
      throw new Error(`图片分析接口请求超时（${timeoutMs}ms）`);
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    dataUrlToBlob,
    joinUrl,
    uploadAnalyzeImage,
    ANALYZE_IMAGE_DEFAULTS,
  };
} else if (typeof self !== "undefined") {
  self.AnalyzeImageClient = {
    dataUrlToBlob,
    joinUrl,
    uploadAnalyzeImage,
    ANALYZE_IMAGE_DEFAULTS,
  };
}
